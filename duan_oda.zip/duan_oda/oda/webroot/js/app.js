function showMask()
{
    // タイマーを設定
    var time = 0;
    var timer = setInterval(function() {
        $("#time").text(++time);
    }, 1000);

	$('#mask').show();
}
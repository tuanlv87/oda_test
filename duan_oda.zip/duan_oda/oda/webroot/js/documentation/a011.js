$(document).ready(function() {
    $("#print_btn").on("click", function() {

        download($(this.form).serialize());
        return false;
    });
});


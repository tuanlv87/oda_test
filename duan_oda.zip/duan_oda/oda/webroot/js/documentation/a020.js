$(document).ready(function() {
    $("#print_btn").on("click", function() {
        var $type = $("input[name='type']:checked");
        if ($type.length == 0) {
            alert("出力する勤務日程表の条件を選択してください");
            return false;
        }

        if ($type.val() == "person" && $("#p_id").val() == "") {
            alert("個人の勤務日程表を出力する場合は社員番号を入力してください。");
            return false;
        }

        var _this = this;

        $.ajax({
            url: "/documentation/createCheckA020",
            type: "POST",
            data: $(this.form).serialize(),
            cache: false
        })
        .done(function( data, textStatus, jqXHR ) {
            try {
                var res = $.parseJSON(data);
            } catch (e) {
                alert("ファイル作成に失敗しました。");
                return;
            }

            var txt = '現在、ファイルを作成しています。作成時間の目安:' + res["result"] + '秒<br/>しばらくお待ちください。処理時間:<span id="time">0</span>秒';

            $("#message").html(txt);

            download($(_this.form).serialize(), 
                function(res){
                    location.href = "/documentation/downloadExcel/" + res["fileName"];
                });
        })
        .fail(function( jqXHR, textStatus, errorThrown ) {
            alert("ファイル作成に失敗しました。");
        })
        .always(function( jqXHR, textStatus ) {
            clearInterval(timer);
            $("#mask").hide();
            $("#time").text("0");
            requestFlag = false;
        });

        return false;
    });
});


$(document).ready(function() {
    $("#print_btn").on("click", function() {
        var $type = $("input[name='type']:checked");
        if ($type.length == 0) {
            alert("出力する勤務日程表の条件を選択してください");
            return false;
        }

        var _this = this;

        download($(_this.form).serialize(), 
            function(res){
                location.href = "/documentation/downloadExcel/" + res["fileName"];
            }
        );


        return false;
    });
});

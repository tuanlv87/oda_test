$(document).ready(function() {
    $(".number").on("blur", function() {
        numberZenToHan(this);

        var val = $(this).val();
        if (val !== ""){

            if (!$.isNumeric(val)) {
                alert("数値で入力してください");
                $(this).val("");
                $(this).focus();
            }

            if (!(Number(val) > 0 && Math.floor(Number(val)) === Number(val))) {
                alert("1以上の整数値で入力してください");
                $(this).val("");
                $(this).focus();
            }

        }
    });
});


/**
 * ダウンロード処理
 *
 * @param data 送信するフォームのデータ
 * @return なし
 */
var requestFlag = false;
function download(data, callback) {
    // 二重に要求させない
    if (requestFlag) return ;
    
    requestFlag = true;

    // タイマーを設定
    var time = 0;
    var timer = setInterval(function() {
        $("#time").text(++time);
    }, 1000);

    $("#mask").show();

    $.ajax({
        url: "/documentation/create",
        type: "post",
        data: data,
        cache: false
    })
    .done(function( data, textStatus, jqXHR ) {
        try {
            var res = $.parseJSON(data);
        } catch (e) {
            alert("ファイル作成に失敗しました。");
            return;
        }

        if (res["result"]) {
            if (typeof callback == "function") {
                callback(res);
            } else {
                location.href = "/documentation/downloadExcel/" + res["fileName"];
            }
        } else {
            alert(res["error"]);
        }
    })
    .fail(function( jqXHR, textStatus, errorThrown ) {
        if (jqXHR.status == "403") {
            alert("ログイン認証の有効期限が切れました。再度ログインを行い、帳票作成を行ってください。");
        } else {
            alert("ファイル作成に失敗しました。");
        }
    })
    .always(function( jqXHR, textStatus ) {
        clearInterval(timer);
        $("#mask").hide();
        $("#time").text("0");
        requestFlag = false;
    });
}

/**
 * フォームの入力値の数字全角⇒半角変換
 * 数字以外が入力された場合はブランクとする
 * エラー処理などは呼び出し元で行う
 * @param el 変換を行うフォームのエレメント
 * @return true:変換OK, false:変換NG
 */
function numberZenToHan(el) {
    var beforeVal = $(el).val();

    // 変換後の半角文字
    han = "0123456789.-+";
    // 変換対象となる全角文字
    zen = "０１２３４５６７８９．－＋";

    var afterVal = "";

    // 先頭から一文ずつ全角文字を半角に変換する
    for (var i = 0; i < beforeVal.length; i++)
    {
        c = beforeVal.charAt(i);
        n = zen.indexOf(c,0);
        if (n >= 0) c = han.charAt(n);
        afterVal += c;
    }

    // 数字以外が入力された場合はブランクにする
    if ($.isNumeric(afterVal) == false) {
        $(el).val("");
        return false;
    }

    $(el).val(afterVal);

    return true;
}

/**
 * 日付の妥当性チェック
 * @param val 日付チェックを
 * @return true:変換OK, false:変換NG
 */

function checkDate(val) {
    // 入力された年月日と、日付型に変換後の年月日が等しいかどうかで
    // 入力された日付データが正しいかどうか判定する。
    var date = new Date(val);
    
    vArray = val.split("/");

    if (isNaN(date)) {
        return false;
    } else if (date.getFullYear() == Number(vArray[0]) && date.getMonth() == Number(vArray[1]) - 1 && date.getDate() == Number(vArray[2])){
        return true
    }

    return false;
}

$(document).ready(function() {
    $("#next_btn").on("click", function() {
        // 入力チェック
        if ($("input[name='document']:checked").length == 0) {
            alert("印刷する資料を選択してください。");
            return false;
        }
    });
});

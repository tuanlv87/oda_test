<?php
/**
 * Smarty plugin
 *
 * @package Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty active modifier plugin
 *
 * Type:     modifier<br>
 * Name:     checked<br>
 * Purpose:  Input error message.<br>
 * Input:<br>
 *          - string: input date string
 *
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param string $val Value
 * @param string $target
 * @return string
 */
function smarty_modifier_term_time($task)
{
	$str = '';
	$st = $task->start_time;
	$et = $task->end_time;

	if ($task->duty_type == DAT_CODE_D)
	{
		$str = DAT_D_START_TIME.'-'.DAT_D_END_TIME;
	}
	else if ($task->duty_type == DAT_CODE_N)
	{
		$str = DAT_N_START_TIME.'-'.DAT_N_END_TIME;
	}
	else
	{
		if ($st != '') {
			if (substr($st, 0, 1) === '0') {
				$str .= substr($st, 1);
			} else {
				$str .= $st;
			}
			if ($st != $et) {
				if (substr($et, 0, 1) === '0') {
					$et = substr($et, 1);
				}
				$str .= '-'.$et;
			}
		}
	}
	return $str;
}
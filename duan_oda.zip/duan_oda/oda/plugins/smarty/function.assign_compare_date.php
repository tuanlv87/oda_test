<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsFunction
 */

/**
 *
 * @param type $params
 * @param type $template
 * @return type
 * @throws SmartyException
 */
function smarty_function_assign_compare_date($params, $template)
{
	$date1 = $params['date1'];
	$date2 = $params['date2'];

	if (empty($date1)) {
		$date1 = '';
	} else if (is_object($date1)) {
		$date1 = substr($date1, 0, 10);
	}

	if (empty($date2)) {
		$date2 = '';
	} else if (is_object($date2)) {
		$date2 = substr($date2, 0, 10);
	}

	if (str_replace('/', '-', $date1) != str_replace('/', '-', $date2)) {
		$template->assign($params['var'], ' '.$params['class_name']);
	} else {
		$template->assign($params['var'], '');
	}

	return;
}

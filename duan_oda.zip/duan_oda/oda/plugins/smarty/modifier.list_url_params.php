<?php
/**
 * Smarty plugin
 *
 * @package Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty active modifier plugin
 *
 * Type:     modifier<br>
 * Name:     checked<br>
 * Purpose:  Input error message.<br>
 * Input:<br>
 *          - string: input date string
 *
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param string $val Value
 * @param string $target
 * @return string
 */
function smarty_modifier_list_url_params($url, $idname, $data)
{
	$params = explode(',', $idname);
	if (isset($params[2])) {
		$url = sprintf($url, $data[$params[0]], $data[$params[1]], $data[$params[2]]);
	} else if (isset($params[1])) {
		$url = sprintf($url, $data[$params[0]], $data[$params[1]]);
	} else {
		$url = sprintf($url, $data[$params[0]]);
	}
	return $url;
}
<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsFunction
 */

/**
 *
 * @param type $params
 * @param type $template
 * @return type
 * @throws SmartyException
 */
function smarty_function_assign_config($params, $template)
{
	$template->assign($params['var'], Cake\Core\Configure::read($params['config']));
	return;
}

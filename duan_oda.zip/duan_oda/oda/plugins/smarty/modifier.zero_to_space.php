<?php
/**
 * Smarty plugin
 *
 * @package Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty active modifier plugin
 *
 * Type:     modifier<br>
 * Name:     checked<br>
 * Purpose:  Input error message.<br>
 * Input:<br>
 *          - string: input date string
 *
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param string $val Value
 * @param string $target
 * @return string
 */
function smarty_modifier_zero_to_space($val)
{
	if ($val == 0) {
		$val = '';
	}
	return $val;
}
<?php
/**
 * Smarty plugin
 *
 * @package Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty active modifier plugin
 *
 * Type:     modifier<br>
 * Name:     checked<br>
 * Purpose:  Input error message.<br>
 * Input:<br>
 *          - string: input date string
 *
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param string $val Value
 * @param string $target
 * @return string
 */
function smarty_modifier_csv_line($data, $errors)
{
	unset($data['p_year']);
	
	foreach ($errors as $error) {
		if (isset($data[$error['field']])) {
			if ($data[$error['field']] == '') $data[$error['field']] = '<空白>';
			$data[$error['field']] = '<span class="text-danger">' . htmlspecialchars((string)$data[$error['field']], ENT_QUOTES, SMARTY_RESOURCE_CHAR_SET) . '</span>';
		}
	}
	
	return implode(', ', $data);
}
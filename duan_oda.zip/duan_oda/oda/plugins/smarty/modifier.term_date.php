<?php
/**
 * Smarty plugin
 *
 * @package Smarty
 * @subpackage PluginsModifier
 */

/**
 * Smarty active modifier plugin
 *
 * Type:     modifier<br>
 * Name:     checked<br>
 * Purpose:  Input error message.<br>
 * Input:<br>
 *          - string: input date string
 *
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param string $val Value
 * @param string $target
 * @return string
 */
function smarty_modifier_term_date($task)
{
	$start_ts = $task->start_date->timestamp;
	$end_ts = isset($task->end_date->timestamp) ? $task->end_date->timestamp : $start_ts;

	$str = date('n/j', $start_ts);
	if ($start_ts != $end_ts) {
		$str .= '-'.date('n/j', $end_ts);
	}

	return $str;
}
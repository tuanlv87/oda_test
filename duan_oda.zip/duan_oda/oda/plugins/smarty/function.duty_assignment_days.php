<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsFunction
 */

/**
 *
 * @param type $params
 * @param type $template
 * @return type
 * @throws SmartyException
 */
function smarty_function_duty_assignment_days($params, $template)
{
	$d = $params['duty_assignment'];
	$v = $params['values'];
	$o = $params['originals'];
	$is_view = $params['mode'] === 'view' ? TRUE : FALSE;

	$year = (int) substr($d->da_year_month, 0, 4);
	$month = (int) substr($d->da_year_month, 4, 2);

	$month -= 1;
	if ($month == 0) {
		$month = 12;
		$year -= 1;
	}

	// 開始のタイムスタンプ
	$start_ts = mktime(0,0,0,$month,DAT_START_DAY,$year);
	//$ts = mktime(0,0,0,$month,DAT_START_DAY,$year);
	//$last_day = date('t', $ts);
	$day_names = Cake\Core\Configure::read('day_names');

	$html = '';

	$w = date('w', $start_ts);
	if ($w == 0) {
		$w = 8;
	}
	$w -= 1;
	$ts = $start_ts - ($w * 86400);
	$next_month = FALSE;

	//$html .= '<h4>'.date('Y', $ts).'年'.date('n', $ts).'月</h4>';
	$html .= '<table class="table-calendar';
	if ($is_view) {
		$html .= ' table-fluid';
	}
	$html .= '"><tbody>';

	$show_day = date('j', $ts);

	for ($i=0; $i<8; $i++)
	{
		$html .= '<tr>';
		for ($n=0; $n<7; $n++)
		{
			$col = '';
			$is_error = FALSE;
			$modify_class = '';
			$is_disabled = '';
			$day = date('j', $ts);
			$show_month = '';
			if ($day == 1) {
				$next_month = TRUE;
			}
			if ((! $next_month && $ts >= $start_ts) || ($next_month && $day < DAT_START_DAY))
			{
				$col = 'd_'.$day;
				if ($is_view && $o && $v[$col] != $o[$col]) {
					$modify_class = ' view-modify';
				}
				$is_error = (isset($errors[$col]) && count($errors[$col])>0);
			}
			else
			{
				$is_disabled = ' disabled';
			}
			$html .= '<td class="'.$modify_class;
			if ($is_error) {
				$html .= ' has-error';
			}
			$html .= '">';

			if ($day == $show_day) {
				$show_month = date('n', $ts).'/';
				$show_day = 1;
			} else if ($day == $show_day) {
				$show_month = date('n', $ts).'/';
				$show_day = 0;
			}

			$html .= '<label for="input-'.$col.'" class="control-label">'.$show_month.date('j', $ts).'日('.$day_names[date('w', $ts)].')</label>';
			if ($is_view) {
				$html .= '<div class="view-value">'.$v[$col].'</div>';
			} else {
				if ($col !== '') {
					$html .= '<input class="form-control duty-code-input" data-duty-date="'.date('Y-m-d', $ts).'" id="input-'.$col.'" name="'.$col.'" value="'.$v[$col].'" type="text"'.$is_disabled.'>';
				} else {
					$html .= '<input class="form-control" type="text"'.$is_disabled.'>';
				}
			}
			if ($is_error) {
				foreach ($errors[$col] as $message) {
					$html .= '<p class="text-danger">'.$message.'</p>';
				}
			}
			$html .= '</td>';
			$ts += 86400;
		}
		$html .= '</tr>';
		if ($next_month && $day >= DAT_START_DAY-1) {
			break;
		}
	}

	$html .= '</tbody></table>';

//	foreach ([DAT_START_DAY, 1] as $i)
//	{
//		if ($i == DAT_START_DAY) {
//			$end = $last_day;
//		} else {
//			$end = DAT_START_DAY - 1;
//		}
//
//		$html .= '<h3>'.date('Y', $ts).'年'.date('n', $ts).'月</h3>';
//		$html .= '<div class="form-group">';
//		$html .= '<div class="col-xs-1"></div>';
//		for ($n=0; $i<=$end; $i++,$n++) {
//			$col = 'd_'.date('j', $ts);
//
//			$modify_class = '';
//			if ($is_view && $o && $v[$col] != $o[$col]) {
//				$modify_class = ' view-modify';
//			}
//
//			$html .= '<div class="col-xs-2'.$modify_class.'">';
//			$html .= '<label for="input-'.$col.'" class="control-label">'.date('j', $ts).'日('.$day_names[date('w', $ts)].')</label>';
//			if ($is_view) {
//				$html .= '<div class="view-value">'.$v[$col].'</div>';
//			} else {
//				$html .= '<input class="form-control duty-code-input" id="input-'.$col.'" name="'.$col.'" value="'.$v[$col].'" autocomplete="off" type="text">';
//			}
//			$html .= '</div>';
//
//			if ($n >= 4) {
//				$html .= '</div>';
//				$html .= '<div class="form-group">';
//				$html .= '<div class="col-xs-1"></div>';
//				$n = -1;
//			}
//			$ts += 86400;
//		}
//		$html .= '</div>';
//	}

	return $html;
}

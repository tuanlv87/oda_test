<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsFunction
 */

/**
 *
 * @param type $params
 * @param type $template
 * @return type
 * @throws SmartyException
 */
function smarty_function_task_month_schedule($params, $template)
{
	$cals = $params['cals'];
	$task_month = $params['task_month'];
	$start_ts = $task_month->start_date->timestamp;
	$end_ts = isset($task_month->end_date->timestamp) ? $task_month->end_date->timestamp : $start_ts;

	$html = '';

	foreach ($cals as $c)
	{
		$ts = $c['ts'];
		$color = '';
		if ($ts >= $start_ts && $ts <= $end_ts) {
			if (empty($task_month->frame_color)) {
				$color = '#ddd';
			} else {
				$color = '#'.$task_month->frame_color;
			}
		}
		$html .= '<td style="background-color:'.$color.'"></td>';
	}

	return $html;
}

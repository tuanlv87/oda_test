<?php
/**
 * Smarty plugin
 *
 * @package    Smarty
 * @subpackage PluginsFunction
 */

/**
 *
 * @param type $params
 * @param type $template
 * @return type
 * @throws SmartyException
 */
function smarty_function_watch_fire_checkbox($params, $template)
{
	$name = $params['name'];
	$v = $params['values'];
	$o = $params['originals'];
	$is_view = $params['mode'] === 'view' ? TRUE : FALSE;
	$year = $params['year'];
	$month = $params['month'];

	$month -= 1;
	if ($month == 0) {
		$month = 12;
		$year -= 1;
	}

	if ($v === NULL) {
		$v = [];
	}
	if ($o === NULL) {
		$o = [];
	}

	// 開始のタイムスタンプ
	$start_ts = mktime(0,0,0,$month,DAT_START_DAY,$year);
	// 対象月の月末数
	$max_day = date('t', mktime(0,0,0,$month,1,$year));
	// 対象月の日数
	$total_day = ($max_day - (DAT_START_DAY - 1)) + (DAT_START_DAY - 1);

	$html = '';

	$ts = $start_ts;
	for ($i=0; $i<$total_day; $i++)
	{
		$val = date("j", $ts);
		$id  = $name.'-'.$val;

		if ($val == 1 || $val == 11) {
			$html .= '<br>';
		}
		if ($is_view)
		{
			$html .= '<span';
			if ((in_array($val, $v)===FALSE && in_array($val, $o))
					|| (in_array($val, $v) && in_array($val, $o)===FALSE)) {
				$html .= ' class="view-modify"';
			}
			$html .= '>';
			if (in_array($val, $v)) {
				$html .= '■';
			} else {
				$html .= '□';
			}
			$html .= $val;
			$html .= '&nbsp;';
			$html .= '</span>';
		}
		else
		{
			$html .= '<label class="checkbox-label" for="'.$id.'">';
			$html .= '<input type="checkbox" name="'.$name.'[]" value="'.$val.'" id="'.$id.'"';
			if (in_array($val, $v)) {
				$html .= ' checked';
			}
			$html .= '>';
			$html .= $val;
			$html .= '&nbsp;</label>';
		}

		$ts += 86400;
	}

	return $html;
}

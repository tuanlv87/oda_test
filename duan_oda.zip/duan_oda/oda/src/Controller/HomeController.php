<?php
/**
 *
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

/**
 *
 */
class HomeController extends AppController
{
	public function index()
	{
		$this->setTitle('ODA-R');

        $this->Session = $this->request->session();
        $this->Session->delete('document.Target_Date');
	}

    public function login()
    {
        if ($this->request->is('POST'))
        {
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                //return $this->redirect($this->Auth->redirectUrl());
				return $this->redirect('/');
            } else {
                $this->set('errors', ['u_id'=>[''], 'password' => ['IDまたはパスワードが間違っています。']]);
            }
        }
        $this->setTitle('ログイン');
    }

    public function logout()
    {
        $this->redirect($this->Auth->logout());
    }
}
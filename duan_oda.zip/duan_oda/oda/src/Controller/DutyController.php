<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Entity\DutyWork;
use App\Model\Table\DutyAssignmentsTable;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;


/**
 * Personnels Controller
 *
 * @property DutyAssignmentsTable $DutyAssignments
 */
class DutyController extends AppController
{
	public $helpers = [
		'Paginator'
	];

	public $components = [
		'Upload',
		'Csv',
		'Duty'
	];

	public function initialize()
	{
		parent::initialize();
		$this->loadModel('DutyAssignments');
	}

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function index()
	{
		$this->set('sideNavi', ['duty'=>'list']);
		$this->setTitle('日程表管理', '一覧');
	}

	public function table()
	{
		Configure::load('list_settings');

		$this->paginate = [
			'limit' => 50,
			'whitelist' => ['year', 'month'],
		];

		$year_options = [];
		for ($i=0; $i<5; $i++) {
			$year_options[SELECT_START_YEAR + $i] = SELECT_START_YEAR + $i;
		}
		$this->set('year_options', $year_options);
		$this->set('month_options', Configure::read('select_month_list'));

		$year = $this->request->query('year');
		$month = $this->request->query('month');

		if (empty($year) || empty($month)) {
			$year = date('Y');
			$month = date('n');
		}

		$this->set('year_selected', $year);
		$this->set('month_selected', $month);

//		$duty_assignment_list = $this->DutyAssignments->find()->join([
//			'table' => 'titles',
//			'alias' => 't',
//			'type' => 'LEFT',
//			'conditions' => [
//				'DutyAssignments.title_code = t.title_code'
//			]
//		])->order([
//			'DutyAssignments.da_year_month' => 'DESC',
//			'DutyAssignments.team_id' => 'ASC',
//			't.title_order IS NULL' => 'ASC',
//			't.title_order' => 'ASC',
//			'DutyAssignments.p_id' => 'ASC'
//		]);

//		$duty_assignment_list = $this->DutyAssignments->find()->join([
//			'table' => 'titles',
//			'alias' => 't',
//			'type' => 'LEFT',
//			'conditions' => [
//				'DutyAssignments.title_code = t.title_code'
//			]
//		])->order([
//			'DutyAssignments.da_year_month' => 'DESC',
//			'DutyAssignments.team_id=\'Y\'' => 'DESC',
//			'DutyAssignments.team_id' => 'ASC',
//			't.title_order IS NULL' => 'ASC',
//			't.title_order' => 'ASC',
//			'DutyAssignments.crew_id' => 'ASC',
//			'DutyAssignments.personnel_id' => 'ASC',
//			'DutyAssignments.p_id' => 'ASC'
//		]);

		$duty_assignment_list = $this->DutyAssignments->find()->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month)
		])->order([
			'document_order' => 'ASC'
		]);

		$this->set('primary_list', $this->paginate($duty_assignment_list));
		$this->set('list_settings', Configure::read('list_settings.duty'));
		$this->set('sideNavi', ['duty'=>'table']);
		$this->setTitle('日程表管理', '一覧');

		// デバッグ用
		$duty_assignment = $this->DutyAssignments->find()->select([
			'avg' => 'AVG(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->first();
		$this->set('all_work_hours_avg', number_format($duty_assignment->avg,2));

		$duty_assignment = $this->DutyAssignments->find()->select([
			'max' => 'MAX(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->first();
		$this->set('all_work_hours_max', number_format($duty_assignment->max,2));

		$duty_assignment = $this->DutyAssignments->find()->select([
			'min' => 'MIN(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->first();
		$this->set('all_work_hours_min', number_format($duty_assignment->min,2));

		$duty_assignment = $this->DutyAssignments->find()->select([
			'stddev' => 'STDDEV(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->first();
		$this->set('all_work_hours_stddev', number_format($duty_assignment->stddev,2));

		$debug_list = [];
		$duty_assignment_list = $this->DutyAssignments->find()->select([
			'team_id' => 'team_id',
			'sum' => 'SUM(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->group(['team_id'])->toArray();
		foreach ($duty_assignment_list as $d) {
			$debug_list[$d->team_id]['work_hours_sum'] = number_format($d->sum, 2);
		}
		$duty_assignment_list = $this->DutyAssignments->find()->select([
			'team_id' => 'team_id',
			'avg' => 'AVG(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->group(['team_id'])->toArray();
		foreach ($duty_assignment_list as $d) {
			$debug_list[$d->team_id]['work_hours_avg'] = number_format($d->avg, 2);
		}
		$duty_assignment_list = $this->DutyAssignments->find()->select([
			'team_id' => 'team_id',
			'max' => 'MAX(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->group(['team_id'])->toArray();
		foreach ($duty_assignment_list as $d) {
			$debug_list[$d->team_id]['work_hours_max'] = number_format($d->max, 2);
		}
		$duty_assignment_list = $this->DutyAssignments->find()->select([
			'team_id' => 'team_id',
			'min' => 'MIN(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->group(['team_id'])->toArray();
		foreach ($duty_assignment_list as $d) {
			$debug_list[$d->team_id]['work_hours_min'] = number_format($d->min, 2);
		}
		$duty_assignment_list = $this->DutyAssignments->find()->select([
			'team_id' => 'team_id',
			'stddev' => 'STDDEV(work_hours + 9.0 * (hd2_days + hd3_days + hd4_days))'
		])->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month),
			'title_code !=' => 'A2'
		])->group(['team_id'])->toArray();
		foreach ($duty_assignment_list as $d) {
			$debug_list[$d->team_id]['work_hours_stddev'] = number_format($d->stddev, 2);
		}
		$this->set('debug_list', $debug_list);
	}

	/**
	 * 休暇設定
	 */
	public function holiday()
	{
		$this->set('sideNavi', ['duty'=>'holiday']);
		$this->setTitle('日程表管理', '休暇設定');
	}

	public function update()
	{
		$this->set('sideNavi', ['duty'=>'update']);
		$this->setTitle('日程表管理', '編集更新');

		$this->set('year_month_list', $this->getYearMonthList());
	}

	public function update_change()
	{
		$this->set('sideNavi', ['duty'=>'update']);
		$this->setTitle('日程表管理', '編集更新');

		$this->set('year_month_list', $this->getYearMonthList());

		$errors = NULL;
		$add_p_id = '';
		$add_num = 0;
		$current_data = [];
		$change_data = [];
		$duty_assignment_data = [];

		if ($this->request->is('GET'))
		{
			// 入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('p_id', TRUE, '社員番号を入力してください。')
				->notEmpty('p_id', '社員番号を入力してください。')
				->add('p_id', [
					'numeric' => [
						'rule' => 'numeric',
						'message' => '社員番号は数値で入力してください。'
					],
					'custom' => [
						'rule' => [$this, 'validDutyAssignment'],
						'message' => 'この社員番号の社員が見つかりません。'
					]
				])
				->requirePresence('year_month', TRUE, '年月を選択してください。')
				->requirePresence('day', TRUE, '日付を入力してください。')
				->notEmpty('day', '日付を入力してください。')
				->add('day', [
					'numeric' => [
						'rule' => 'numeric',
						'message' => '日付は数値で入力してください。'
					],
					'custom' => [
						'rule' => [$this, 'validDay'],
						'message' => '正しい日付を入力してください。'
					]
				]);


			$errors = $validator->errors($this->request->query);

			if ($errors)
			{
				$this->set('errors', $errors);
				$this->render('update');
			}

			$p_id = $this->request->query('p_id');
			$year_month = $this->request->query('year_month');
			$day = $this->request->query('day');
			$add_p_id = $p_id;

			$current_data[$p_id] = '';
			$change_data[$p_id] = '';
		}
		else
		{
			if (isset($this->request->data['btn_action'])
					&& $this->request->data['btn_action'] === 'add_p_id')
			{
				// 交代要員社員番号の入力チェック
				$validator = new Validator();
				$validator
					->requirePresence('add_p_id', TRUE, '社員番号を入力してください。')
					->notEmpty('add_p_id', '交代要員社員番号を入力してください。')
					->add('add_p_id', [
						'numeric' => [
							'rule' => 'numeric',
							'message' => '交代要員社員番号は数値で入力してください。'
						],
						'custom' => [
							'rule' => [$this, 'validDutyAssignment'],
							'message' => 'この交代要員社員番号の社員が見つかりません。'
						],
						'custom2' => [
							'rule' => function($value, $content) {
								if (empty($value)) return TRUE;
								if (isset($content['data']['current_data'][$value])) {
									return FALSE;
								}
								return TRUE;
							},
							'message' => 'この交代要員社員番号は既に入力済みです。'
						]
					]);


				$errors = $validator->errors($this->request->data);
			}

			$p_id = $this->request->data['p_id'];
			$year_month = $this->request->data['year_month'];
			$day = $this->request->data['day'];
			$add_num = $this->request->data['add_num'];

			$current_data = $this->request->data['current_data'];
			$change_data = $this->request->data['change_data'];

			if ($errors)
			{
				$this->set('errors', $errors);
			}
			else if ($add_num < 2)
			{
				$add_p_id = $this->request->data['add_p_id'];
				if ($add_p_id > 0 && isset($current_data[$add_p_id]) === FALSE)
				{
					$current_data[$add_p_id] = '';
					$change_data[$add_p_id] = '';
					$add_num++;
					unset($_REQUEST['add_p_id']);
				}
			}
		}

		$col = 'd_'.$day;

		foreach ($current_data as $temp_p_id => $temp)
		{
			$duty_assignment_data[$temp_p_id] = $this->getDutyAssignment($temp_p_id, $year_month);

			if ($duty_assignment_data[$temp_p_id] !== NULL && $add_p_id !== '' && $add_p_id == $temp_p_id)
			{
				$current_data[$temp_p_id] = $duty_assignment_data[$temp_p_id]->{$col};
				$change_data[$temp_p_id] = '';
				$add_p_id = '';
			}
		}

		$this->set('p_id', $p_id);
		$this->set('year_month', $year_month);
		$this->set('day', $day);
		$this->set('current_data', $current_data);
		$this->set('change_data', $change_data);
		$this->set('duty_assignment_data', $duty_assignment_data);
		$this->set('add_num', $add_num);
		//$this->set('add_p_id', $add_p_id);
	}

	public function update_confirm()
	{
		$this->set('sideNavi', ['duty'=>'update']);
		$this->setTitle('日程表管理', '編集更新（確認）');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'update']);
		}

		$p_id = $this->request->data['p_id'];
		$year_month = $this->request->data['year_month'];
		$day = $this->request->data['day'];
		$add_num = $this->request->data['add_num'];
		$current_data = $this->request->data['current_data'];
		$change_data = $this->request->data['change_data'];
		$col = 'd_'.$day;
		$errors = NULL;

		// 整合性チェック
		$before_checks = $this->countDutyType($current_data);
		$after_checks = $this->countDutyType($change_data);
		if (count($before_checks) > 0)
		{
			foreach ($before_checks as $type => $total) {
				if (isset($after_checks[$type]) === FALSE
						|| $after_checks[$type] != $total)
				{
					//$errors = ['check' => ['勤務種別の変更内容が不正です。確認してください。'.$type.'/'.$after_checks[$type].'/'.$total]];
					//$errors = ['check' => ['勤務種別の変更内容が不正です。確認してください。']];
					$errors = ['check' => [$type.'勤務が正しく配置されていません。確認してください。']];
					break;
				}
			}
		}


		foreach ($current_data as $temp_p_id => $temp)
		{
			$duty_assignment_data[$temp_p_id] = $this->getDutyAssignment($temp_p_id, $year_month);
		}

		$this->set('p_id', $p_id);
		$this->set('year_month', $year_month);
		$this->set('day', $day);
		$this->set('current_data', $current_data);
		$this->set('change_data', $change_data);
		$this->set('duty_assignment_data', $duty_assignment_data);
		$this->set('add_num', $add_num);

		$this->set('values', $this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->render('update_change');
		}
	}

	private function countDutyType(array &$data)
	{
		$checks = [];
		foreach ($data as $temp_p_id => $duty_type)
		{
			$duty_type = mb_convert_kana($duty_type, 'a');
			// 予防処置
			$duty_type = str_replace('DN', 'D,N', $duty_type);
			$duty_type_arr = explode(',', $duty_type);
			foreach ($duty_type_arr as $type) {
				$type = trim($type);
				if ($type != '') {
					// 休日系はチェックから外す
					if (preg_match("/^HD[0-9]+/", $type)) {
						continue;
					}
					if (isset($checks[$type]) === FALSE) {
						$checks[$type] = 0;
					}
					$checks[$type]++;
				}
			}
		}
		return $checks;
	}

	public function update_comp()
	{
		$this->set('sideNavi', ['duty'=>'update']);
		$this->setTitle('日程表管理', '編集更新（完了）');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'update']);
		}

		$current_data = $this->request->data('current_data');
		$change_data = $this->request->data('change_data');
		$base_p_id = $this->request->data('p_id');
		$year_month = $this->request->data('year_month');
		$year = (int)substr($year_month,0,4);
		$month = (int)substr($year_month,4,2);
		$day = $this->request->data('day');
		// 調整
		if ($day >= DAT_START_DAY && $day <= 31) {
			$month -= 1;
			if ($month == 0) {
				$month = 12;
				$year -= 1;
			}
		}
		$col = 'd_'.$day;
		$data = [
			'dl_year_month' => $year_month,
			'date' => sprintf("%04d-%02d-%02d", $year, $month, $day),
			'change_date' => date("Y-m-d")
		];
		$duty_work_list = [];
		$update_p_ids = [];
		$is_err = FALSE;

		$this->DutyAssignments->connection()->begin();

		foreach ($current_data as $p_id => $current_duty)
		{
			$change_data[$p_id] = mb_convert_kana($change_data[$p_id], 'a');
			// 予防処置
			$change_data[$p_id] = str_replace('DN', 'D,N', $change_data[$p_id]);

			$duty_assignment = $this->getDutyAssignment($p_id, $year_month);
			$duty_assignment = $this->DutyAssignments->patchEntity($duty_assignment, [
				$col => $change_data[$p_id]
			]);
			if ($this->DutyAssignments->save($duty_assignment) === FALSE) {
				$this->DutyAssignments->connection()->rollback();
				$this->set('errors', $duty_assignment->errors());
				Log::error($duty_assignment->errors());
				$is_err = TRUE;
				break;
			}

			if ($base_p_id == $p_id)
			{
				// 交代元
				$data['p_id'] = $p_id;
				$data['name'] = $duty_assignment->name;
				$data['before_type'] = $current_duty;
				$data['after_type'] = $change_data[$p_id];

				$base_work_list = $this->getBaseDutyWorkList($year, $month, $day, $p_id, $data['before_type']);

//				if ($this->Duty->reTotalize($year_month, $p_id) === FALSE) {
//					$this->DutyAssignments->connection()->rollback();
//					$is_err = TRUE;
//					break;
//				}
			}
			else
			{
				// 交代先
				if (isset($data['change_p_id1']))
				{
					$data['change_p_id2'] = $p_id;
					$data['change_name2'] = $duty_assignment->name;
					$data['change_before_type2'] = $current_duty;
					$data['change_after_type2'] = $change_data[$p_id];

					$change_work_list2 = $this->getBaseDutyWorkList($year, $month, $day, $p_id, $data['change_before_type2']);

//					// DutyWorkの付け替え
//					$duty_types = $this->getAddDutyType($data['change_before_type2'], $data['change_after_type2']);
//					if (count($duty_types)>0) {
//						foreach ($duty_types as $type) {
//							if (isset($duty_work_list[$type])) {
//								if ($this->updateDutyWork($duty_work_list[$type], $p_id) === FALSE) {
//									$this->DutyAssignments->connection()->rollback();
//									$is_err = TRUE;
//									break;
//								}
//							}
//						}
//					}

//					if ($this->Duty->reTotalize($year_month, $p_id) === FALSE) {
//						$this->DutyAssignments->connection()->rollback();
//						$is_err = TRUE;
//						break;
//					}
				}
				else
				{
					$data['change_p_id1'] = $p_id;
					$data['change_name1'] = $duty_assignment->name;
					$data['change_before_type1'] = $current_duty;
					$data['change_after_type1'] = $change_data[$p_id];

					$change_work_list1 = $this->getBaseDutyWorkList($year, $month, $day, $p_id, $data['change_before_type1']);

//					// DutyWorkの付け替え
//					$duty_types = $this->getAddDutyType($data['change_before_type1'], $data['change_after_type1']);
//					if (count($duty_types)>0) {
//						foreach ($duty_types as $type) {
//							if (isset($duty_work_list[$type])) {
//								if ($this->updateDutyWork($duty_work_list[$type], $p_id) === FALSE) {
//									$this->DutyAssignments->connection()->rollback();
//									$is_err = TRUE;
//									break;
//								}
//							}
//						}
//					}

//					if ($this->Duty->reTotalize($year_month, $p_id) === FALSE) {
//						$this->DutyAssignments->connection()->rollback();
//						$is_err = TRUE;
//						break;
//					}
				}
			}
		}

		$after_arr = explode(',', $data['after_type']);
		if (count($after_arr)>0) {
			foreach ($after_arr as $type) {
				$type = trim($type);
				if (isset($base_work_list[$type]) === FALSE) {
					if (isset($change_work_list1[$type])) {
						if ($this->updateDutyWork($change_work_list1[$type], $data['p_id']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					} else if (isset($change_work_list2[$type])) {
						if ($this->updateDutyWork($change_work_list2[$type], $data['p_id']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					}
				}
			}
		}
		$after_arr = explode(',', isset($data['change_after_type1'])?$data['change_after_type1']:'');
		if (count($after_arr)>0) {
			foreach ($after_arr as $type) {
				$type = trim($type);
				if (isset($change_work_list1[$type]) === FALSE) {
					if (isset($base_work_list[$type])) {
						if ($this->updateDutyWork($base_work_list[$type], $data['change_p_id1']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					} else if (isset($change_work_list2[$type])) {
						if ($this->updateDutyWork($change_work_list2[$type], $data['change_p_id1']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					}
				}
			}
		}
		$after_arr = explode(',', isset($data['change_after_type2'])?$data['change_after_type2']:'');
		if (count($after_arr)>0) {
			foreach ($after_arr as $type) {
				$type = trim($type);
				if (isset($change_work_list2[$type]) === FALSE) {
					if (isset($base_work_list[$type])) {
						if ($this->updateDutyWork($base_work_list[$type], $data['change_p_id2']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					} else if (isset($change_work_list1[$type])) {
						if ($this->updateDutyWork($change_work_list1[$type], $data['change_p_id2']) === FALSE) {
							$this->DutyAssignments->connection()->rollback();
							$is_err = TRUE;
						}
					}
				}
			}
		}

		// 再集計
		if ($this->Duty->reTotalize($year_month, $p_id) === FALSE) {
			$this->DutyAssignments->connection()->rollback();
			$is_err = TRUE;
		}
		if (isset($data['change_p_id1']) && $data['change_p_id1']>0) {
			if ($this->Duty->reTotalize($year_month, $data['change_p_id1']) === FALSE) {
				$this->DutyAssignments->connection()->rollback();
				$is_err = TRUE;
			}
		}
		if (isset($data['change_p_id2']) && $data['change_p_id2']>0) {
			if ($this->Duty->reTotalize($year_month, $data['change_p_id2']) === FALSE) {
				$this->DutyAssignments->connection()->rollback();
				$is_err = TRUE;
			}
		}

		if ($is_err === FALSE)
		{
			// ログ登録
			$DutyLogs = TableRegistry::get('DutyLogs');
			$duty_log = $DutyLogs->newEntity($data);

			if ($DutyLogs->save($duty_log) === FALSE) {
				$this->DutyAssignments->connection()->rollback();
				$this->set('errors', $duty_log->errors());
				Log::error($duty_log->errors());
			}

			$this->DutyAssignments->connection()->commit();
		}
	}

	private function getBaseDutyWorkList($year, $month, $day, $p_id, $before)
	{
		$before_arr = explode(',', $before);

		$duty_work_list = [];

		foreach ($before_arr as $type)
		{
			$type = trim($type);

//			$flag = FALSE;
//			foreach ($after_arr as $type2) {
//				if ($type == trim($type2)) {
//					$flag = TRUE;
//				}
//			}
			//if ($flag === FALSE && $type != '') {
				$DutyWorks = TableRegistry::get('DutyWorks');
				$wh = [
					'dw_date' => sprintf("%04d-%02d-%02d", $year, $month, $day),
					'p_id' => $p_id,
					'duty_type' => $type
				];
				$duty_work = $DutyWorks->find()->where($wh)->first();
				if ($duty_work !== NULL) {
					$duty_work_list[$type] = $duty_work;
				} else {
					// ここで取得できない場合はデータがおかしい
					Log::error('日程表の詳細データが取得できません。'.$month.'/'.$day.'>'.$type);
				}
			//}
		}

		return $duty_work_list;
	}

	private function getAddDutyType($before, $after)
	{
		$before_arr = explode(',', $before);
		$after_arr = explode(',', $after);

		$duty_types = [];

		foreach ($after_arr as $type)
		{
			$type = trim($type);

			$flag = FALSE;
			foreach ($before_arr as $type2) {
				if ($type == trim($type2)) {
					$flag = TRUE;
				}
			}
			if ($flag === FALSE && $type != '') {
				$duty_types[] = $type;
			}
		}

		return $duty_types;
	}

	private function updateDutyWork(DutyWork &$duty_work, $p_id)
	{
		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work = $DutyWorks->patchEntity($duty_work, [
			'p_id' => $p_id
		]);
		if ($DutyWorks->save($duty_work) === FALSE) {
			$this->set('errors', $duty_work->errors());
			Log::error($duty_work->errors());
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * ダウンロード
	 */
	public function download()
	{
		$this->set('sideNavi', ['duty'=>'download']);
		$this->setTitle('日程表管理', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			// 交代要員社員番号の入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('year_month', TRUE, '年月を選択してください。');

			$errors = $validator->errors($this->request->data());
			if ($errors)
			{
				$this->set('errors', $errors);
			}
			else
			{
				$year_month = $this->request->data('year_month');
				$duty_assignment_list = $this->DutyAssignments->find()->where([
					'da_year_month' => $year_month
				])->order([
					'document_order' => 'ASC'
				])->toArray();
				$this->Csv->setData($duty_assignment_list);
				$this->Csv->download('duty_assignment', 'DAT_'.date("Ymd").'.csv');
			}
		}

		// 作成済日程表の年月リスト
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env_list = $DutyEnvs->find()->select([
			'year_month' => 'de_year_month'
		])->where([
			'status' >= DE_STATUS_BUILD
		])->order([
			'de_year_month' => 'DESC'
		])->toArray();
		$this->set('duty_env_list', $duty_env_list);
	}

	public function validDutyAssignment($p_id)
	{
		if (empty($p_id)) {
			return TRUE;
		}
		if (isset($this->request->query['year_month'])) {
			$year_month = $this->request->query['year_month'];
		} else if (isset($this->request->data['year_month'])) {
			$year_month = $this->request->data['year_month'];
		}
		$duty_assignment = $this->getDutyAssignment($p_id, $year_month);
		return ($duty_assignment !== NULL) ? TRUE : FALSE;
	}

	public function validDay($day)
	{
		if (empty($day)) {
			return TRUE;
		}
		if (isset($this->request->query['year_month'])) {
			$year_month = $this->request->query['year_month'];
		} else if (isset($this->request->data['year_month'])) {
			$year_month = $this->request->data['year_month'];
		}
		return checkdate(substr($year_month,4,2), (int)$day, substr($year_month,0,4));
	}

	private function getDutyAssignment($p_id, $year_month)
	{
		return $this->DutyAssignments->find()->where([
			'p_id' => $p_id,
			'da_year_month' => $year_month
		])->first();
	}
}

<?php
namespace App\Controller;

use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 *  月末処理
 */
class CloseMonthController extends AppController
{
	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function index()
	{
		$this->set('sideNavi', ['close_month'=>'index']);
		$this->setTitle('日程表管理', '月末処理');
	}
	
	public function update()
	{
		$this->set('sideNavi', ['close_month'=>'update']);
		$this->setTitle('日程表管理', '月末処理 - 更新');

		$this->set('duty_env_list', $this->getDutyEnvsList());
	}
	
//	public function update_confirm()
//	{
//		$this->set('sideNavi', ['close_month'=>'update']);
//		$this->setTitle('日程表管理', '月末処理 - 更新');
//
//		if ($this->request->is('POST') === FALSE) {
//			return $this->redirect(['action' => 'update']);
//		}
//	}

	public function update_comp()
	{
		$this->set('sideNavi', ['close_month'=>'update']);
		$this->setTitle('日程表管理', '月末処理 - 更新');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'update']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator->requirePresence('year_month', TRUE, '年月を選択してください。');

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->set('duty_env_list', $this->getDutyEnvsList());
			$this->render('update');
		}
		else
		{
			$year_month = $this->request->data['year_month'];

			$DutyAssignments = TableRegistry::get('DutyAssignments');
			$duty_assignment_list = $DutyAssignments->find()->where([
				'da_year_month' => $year_month
			])->toArray();
			
			$PersonnelYears = TableRegistry::get('PersonnelYears');

			if ($duty_assignment_list !== NULL)
			{
				$PersonnelYears->connection()->begin();

				foreach ($duty_assignment_list as $d)
				{
					$personnel_year = $PersonnelYears->find()->where([
						'p_id' => $d->p_id,
						'py_year_month' => $year_month
					])->first();
					
					// 残業時間
					$orvertime = $d->overtime25 + $d->overtime35;

					$data = [
						'work_days' => $d->work_days,
						'vacation_days' => $d->vacation_days,
						'work_hours' => $d->work_hours,
						'night_work_hours' => $d->night_work_hours,
						'extra_work_hours' => $d->extra_work_hours,
						'extra_night_work_hours' => $d->extra_night_work_hours,
						'overtime' => $orvertime,
						'overtime25' => $d->overtime25,
						'overtime35' => $d->overtime35,
						'd_duty' => $d->d_duty,
						'n_duty' => $d->n_duty,
						'dn_duty' => $d->dn_duty,
						'day_duty' => $d->day_duty,
						'night_duty' => $d->night_duty,
						'fire_plural' => $d->fire_plural,
						'fire_jippo' => $d->fire_jippo,
						'acting_captain' => $d->acting_captain,
						'meal_allowance' => $d->meal_allowance,
						'absence_days' => $d->absence_days,
						'r_days' => $d->r_days,
						'hl_days' => $d->r_days,
						'hd1_days' => $d->hd1_days,
						'hd2_days' => $d->hd2_days,
						'hd3_days' => $d->hd3_days,
						'hd4_days' => $d->hd4_days,
						'hd5_days' => $d->hd5_days,
						'x_days' => $d->x_days,
						'y_days' => $d->y_days,
						'z_days' => $d->z_days,
						'me1_days' => $d->me1_days,
						'me2_days' => $d->me2_days,
						'ne1_hours' => $d->ne1_hours,
						'ne2_hours' => $d->ne2_hours,
						'ne3_hours' => $d->ne3_hours,
						'ne4_hours' => $d->ne4_hours,
						'f_hours' => $d->f_hours,
						'fe_hours' => $d->fe_hours,
						'fd_days' => $d->fd_days,
						'oj1_hours' => $d->oj1_hours,
						'oj2_hours' => $d->oj2_hours,
						'oj3_hours' => $d->oj3_hours,
						'sh_days' => $d->sh_days,
						'se_hours' => $d->se_hours,
						'se_night_hours' => $d->se_night_hours,
						'sm_hours' => $d->sm_hours,
						'sm_night_hours' => $d->sm_night_hours,
						'te_days' => $d->te_days,
						'mt_hours' => $d->mt_hours,
					];

					if ($personnel_year === NULL)
					{
						// 新規
						$data['p_id'] = $d->p_id;
						$data['py_year_month'] = $year_month;
						$personnel_year = $PersonnelYears->newEntity($data);
					}
					else
					{
						// 更新
						$personnel_year = $PersonnelYears->patchEntity($personnel_year, $data);
					}

					if ($PersonnelYears->save($personnel_year) === FALSE) {
						$PersonnelYears->connection()->rollback();
						Log::error($personnel_year->errors());
						$this->set('errors', $personnel_year->errors());
						break;
					}
				}

				$PersonnelYears->connection()->commit();
			}
		}
	}

	private function getDutyEnvsList()
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env_list = $DutyEnvs->find()->where([
			'status >=' => DE_STATUS_BUILD
		])->order([
			'de_year_month' => 'DESC'
		])->limit(1)->toArray();
		return $duty_env_list;
	}
}
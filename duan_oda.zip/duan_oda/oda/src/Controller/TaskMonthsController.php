<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 *
 */
class TaskMonthsController extends AppController
{
	public $helpers = [
		'Paginator'
	];

	public $components = [
		'Upload',
		'Csv'
	];

	public $errors = [];

	public function initialize()
	{
		parent::initialize();

		$this->paginate = [
			'limit' => 50,
			'order' => [
				'tm_year_month' => 'DESC',
				'tm_id' => 'ASC'
			]
		];

		$this->currentYearMonth();
	}

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function top()
	{
		$this->setTitle('月次タスクマスター', 'ファイル選択');
	}

	public function index()
	{
		$this->set('sideNavi', ['task_month'=>'index']);
		$this->setTitle('月次タスクマスター', '');
	}

	public function year_month()
	{
		$this->set('sideNavi', ['task_month'=>'year_month']);
		$this->setTitle('月次タスクマスター', '年月指定');
	}

	public function year_month_confirm()
	{
		$this->set('sideNavi', ['task_month'=>'year_month']);
		$this->setTitle('月次タスクマスター', '年月指定');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'year_month']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('year', TRUE, '年を入力してください。')
			->notEmpty('year', '年を入力してください。')
			->add('year', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '年は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 2000 && $value <=2050);
					},
					'message' => '年は2000〜2050を入力してください。'
				]
			])
			->requirePresence('month', TRUE, '月を入力してください。')
			->notEmpty('month', '月を入力してください。')
			->add('month', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '月は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 1 && $value <=12);
					},
					'message' => '月は1〜12を入力してください。'
				]
			]);

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->render('year_month');
		}
		else if ($this->current_year_month !== NULL)
		{
			$query = $this->TaskMonths->find()->select(['total'=>'COUNT(*)'])->where([
				'tm_year_month' => sprintf("%04d%02d", $this->request->data('year'), $this->request->data('month'))
			])->order([
				'tm_id' => 'ASC'
			])->first();
			$this->set('total', $query->total);
		}
	}

	public function year_month_save()
	{
		$this->set('sideNavi', ['task_month'=>'year_month']);
		$this->setTitle('月次タスクマスター', '年月指定');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'year_month']);
		}

		$year = $this->request->data('year');
		$month = $this->request->data('month');
		$year_month = sprintf("%04d%02d", $year, $month);
		$Env = TableRegistry::get('Envs');
		$errors = $Env->toSave(ENV_TMM_CURRENT_YEAR_MONTH, $year_month);
		if ($errors) {
			$this->set('errors', $errors);
		} else {
			if ($this->current_year_month !== NULL) {
				$this->set('current_change', 1);
			}
			$this->currentYearMonth();
		}

	}

	public function table()
	{
		$this->set('sideNavi', ['task_month'=>'table']);
		$this->setTitle('月次タスクマスター', '一覧表示');
	}

	public function table_list()
	{
		$this->set('sideNavi', ['task_month'=>'table']);
		$this->setTitle('月次タスクマスター', '一覧表示');

		if ($this->current_year_month !== NULL)
		{
			Configure::load('list_settings');
			$this->set('list_settings', Configure::read('list_settings.task_month'));

			$query = $this->TaskMonths->find()->where([
				'tm_year_month' => $this->current_year_month
			])->order([
				'tm_id' => 'ASC'
			]);
			$this->set('primary_list', $this->paginate($query));
		}
	}

	public function table_schedule()
	{
		$this->set('sideNavi', ['task_month'=>'table']);
		$this->setTitle('月次タスクマスター', '日程表表示');

		if ($this->current_year_month !== NULL)
		{
			// カレンダー表示用
			$year = $this->current_year;
			$month = $this->current_month;
			$month -= 1;
			if ($month == 0) {
				$month = 12;
				$year -= 1;
			}

			$start_ts = mktime(0,0,0,$month,DAT_START_DAY,$year);
			$max_day = date('t', mktime(0,0,0,$month,1,$year));
			$total_day = ($max_day - (DAT_START_DAY - 1)) + (DAT_START_DAY - 1);
			$day_names = Configure::read('day_names');

			// 祝日
			$start_date = date("Y-m-d", $start_ts);
			$end_date = date("Y-m-d", strtotime(sprintf("%04d-%02d-%02d", $year, $month, DAT_START_DAY-1) . ' +1 month'));

			$holiday_map = TableRegistry::get('Holidays')->getHolidayMap($start_date, $end_date);

			$cals = [];
			$ts = 0;
			for ($i=0; $i<$total_day; $i++)
			{
				$ts = $start_ts + (86400 * $i);
				$wn = date("w", $ts);

				if (isset($holiday_map[$ts]) || $wn == 0) {
					$color = '#FFD5EC';
				} else if ($wn == 6) {
					$color = '#D7EEFF';
				} else {
					$color = '';
				}

				$cals[$i] = [
					'day' => date('j', $ts),
					'day_name' => $day_names[date("w", $ts)],
					'color' => $color,
					'ts' => $ts
				];
			}

			$primary_list = $this->TaskMonths->find()->where([
				'tm_year_month' => $this->current_year_month
			])->order([
				'tm_id' => 'ASC'
			])->toArray();

			// タイトル用
			$date_title  = date('Y.n.j', $start_ts);
			$date_title .= '-';
			if (date('Y', $start_ts) != date('Y', $ts)) {
				$date_title .= date('Y.', $ts);
			}
			$date_title .= date('n.j', $ts);
			$month_title = date('n', $ts);
			$this->set('date_title', $date_title);
			$this->set('month_title', $month_title);
			$this->set('primary_list', $primary_list);
			$this->set('cals', $cals);
		}
	}

	/**
	 * 現在の年月を取得
	 *
	 * @return boolean
	 */
	public function currentYearMonth()
	{
		$Envs = TableRegistry::get('Envs');
		$year_month = $Envs->getValue(ENV_TMM_CURRENT_YEAR_MONTH);

		if ($year_month === NULL) {
			$this->current_year_month = NULL;
			$this->current_year = NULL;
			$this->current_month = NULL;
		} else {
			$this->current_year_month = $year_month;
			$this->current_year = (int)substr($year_month, 0, 4);
			$this->current_month = (int)substr($year_month, 4, 2);
		}
		$this->set('current_year_month', $this->current_year_month);
		$this->set('current_year', $this->current_year);
		$this->set('current_month', $this->current_month);

		return TRUE;
	}

//	private function currentYearMonth2()
//	{
//		// 一番最新の月度を表示
//		$query = $this->TaskMonths->find();
//		$res = $query->select(['max' => $query->func()->max('tm_year_month')])->first();
//		return $res->max;
//	}

//	private function getTaskMonthList()
//	{
//		$query = $this->TaskMonths->find()->where([
//			'tm_year_month' => $this->current_year_month
//		])->order([
//			'tm_id' => 'ASC'
//		])->toArray();
//
//		return $query;
//	}

	public function form()
	{
		$this->set('sideNavi', ['task_month'=>'form']);
		$this->setTitle('月次タスクマスター', '登録・更新');
	}

	public function add()
	{
		$this->set('sideNavi', ['task_month'=>'form']);
		$this->setTitle('月次タスクマスター', '登録');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task_month'));
		$this->set('values', $this->request->data);
	}

	public function add_confirm()
	{
		return $this->_add('confirm');
	}

	public function add_save()
	{
		return $this->_add('save');
	}

	private function _add($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['task_month'=>'form']);
		$this->setTitle('月次タスクマスター', '登録');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.task_month');
		$this->set('form_settings', $form_settings);

		$ret = $this->request->data('ret');

		$this->filterRequestData($form_settings);
		$this->request->data['status'] = TMT_STATUS_TYPE_NOTCOMP;
		$this->request->data['tm_year_month'] = $this->current_year_month;
		$end_date_flag = FALSE;
		if ($this->request->data('start_date') != '' && $this->request->data('end_date') == '') {
			$this->request->data['end_date'] = $this->request->data('start_date');
			$end_date_flag = TRUE;
		}
		if ($this->request->data('duty_type') != '') {
			if ($this->request->data('duty_type') == 'D') {
				if ($this->request->data('start_time') == '') {
					$this->request->data['start_time'] = DAT_D_START_TIME;
				}
				if ($this->request->data('end_time') == '') {
					$this->request->data['end_time'] = DAT_D_END_TIME;
				}
				if ($this->request->data('work_hours') == '') {
					$this->request->data['work_hours'] = DAT_D_WORK_HOURS;
				}
			} else if ($this->request->data('duty_type') == 'N') {
				if ($this->request->data('start_time') == '') {
					$this->request->data['start_time'] = DAT_N_START_TIME;
				}
				if ($this->request->data('end_time') == '') {
					$this->request->data['end_time'] = DAT_N_END_TIME;
				}
				if ($this->request->data('work_hours') == '') {
					$this->request->data['work_hours'] = DAT_N_WORK_HOURS;
				}
				if ($this->request->data('night_work_hours') == '') {
					$this->request->data['night_work_hours'] = DAT_N_NIGHT_HOURS;
				}
			}
		}
		$task_month = $this->TaskMonths->newEntity($this->request->data);
		$this->TaskMonths->isRules($task_month);

		if ($task_month->errors())
		{
			if ($end_date_flag && $this->request->data('start_date') != ''
				&& $this->request->data('start_date') == $this->request->data('end_date'))
			{
				$this->request->data['end_date'] = '';
			}
			$this->set('errors', $task_month->errors());
			$this->set('values', $this->request->data);
			$this->set('ret', $ret);

			return $this->render('add');
		}
		else if ($mode === 'save')
		{
			if ($this->TaskMonths->save($task_month) === FALSE) {
				$this->set('errors', $task_month->errors());
				Log::error('月次タスクマスターの登録に失敗しました。');
			}
		}

		$this->set('values', $this->request->data);
		$this->set('ret', 'form');
	}

	public function edit()
	{
		$this->set('sideNavi', ['task_month'=>'form']);
		$this->setTitle('月次タスクマスター', '更新');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task_month'));

		$task_month = NULL;
		$tm_id = NULL;
		$ret = '';
		$errors = [];

		if ($this->request->is('POST'))
		{
			$tm_id = $this->request->data('_tm_id');
			$ret = $this->request->data('ret');
		}
		else
		{
			$tm_id = $this->request->query('tm_id');
			$ret = $this->request->query('ret');
		}

		if ($tm_id && $this->current_year_month) {
			$task_month = $this->TaskMonths->find()->where([
				'tm_id' => $tm_id,
				'tm_year_month' => $this->current_year_month
			])->first();
		}

		if ($task_month === NULL)
		{
			if (empty($tm_id)) {
				$errors['tm_id'] = ['更新する月次タスクIDを入力してください。'];
			} else {
				$errors['tm_id'] = ['該当する月次タスクマスターは存在しません。'];
				$this->set('tm_id', $tm_id);
			}
			$this->set('errors', $errors);
			$this->setTitle('月次タスクマスター', '登録・更新');
			return $this->render('form');
		}
		else if (isset($task_month->status) && $task_month->status == TMM_STATUS_TYPE_CANCEL)
		{
			$errors['tm_id'] = ['該当する月次タスクマスターは取消されています。更新できません。'];
			$this->set('tm_id', $tm_id);
			$this->set('errors', $errors);
			$this->setTitle('月次タスクマスター', '登録・更新');
			return $this->render('form');
		}
		else if ($this->request->is('POST'))
		{
			// 固定の値なので
			$this->request->data['status'] = $task_month->status;
			$this->set('values', $this->request->data);
		}
		else
		{
			$this->set('values', $task_month);
		}

		$this->set('_tm_id', $tm_id);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	public function edit_confirm()
	{
		return $this->_edit('confirm');
	}

	public function edit_save()
	{
		return $this->_edit('save');
	}

	private function _edit($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['task_month'=>'form']);
		$this->setTitle('月次タスクマスター', '更新');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.task_month');
		$this->set('form_settings', $form_settings);

		$tm_id = $this->request->data('_tm_id');
		$ret = $this->request->data('ret');

		if (empty($tm_id)) {
			throw new FatalErrorException("tm_idが見つかりません。");
		}

		$task_month = $this->TaskMonths->find()->where([
			'tm_id' => $tm_id,
			'tm_year_month' => $this->current_year_month
		])->first();

		if ($task_month === NULL) {
			throw new FatalErrorException('月次タスクマスターが見つかりません。[tm_id='.$tm_id.', tm_year_month='.$this->current_year_month.']');
		}

		$originals = clone $task_month;
		$this->filterRequestData($form_settings);
		$this->request->data['tm_year_month'] = $this->current_year_month;
		$end_date_flag = FALSE;
		if ($this->request->data('start_date') != '' && $this->request->data('end_date') == '') {
			$this->request->data['end_date'] = $this->request->data('start_date');
			$end_date_flag = TRUE;
		}
		if ($this->request->data('duty_type') != '') {
			if ($this->request->data('duty_type') == 'D') {
				if ($this->request->data('start_time') == '') {
					$this->request->data['start_time'] = DAT_D_START_TIME;
				}
				if ($this->request->data('end_time') == '') {
					$this->request->data['end_time'] = DAT_D_END_TIME;
				}
				if ($this->request->data('work_hours') == '') {
					$this->request->data['work_hours'] = DAT_D_WORK_HOURS;
				}
			} else if ($this->request->data('duty_type') == 'N') {
				if ($this->request->data('start_time') == '') {
					$this->request->data['start_time'] = DAT_N_START_TIME;
				}
				if ($this->request->data('end_time') == '') {
					$this->request->data['end_time'] = DAT_N_END_TIME;
				}
				if ($this->request->data('work_hours') == '') {
					$this->request->data['work_hours'] = DAT_N_WORK_HOURS;
				}
				if ($this->request->data('night_work_hours') == '') {
					$this->request->data['night_work_hours'] = DAT_N_NIGHT_HOURS;
				}
			}
		}
		$task_month = $this->TaskMonths->patchEntity($task_month, $this->request->data);
		$this->TaskMonths->isRules($task_month);

		$this->request->data['status'] = $task_month->status;

		if ($task_month->errors())
		{
			if ($end_date_flag && $this->request->data('start_date') != ''
				&& $this->request->data('start_date') == $this->request->data('end_date'))
			{
				$this->request->data['end_date'] = '';
			}
			$this->set('errors', $task_month->errors());
			$this->set('values', $this->request->data);
			$this->set('_tm_id', $tm_id);
			$this->set('ret', $ret);

			return $this->render('edit');
		}
		else if ($mode === 'save')
		{
			if ($this->TaskMonths->save($task_month) === FALSE) {
				$this->set('errors', $task_month->errors());
				Log::error('月次タスクマスターの更新に失敗しました。[tm_id='.$tm_id.', tm_year_month='.$this->current_year_month.']');
			}

			// 日程表が作成済みであれば時間が変わっている可能性があるため再計算する
			if ($this->isCreatedDutyTable())
			{
				$DutyWorks = TableRegistry::get('DutyWorks');
				$duty_work_list = $DutyWorks->find()->where([
					'dw_year_month' => $this->current_year_month,
					'task_id' => $tm_id,
					'task_type' => TW_TYPE_TMM
				])->toArray();

				$this->loadComponent('Duty');
				foreach ($duty_work_list as $duty_work)
				{
					$duty_work->duty_type      = $this->request->data["duty_type"];
					$duty_work->start_time     = $this->request->data["start_time"];
					$duty_work->end_time       = $this->request->data["end_time"];
					$duty_work->work_hours     = $this->request->data["work_hours"];
					$duty_work->night_hours    = $this->request->data["night_hours"];
					$duty_work->meal_allowance = $this->request->data["meal_allowance"];
					$DutyWorks->save($duty_work);
					$this->Duty->reTotalize($this->current_year_month, $duty_work->p_id);
				}
			}
		}

		$this->set('originals', $originals);
		$this->set('values', $this->request->data);
		$this->set('_tm_id', $tm_id);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	/**
     * Delete method
     *
     * @param string|null $id Personnel id.
     * @return void Redirects to index.
     * @throws NotFoundException When record not found.
     */
    public function delete()
    {
		$this->set('sideNavi', ['task_month'=>'delete']);
		$this->setTitle('月次タスクマスター', '削除');
    }

	public function delete_confirm($id = null)
	{
		$this->set('sideNavi', ['task_month'=>'delete']);
		$this->setTitle('月次タスクマスター', '削除');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task_month'));

		$task_month = NULL;
		$tm_id = NULL;
		$ret = '';
		$errors = [];

		if ($this->request->is('POST'))
		{
			$tm_id = $this->request->data('_tm_id');
			$ret = $this->request->data('ret');
		}
		else
		{
			$tm_id = $this->request->query('tm_id');
			$ret = $this->request->query('ret');
		}

		if ($tm_id && $this->current_year_month)
		{
			$task_month = $this->TaskMonths->find()->where([
				'tm_id' => $tm_id,
				'tm_year_month' => $this->current_year_month
			])->first();
		}

		if ($task_month === NULL)
		{
			if (empty($tm_id)) {
				$errors['tm_id'] = ['削除する月次タスクIDを入力してください。'];
			} else {
				$errors['tm_id'] = ['該当する月次タスクマスターは存在しません。'];
				$this->set('tm_id', $tm_id);
			}
			$this->set('errors', $errors);
			return $this->render('delete');
		}
		else if (isset($task_month->status) && $task_month->status == TMM_STATUS_TYPE_CANCEL)
		{
			$errors['tm_id'] = ['該当する月次タスクマスターは取消されています。削除できません。'];
			$this->set('tm_id', $tm_id);
			$this->set('errors', $errors);
			return $this->render('delete');
		}

		$this->set('publish_after_flag', $this->checkPublishDateAfter());
		$this->set('values', $task_month);
		$this->set('_tm_id', $tm_id);
		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}

	public function delete_save()
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'delete']);
		}

		$this->set('sideNavi', ['task_month'=>'delete']);
		$this->setTitle('月次タスクマスター', '削除');

		$task_month = NULL;
		$tm_id = $this->request->data('_tm_id');
		$ret = $this->request->data('ret');

		if ($tm_id && $this->current_year_month) {
			$task_month = $this->TaskMonths->find()->where([
				'tm_id' => $tm_id,
				'tm_year_month' => $this->current_year_month
			])->first();
		}

		if ($task_month === NULL) {
			throw new FatalErrorException('月次タスクマスターが存在しません。[tm_id='.$tm_id.', tm_year_month='.$this->current_year_month.']');
		}

		if ($this->checkPublishDateAfter())
		{
			// 発刊後は取消し処理
			if ($this->cancelTaskMonth($tm_id) === FALSE) {
				$this->set('errors', $this->errors);
				Log::error('月次タスクマスターの取消しに失敗しました。[tm_id='.$tm_id.', tm_year_month='.$this->current_year_month.']');
			}
		}
		else
		{
			// 発刊前は物理削除
			if ($this->deleteTaskMonth($task_month) === FALSE) {
				$this->set('errors', $task_month->errors());
				Log::error('月次タスクマスターの削除に失敗しました。[tm_id='.$tm_id.', tm_year_month='.$this->current_year_month.']');
			}
		}

		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}


	/**
	 * 一括登録
	 */
	public function batch()
	{
		$this->set('sideNavi', ['task_month'=>'batch']);
		$this->setTitle('月次タスクマスター', '一括登録');

//		$tmp_csv_file = '';
//
//		if ($this->request->is('POST'))
//		{
//			if (isset($this->request->data['file']))
//			{
//				// アップロード時
//				if ($this->Upload->isError())
//				{
//					Log::write('error', $this->Upload->getErrorMessage());
//				}
//				else
//				{
//					$tmp_csv_file = $this->Upload->getFile('TMM');
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'task_month', $this->TaskMonths) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//			else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//			{
//				// エラー変更時
//				$tmp_csv_file = $this->request->data['tmp_csv_file'];
//				if (file_exists($tmp_csv_file))
//				{
//					$this->Csv->setUpdateValues($this->request->data['values']);
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'task_month', $this->TaskMonths) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//		}
//
//		$this->set('tmp_csv_file', $tmp_csv_file);
	}

	public function batch_confirm()
	{
		$this->set('sideNavi', ['task_month'=>'batch']);
		$this->setTitle('月次タスクマスター', '一括登録');

		$tmp_csv_file = '';
		$data = [];

		if ($this->request->is('POST'))
		{
			if (isset($this->request->data['file']))
			{
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
                {
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
                }
				else
				{
					$tmp_csv_file = $this->Upload->getFile('TMM');
					$fp = fopen($tmp_csv_file, 'r');
					if ($this->Csv->parse($fp, 'task_month', $this->TaskMonths, ['tm_year_month'=>$this->current_year_month]) === FALSE)
					{
						$this->set('csv_errors', $this->Csv->getErrors());
						Log::debug($this->Csv->getErrors());
					}
					$data = $this->Csv->getData();
				}
			}
		}

		$this->set('tmp_csv_file', $tmp_csv_file);
		$this->set('data', $data);
	}

	public function batch_save()
	{
		$this->set('sideNavi', ['task_month'=>'batch']);
		$this->setTitle('月次タスクマスター', '一括登録');

		$tmp_csv_file = $this->request->data['tmp_csv_file'];
		if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
		{
			throw new FatalErrorException("一時ファイルが見つかりません。");
		}
		$fp = fopen($tmp_csv_file, 'r');
		if ($this->Csv->parse($fp, 'task_month', $this->TaskMonths, ['tm_year_month'=>$this->current_year_month]) === FALSE)
		{
			$this->set('csv_errors', $this->Csv->getErrors());
			Log::debug($this->Csv->getErrors());
			$this->set('tmp_csv_file', $tmp_csv_file);
			$this->set('data', $this->Csv->getData());
			return $this->render('batch_confirm');
		}
		else
		{
			$this->Csv->import($this->TaskMonths, 'tm_id,tm_year_month');
			$this->set('total', $this->Csv->getTotal());
		}
	}

	/**
	 * ダウンロード
	 */
	public function download()
	{
		$this->set('sideNavi', ['task_month'=>'download']);
		$this->setTitle('月次タスクマスター', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			$list = $this->TaskMonths->find()->where([
				'tm_year_month' => $this->current_year_month
			])->order([
				'tm_id' => 'ASC'
			])->toArray();
			$this->Csv->setData($list);
			$this->Csv->download('task_month', 'TMM_'.date("Ymd").'.csv');
		}
	}

	/**
	 * 今日が発刊日後かどうか
	 */
	private function checkPublishDateAfter()
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'de_year_month' => $this->current_year_month
		])->first();
		if ($duty_env !== NULL && $duty_env->publish_date !== NULL) {
			$publish_date_ts = $duty_env->publish_date->timestamp;
			if ($publish_date_ts > 0 && $publish_date_ts < time()) {
				return TRUE;
			}
		}
		return FALSE;
	}

	/**
	 * 月次タスクの削除
	 *
	 * @param $task_month
	 * @return boolean
	 */
	private function deleteTaskMonth($task_month)
	{
		$this->TaskMonths->connection()->begin();
		$this->TaskMonths->delete($task_month);

		$tm_id = $task_month->tm_id;

		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work_list = $DutyWorks->find()->where([
			'dw_year_month' => $this->current_year_month,
			'task_id' => $tm_id,
			'task_type' => TW_TYPE_TMM
		])->toArray();

		if (count($duty_work_list)>0)
		{
			$updated = [];
			foreach ($duty_work_list as $duty_work)
			{
				if ($this->changeDutyAssignment($tm_id, $duty_work->p_id, $updated) === FALSE) {
					$this->TaskMonths->connection()->rollback();
					return FALSE;
				}
				if ($DutyWorks->delete($duty_work) === FALSE) {
					$this->TaskMonths->connection()->rollback();
					$this->errors = $duty_work->errors();
					Log::error($duty_work->errors());
					return FALSE;
				}
			}
			// 再集計
			if (count($updated)>0)
			{
				$this->loadComponent('Duty');
				foreach ($updated as $p_id)
				{
					if ($this->Duty->reTotalize($this->current_year_month, $p_id) === FALSE) {
						$this->TaskMonths->connection()->rollback();
						return FALSE;
					}
				}
			}
		}
		$this->TaskMonths->connection()->commit();
		return TRUE;
	}

	/**
	 * 月次タスクの取消し処理
	 *
	 * @param type $tm_id
	 * @return boolean
	 */
	private function cancelTaskMonth($tm_id)
	{
		$this->TaskMonths->connection()->begin();
		$this->TaskMonths->updateAll([
			'status' => TMM_STATUS_TYPE_CANCEL
		],[
			'tm_year_month' => $this->current_year_month,
			'tm_id' => $tm_id
		]);

		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work_list = $DutyWorks->find()->where([
			'dw_year_month' => $this->current_year_month,
			'task_id' => $tm_id,
			'task_type' => TW_TYPE_TMM
		])->toArray();

		if (count($duty_work_list)>0)
		{
			$updated = [];
			foreach ($duty_work_list as $duty_work)
			{
				if ($this->changeDutyAssignment($tm_id, $duty_work->p_id, $updated) === FALSE) {
					$this->TaskMonths->connection()->rollback();
					return FALSE;
				}
				if ($DutyWorks->delete($duty_work) === FALSE) {
					$this->TaskMonths->connection()->rollback();
					$this->errors = $duty_work->errors();
					Log::error($duty_work->errors());
					return FALSE;
				}
			}
			// 再集計
			if (count($updated)>0)
			{
				$this->loadComponent('Duty');
				foreach ($updated as $p_id)
				{
					if ($this->Duty->reTotalize($this->current_year_month, $p_id) === FALSE) {
						$this->TaskMonths->connection()->rollback();
						return FALSE;
					}
				}
			}
		}
		$this->TaskMonths->connection()->commit();
		return TRUE;
	}

	/**
	 * 日程表の各日付の勤務データから対象月次タスクを削除して更新
	 *
	 * @param type $tm_id
	 * @param type $p_id
	 * @param type $updated
	 * @return boolean
	 */
	private function changeDutyAssignment($tm_id, $p_id, &$updated)
	{
		// 更新済み
		if (in_array($p_id, $updated) !== FALSE) {
			return TRUE;
		}
		$DutyAssignments = TableRegistry::get('DutyAssignments');
		$duty_assignment = $DutyAssignments->find()->where([
			'da_year_month' => $this->current_year_month,
			'p_id' => $p_id
		])->first();
		if ($duty_assignment !== NULL)
		{
			$change_flag = FALSE;
			$d_data = [];
			foreach ([21,22,23,24,25,26,27,28,29,30,31,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] as $day)
			{
				$col = 'd_'.$day;
				$d_val = $duty_assignment->{$col};
				$col_flag = FALSE;
				if ($d_val != '' && strpos($d_val, $tm_id) !== FALSE) {
					$d_arr = explode(',', $d_val);
					$new_arr = [];
					foreach ($d_arr as $val) {
						$val = trim($val);
						if ($val == $tm_id) {
							$change_flag = TRUE;
							$col_flag = TRUE;
						} else if ($val !== '') {
							$new_arr[] = $val;
						}
					}
					if ($col_flag) {
						// 更新対象
						$d_data[$col] = implode(',', $new_arr);
					}
				}
			}
			if ($change_flag)
			{
				$duty_assignment = $DutyAssignments->patchEntity($duty_assignment, $d_data);
				if ($DutyAssignments->save($duty_assignment) === FALSE) {
					$this->errors = $duty_assignment->errors();
					Log::error($duty_assignment->errors());
					return FALSE;
				}
				$updated[] = $p_id;
			}
		}
		return TRUE;
	}

	/*
	 * 日程表が作成済みかどうか判定する
	 */
	public function isCreatedDutyTable()
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'de_year_month' => $this->current_year_month
		])->first();

		return ($duty_env->status == 2);
	}
}

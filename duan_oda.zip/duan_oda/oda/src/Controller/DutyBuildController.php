<?php
namespace App\Controller;

use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 *
 */
class DutyBuildController extends AppController
{
	public $components = [
		'Duty',
		'Backup'
	];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function index()
	{
		$this->set('sideNavi', ['duty_build'=>'index']);
		$this->setTitle('日程表管理', '作成');
	}

	public function init()
	{
		$this->set('sideNavi', ['duty_build'=>'init']);
		$this->setTitle('日程表管理', '作成 - 初期化');
	}

	public function init_confirm()
	{
		$this->set('sideNavi', ['duty_build'=>'init']);
		$this->setTitle('日程表管理', '作成 - 初期化');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'init']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('duty_year', TRUE, '年を入力してください。')
			->notEmpty('duty_year', '年を入力してください。')
			->add('duty_year', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '年は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 2000 && $value <=2050);
					},
					'message' => '年は2000〜2050を入力してください。'
				],
//				'custom' => [
//					'rule' => [$this, 'duplicateDutyAssignment'],
//					'message' => 'この年月の日程表は初期化済です。'
//				]
			])
			->requirePresence('duty_month', TRUE, '月を入力してください。')
			->add('duty_month', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '月は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 1 && $value <=12);
					},
					'message' => '月は1〜12を入力してください。'
				]
			])
			->notEmpty('duty_month', '月を入力してください。');

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->render('init');
		}
		else
		{
			if ($this->duplicateDutyAssignment() === FALSE) {
				// 初期化済
				$this->set('init_status', 1);
			} else {
				$this->set('init_status', 0);
			}
		}
	}

	public function init_comp()
	{
		$this->set('sideNavi', ['duty_build'=>'init']);
		$this->setTitle('日程表管理', '作成 - 初期化');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'init']);
		}

		$year = $this->request->data('duty_year');
		$month = $this->request->data('duty_month');

		if ($this->duplicateDutyAssignment() === FALSE) {
			// 初期化済なので既存データをクリア
			$this->Duty->clearDutyAssignment();
		}

		// 初期化実行
		if ($this->Duty->initDutyAssignment() === FALSE) {
			$this->set('errors', $this->Duty->errors);
			$this->set('values', $this->request->data);
		}

		// 初期化後バックアップ
		if (POST_INIT_BACKUP) {
			$year_month = sprintf("%04d%02d", $year, $month);
			if ($this->Backup->createBackup(BACKUP_TYPE_POST_INIT, $year_month) === FALSE) {
				$this->set('errors', $this->Backup->errors());
				$this->set('values', $this->request->data);
			}
		}
	}

	/**
	 * 作成（更新）画面
	 */
	public function build()
	{
		$this->set('sideNavi', ['duty_build'=>'build']);
		$this->setTitle('日程表管理', '作成 - 作成');
		$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_INIT));
	}

	/**
	 * 作成（更新）確認画面
	 */
	public function build_confirm()
	{
		$this->set('sideNavi', ['duty_build'=>'build']);
		$this->setTitle('日程表管理', '作成 - 作成');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('duty_year_month', TRUE, '年月を選択してください。')
			->requirePresence('duty_fire_date', TRUE, '消防兼務開始日を選択してください。')
			->requirePresence('duty_team_id', TRUE, 'チームを選択してください。');

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_INIT));
			$this->render('build');
		}
		else
		{
			// 状態を確認する
			$duty_year_month = $this->request->data['duty_year_month'];
			$duty_year = (int)substr($duty_year_month, 0, 4);
			$duty_month = (int)substr($duty_year_month, 4, 2);
			$duty_env = TableRegistry::get('DutyEnvs')->find()->where([
				'de_year_month' => sprintf("%04d%02d", $duty_year, $duty_month)
			])->first();
			$status = 0;
			$holiday_flag = 0;
			$task_month_total = 0;
			if ($duty_env === NULL) {
				// 初期化まだ
			} else if ($duty_env->status == DE_STATUS_INIT) {
				// 初期化済＞作成
				$status = 1;
				$holiday_flag = $duty_env->holiday_flag;
				$task_month_total = $this->getTaskMonthTotal();
			} else if ($duty_env->status == DE_STATUS_BUILD) {
				// 作成済＞更新
				$status = 2;
				$holiday_flag = $duty_env->holiday_flag;
			}
			$_POST['duty_env_status'] = $status;
			$this->set('duty_env_status', $status);
			$this->set('task_month_total', $task_month_total);
			$this->set('holiday_flag', $holiday_flag);
			//$this->Duty->buildDutyAssignment();
			// 完了画面
		}
	}

	/**
	 * 作成（更新）実行
	 */
	public function build_comp()
	{
		$this->set('sideNavi', ['duty_build'=>'build']);
		$this->setTitle('日程表管理', '作成 - 作成');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build']);
		}

		$year_month = $this->request->data['duty_year_month'];

		// 日程表作成前バックアップ
		if (PRE_BUILD_BACKUP) {
			if ($this->Backup->createBackup(BACKUP_TYPE_PRE_BUILD, $year_month) === FALSE) {
				$this->set('errors', $this->Backup->errors());
				return;
			}
		}
		// 日程表作成
		if ($this->Duty->buildDutyAssignment() === FALSE) {
			$this->set('errors', $this->Duty->errors);
		}
	}

	/**
	 * 作成（月次タスクの名前指定追加）
	 */
	public function build_add()
	{
		$this->set('sideNavi', ['duty_build'=>'build_add']);
		$this->setTitle('日程表管理', '作成 - 作成（月次タスク追加）');
		$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_BUILD));
		$this->render('build_add');
	}

	/**
	 * 作成（月次タスクの名前指定追加）確認画面
	 */
	public function build_add_confirm()
	{
		$this->set('sideNavi', ['duty_build'=>'build_add']);
		$this->setTitle('日程表管理', '作成 - 作成（月次タスク追加）');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build_add']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('duty_year_month', TRUE, '年月を選択してください。');

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->build_add();
		}
		else
		{
			// 状態を確認する
			$duty_year_month = $this->request->data['duty_year_month'];
			$duty_year = (int)substr($duty_year_month, 0, 4);
			$duty_month = (int)substr($duty_year_month, 4, 2);
			$duty_env = TableRegistry::get('DutyEnvs')->find()->where([
				'de_year_month' => sprintf("%04d%02d", $duty_year, $duty_month)
			])->first();
			$status = 0;
			$holiday_flag = 0;
			$task_month_total = 0;
			if ($duty_env === NULL) {
				// 初期化まだ
			} else if ($duty_env->status == DE_STATUS_INIT) {
				// 初期化済＞作成
				$status = 1;
				$holiday_flag = $duty_env->holiday_flag;
				$task_month_total = $this->getTaskMonthTotal();
			} else if ($duty_env->status == DE_STATUS_BUILD) {
				// 作成済＞更新
				$status = 2;
				$holiday_flag = $duty_env->holiday_flag;
			}
			$_POST['duty_env_status'] = $status;
			$this->set('duty_env_status', $status);
			$this->set('task_month_total', $task_month_total);
			$this->set('holiday_flag', $holiday_flag);
			//$this->Duty->buildDutyAssignment();
			// 完了画面
		}
	}

	/**
	 * 作成（月次タスクの名前指定追加）完了画面
	 */
	public function build_add_comp()
	{
		$this->set('sideNavi', ['duty_build'=>'build_add']);
		$this->setTitle('日程表管理', '作成 - 作成（月次タスク追加）');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build_add']);
		}

		// 日程表作成（月次タスクの名前指定追加）
		if ($this->Duty->buildAddDutyAssignment() === FALSE) {
			$this->set('errors', $this->Duty->errors);
		}
	}

	/**
	 * 整合性チェック
	 */
	public function check()
	{
		$this->set('sideNavi', ['duty_build'=>'check']);
		$this->setTitle('日程表管理', '作成 - 整合性チェック');

		if ($this->request->is('POST'))
		{
			// 入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('duty_year_month', TRUE, '年月を選択してください。');

			$errors = $validator->errors($this->request->data());

			if ($errors)
			{
				$this->set('errors', $errors);
			}
			else
			{
				// 初期化実行
				if ($this->Duty->checkDutyAssignment() === FALSE) {
					$this->set('check_errors', $this->Duty->getCheckErrors());
				}
				// 完了画面
				$this->render('check_confirm');
			}
		}

		$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_BUILD));
	}

	/**
	 * 既に初期化済かを確認
	 * @return boolean
	 */
	public function duplicateDutyAssignment()
	{
		$duty_year = $this->request->data['duty_year'];
		$duty_month = $this->request->data['duty_month'];
		if (empty($duty_year) || empty($duty_month)) {
			return TRUE;
		}

		$duty_env = TableRegistry::get('DutyEnvs')->find()->where([
			'de_year_month' => sprintf("%04d%02d", $duty_year, $duty_month)
		])->first();

		if ($duty_env === NULL) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	private function getTaskMonthTotal()
	{
		$duty_year_month = $this->request->data['duty_year_month'];

		$total = TableRegistry::get('TaskMonths')->find()->select([
			'count' => 'COUNT(*)'
		])->where([
			'tm_year_month' => $duty_year_month
		])->first();

		return $total->count;
	}

	private function getDutyEnvsList($status)
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');

		if ($status == DE_STATUS_BUILD) {
			$wh = [
				'status' => $status
			];
		} else {
			$wh = [
				'status >=' => $status
			];
		}

		$duty_env_list = $DutyEnvs->find()->where($wh)->order([
			'de_year_month' => 'DESC'
		])->limit(10)->toArray();

		return $duty_env_list;
	}

	/**
	 * 集計
	 */
	public function build_totalize()
	{
		$this->set('sideNavi', ['duty_build'=>'build_totalize']);
		$this->setTitle('日程表管理', '作成 - 再集計');
		$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_BUILD));
	}

	/**
	 * 集計
	 */
	public function build_totalize_confirm()
	{
		$this->set('sideNavi', ['duty_build'=>'build_totalize']);
		$this->setTitle('日程表管理', '作成 - 再集計');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build_totalize']);
		}

		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('duty_year_month', TRUE, '年月を選択してください。');

		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->build_totalize();
		}
		else
		{
			// 状態を確認する
			$duty_year_month = $this->request->data['duty_year_month'];
			$duty_year = (int)substr($duty_year_month, 0, 4);
			$duty_month = (int)substr($duty_year_month, 4, 2);
			$duty_env = TableRegistry::get('DutyEnvs')->find()->where([
				'de_year_month' => sprintf("%04d%02d", $duty_year, $duty_month)
			])->first();
			$status = 0;
			$holiday_flag = 0;
			$task_month_total = 0;
			if ($duty_env === NULL) {
				// 初期化まだ
			} else if ($duty_env->status == DE_STATUS_INIT) {
				// 初期化済＞作成
				$status = 1;
				$holiday_flag = $duty_env->holiday_flag;
				$task_month_total = $this->getTaskMonthTotal();
			} else if ($duty_env->status == DE_STATUS_BUILD) {
				// 作成済＞更新
				$status = 2;
				$holiday_flag = $duty_env->holiday_flag;
			}
			$_POST['duty_env_status'] = $status;
			$this->set('duty_env_status', $status);
			$this->set('task_month_total', $task_month_total);
			$this->set('holiday_flag', $holiday_flag);
			//$this->Duty->buildDutyAssignment();
			// 完了画面
		}
	}

	/**
	 * 集計
	 */
	public function build_totalize_comp()
	{
		$this->set('sideNavi', ['duty_build'=>'build_totalize']);
		$this->setTitle('日程表管理', '作成 - 集計');

		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'build_totalize']);
		}

		// 日程表作成（再集計）
		$this->Duty->buildRetotalize();
	}

}

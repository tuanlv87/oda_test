<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\UsersTable;
use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Network\Exception\NotFoundException;

/**
 * Users Controller
 *
 * @property UsersTable $Users
 */
class UsersController extends AppController
{
    public $helpers = [
        'Paginator'
    ];

    public $components = [
        'Upload',
        'Csv'
    ];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

    /**
     * Index method
     *
     * @return void
     */
    public function index()
    {
        $this->set('sideNavi', array('user'=>'index'));
        $this->setTitle('利用者管理', 'メニュー');
    }

    public function table()
    {
        Configure::load('list_settings');

        $this->paginate = [
            'limit' => 50,
            'order' => ['u_id' => 'asc']
        ];

		// admin以外（管理者）は自分のデータのみ
		if ($this->userInfo['auth_type'] != AUTH_TYPE_ADMIN)
		{
			$query = $this->Users->find()->where(['u_id' => $this->userInfo['u_id']]);

			$this->set('primary_list', $this->paginate($query));
		}
		else
		{
			 $this->set('primary_list', $this->paginate($this->Users));
		}


        $this->set('list_settings', Configure::read('list_settings.user'));

        $this->set('sideNavi', array('user'=>'table'));
        $this->setTitle('利用者管理', '一覧');
    }

    public function form()
    {
        $this->set('sideNavi', array('user'=>'form'));
        $this->setTitle('利用者管理', '登録・更新');
    }

    /**
     * 登録画面
     */
    public function add()
    {
        Configure::load('form_settings');
        $this->set('form_settings', Configure::read('form_settings.user'));

        $this->set('values', $this->request->data);
        $this->set('sideNavi', array('user'=>'form'));
        $this->setTitle('利用者管理', '登録');
    }

    public function add_confirm()
    {
        return $this->_add('confirm');
    }

    public function add_save()
    {
        return $this->_add('save');
    }

    private function _add($mode)
    {
        if ($this->request->is('POST') === FALSE) {
            return $this->redirect(['action' => 'add']);
        }

		$this->set('sideNavi', ['user'=>'form']);
		$this->setTitle('利用者管理', '登録');

        Configure::load('form_settings');
        $this->set('form_settings', Configure::read('form_settings.user'));

        $ret = $this->request->data('ret');

        $user = $this->Users->newEntity();
        $user = $this->Users->patchEntity($user, $this->request->data, ["validate" => "custom"]);
		$this->Users->isRules($user);

        if ($user->errors())
        {
            $this->set('errors', $user->errors());
            $this->set('values', $this->request->data);
            $this->set('ret', $ret);
            return $this->render('add');
        }
        else if ($mode === 'save')
        {
            if ($this->Users->save($user) === FALSE) {
				$this->set('errors', $user->errors());
				Log::error('新規登録に失敗しました。');
            }
        }

        $this->set('values', $this->request->data);
        $this->set('ret', 'form');
    }

    /**
     * 編集画面
     *
     * @param int $id u_id
     */
    public function edit($id = NULL)
    {
		$this->set('sideNavi', ['user'=>'form']);
		$this->setTitle('利用者管理', '更新');

        Configure::load('form_settings');
        $this->set('form_settings', Configure::read('form_settings.user'));

        $user = NULL;
        $u_id = '';
        $ret = '';
        if ($this->request->is('POST'))
        {
            $u_id = $this->request->data('_u_id');
            $ret = $this->request->data('ret');
        }
        else
        {
			$u_id = $this->request->query('u_id');
			$ret = $this->request->query('ret');
        }

        if ($u_id != '') {
            $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        }

        if ($user === NULL)
        {
            if (empty($u_id)) {
                $this->set('errors', ['u_id' => ['更新する利用者IDを入力してください。']]);
            } else {
                $this->set('errors', ['u_id' => ['該当する利用者情報は存在しません。']]);
                $this->set('u_id', $u_id);
            }
            return $this->render('form');
        }
        else if ($this->request->is('POST'))
        {
			$this->request->data['created'] = $user->created;
			$this->request->data['modified'] = $user->modified;
            $this->set('values', $this->request->data);
        }
        else
        {
			$user->password_confirm = $user->password;
            $this->set('values', $user);
        }

        $this->set('_u_id', $u_id);
        $this->set('ret', $this->createReturnUrl($ret, 'form'));
    }

    public function edit_confirm()
    {
        return $this->_edit('confirm');
    }

    public function edit_save()
    {
        return $this->_edit('save');
    }

    private function _edit($mode)
    {
        if ($this->request->is('POST') === FALSE) {
            return $this->redirect(['action' => 'add']);
        }

        Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.user');
        $this->set('form_settings', $form_settings);
		$this->set('sideNavi', ['user'=>'form']);
		$this->setTitle('利用者マスター', '更新');

        $u_id = $this->request->data('_u_id');
        $ret = $this->request->data('ret');

        if (empty($u_id)) {
            throw new FatalErrorException("u_idの指定がありません。");
        }

        $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        if ($user === NULL) {
            throw new FatalErrorException("利用者管理情報が見つかりません。");
        }
        $originals = clone $user;
		$this->filterRequestData($form_settings);
        $user = $this->Users->patchEntity($user, $this->request->data, ["validate" => "custom"]);
		$this->Users->isRules($user);

        if ($user->errors())
        {
			$this->request->data['created'] = $user->created;
			$this->request->data['modified'] = $user->modified;

            $this->set('errors', $user->errors());
            $this->set('values', $this->request->data);
            $this->set('_u_id', $u_id);
            $this->set('ret', $ret);
            return $this->render('edit');
        }
        else if ($mode === 'save')
        {
            if ($this->Users->save($user) === FALSE) {
				$this->set('errors', $user->errors());
				Log::error('更新に失敗しました。[u_id='.$u_id.']');
            }
        }

        $this->set('originals', $originals);
        $this->set('values', $this->request->data);
        $this->set('_u_id', $u_id);
        $this->set('ret', $this->createReturnUrl($ret, 'form'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return void Redirects to index.
     * @throws NotFoundException When record not found.
     */
    public function delete()
    {
        $this->set('sideNavi', ['user'=>'delete']);
        $this->setTitle('利用者管理', '削除');
    }

    public function delete_confirm($id = null)
    {
		$this->set('sideNavi', ['user'=>'delete']);
		$this->setTitle('利用者管理', '削除');

        Configure::load('form_settings');
        $this->set('form_settings', Configure::read('form_settings.user'));

        $user = NULL;
        $u_id = NULL;
        $ret = '';
        if ($this->request->is('POST'))
        {
			$u_id = $this->request->data('_u_id');
			$ret = $this->request->data('ret');
        }
        else
        {
			$u_id = $this->request->query('u_id');
			$ret = $this->request->query('ret');
        }

        if ($u_id) {
            $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        }
        if ($user === NULL)
        {
            if (empty($u_id)) {
                $this->set('errors', ['u_id' => ['削除する利用者IDを入力してください。']]);
            } else {
                $this->set('errors', ['u_id' => ['該当する利用者IDは存在しません。']]);
                $this->set('u_id', $u_id);
            }
            return $this->render('delete');
        }
		else
		{
			if ($user->auth_type == 1) {
				$this->set('errors', ['u_id' => ['admin権限の利用者は削除できません。']]);
				$this->set('u_id', $u_id);
				return $this->render('delete');
			}
		}

        $this->set('values', $user);
        $this->set('_u_id', $u_id);
        $this->set('ret', $this->createReturnUrl($ret, 'delete'));
    }

    public function delete_save()
    {
        if ($this->request->is('POST') === FALSE) {
            return $this->redirect(['action' => 'delete']);
        }

		$this->set('sideNavi', ['user'=>'delete']);
		$this->setTitle('利用者管理', '削除');

        $u_id = $this->request->data['_u_id'];
        $ret = $this->request->data['ret'];

        if ($u_id) {
            $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        }
        if ($user === NULL) {
            throw new FatalErrorException('利用者情報が存在しません。[u_id='.$u_id.']');
        }
        //$user = $this->Users->get($user->id);
        if ($this->Users->delete($user) === FALSE) {
            Log::error('利用者情報の削除に失敗しました。[u_id='.$u_id.']');
			$this->set('errors', $user->errors());
        }

        $this->set('ret', $this->createReturnUrl($ret, 'delete'));
    }


    /**
     * 一括登録
     */
    public function batch()
    {
		$this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

//        $tmp_csv_file = '';
//
//        if ($this->request->is('POST'))
//        {
//            if (isset($this->request->data['file']))
//            {
//                // アップロード時
//                if ($this->Upload->isError())
//                {
//                    Log::write('error', $this->Upload->getErrorMessage());
//                }
//                else
//                {
//                    $tmp_csv_file = $this->Upload->getFile('UM');
//                    $fp = fopen($tmp_csv_file, 'r');
//                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
//                    {
//                        $this->set('csv_errors', $this->Csv->getErrors());
//                        Log::debug($this->Csv->getErrors());
//                    }
//                }
//            }
//            else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//            {
//                // エラー変更時
//                $tmp_csv_file = $this->request->data['tmp_csv_file'];
//                if (file_exists($tmp_csv_file))
//                {
//                    $this->Csv->setUpdateValues($this->request->data['values']);
//                    $fp = fopen($tmp_csv_file, 'r');
//                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
//                    {
//                        $this->set('csv_errors', $this->Csv->getErrors());
//                        Log::debug($this->Csv->getErrors());
//                    }
//                }
//            }
//        }
//
//        $this->set('tmp_csv_file', $tmp_csv_file);
    }

    public function batch_confirm()
    {
        $this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

        $tmp_csv_file = '';
        $data = [];

        if ($this->request->is('POST'))
        {
            if (isset($this->request->data['file']))
            {
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
                {
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
                }
                else
                {
                    $tmp_csv_file = $this->Upload->getFile('UM');
                    $fp = fopen($tmp_csv_file, 'r');
                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
                    {
                        $this->set('csv_errors', $this->Csv->getErrors());
                        Log::debug($this->Csv->getErrors());
                    }
                    $data = $this->Csv->getData();
                }
            }
        }

        $this->set('tmp_csv_file', $tmp_csv_file);
        $this->set('data', $data);
    }

    public function batch_save()
    {
        $this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

        $tmp_csv_file = $this->request->data['tmp_csv_file'];
        if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
        {
            throw new FatalErrorException('一時ファイルが見つかりません。');
        }
        $fp = fopen($tmp_csv_file, 'r');
        if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
        {
            $this->set('csv_errors', $this->Csv->getErrors());
           Log::debug($this->Csv->getErrors());
            $this->set('tmp_csv_file', $tmp_csv_file);
            $this->set('data', $this->Csv->getData());
            return $this->render('batch_confirm');
        }
        else
        {
            $this->Csv->import($this->Users, 'u_id');
            $this->set('total', $this->Csv->getTotal());
        }
    }

    public function download()
    {
        $this->set('sideNavi', ['user'=>'download']);
        $this->setTitle('利用者管理', 'ダウンロード');

        if ($this->request->is('POST'))
        {
            $list = $this->Users->find()->order([
				'u_id' => 'ASC'
			])->toArray();
            $this->Csv->setData($list);
            $this->Csv->download('user', 'UM_'.date("Ymd").'.csv');
        }
    }
}

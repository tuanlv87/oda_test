<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\TableRegistry;
use Cake\View\Exception\MissingTemplateException;
use Cake\Event\Event;
use Cake\Error\Debugger;

class DocumentationController extends AppController {

    public function beforeFilter(Event $event){
        parent::beforeFilter($event);

        $this->loadComponent('Excel');
        Configure::load('documentation_settings');
        Configure::load('message_settings');
        $this->errorMessages = Configure::read('message_settings.error_messages');
        $this->Session = $this->request->session();
        $this->userId = $this->userInfo["u_id"];

    }

    /**
     * トップページ
     *
     * @param なし
     * @return なし
     */
    public function index() {
        $documents = Configure::read('documentation_settings.documents');
        $this->set("documents", $documents);

        if ($this->Session->read('document.Target_Date') != "")
        {
            $defautDate = date("Y/m/d", strtotime($this->Session->read('document.Target_Date')));
            $defautYear = date("Y", strtotime($this->Session->read('document.Target_Date')));
            $this->Session->delete('document.Target_Date');
        }
        else
        {
            $defautDate = date("Y/m/d");
            $defautYear = date("Y");
        }

        $this->set("defautDate", $defautDate);
        $this->set("defautYear", $defautYear);
        $this->set('title_for_layout', "資料作成");
    }

    /**
     * 印刷する資料の設定を行う
     *
     * @param なし
     * @return なし
     */
    public function setting() {
        if ($this->request->is("post")) {
            $req = $this->request->data;
        } else {
            throw new \Exception($this->errorMessages["E001"]);
        }

        $documents = Configure::read('documentation_settings.documents');
        if (!isset($documents[$req["document"]])) {
            throw new \Exception($this->errorMessages["E001"]);
        }

        // 画面表示に必要なデータを取得する
        switch ($req["document"]) {
            case "A011" :
                $dutyAssignments = TableRegistry::get('DutyAssignments');
                $dutyAssignmentDatas = $dutyAssignments->find()
                                                       ->group(["team_id"])
                                                       ->order(["team_id"])
                                                       ->toArray();

                $teamList = [];
                foreach ($dutyAssignmentDatas as $row) {
                    $teamList[$row["team_id"]] = $row["team_id"];
                }

                $this->set("teamList", $teamList);
                break;
            case "A012" :
                $dutyAssignments = TableRegistry::get('DutyAssignments');

                $dutyAssignmentDatas = $dutyAssignments->find()
                                                       ->group(["team_id"])
                                                       ->order(["team_id"])
                                                       ->toArray();
                $teamList = [];
                foreach ($dutyAssignmentDatas as $row) {
                    $teamList[$row["team_id"]] = $row["team_id"];
                }
                $this->set("teamList", $teamList);

                $dutyAssignmentDatas = $dutyAssignments->find()
                                                       ->group(["crew_id"])
                                                       ->order(["crew_id"])
                                                       ->toArray();

                $crewList = [];
                foreach ($dutyAssignmentDatas as $row) {
                    $crewList[$row["crew_id"]] = $row["crew_id"];
                }

                $this->set("crewList", $crewList);
                break;
        }

        $this->set('document', $req["document"]);
        $this->set('documents', $documents);
        $this->set('title_for_layout', "資料作成");

        // 選択した年月日を画面に渡す
        $this->set('Target_Date_Year', $req["Date_Year"]);
        $this->set('Target_Date_Month', $req["Date_Month"]);
        $this->set('Target_Date', date("Y年n月度", strtotime($req["Date_Year"] . $req["Date_Month"] . "01")));


        $this->Session->write('document.Target_Date', $req["Date_Year"] . "/" . $req["Date_Month"] . "/01");

        $this->render($req["document"]);
    }

    /**
     * A020の作成時間を求める
     *
     */
    public function createCheckA020() {
        if (!$this->request->is('ajax')) {
            throw new \Exception($this->errorMessages["E001"]);
        }

        // ajaxで返すためレンダーしない
        $this->autoRender = false;

        // リクエストデータを取得
        $req = $this->request->data;

        // 出力年度と開始年度を設定する
        $req["ymTarget"] = $req["Target_Date_Year"] . $req["Target_Date_Month"];
        $req["ymStart"] = date("Ym", strtotime($req["Target_Date_Year"] . $req["Target_Date_Month"] . "01 -1month"));

        $dutyAssignments = TableRegistry::get('DutyAssignments');

        switch($req["type"]) {
            case "all":
                // 全員
                $dutyAssignmentDatas = $dutyAssignments->find()
                                                       ->where(["da_year_month" => $req["ymTarget"]])
                                                       ->order(["document_order" => "ASC"])
                                                       ->toArray();
                break;

            case "person":
                // 個人指定
                $dutyAssignmentDatas = $dutyAssignments->find()
                                       ->where(["p_id" => $req["p_id"], "da_year_month" => $req["ymTarget"]])
                                       ->order(["document_order" => "ASC"])
                                       ->toArray();
                break;

            case "date":
                // 日付指定
                $day = date("Y") . "/" . $req["Date_Month"] . "/". $req["Date_Day"];
                $dutyAssignmentDatas = $dutyAssignments->find()
                                        ->where(["modified >= " => $day, "da_year_month" => $req["ymTarget"]])
                                        ->order(["document_order" => "ASC"])
                                        ->toArray();
                break;

            default;
                $error = $this->errorMessages["E001"];
                return false;
        }

        // 処理時間
        $time = ceil(count($dutyAssignmentDatas) * Configure::read('documentation_settings.a020_create_time'));
        $res = ["result" => $time];

        $json = json_encode($res);
        echo $json;
    }

    /**
     * エクセルファイル作成（共通）
     *
     * @param なし
     * @return なし
     */
    public function create() {
        if (!$this->request->is('ajax')) {
            throw new \Exception($this->errorMessages["E001"]);
        }

        $documents = Configure::read('documentation_settings.documents');

        // 独自のエラーハンドルを設定
        set_error_handler(array($this, "myErrorHandler"));

        // ajaxで返すためレンダーしない
        $this->autoRender = false;

        // リクエストデータを取得
        $req = $this->request->data;

        // 出力年度と開始年度を設定する
        $req["ymTarget"] = $req["Target_Date_Year"] . $req["Target_Date_Month"];
        $req["ymStart"] = date("Ym", strtotime($req["Target_Date_Year"] . $req["Target_Date_Month"] . "01 -1month"));

        try {
            if (isset($req["document"]) && isset($documents[$req["document"]])) {
                $error = "";
                // ファイル作成（個別のコンポーネントを呼び出す）
                $this->loadComponent($req['document'],  ['className' => "Documentation/{$req['document']}"]);
                $result = $this->{$req['document']}->createExcel($req, $this->userId, $fileName, $error);
            } else {
                // 存在しないタイプの帳票が要求された場合はエラーとする
                $result = false;
                $fileName = "";
                $error = $this->errorMessages["E001"];
            }

        } catch (\Exception $e) {
            $result = false;
            $fileName = "";
            $error = "ファイル作成に失敗しました。下記の情報をシステム管理者に連絡してください。\n";
            $error .= "ERROR [errfile={$e->getFile()},errline={$e->getLine()}] {$e->getMessage()}\n";

            $this->log($error);
            $this->log($this->dump_trace($e));
        }

        $array = array("result"   => $result,
                       "fileName" => $fileName,
                       "error"    => $error
                      );

        $json = json_encode($array);
        echo $json;
    }

    /**
     * タウンロード処理（共通）
     *
     * @param $fileName ファイル名（拡張子なし）
     * @return なし
     */
    public function downloadExcel($fileName) {
        // 別ディレクトリのファイルをダウンロードさせないようにチェック
        if (strpos($fileName, ".")) {
            throw new \Exception($this->errorMessages["E001"]);
        }

        $this->Excel->downloadExcel($this->userId, $fileName, "Excel2007");
    }

    /**
     * タウンロード処理（共通）
     *
     * @param $fileName ファイル名（拡張子なし）
     * @return なし
     */
    public function downloadZip($fileName) {
        // 別ディレクトリのファイルをダウンロードさせないようにチェック
        if (strpos($fileName, ".")) {
            throw new \Exception($this->errorMessages["E001"]);
        }

        $zipFilePath = $this->Excel->_getDirectory($this->userId);

        $zipFileName =  $fileName . ".zip";

        header('Content-Type: application/zip; name="' . $zipFileName . '"');
        header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
        header('Content-Length: '.filesize($zipFilePath . $zipFileName));
        echo file_get_contents($zipFilePath . $zipFileName);
        exit();
    }

    // エラーハンドラ関数
    function myErrorHandler($errno, $errstr, $errfile, $errline)
    {
        if (!(error_reporting() & $errno)) {
            // error_reporting 設定に含まれていないエラーコードです
            return;
        }

        $error = "ファイル作成に失敗しました。下記の情報をシステム管理者に連絡してください。\n";

        switch ($errno) {
        case E_USER_ERROR:
            $error .= "ERROR [errfile={$errfile},errline={$errline},errno={$errno}] $errstr\n";
            break;

        case E_USER_WARNING:
            $error .= "WARNING [errfile={$errfile},errline={$errline},errno={$errno}] $errstr\n";
            break;

        case E_USER_NOTICE:
            $error .= "NOTICE [errfile={$errfile},errline={$errline},errno={$errno}] $errstr\n";
            break;

        default:
            $error .= "Unknown error type: [errfile={$errfile},errline={$errline},errno={$errno}] $errstr\n";
            break;
        }

        // Cakeのエラーハンドルを上書きしてしまうため、
        // ここでエラーログファイルに書き込む
        $this->log($error);

        // トレースログも書き込んでおく
        $trace = Debugger::trace([
                'start' => 1,
                'format' => 'log'
            ]);
        $this->log($trace . "\r\n");

        // 画面にエラーをjson形式で返却
        $res = ["result"   => false,
                "fileName" => "",
                "error"    => $error
               ];

        $json = json_encode($res);
        echo $json;

        exit();
    }

    /*
     * トレースログを取得する
     *
     * @param $e EXCEPTION
     * @return トレースログ
     */
    private function dump_trace($e) {
        $trace = $e->getTrace();
        $result = "";

        array_shift($trace);
        foreach($trace as $i => $item) {
            if (isset($item['file'])) {
                $result .= "{$item['file']}:{$item['function']}() line {$item['line']}\n";
            }
        }

        return $result;
    }
}

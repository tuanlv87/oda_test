<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\I18n\Time;
use Cake\Network\Exception\UnauthorizedException;
use Cake\ORM\TableRegistry;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{
	public $viewClass = 'App\View\SmartyView';

	public $userInfo = NULL;

	public $current_year_month;
	public $current_year;
	public $current_month;

    public function initialize()
    {
		$this->loadComponent('Cookie');
		$this->loadComponent('Auth', [
			'loginAction' => [
				'controller' => '',
				'action' => 'login'
			],
			'loginRedirect' => [
				'controller' => '',
				'action' => 'index'
			],
			'logoutRedirect' => [
				'controller' => '',
				'action' => 'login'
			],
			'authError' => 'このエラーは保護されたWebサイトにユーザがアクセスしようとした際に表示されます。',
			'authenticate' => [
				'Form' => [
					'fields' => ['username' => 'u_id'],
					'passwordHasher' => ['className' => 'App\Controller\Component\Auth\TextPasswordHasher']
				]
			]
		]);
		
		Configure::write('Session', [
			'defaults' => 'php',
			'timeout' => 1440,
			'autoRegenerate' => TRUE,
			'ini' => [
				'session.gc_maxlifetime' => 86400
			]
		]);
		ini_set('session.gc_maxlifetime', 86400);
    }

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		
        // ユーザ情報の読み込み
		$this->userInfo = $this->Auth->user();
		if ($this->userInfo)
		{
			$this->set('userInfo', $this->userInfo);
			Configure::write('logged_u_id', $this->userInfo['u_id']);
		}
	}

	public function setTitle($title, $sub_title=NULL)
	{
		if ($sub_title !== NULL) {
			$title = $title . ' ' . $sub_title;
		}
		$this->set('title_for_layout', $title);
	}

	public function createReturnUrl($ret, $default='')
	{
		if (empty($ret)) {
			$ret = $default;
		} else {
			///personnels/table.page:2
			$ret = str_replace(['.', ':', ';'], ['?', '=', '&'], $ret);
		}
		return $ret;
	}

	public function currentYear()
	{
		// @TODO:とりあえず現在年
		$this->current_year = date('Y', time());

		$this->set('current_year', $this->current_year);

		return $this->current_year;
	}

	public function currentYearMonth()
	{
		// @TODO:とりあえず最新の作成済みの日程表年月
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'status >=' => DE_STATUS_BUILD
		])->order([
			'de_year_month' => 'DESC'
		])->first();

		if ($duty_env === NULL) {
			return FALSE;
		}

		$this->current_year_month = $duty_env->de_year_month;
		$this->current_year = substr($this->current_year_month, 0, 4);
		$this->current_month = substr($this->current_year_month, 4, 2);

		$this->set('current_year_month', $this->current_year_month);

		return TRUE;
	}

	public function getYearMonthList($status=0)
	{
		if ($status === 0) {
			$status = DE_STATUS_BUILD;
		}
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'status >=' => $status
		])->order([
			'de_year_month' => 'DESC'
		])->toArray();

		$list = [];
		if (count($duty_env)>0) {
			foreach ($duty_env as $d) {
				$list[] = $d->de_year_month;
			}
		}
		return $list;
	}

	public function dateToYearMonth($date)
	{
		$time = new Time($date);
		if ($time->day >= DAT_START_DAY) {
			$time->modify('+1 month');
			$current_year = $time->year;
			$current_month = $time->month;
		} else {
			$current_year = $time->year;
			$current_month = $time->month;
		}
		$current_year_month = sprintf("%04d%02d", $current_year, $current_month);
		return $current_year_month;
	}

	public function filterRequestData(array &$form_settings)
	{
		foreach ($form_settings as $col => $d) {
			if (isset($this->request->data[$col]) && isset($d['filter'])) {
				if (! is_array($d['filter'])) {
					$d['filter'] = array($d['filter']);
				}
				foreach ($d['filter'] as $filter) {
					$arr = explode(':', $filter);
					if ($arr[0] === 'mb_convert_kana') {
						$this->request->data[$col] = mb_convert_kana($this->request->data[$col], $arr[1]);
					} else if ($arr[0] === 'removeSpace') {
						$this->request->data[$col] = $this->removeSpace($this->request->data[$col]);
					} else if ($arr[0] === 'convertName') {
						$this->request->data[$col] = $this->convertName($this->request->data[$col]);
					} else if ($arr[0] === 'yearMonth') {
						$val = str_replace(['-','/'], '', $this->request->data[$col]);
						$len = strlen($val);
						if ($len>0) {
							if ($len == 5) {
								$val = sprintf("%04d%02d", substr($val, 0, 4), substr($val, 4));
							}
						}
						$this->request->data[$col] = $val;
					} else if ($arr[0] === 'time') {
						if ($this->request->data[$col] != '') {
							$times = explode(':', $this->request->data[$col], 2);
							if (isset($times[1]) === FALSE) {
								$times[1] = 0;
							}
							$this->request->data[$col] = sprintf("%02d:%02d", $times[0], $times[1]);
						}
					}
				}
			}
		}
	}

	public function removeSpace($val)
	{
		return str_replace([' ', '　'], '', $val);
	}

	/**
	 * 月次タスクマスタの入力社員名の区切り文字を変換
	 *
	 * @param string $val
	 * @return string
	 */
	public function convertName($val)
	{
		return str_replace([',','、'], ';', $val);
	}

	/**
	 * 権限の確認
	 * 各ControllerのbeforeFilterに追加
	 * 
	 * @throws UnauthorizedException
	 */
	protected function isAuthorityRead()
	{
		if ($this->userInfo['auth_type'] == AUTH_TYPE_USER)
		{
			$auth_allow_read_user = Configure::read('auth_allow_read_user');

			$controller = $this->request->params['controller'];
			$action = $this->request->params['action'];

			if (isset($auth_allow_read_user[$controller]) === FALSE
					|| in_array($action, $auth_allow_read_user[$controller]) === FALSE)
			{
				throw new UnauthorizedException("読み取り権限がありません。");
			}
		}
		else if ($this->userInfo['auth_type'] == AUTH_TYPE_MANAGER)
		{
			$auth_allow_read_manager = Configure::read('auth_allow_read_manager');

			$controller = $this->request->params['controller'];
			$action = $this->request->params['action'];

			if (isset($auth_allow_read_manager[$controller])
					&& in_array($action, $auth_allow_read_manager[$controller]) === FALSE)
			{
				throw new UnauthorizedException("読み取り権限がありません。");
			}
		}
	}
}

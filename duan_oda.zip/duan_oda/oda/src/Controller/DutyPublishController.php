<?php
namespace App\Controller;

use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 *
 */
class DutyPublishController extends AppController
{
	public $components = [
		'Backup'
	];

	public function initialize()
	{
		parent::initialize();

		$this->set('sideNavi', ['duty_publish'=>'index']);
		$this->setTitle('日程表管理', '日程表発簡');
	}

	public function index()
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$env_list = $DutyEnvs->find()->where([
			'status' => DE_STATUS_BUILD
		])->order([
			'de_year_month' => 'DESC'
		])->limit(10)->toArray();
		$this->set('duty_env_list', $env_list);
	}

	public function form()
	{
		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('year_month', TRUE, '年月を選択してください。')
			->notEmpty('year_month', '年月を選択してください。');

		$errors = $validator->errors($this->request->query);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->index();
			$this->render('index');
		}
		else
		{

		}
	}

	public function form_save()
	{
		// 入力チェック
		$validator = new Validator();
		$validator
			->requirePresence('year', TRUE, '年を入力してください。')
			->notEmpty('year', '年を入力してください。')
			->add('year', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '年は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 2000 && $value <=2050);
					},
					'message' => '年は2000〜2050を入力してください。'
				]
			])
			->requirePresence('month', TRUE, '月を入力してください。')
			->notEmpty('month', '月を入力してください。')
			->add('month', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '月は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						return ($value >= 1 && $value <=12);
					},
					'message' => '月は1〜12を入力してください。'
				]
			])
			->requirePresence('day', TRUE, '日を入力してください。')
			->notEmpty('day', '日を入力してください。')
			->add('day', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => '日は数値で入力してください。'
				],
				'valid' => [
					'rule' => function($value, $content) {
						if ($value === '') return TRUE;
						if (isset($content['data']['year']) && $content['data']['year']!=''
								&& isset($content['data']['month']) && $content['data']['month']!='')
						{
							if (checkdate($content['data']['month'], $value, $content['data']['year'])) {
								return TRUE;
							} else {
								return FALSE;
							}
						}
						return TRUE;
					},
					'message' => '正しい日付を入力してください。'
				]
			]);


		$errors = $validator->errors($this->request->data);

		if ($errors)
		{
			$this->set('errors', $errors);
			$this->render('form');
		}
		else
		{
			$year_month = $this->request->data('year_month');
			$year = $this->request->data('year');
			$month = $this->request->data('month');
			$day = $this->request->data('day');

			$DutyEnvs = TableRegistry::get('DutyEnvs');
			$duty_env = $DutyEnvs->find()->where(['de_year_month' => $year_month])->first();
			$duty_env = $DutyEnvs->patchEntity($duty_env, [
				'publish_date' => sprintf("%04d-%02d-%02d", $year, $month, $day)
			]);
			if ($DutyEnvs->save($duty_env) === FALSE) {
				Log::error($duty_env->errors());
				$this->set('errors', $duty_env->errors());
			}

			// バックアップ
			if ($this->Backup->createBackup(BACKUP_TYPE_PUBLISH, $year_month) === FALSE) {
				$this->set('errors', $this->Backup->errors());
				return;
			}
		}

		$this->set('ret', $this->createReturnUrl('/duty_publish/', 'form'));
	}
}

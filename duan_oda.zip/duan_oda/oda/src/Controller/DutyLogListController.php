<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Entity\DutyWork;
use App\Model\Table\DutyAssignmentsTable;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 * DutyLogList Controller
 */
class DutyLogListController extends AppController
{
    public $helpers = [
        'Paginator'
    ];

    public function initialize()
    {
        parent::initialize();
        $this->loadModel('DutyLogs');
        $this->loadModel('DutyLogAlerts');
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->isAuthorityRead();
    }

    public function index()
    {
        Configure::load('list_settings');

        $this->paginate = [
            'limit' => 50,
            'whitelist' => ['year', 'month'],
        ];

        $year_options = [];
        for ($i=0; $i<5; $i++) {
            $year_options[SELECT_START_YEAR + $i] = SELECT_START_YEAR + $i;
        }
        $this->set('year_options', $year_options);
        $this->set('month_options', Configure::read('select_month_list'));

        $year = $this->request->query('year');
        $month = $this->request->query('month');

        if (empty($year) || empty($month)) {
            $year = date('Y');
            $month = date('n');
        }

        $this->set('year_selected', $year);
        $this->set('month_selected', $month);

        $duty_log_list = $this->DutyLogs->find()->where([
            'dl_year_month' => sprintf("%04d%02d", $year, $month)
        ])->order([
            'log_id' => 'ASC',
            'change_date' => 'ASC',
            'date' => 'ASC'
        ]);

        $duty_log_alerts_map = $this->DutyLogAlerts->getMapForLogId(sprintf("%04d%02d", $year, $month));

        $this->set('primary_list', $this->paginate($duty_log_list));
        $this->set('list_settings', Configure::read('list_settings.duty_log_list'));
        $this->set('sideNavi', ['duty_log_list'=>'index']);
        $this->set('duty_log_alerts_map', $duty_log_alerts_map);
        $this->setTitle('日程表管理', '一覧');
    }
}

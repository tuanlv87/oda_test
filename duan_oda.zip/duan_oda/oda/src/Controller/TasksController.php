<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
/**
 * Task Controller
 *
 * @property TasksTable $Tasks
 */
class TasksController extends AppController
{
	public $helpers = [
		'Paginator'
	];

	public $components = [
		'Upload',
		'Csv'
	];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
        $this->MstTasks = TableRegistry::get('MstTasks');
	}

	public function index()
	{
		$this->set('sideNavi', ['task'=>'index']);
		$this->setTitle('タスクマスター', '');
	}

	public function table()
	{
		$this->set('sideNavi', ['task'=>'table']);
		$this->setTitle('タスクマスター', '一覧表示');

		Configure::load('list_settings');
		$this->set('list_settings', Configure::read('list_settings.task'));

		$this->paginate = [
		//	'fields' => ['u_id', 'auth_type', 'name', 'rname', 'email', 'created'],
			'limit' => 50,
			'order' => ['t_id' => 'ASC']
		];
		$this->set('primary_list', $this->paginate($this->MstTasks));
	}

	public function form()
	{
		$this->set('sideNavi', ['task'=>'form']);
		$this->setTitle('タスクマスター', '登録・更新');
	}

	public function add()
	{
		$this->set('sideNavi', ['task'=>'form']);
		$this->setTitle('タスクマスター', '登録');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task'));
		$this->set('values', $this->request->data);
	}

	public function add_confirm()
	{
		return $this->_add('confirm');
	}

	public function add_save()
	{
		return $this->_add('save');
	}

	private function _add($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['task'=>'form']);
		$this->setTitle('タスクマスター', '登録');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.task');
		$this->set('form_settings', $form_settings);

		$ret = $this->request->data('ret');

		$this->filterRequestData($form_settings);
		$task = $this->MstTasks->newEntity($this->request->data);
		$this->MstTasks->isRules($task);

		if ($task->errors())
		{
			$this->set('errors', $task->errors());
			$this->set('values', $this->request->data);
			$this->set('ret', $ret);
			return $this->render('add');
		}
		else if ($mode === 'save')
		{
			if ($this->MstTasks->save($task) === FALSE) {
				$this->set('errors', $task->errors());
				Log::error('タスクマスターの登録に失敗しました。');
			}
			// タスクを集計する
			$this->TaskSummary();
		}

		$this->set('values', $this->request->data);
		$this->set('ret', 'form');
	}

	public function edit()
	{
		$this->set('sideNavi', ['task'=>'form']);
		$this->setTitle('タスクマスター', '更新');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task'));

		$task = NULL;
		$t_id = NULL;
		$ret = '';

		if ($this->request->is('POST'))
		{
			$t_id = $this->request->data('_t_id');
			$ret = $this->request->data('ret');
		}
		else
		{
			$t_id = $this->request->query('t_id');
			$ret = $this->request->query('ret');
		}

		if ($t_id) {
			$task = $this->MstTasks->find()->where(['t_id' => $t_id])->first();
		}

		if ($task === NULL)
		{
			if (empty($t_id)) {
				$this->set('errors', ['t_id' => ['更新するタスクマスターのIDを入力してください。']]);
			} else {
				$this->set('errors', ['t_id' => ['該当するタスクマスターは存在しません。']]);
				$this->set('t_id', $t_id);
			}
			$this->setTitle('タスクマスター', '登録・更新');
			return $this->render('form');
		}
		else if ($this->request->is('POST'))
		{
			$this->set('values', $this->request->data);
		}
		else
		{
			$this->set('values', $task);
		}

		$this->set('_t_id', $t_id);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	public function edit_confirm()
	{
		return $this->_edit('confirm');
	}

	public function edit_save()
	{
		return $this->_edit('save');
	}

	private function _edit($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['task'=>'form']);
		$this->setTitle('タスクマスター', '更新');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.task');
		$this->set('form_settings', $form_settings);

		$t_id = $this->request->data('_t_id');
		$ret = $this->request->data('ret');

		if (empty($t_id)) {
			throw new FatalErrorException("t_idの指定がありません。");
		}

		$task = $this->MstTasks->find()->where(['t_id' => $t_id])->first();
		if ($task === NULL) {
			throw new FatalErrorException('タスクマスターが存在しません。[t_id='.$t_id.']');
		}
		$originals = clone $task;
		$this->filterRequestData($form_settings);
		$task = $this->MstTasks->patchEntity($task, $this->request->data);
		$this->MstTasks->isRules($task);

		if ($task->errors())
		{
			$this->set('errors', $task->errors());
			$this->set('values', $this->request->data);
			$this->set('_t_id', $t_id);
			$this->set('ret', $ret);

			return $this->render('edit');
		}
		else if ($mode === 'save')
		{
			if ($this->MstTasks->save($task) === FALSE) {
				$this->set('errors', $task->errors());
				Log::error('タスクマスターの更新に失敗しました。[t_id='.$t_id.']');
			}
			// タスクを集計する
			$this->TaskSummary();
		}

		$this->set('originals', $originals);
		$this->set('values', $this->request->data);
		$this->set('_t_id', $t_id);
		$this->set('ret', $ret);
	}

	/**
     * Delete method
     *
     * @param string|null $id Personnel id.
     * @return void Redirects to index.
     * @throws NotFoundException When record not found.
     */
    public function delete()
    {
		$this->set('sideNavi', ['task'=>'delete']);
		$this->setTitle('タスクマスター', '削除');
    }

	public function delete_confirm($id = null)
	{
		$this->set('sideNavi', ['task'=>'delete']);
		$this->setTitle('タスクマスター', '削除');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.task'));

		$task = NULL;
		$t_id = NULL;
		$ret = '';

		if ($this->request->is('POST'))
		{
			$t_id = $this->request->data['_t_id'];
			$ret = $this->request->data['ret'];
		}
		else
		{
			if (isset($this->request->query['t_id'])) {
				$t_id = $this->request->query['t_id'];
			}
			if (isset($this->request->query['ret'])) {
				$ret = $this->request->query['ret'];
			}
		}

		if ($t_id) {
			$task = $this->MstTasks->find()->where(['t_id' => $t_id])->first();
		}

		if ($task === NULL)
		{
			if (empty($t_id)) {
				$this->set('errors', ['t_id' => ['削除するIDを入力してください。']]);
			} else {
				$this->set('errors', ['t_id' => ['該当するタスクマスターは存在しません。']]);
				$this->set('t_id', $t_id);
			}
			return $this->render('delete');
		}

		$this->set('values', $task);
		$this->set('_t_id', $t_id);
		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}

	public function delete_save()
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'delete']);
		}

		$this->set('sideNavi', ['task'=>'delete']);
		$this->setTitle('タスクマスター', '削除');

		$task = NULL;
		$t_id = $this->request->data['_t_id'];
		$ret = $this->request->data['ret'];

		if ($t_id) {
			$task = $this->MstTasks->find()->where(['t_id' => $t_id])->first();
		}
		if ($task === NULL) {
			throw new FatalErrorException("タスクマスターが存在しません。[t_id=".$t_id."]");
		}
		//$task = $this->MstTasks->get($task->id);
		if ($this->MstTasks->delete($task) === FALSE) {
			$this->set('errors', $task->errors());
			Log::error('タスクマスターの削除に失敗しました。[t_id='.$t_id.']');
		}

		// タスクを集計する
		$this->TaskSummary();

		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}

	/**
	 * 一括登録
	 */
	public function batch()
	{
		$this->set('sideNavi', ['task'=>'batch']);
		$this->setTitle('タスクマスター', '一括登録');

//		$tmp_csv_file = '';
//
//		if ($this->request->is('POST'))
//		{
//			if (isset($this->request->data['file']))
//			{
//				// アップロード時
//				if ($this->Upload->isError())
//				{
//					Log::write('error', $this->Upload->getErrorMessage());
//				}
//				else
//				{
//					$tmp_csv_file = $this->Upload->getFile('TM');
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'task', $this->MstTasks) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//			else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//			{
//				// エラー変更時
//				$tmp_csv_file = $this->request->data['tmp_csv_file'];
//				if (file_exists($tmp_csv_file))
//				{
//					$this->Csv->setUpdateValues($this->request->data['values']);
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'task', $this->MstTasks) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//		}
//
//		$this->set('tmp_csv_file', $tmp_csv_file);
	}

	public function batch_confirm()
	{
		$this->set('sideNavi', ['task'=>'batch']);
		$this->setTitle('タスクマスター', '一括登録');

		$tmp_csv_file = '';
		$data = [];

		if ($this->request->is('POST'))
		{
			if (isset($this->request->data['file']))
			{
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
				{
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
				}
				else
				{
					$tmp_csv_file = $this->Upload->getFile('TM');
					$fp = fopen($tmp_csv_file, 'r');
					if ($this->Csv->parse($fp, 'task', $this->MstTasks) === FALSE)
					{
						$this->set('csv_errors', $this->Csv->getErrors());
						Log::debug($this->Csv->getErrors());
					}
					$data = $this->Csv->getData();
				}
			}
		}

		$this->set('tmp_csv_file', $tmp_csv_file);
		$this->set('data', $data);
	}

	public function batch_save()
	{
		$this->set('sideNavi', ['task'=>'batch']);
		$this->setTitle('タスクマスター', '一括登録');

		$tmp_csv_file = $this->request->data['tmp_csv_file'];
		if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
		{
			throw new FatalErrorException("一時ファイルが見つかりません。");
		}
		$fp = fopen($tmp_csv_file, 'r');
		if ($this->Csv->parse($fp, 'task', $this->MstTasks) === FALSE)
		{
			$this->set('csv_errors', $this->Csv->getErrors());
			Log::debug($this->Csv->getErrors());
			$this->set('tmp_csv_file', $tmp_csv_file);
			$this->set('data', $this->Csv->getData());
			return $this->render('batch_confirm');
		}
		else
		{
			$this->Csv->import($this->MstTasks, 't_id');
			$this->set('total', $this->Csv->getTotal());

			// タスクを集計する
			$this->TaskSummary();
		}
	}

	/**
	 * ダウンロード
	 */
	public function download()
	{
		$this->set('sideNavi', ['task'=>'download']);
		$this->setTitle('タスクマスター', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			$list = $this->MstTasks->find()->order([
				't_id' => 'ASC'
			])->toArray();
			$this->Csv->setData($list);
			$this->Csv->download('task', 'TM_'.date("Ymd").'.csv');
		}
	}

	// 定常タスクをサマリ化する
	private function TaskSummary()
	{
		// 定常タスクマスタを集計する
		$cols = [];
		$cols["status"] 		= "status";
		$cols["day_type"] 		= "day_type";
		$cols["night_day"] 		= "night_day";
		$cols["personnel"] 		= "sum(personnel)";
		$cols["manager"] 		= "sum(manager)";
		$cols["sub_manager"] 	= "sum(sub_manager)";
		$cols["leader"] 		= "sum(leader)";
		$cols["sub_leader"] 	= "sum(sub_leader)";
		$cols["chief"] 			= "sum(chief)";
		$cols["sub_chief"] 		= "sum(sub_chief)";
		$cols["woman_only"] 	= "sum(woman_only)";
		$cols["woman_possible"] = "sum(woman_possible)";
		$cols["license_01"] 	= "sum(license_01)";
		$cols["license_02"] 	= "sum(license_02)";
		$cols["license_03"] 	= "sum(license_03)";
		$cols["license_04"] 	= "sum(license_04)";
		$cols["license_05"] 	= "sum(license_05)";
		$cols["license_06"] 	= "sum(license_06)";
		$cols["license_07"] 	= "sum(license_07)";
		$cols["license_08"] 	= "sum(license_08)";
		$cols["license_09"] 	= "sum(license_09)";
		$cols["license_10"] 	= "sum(license_10)";

		$where = [];
		$where["status"] = 1;

		$taskSummaries = $this->MstTasks->find()->select($cols)->group(["day_type", "night_day"])->where($where)->toArray();
		foreach($taskSummaries as $key => $taskSummary)
		{
			$taskSummaries[$key]["t_id"] = $taskSummary["day_type"] ."-". $taskSummary["night_day"];

			switch($taskSummaries[$key]["t_id"])
			{
				case "W-D":
					$taskSummaries[$key]["guard_name"] = "平日D勤務";
					break;
				case "W-N":
					$taskSummaries[$key]["guard_name"] = "平日N勤務";
					break;
				case "S-D":
					$taskSummaries[$key]["guard_name"] = "土曜日D勤務";
					break;
				case "S-N":
					$taskSummaries[$key]["guard_name"] = "土曜日N勤務";
					break;
				case "H-D":
					$taskSummaries[$key]["guard_name"] = "日祝日D勤務";
					break;
				case "H-N":
					$taskSummaries[$key]["guard_name"] = "日祝日N勤務";
					break;
			}
		}
		// タスクテーブルを削除

		$conn = ConnectionManager::get('default');
		$conn->query("TRUNCATE TABLE tasks");

		// タスクテーブルにINSERTする
		foreach($taskSummaries as $key => $taskSummary)
		{
			$data = [];
			$data = json_decode(json_encode($taskSummary), true);
			$task = $this->Tasks->newEntity($data);
			$this->Tasks->save($task);
		}
	}
}

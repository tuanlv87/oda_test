<?php
namespace App\Controller;

use Cake\Log\Log;
use Cake\ORM\TableRegistry;

/**
 * 日程表の編集（休暇設定とほぼ同じ）
 */
class DutyUpdateController extends HolidayController
{


	public function initialize()
	{
		parent::initialize();

		$this->loadComponent('RequestHandler');

		$this->set('sideNavi', ['duty_update'=>'form']);
		$this->setTitle('日程表管理', '編集更新');

		// 日程表編集
		$this->edit_mode = 1;
	}

	/**
	 * 年月指定
	 */
	public function form()
	{
		$DutyLogs = TableRegistry::get('DutyLogs');

		// 終了していないログがある場合は年月、ログNOは決定済み
		$duty_log = $DutyLogs->find()->where([
			'end_flag' => 0
		])->order([
			'log_id' => 'DESC',
			'id' => 'DESC'
		])->limit(1)->first();

		if ($duty_log !== NULL)
		{
			$year = substr($duty_log->dl_year_month, 0, 4);
			$month = (int) substr($duty_log->dl_year_month, 4, 2);
			$log_id = $duty_log->log_id;

			$this->redirect('/duty_update/form_pid?year='.$year.'&month='.$month.'&log_id='.$log_id.'&new_flag=0');
		}
		else
		{
			$this->set('year_selected', $this->default_year);
			$this->set('month_selected', $this->default_month);
		}
	}

	/**
	 * Log No. の表示・選択
	 */
	private function form_log($dateYm)
	{
		$DutyLogs = TableRegistry::get('DutyLogs');
		$duty_log = $DutyLogs->find()
		->where(['dl_year_month' => $dateYm])
		->order([
			'log_id' => 'DESC'
		])->limit(1)->first();

		$log_id = 0;
		$new_flag = 1;

		if ($duty_log !== NULL)
		{
			if ($duty_log->end_flag == 0) {
				// ログが終了していなければ現在のログID
				$log_id = $duty_log->log_id;
				$new_flag = 0;
			} else {
				// ログが終了していたら新しいログID
				$log_id = $duty_log->log_id + 1;
			}
		}

		if (empty($log_id)) {
			$log_id = 1;
		}

		$this->set('log_id', $log_id);
		$this->set('new_flag', $new_flag);

        return $log_id;
	}

	/**
	 * 社員番号の入力
	 */
	public function form_pid()
	{
		$year = $this->request->query('year');
		$month = $this->request->query('month');
		$log_id = $this->request->query('log_id');
		$new_flag = $this->request->query('new_flag');
		$p_id = $this->request->query('p_id');
		$ret = $this->request->query('ret');

		// 全部揃っていたら編集画面へ
		if ($year > 0 && $month > 0 && $log_id > 0 && $p_id != '')
		{
			$url = "/duty_update/edit?year=".$year."&month=".$month."&log_id=".$log_id."&new_flag=".$new_flag."&p_id=".$p_id;
			if ($ret != '') {
				$url .= '&ret='.$ret;
			}
			$this->redirect($url);
		}

		$log_id = $this->form_log(sprintf('%04d%02d', $year, $month));

		$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);
	}

	/*
	 * 整合性チェック
	 * 整合性チェックがOKの場合はログを終了させる
	 */
	public function integrity_check()
	{
		$year = $this->request->data('_year');
		$month = $this->request->data('_month');
		$log_id = $this->request->data('_log_id');
		$dutyLogs = TableRegistry::get('DutyLogs');

		// ログリストの取得
		$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);

		// 整合性チェック
		$this->checkToAlert(sprintf('%04d%02d', $year, $month));

		if (count($this->task_errors) == 0)
		{
			$dutyLogs->query()
						->update()
						->set(['end_flag' => true])
						->where(['log_id' => $log_id])
						->execute();
		 }

		 $this->set("values", $this->request->data);
	}

	/*
	 * ログの一覧を取得する
	 */
	protected function getLogList($year_month, $log_id)
	{
		$DutyLogs = TableRegistry::get('DutyLogs');
		$this->duty_log_list = $DutyLogs->find()->where([
			'dl_year_month' => $year_month,
			'log_id' => $log_id
		])->toArray();
		$this->set('duty_log_list', $this->duty_log_list);
	}

	/*
	 * ログの整合性チェックを行う
	 */
	private function checkToAlert($dateYm)
	{
		$Tasks = TableRegistry::get('Tasks');
		$TaskMonths = TableRegistry::get('TaskMonths');
		$DutyWorks = TableRegistry::get('DutyWorks');

		$task_list = $Tasks->find()->order([
			't_id' => 'ASC'
		])->toArray();

		$task_month_list = $TaskMonths->find()->where([
			'tm_year_month' => $dateYm
		])->order([
			'tm_id' => 'ASC'
		])->toArray();

		$this->task_errors = [];

		// ログの集計
		$taskArray = [];
		foreach ($this->duty_log_list as $row) {
			$suffix = "_" . strtotime($row["date"]);
			foreach(explode(",", $row["before_type"]) as $task) {
				$taskArray[$task . $suffix] = isset($taskArray[$task. $suffix]) ? $taskArray[$task . $suffix] - 1 : -1;
			}

			foreach(explode(",", $row["after_type"]) as $task) {
				$taskArray[$task . $suffix] = isset($taskArray[$task . $suffix]) ? $taskArray[$task . $suffix] + 1: 1;
			}
		}

		// TODO:整合性チェック処理
		foreach($taskArray as $key => $taskCount) {
			if ($taskCount != 0) {
				$taskId = explode("_", $key)[0];
				$keyDate = explode("_", $key)[1];
				$date = date("Y/m/d", $keyDate);

				// 通常タスク
				if ($this->isTask($taskId, $task_list)) {
					$this->task_errors[] = $date . "　" .$taskId ."：交代が正常に行われていません。";
				}
				// 月次タスク
				else if ($this->isTaskMonth($taskId, $task_month_list)){
					$task = $this->getTaskMonth($taskId, $task_month_list);
					// 必要人数
					$personnel = $task->personnel;

					$duty_work = $DutyWorks->find()->select(['total'=>'COUNT(*)'])->where([
						'dw_date' => $date,
						'task_id' => $taskId
					])->first();

					$total = $duty_work->total;
					// 月次タスク取消し
					if ($task->status == -9) {
						if ($total > 0) {
							$this->task_errors[] = $date.'　'.$taskId.'：取り消された月次タスクに対して' . ($total) . '人配置されています。';
						}
					}
					// 人数が設定されている場合はチェックする
					else if($personnel > 0){
						if ($total == $personnel) {
							// 人数があっているのでなにもしない
						} else if ($total > $personnel) {
							$this->task_errors[] = $date.'　'.$taskId.'：必要人数'.$personnel.'人に対して'.($total-$personnel).'人過剰に配置されています。';
						} else {
							$this->task_errors[] = $date.'　'.$taskId.'：必要人数'.$personnel.'人に対して'.($personnel-$total).'人不足しています。';
						}
					}

					// 早退Ynnnnの場合は補勤Znnnnがあるかチェック
					if (preg_match('/^Y[0-9]{4}$/', $taskId)) {
						$zTaskId = "Z" . substr($taskId, 1, 4);
						if (!isset($taskArray[$zTaskId . "_" . $keyDate]) || $taskCount - $taskArray[$zTaskId . "_" . $keyDate] > 0) {
							$this->task_errors[] = $date.'　'. $taskId .'(早退)に対応する'. $zTaskId . '（補勤）が存在しません。';
						}
					}

					// 補勤Znnnnの場合は早退Ynnnnがあるかチェック
					if (preg_match('/^Z[0-9]{4}$/', $taskId)) {
						$yTaskId = "Y" . substr($taskId, 1, 4);
						if (!isset($taskArray[$zTaskId . "_" . $keyDate]) || $taskCount - $taskArray[$zTaskId . "_" . $keyDate] > 0) {
							$this->task_errors[] = $date.'　'. $taskId .'(補勤)に対応する'. $yTaskId . '（早退）が存在しません。';
						}
					}
				}
			}
		}

		$this->set("task_errors", $this->task_errors);
	}

	/*
	 * 定常タスクかどうか判定
	 */
	private function isTask($taskId, $taskList) {
		foreach($taskList as $task) {
			if ($task->t_id == $taskId) return true;
		}
		return false;
	}

	/*
	 * 月次タスクかどうか判定
	 */
	private function isTaskMonth($taskId, $taskMonthList) {
		foreach($taskMonthList as $task) {
			if ($task->tm_id == $taskId) return true;
		}
		return false;
	}

	/*
	 * 月次タスクを取得する
	 */
	private function getTaskMonth($taskId, $taskMonthList) {
		foreach($taskMonthList as $task) {
			if ($task->tm_id == $taskId) return $task;
		}
		return false;
	}

	 /*
	 * 整合性チェックでエラー後、次のログを始める
	 */
	public function end_new()
	{
		$log_id = $this->request->data('_log_id');
		$year = $this->request->data('_year');
		$month = $this->request->data('_month');

		$dutyLogs = TableRegistry::get('DutyLogs');
		$dutyLogAlerts = TableRegistry::get('dutyLogAlerts');

		// ログリストの取得
		$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);

		// エラー内容を取得
		$this->checkToAlert(sprintf('%04d%02d', $year, $month));

		$dutyLogAlerts->saveAlertMessages($log_id, sprintf('%04d%02d', $year, $month), $this->task_errors);

		$dutyLogs->query()
					->update()
					->set(['end_flag' => true])
					->where(['log_id' => $log_id])
					->execute();

		$url = "/duty_update/form_pid?year=".$year."&month=".$month."&log_id=".($log_id+1)."&new_flag=1";

		$this->redirect($url);
	 }

	 /*
	 * 整合性チェックでエラー後、更新処理を終了する
	 */
	public function end()
	{
		$log_id = $this->request->data('_log_id');
		$year = $this->request->data('_year');
		$month = $this->request->data('_month');
		$dutyLogs = TableRegistry::get('DutyLogs');
		$dutyLogAlerts = TableRegistry::get('dutyLogAlerts');

		// ログリストの取得
		$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);

		// エラー内容を取得
 		$this->checkToAlert(sprintf('%04d%02d', $year, $month));

		$dutyLogAlerts->saveAlertMessages($log_id, sprintf('%04d%02d', $year, $month), $this->task_errors);

		$dutyLogs->query()
					->update()
					->set(['end_flag' => true])
					->where(['log_id' => $log_id])
					->execute();

		$this->redirect("/Duty/index");
	 }


	/**
	 * 定常タスクのプルダウン用（ajax）
	 */
	public function task_id_list()
	{
        if ($this->request->is('ajax') === FALSE) {
			throw new FatalErrorException("アクセスできません。");
        }

		$date = $this->request->data('date');
		$log_no = $this->request->data('log_no');

		$items = $this->removeTaskList($log_no, $date);

		$this->autoRender = FALSE;
		echo json_encode($items);
	}
}

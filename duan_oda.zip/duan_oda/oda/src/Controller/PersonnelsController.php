<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\PersonnelsTable;
use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Network\Exception\NotFoundException;
use Cake\Validation\Validator;

/**
 * Personnels Controller
 *
 * @property PersonnelsTable $Personnels
 */
class PersonnelsController extends AppController
{
	public $helpers = [
		'Paginator'
	];

	public $components = [
		'Upload',
		'Csv'
	];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	/**
	 * トップ画面
	 */
	public function index()
	{
		$this->set('sideNavi', ['personnel'=>'index']);
		$this->setTitle('警備員マスター', 'トップ');
	}

	/**
	 * 一覧画面
	 */
    public function table()
    {
		$this->set('sideNavi', ['personnel'=>'table']);
		$this->setTitle('警備員マスター', '一覧');

		Configure::load('list_settings');
		$this->set('list_settings', Configure::read('list_settings.personnel'));
		
		$this->paginate = [
		//	'fields' => ['u_id', 'auth_type', 'name', 'rname', 'email', 'created'],
			'limit' => 50,
			'order' => ['p_id' => 'ASC']
		];
		$this->set('primary_list', $this->paginate($this->Personnels));
    }

	/**
	 * 登録・更新トップ画面
	 */
	public function form()
	{
		$this->set('sideNavi', ['personnel'=>'form']);
		$this->setTitle('警備員マスター', '登録・更新');
	}

	/**
	 * 登録画面
	 */
    public function add()
    {
		$this->set('sideNavi', ['personnel'=>'form']);
		$this->setTitle('警備員マスター', '登録');
		
		Configure::load('form_settings');
		$form_settings=Configure::read('form_settings.personnel');
		//var_dump($form_settings);
		$this->set('form_settings', Configure::read('form_settings.personnel'));
		$this->set('values', $this->request->data);
    }

	public function add_confirm()
	{
		return $this->_add('confirm');
	}

	public function add_save()
	{
		return $this->_add('save');
	}

	private function _add($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['personnel'=>'form']);
		$this->setTitle('警備員マスター', '登録');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.personnel');
		//var_dump($form_settings);
		$this->set('form_settings', $form_settings);

		$ret = $this->request->data('ret');
		
		$this->filterRequestData($form_settings);
		$personnel = $this->Personnels->newEntity($this->request->data);
		$this->Personnels->isRules($personnel);

		if ($personnel->errors())
		{
			$this->set('errors', $personnel->errors());
			$this->set('values', $this->request->data);
			$this->set('ret', $this->createReturnUrl($ret, 'form'));
			return $this->render('add');
		}
		else if ($mode === 'save')
		{
			if ($this->Personnels->save($personnel) === FALSE) {
				$this->set('errors', $personnel->errors());
				Log::error('警備員マスターの登録に失敗しました。');
			}
		}

		$this->set('values', $this->request->data);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	/**
	 * 編集画面
	 *
	 * @param int $id p_id
	 */
	public function edit($id = NULL)
	{
		$this->set('sideNavi', ['personnel'=>'form']);
		$this->setTitle('警備員マスター', '更新');
		
		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.personnel');
		//echo '<pre>';
		//var_dump( $form_settings);
//		var_dump ($form_settings["personnel_id"]["config"]);
		$this->set('form_settings', Configure::read('form_settings.personnel'));

		$personnel = NULL;
		$p_id = NULL;
		$ret = '';

		if ($this->request->is('POST'))
		{
			$p_id = $this->request->data['_p_id'];
			$ret = $this->request->data['ret'];
		}
		else
		{
			if (isset($this->request->query['p_id'])) {
				$p_id = $this->request->query['p_id'];
			}
			if (isset($this->request->query['ret'])) {
				$ret = $this->request->query['ret'];
			}
		}

		if ($p_id) {
			$personnel = $this->Personnels->find()->where(['p_id' => $p_id])->first();
		}

		if ($personnel === NULL)
		{
			if (empty($p_id)) {
				$this->set('errors', ['p_id' => ['更新する社員番号を入力してください。']]);
			} else {
				$this->set('errors', ['p_id' => ['該当する警備員マスターは存在しません。']]);
				$this->set('p_id', $p_id);
			}
			$this->setTitle('警備員マスター', '登録・更新');
			return $this->render('form');
		}
		else if ($this->request->is('POST'))
		{
			$this->set('values', $this->request->data);
		}
		else
		{
			$this->set('values', $personnel);
		}

		$this->set('_p_id', $p_id);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	public function edit_confirm()
	{
		return $this->_edit('confirm');
	}

	public function edit_save()
	{
		return $this->_edit('save');
	}

	private function _edit($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'add']);
		}

		$this->set('sideNavi', ['personnel'=>'form']);
		$this->setTitle('警備員マスター', '更新');

		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.personnel');

		$this->set('form_settings', $form_settings);

		$p_id = $this->request->data('_p_id');
		$ret = $this->request->data('ret');

		if (empty($p_id)) {
			throw new FatalErrorException("p_idの指定がありません。");
		}

		$personnel = $this->Personnels->find()->where(['p_id' => $p_id])->first();
		if ($personnel === NULL) {
			throw new FatalErrorException('警備員マスターが存在しません。[p_id='.$p_id.']');
		}
		$originals = clone $personnel;
		$this->filterRequestData($form_settings);
		$personnel = $this->Personnels->patchEntity($personnel, $this->request->data);
		$this->Personnels->isRules($personnel);

		if ($personnel->errors())
		{
			$this->set('errors', $personnel->errors());
			$this->set('values', $this->request->data);
			$this->set('_p_id', $p_id);
			$this->set('ret', $this->createReturnUrl($ret));
			return $this->render('edit');
		}
		else if ($mode === 'save')
		{
			if ($this->Personnels->save($personnel) === FALSE) {
				$this->set('errors', $personnel->errors());
				Log::error('警備員マスターの更新に失敗しました。[p_id='.$p_id.']');
			}
		}

		$this->set('originals', $originals);
		$this->set('values', $this->request->data);
		$this->set('_p_id', $p_id);
		$this->set('ret', $this->createReturnUrl($ret));
	}

	/**
     * Delete method
     *
     * @param string|null $id Personnel id.
     * @return void Redirects to index.
     * @throws NotFoundException When record not found.
     */
    public function delete()
    {
		$this->set('sideNavi', ['personnel'=>'delete']);
		$this->setTitle('警備員マスター', '削除');
    }

	public function delete_confirm($id = null)
	{
		$this->set('sideNavi', ['personnel'=>'delete']);
		$this->setTitle('警備員マスター', '削除');

		Configure::load('form_settings');
		$this->set('form_settings', Configure::read('form_settings.personnel'));

		$personnel = NULL;
		$p_id = NULL;
		$ret = '';

		if ($this->request->is('POST'))
		{
			$p_id = $this->request->data['_p_id'];
			$ret = $this->request->data['ret'];
		}
		else
		{
			if (isset($this->request->query['p_id'])) {
				$p_id = $this->request->query['p_id'];
			}
			if (isset($this->request->query['ret'])) {
				$ret = $this->request->query['ret'];
			}
		}

		if ($p_id) {
			$personnel = $this->Personnels->find()->where(['p_id' => $p_id])->first();
		}

		if ($personnel === NULL)
		{
			if (empty($p_id)) {
				$this->set('errors', ['p_id' => ['削除する社員番号を入力してください。']]);
			} else {
				$this->set('errors', ['p_id' => ['該当する警備員マスターは存在しません。']]);
				$this->set('p_id', $p_id);
			}
			return $this->render('delete');
		}

		$this->set('values', $personnel);
		$this->set('_p_id', $p_id);
		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}

	public function delete_save()
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'delete']);
		}

		$this->set('sideNavi', ['personnel'=>'delete']);
		$this->setTitle('警備員マスター', '削除');

		$personnel = NULL;
		$p_id = $this->request->data['_p_id'];
		$ret = $this->request->data['ret'];

		if ($p_id) {
			$personnel = $this->Personnels->find()->where(['p_id' => $p_id])->first();
		}
		if ($personnel === NULL) {
			throw new FatalErrorException('警備員マスターが存在しません。[p_id='.$p_id.']');
		}
		//$personnel = $this->Personnels->get($personnel->id);
		if ($this->Personnels->delete($personnel) === FALSE) {
			$this->set('errors', $personnel->errors());
			Log::error('警備員マスターの削除に失敗しました。[p_id='.$p_id.']');
		}

		$this->set('ret', $this->createReturnUrl($ret, 'delete'));
	}

	/**
	 * 一括登録
	 */
	public function batch()
	{
		$this->set('sideNavi', ['personnel'=>'batch']);
		$this->setTitle('警備員マスター', '一括登録');

//		$tmp_csv_file = '';
//
//		if ($this->request->is('POST'))
//		{
//			if (isset($this->request->data['file']))
//			{
//				// アップロード時
//				if ($this->Upload->isError())
//				{
//					Log::write('error', $this->Upload->getErrorMessage());
//				}
//				else
//				{
//					$tmp_csv_file = $this->Upload->getFile('PM');
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//			else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//			{
//				// エラー変更時
//				$tmp_csv_file = $this->request->data['tmp_csv_file'];
//				if (file_exists($tmp_csv_file))
//				{
//					$this->Csv->setUpdateValues($this->request->data['values']);
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//		}
//
//		$this->set('tmp_csv_file', $tmp_csv_file);
	}

	public function batch_confirm()
	{
		$this->set('sideNavi', ['personnel'=>'batch']);
		$this->setTitle('警備員マスター', '一括登録');

		$tmp_csv_file = '';
		$data = [];

		if ($this->request->is('POST'))
		{
			if (isset($this->request->data['file']))
			{
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
                {
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
                }
				else
				{
					$tmp_csv_file = $this->Upload->getFile('PM');
					$fp = fopen($tmp_csv_file, 'r');
					if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
					{
						$this->set('csv_errors', $this->Csv->getErrors());
						Log::debug($this->Csv->getErrors());
					}
					$data = $this->Csv->getData();
				}
			}
		}

		$this->set('tmp_csv_file', $tmp_csv_file);
		$this->set('data', $data);
	}

	public function batch_save()
	{
		$this->set('sideNavi', ['personnel'=>'batch']);
		$this->setTitle('警備員マスター', '一括登録');

		$tmp_csv_file = $this->request->data['tmp_csv_file'];
		if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
		{
			throw new FatalErrorException("一時ファイルが見つかりません。");
		}
		$fp = fopen($tmp_csv_file, 'r');
		if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
		{
			$this->set('csv_errors', $this->Csv->getErrors());
			Log::debug($this->Csv->getErrors());
			$this->set('tmp_csv_file', $tmp_csv_file);
			$this->set('data', $this->Csv->getData());
			return $this->render('batch_confirm');
		}
		else
		{
			$this->Csv->import($this->Personnels, 'p_id');
			$this->set('total', $this->Csv->getTotal());
		}
	}

	public function download()
	{
		$this->set('sideNavi', ['personnel'=>'download']);
		$this->setTitle('警備員マスター', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			$list = $this->Personnels->find()->order([
				'p_id' => 'ASC'
			])->toArray();
			$this->Csv->setData($list);
			$this->Csv->download('personnel', 'PM_'.date("Ymd").'.csv');
		}
	}
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\SettingsTable;
use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Network\Exception\NotFoundException;
use Cake\Validation\Validator;

/**
 * Users Controller
 *
 * @property UsersTable $Users
 */
class SettingDateController extends AppController
{
    public $helpers = [
        'Paginator'
    ];

    public $components = [
        'Upload',
        'Csv'
    ];
    public function initialize()
    {
        parent::initialize();

        $this->loadModel('Settings');
        $this->loadModel('CrewMasters');


    }
	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

    /**
     * Index method
     *
     * @return void
     */
    public function index()
    {
        $this->set('sideNavi', array('setting_date'=>'index'));
        $this->setTitle('初期値設定', '休祝日');
    }



    public function numberFire (){
        $this->set('sideNavi', ['setting_date'=>'numberFire']);
        $this->setTitle('利用者管理', '更新');

        $numberCrewNow = $this->Settings->find()->where(['title' => CREW_NO])->first();
        $numCrew = 8;
        $check = 0;
        if(isset($numberCrewNow->value)&&$numberCrewNow->value>0){
            $check = 1;
        }
        //submit form
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $numberCrew = $this->request->data('crew');
            if(isset($numberCrew) && $numberCrew >0){
                $data = ['title'=>CREW_NO,
                    'value'=>$numberCrew
                ];

                if($check==0){
                    $entity = $this->Settings->newEntity($data);
                }else if($check==1) {
                    $entity = $this->Settings->patchEntity($numberCrewNow,$data);
                }
                if ($this->Settings->save($entity) === FALSE) {
                    $this->set('errors', $entity->errors());
                    Log::error('新規登録に失敗しました。');
                }

            }

        }
        $numberCrewNowNew = $this->Settings->find()->where(['title' => CREW_NO])->first();
        if(isset($numberCrewNowNew->value)&&$numberCrewNowNew->value>0){
            $numCrew = $numberCrewNowNew->value;
        }
        $this->set('numCrew',$numCrew);
    }



    public function fire (){
        $this->set('sideNavi', ['setting_date'=>'fire']);
        $this->setTitle('利用者管理', '更新');

        $numberFireNow = $this->Settings->find()->where(['title' => FIRE_NO])->first();
        $numFire = 3;
        $check = 0;
        if(isset($numberFireNow->value)&&$numberFireNow->value>0){
            $check = 1;
        }
        //submit form
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $numberFire = $this->request->data('number_fire');
            if(isset($numberFire) && $numberFire >0){
                $data = ['title'=>FIRE_NO,
                    'value'=>$numberFire
                ];

                if($check==0){
                    $entity = $this->Settings->newEntity($data);
                }else if($check==1) {
                    $entity = $this->Settings->patchEntity($numberFireNow,$data);
                }
                if ($this->Settings->save($entity) === FALSE) {
                    $this->set('errors', $entity->errors());
                    Log::error('新規登録に失敗しました。');
                }

            }

        }
        $numberFireNew = $this->Settings->find()->where(['title' => FIRE_NO])->first();
        if(isset($numberFireNew->value)&&$numberFireNew->value>0){
            $numFire = $numberFireNew->value;
        }
        $this->set('numFire',$numFire);

    }
    public function numberCrew (){
        $this->set('sideNavi', ['setting_date'=>'numberCrew']);
        $this->setTitle('利用者管理', '更新');
        //get number crew
        $numberCrew = $this->Settings->find()->where(['title' => CREW_NO])->first();
        $crewDefault = 8;
        if(isset($numberCrew->value) && $numberCrew->value>0){
            $crewDefault = $numberCrew->value;
        }
        $this->set('numberCrew',$crewDefault);

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $check = $this->request->data('setting_crew');
            //echo $check;
            //setting all
            if(isset($check) && $check == All_SETTING ) {


            } else if(isset($check) && $check == PRIVATE_SETTING){

            }

        }


    }
    public function trainingFire (){
        $this->set('sideNavi', ['setting_date'=>'trainingFire']);
        $this->setTitle('利用者管理', '更新');
        $timeStart = $this->Settings->find()->where(['title'=>TRAINING_START_TIME])->first();
        $timeStop = $this->Settings->find()->where(['title'=>TRAINING_STOP_TIME])->first();
        $timeStartDefault = '9:00';
        $timeStopDefault = '12:00';
        $check = 0;
        if(isset($timeStart) && $timeStart->value != "" && isset($timeStop)&&$timeStop->value !=""){
            $check = 1;
        }
        //check submit
        if($_SERVER['REQUEST_METHOD']=='POST') {
            $timeStartUpdate = $this->request->data('start_time');
            $timeStopUpdate = $this->request->data('stop_time');
            if(isset($timeStartUpdate) && $timeStartUpdate !="" && isset($timeStopUpdate) && $timeStopUpdate != ""){
                $dataStart = [
                    'title'=>TRAINING_START_TIME,
                    'value' =>sprintf('%02d:%02d', (int) $timeStartUpdate, fmod($timeStartUpdate, 1) * 60)
                ];

                $dataStop = [
                    'title'=>TRAINING_STOP_TIME,
                    'value' =>sprintf('%02d:%02d',(int) $timeStopUpdate, fmod($timeStopUpdate, 1) * 60)
                ];

                if($check==0){
                    $entityStart = $this->Settings->newEntity($dataStart);
                    $entityStop = $this->Settings->newEntity($dataStop);
                }else if($check==1) {
                    $entityStart = $this->Settings->patchEntity($timeStart,$dataStart);
                    $entityStop = $this->Settings->patchEntity($timeStop,$dataStop);
                }

                if ($this->Settings->save($entityStart) === FALSE) {
                    $this->set('errors', $entityStart->errors());
                    Log::error('新規登録に失敗しました。');
                }

                if ($this->Settings->save($entityStop) === FALSE) {
                    $this->set('errors', $entityStop->errors());
                    Log::error('新規登録に失敗しました。');
                }

            }
        }
        $timeStartUpdate = $this->Settings->find()->where(['title'=>TRAINING_START_TIME])->first();
        $timeStopUpdate = $this->Settings->find()->where(['title'=>TRAINING_STOP_TIME])->first();
        if(isset($timeStartUpdate) && $timeStartUpdate->value != "" && isset($timeStopUpdate) && $timeStopUpdate->value != ""){
            $timeStartDefault = $timeStartUpdate->value;
            $timeStopDefault = $timeStopUpdate->value;
        }

        $this->set('timeStartDefault',$timeStartDefault);
        $this->set('timeStopDefault',$timeStopDefault);

    }



    public function form()
    {
        $this->set('sideNavi', array('setting_date'=>'form'));
        $this->setTitle('利用者管理', '登録・更新');
    }


    /**
     * 編集画面
     *
     * @param int $id u_id
     */
    public function edit($id = NULL)
    {
		$this->set('sideNavi', ['setting_date'=>'form']);
		$this->setTitle('利用者管理', '更新');

       // Configure::load('form_settings');
        //$this->set('form_settings', Configure::read('form_settings.user'));
       // $year = $this->request->query('year');


        $year = 0;
        $month = 0;
        $dw_data = [];
        $nw_data = [];
        $fe_data = [];
        $fire='';
        $ret = '';

        if ($this->request->is('GET'))
        {
            $year_month = $this->request->query('year');
            if ($year_month != '') {
                $this->request->query['year'] = (int)substr($year_month, 0, 4);
                $year = (int)substr($year_month, 0, 4);
                echo $year;

            }

            // 入力チェック
            $validator = new Validator();
            $validator
                ->requirePresence('year', TRUE, '年を入力してください。')
                ->notEmpty('year', '年を入力してください。')
                ->add('year', [
                    'numeric' => [
                        'rule' => 'numeric',
                        'message' => '年は数値で入力してください。'
                    ],
                    'valid' => [
                        'rule' => function($value, $content) {
                            if ($value === '') return TRUE;
                            return ($value >= 2000 && $value <=2050);
                        },
                        'message' => '年は2000〜2050を入力してください。'
                    ]
                ]);


            $errors = $validator->errors($this->request->query);

            if ($errors)
            {
                $this->set('errors', $errors);
                $this->set('sideNavi', ['setting_date'=>'form']);
                return $this->render('form');
            }
            else
            {
                $year = $this->request->query('year');
                //$month = $this->request->query('month');
                $ret = $this->request->query('ret');

                if ($year > 0 && $month > 0)
                {
                    /*$watch_fire_list = $this->WatchFires->find()->where([
                        'wf_year_month' => sprintf("%04d%02d", $year, $month)
                    ])->toArray()*/;

                    /*if (count($watch_fire_list)>0)
                    {
                        foreach ($watch_fire_list as $d)
                        {
                            foreach ([21,22,23,24,25,26,27,28,29,30,31,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] as $day)
                            {
                                $col = 'd_'.$day;
                                if ($d->{$col} > 0) {
                                    if ($d->wf_type === DAT_CODE_DW) {
                                        $dw_data[] = $day;
                                    } else if ($d->wf_type === DAT_CODE_NW) {
                                        $nw_data[] = $day;
                                    } else if ($d->wf_type === DAT_CODE_FE) {
                                        $fe_data[$col] = $d->{$col};
                                    }
                                }
                            }
                            if ($d->wf_type === DAT_CODE_FE) {
                                $fire = $d;
                            }
                        }
                    }*/
                }
               //$this->set('dw_data', $dw_data);
                //$this->set('nw_data', $nw_data);
                //$this->set('fe_data', $fe_data);
            }
        }
        else
        {
            // POST時
            $year = $this->request->data('year');
            //$month = $this->request->data('month');
            $ret = $this->request->data('ret');

            //$this->set('dw_data', $this->request->data('dw_data'));
            //$this->set('nw_data', $this->request->data('nw_data'));
           // $this->set('fe_data', $this->request->data);
        }

        $this->set('year', $year);
       // $this->set('month', $month);
       /* $this->set('fire', $this->WatchFires->find()->where([
            'wf_year_month' => sprintf("%04d%02d", $year, $month),
            'wf_type' => DAT_CODE_FE
        ])->first());*/
        $this->set('ret', $this->createReturnUrl($ret, 'form'));
    }

    public function edit_confirm()
    {
        return $this->_edit('confirm');
    }

    public function edit_save()
    {
        return $this->_edit('save');
    }

    private function _edit($mode)
    {
        if ($this->request->is('POST') === FALSE) {
            return $this->redirect(['action' => 'add']);
        }

        Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.user');
        $this->set('form_settings', $form_settings);
		$this->set('sideNavi', ['user'=>'form']);
		$this->setTitle('利用者マスター', '更新');

        $u_id = $this->request->data('_u_id');
        $ret = $this->request->data('ret');

        if (empty($u_id)) {
            throw new FatalErrorException("u_idの指定がありません。");
        }

        $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        if ($user === NULL) {
            throw new FatalErrorException("利用者管理情報が見つかりません。");
        }
        $originals = clone $user;
		$this->filterRequestData($form_settings);
        $user = $this->Users->patchEntity($user, $this->request->data, ["validate" => "custom"]);
		$this->Users->isRules($user);

        if ($user->errors())
        {
			$this->request->data['created'] = $user->created;
			$this->request->data['modified'] = $user->modified;

            $this->set('errors', $user->errors());
            $this->set('values', $this->request->data);
            $this->set('_u_id', $u_id);
            $this->set('ret', $ret);
            return $this->render('edit');
        }
        else if ($mode === 'save')
        {
            if ($this->Users->save($user) === FALSE) {
				$this->set('errors', $user->errors());
				Log::error('更新に失敗しました。[u_id='.$u_id.']');
            }
        }

        $this->set('originals', $originals);
        $this->set('values', $this->request->data);
        $this->set('_u_id', $u_id);
        $this->set('ret', $this->createReturnUrl($ret, 'form'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return void Redirects to index.
     * @throws NotFoundException When record not found.
     */
    public function delete()
    {
        $this->set('sideNavi', ['user'=>'delete']);
        $this->setTitle('利用者管理', '削除');
    }

    public function delete_confirm($id = null)
    {
		$this->set('sideNavi', ['user'=>'delete']);
		$this->setTitle('利用者管理', '削除');

        Configure::load('form_settings');
        $this->set('form_settings', Configure::read('form_settings.user'));

        $user = NULL;
        $u_id = NULL;
        $ret = '';
        if ($this->request->is('POST'))
        {
			$u_id = $this->request->data('_u_id');
			$ret = $this->request->data('ret');
        }
        else
        {
			$u_id = $this->request->query('u_id');
			$ret = $this->request->query('ret');
        }

        if ($u_id) {
            $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        }
        if ($user === NULL)
        {
            if (empty($u_id)) {
                $this->set('errors', ['u_id' => ['削除する利用者IDを入力してください。']]);
            } else {
                $this->set('errors', ['u_id' => ['該当する利用者IDは存在しません。']]);
                $this->set('u_id', $u_id);
            }
            return $this->render('delete');
        }
		else
		{
			if ($user->auth_type == 1) {
				$this->set('errors', ['u_id' => ['admin権限の利用者は削除できません。']]);
				$this->set('u_id', $u_id);
				return $this->render('delete');
			}
		}

        $this->set('values', $user);
        $this->set('_u_id', $u_id);
        $this->set('ret', $this->createReturnUrl($ret, 'delete'));
    }

    public function delete_save()
    {
        if ($this->request->is('POST') === FALSE) {
            return $this->redirect(['action' => 'delete']);
        }

		$this->set('sideNavi', ['user'=>'delete']);
		$this->setTitle('利用者管理', '削除');

        $u_id = $this->request->data['_u_id'];
        $ret = $this->request->data['ret'];

        if ($u_id) {
            $user = $this->Users->find()->where(['u_id' => $u_id])->first();
        }
        if ($user === NULL) {
            throw new FatalErrorException('利用者情報が存在しません。[u_id='.$u_id.']');
        }
        //$user = $this->Users->get($user->id);
        if ($this->Users->delete($user) === FALSE) {
            Log::error('利用者情報の削除に失敗しました。[u_id='.$u_id.']');
			$this->set('errors', $user->errors());
        }

        $this->set('ret', $this->createReturnUrl($ret, 'delete'));
    }


    /**
     * 一括登録
     */
    public function batch()
    {
		$this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

//        $tmp_csv_file = '';
//
//        if ($this->request->is('POST'))
//        {
//            if (isset($this->request->data['file']))
//            {
//                // アップロード時
//                if ($this->Upload->isError())
//                {
//                    Log::write('error', $this->Upload->getErrorMessage());
//                }
//                else
//                {
//                    $tmp_csv_file = $this->Upload->getFile('UM');
//                    $fp = fopen($tmp_csv_file, 'r');
//                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
//                    {
//                        $this->set('csv_errors', $this->Csv->getErrors());
//                        Log::debug($this->Csv->getErrors());
//                    }
//                }
//            }
//            else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//            {
//                // エラー変更時
//                $tmp_csv_file = $this->request->data['tmp_csv_file'];
//                if (file_exists($tmp_csv_file))
//                {
//                    $this->Csv->setUpdateValues($this->request->data['values']);
//                    $fp = fopen($tmp_csv_file, 'r');
//                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
//                    {
//                        $this->set('csv_errors', $this->Csv->getErrors());
//                        Log::debug($this->Csv->getErrors());
//                    }
//                }
//            }
//        }
//
//        $this->set('tmp_csv_file', $tmp_csv_file);
    }

    public function batch_confirm()
    {
        $this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

        $tmp_csv_file = '';
        $data = [];

        if ($this->request->is('POST'))
        {
            if (isset($this->request->data['file']))
            {
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
                {
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
                }
                else
                {
                    $tmp_csv_file = $this->Upload->getFile('UM');
                    $fp = fopen($tmp_csv_file, 'r');
                    if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
                    {
                        $this->set('csv_errors', $this->Csv->getErrors());
                        Log::debug($this->Csv->getErrors());
                    }
                    $data = $this->Csv->getData();
                }
            }
        }

        $this->set('tmp_csv_file', $tmp_csv_file);
        $this->set('data', $data);
    }

    public function batch_save()
    {
        $this->set('sideNavi', ['user'=>'batch']);
        $this->setTitle('利用者管理', '一括登録');

        $tmp_csv_file = $this->request->data['tmp_csv_file'];
        if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
        {
            throw new FatalErrorException('一時ファイルが見つかりません。');
        }
        $fp = fopen($tmp_csv_file, 'r');
        if ($this->Csv->parse($fp, 'user', $this->Users) === FALSE)
        {
            $this->set('csv_errors', $this->Csv->getErrors());
           Log::debug($this->Csv->getErrors());
            $this->set('tmp_csv_file', $tmp_csv_file);
            $this->set('data', $this->Csv->getData());
            return $this->render('batch_confirm');
        }
        else
        {
            $this->Csv->import($this->Users, 'u_id');
            $this->set('total', $this->Csv->getTotal());
        }
    }

    public function download()
    {
        $this->set('sideNavi', ['user'=>'download']);
        $this->setTitle('利用者管理', 'ダウンロード');

        if ($this->request->is('POST'))
        {
            $list = $this->Users->find()->order([
				'u_id' => 'ASC'
			])->toArray();
            $this->Csv->setData($list);
            $this->Csv->download('user', 'UM_'.date("Ymd").'.csv');
        }
    }

}

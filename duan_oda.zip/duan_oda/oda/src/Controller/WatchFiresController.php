<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Validation\Validator;

/**
 *  宿日直・消防訓練
 */
class WatchFiresController extends AppController
{
	public $helpers = [
		'Paginator'
	];

	public $components = [
		'Csv'
	];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function index()
	{
		$this->set('sideNavi', ['watch_fire'=>'index']);
		$this->setTitle('宿日直・消防訓練', '');
	}

	public function table()
	{
		$this->set('sideNavi', ['watch_fire'=>'table']);
		$this->setTitle('宿日直・消防訓練', '一覧表示');

		Configure::load('list_settings');
		$this->set('list_settings', Configure::read('list_settings.watch_fire'));

		$this->paginate = [
			'limit' => 36,
			'order' => [
				'wf_year' => 'DESC',
				'wf_month' => 'ASC',
				'wf_order' => 'ASC'
			]
		];
		$this->set('primary_list', $this->paginate($this->WatchFires));
	}

	private function getWatchFireList()
	{
		$watch_fire_list = $this->WatchFires->find()->order([
			'wf_year' => 'DESC',
			'wf_month' => 'ASC',
			'wf_order' => 'ASC'
		])->toArray();
		return $watch_fire_list;
	}

	public function form()
	{
		$this->set('sideNavi', ['watch_fire'=>'form']);
		$this->setTitle('宿日直・消防訓練', '登録・更新');
	}

	public function edit()
	{
		$this->set('sideNavi', ['watch_fire'=>'form']);
		$this->setTitle('宿日直・消防訓練', '登録・更新');

		$year = 0;
		$month = 0;
		$dw_data = [];
		$nw_data = [];
		$fe_data = [];
		$fire;
		$ret = '';

		if ($this->request->is('GET'))
		{
			$year_month = $this->request->query('year_month');
			if ($year_month != '') {
				$this->request->query['year'] = (int)substr($year_month, 0, 4);
				$this->request->query['month'] = (int)substr($year_month, 4, 2);
			}

			// 入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('year', TRUE, '年を入力してください。')
				->notEmpty('year', '年を入力してください。')
				->add('year', [
					'numeric' => [
						'rule' => 'numeric',
						'message' => '年は数値で入力してください。'
					],
					'valid' => [
						'rule' => function($value, $content) {
							if ($value === '') return TRUE;
							return ($value >= 2000 && $value <=2050);
						},
						'message' => '年は2000〜2050を入力してください。'
					]
				])
				->requirePresence('month', TRUE, '月を入力してください。')
				->notEmpty('month', '月を入力してください。')
				->add('month', [
					'numeric' => [
						'rule' => 'numeric',
						'message' => '月は数値で入力してください。'
					],
					'valid' => [
						'rule' => function($value, $content) {
							if ($value === '') return TRUE;
							return ($value >= 1 && $value <=12);
						},
						'message' => '月は1〜12を入力してください。'
					]
				]);

			$errors = $validator->errors($this->request->query);

			if ($errors)
			{
				$this->set('errors', $errors);
				$this->set('sideNavi', ['watch_fire'=>'form']);
				return $this->render('form');
			}
			else
			{
				$year = $this->request->query('year');
				$month = $this->request->query('month');
				$ret = $this->request->query('ret');

				if ($year > 0 && $month > 0)
				{
					$watch_fire_list = $this->WatchFires->find()->where([
						'wf_year_month' => sprintf("%04d%02d", $year, $month)
					])->toArray();

					if (count($watch_fire_list)>0)
					{
						foreach ($watch_fire_list as $d)
						{
							foreach ([21,22,23,24,25,26,27,28,29,30,31,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] as $day)
							{
								$col = 'd_'.$day;
								if ($d->{$col} > 0) {
									if ($d->wf_type === DAT_CODE_DW) {
										$dw_data[] = $day;
									} else if ($d->wf_type === DAT_CODE_NW) {
										$nw_data[] = $day;
									} else if ($d->wf_type === DAT_CODE_FE) {
										$fe_data[$col] = $d->{$col};
									}
								}
							}
							if ($d->wf_type === DAT_CODE_FE) {
								$fire = $d;
							}
						}
					}
				}
				$this->set('dw_data', $dw_data);
				$this->set('nw_data', $nw_data);
				$this->set('fe_data', $fe_data);
			}
		}
		else
		{
			// POST時
			$year = $this->request->data('year');
			$month = $this->request->data('month');
			$ret = $this->request->data('ret');

			$this->set('dw_data', $this->request->data('dw_data'));
			$this->set('nw_data', $this->request->data('nw_data'));
			$this->set('fe_data', $this->request->data);
		}

		$this->set('year', $year);
		$this->set('month', $month);
		$this->set('fire', $this->WatchFires->find()->where([
			'wf_year_month' => sprintf("%04d%02d", $year, $month),
			'wf_type' => DAT_CODE_FE
		])->first());
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
	}

	public function edit_confirm()
	{
		$this->_edit('confirm');
	}

	public function edit_save()
	{
		$this->_edit('save');
	}

	private function _edit($mode)
	{
		$this->set('sideNavi', ['watch_fire'=>'form']);
		$this->setTitle('宿日直・消防訓練', '登録・更新');
		
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'form']);
		}

		$year = $this->request->data('year');
		$month = $this->request->data('month');
		$ret = $this->request->data('ret');
		$dw_data = $this->request->data('dw_data');
		$nw_data = $this->request->data('nw_data');
		if ($dw_data === NULL) {
			$dw_data = [];
		}
		if ($nw_data === NULL) {
			$nw_data = [];
		}
		$dw_odata = [];
		$nw_odata = [];
		$fe_data = [];

		if (empty($year) || empty($month)) {
			throw new FatalErrorException("日付の指定がありません。");
		}

		// 入力チェック
		$errors = [];
		$fire_ids = Configure::read('fire_ids');
		foreach (Configure::read('day_order_array') as $day)
		{
			$col = 'd_'.$day;
			if (isset($this->request->data[$col])) {
				$fe_data[$col] = $this->request->data[$col];
				if ($fe_data[$col] != '' && in_array($fe_data[$col], $fire_ids) === FALSE) {
					if (isset($errors[$col]) === FALSE) {
						$errors[$col] = [];
					}
					$errors[$col][] = '消防班番号（'.$fe_data[$col].'）は無効です。';
				}
			}
		}

		$wf_data = $this->WatchFires->getTypeMap(sprintf("%04d%02d", $year, $month));

		foreach (Configure::read('day_order_array') as $day)
		{
			$col = 'd_'.$day;
			if (isset($wf_data[DAT_CODE_DW]->{$col}) && $wf_data[DAT_CODE_DW]->{$col}>0) {
				$dw_odata[] = $day;
			}
			if (isset($wf_data[DAT_CODE_NW]->{$col}) && $wf_data[DAT_CODE_NW]->{$col}>0) {
				$nw_odata[] = $day;
			}
		}

		$fire = isset($wf_data[DAT_CODE_FE]) ? $wf_data[DAT_CODE_FE] : NULL;

		$this->set('dw_data', $dw_data);
		$this->set('nw_data', $nw_data);
		$this->set('dw_odata', $dw_odata);
		$this->set('nw_odata', $nw_odata);
		$this->set('fe_data', $this->request->data);
		$this->set('year', $year);
		$this->set('month', $month);
		$this->set('fire', $fire);
		$this->set('originals', $fire);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));


		if (count($errors)>0)
		{
			$this->set('errors', $errors);
			$this->set('sideNavi', ['watch_fire'=>'form']);
			return $this->render('edit');
		}
		else if ($mode === 'save')
		{
			$watch_fire_list = $this->WatchFires->find()->where([
				'wf_year_month' => sprintf("%04d%02d", $year, $month)
			])->toArray();

			$entities = [DAT_CODE_DW=>NULL, DAT_CODE_NW=>NULL, DAT_CODE_FE=>NULL];

			if (count($watch_fire_list) > 0)
			{
				foreach ($watch_fire_list as $d)
				{
					if ($d->wf_type == DAT_CODE_DW) {
						$entities[DAT_CODE_DW] = $d;
					} else if ($d->wf_type == DAT_CODE_NW) {
						$entities[DAT_CODE_NW] = $d;
					} else if ($d->wf_type == DAT_CODE_FE) {
						$entities[DAT_CODE_FE] = $d;
					}
				}
			}

			try
			{
				$this->WatchFires->connection()->begin();

				foreach ($entities as $code => $entity)
				{
					$data = [];

					if ($entity === NULL) {
						// 新規
						$data = [
							'status' => WFT_STATUS_TYPE_NOTCOMP,
							'wf_year_month' => sprintf("%04d%02d", $year, $month),
							'wf_year' => $year,
							'wf_month' => $month,
							'wf_type' => $code
						];
					}
					// @TODO:更新時は必要ないが
					$data['wf_year'] = $year;
					$data['wf_month'] = $month;

					if ($code === DAT_CODE_DW) {
						$data['wf_order'] = 0;
						foreach (Configure::read('day_order_array') as $day) {
							$data['d_'.$day] = in_array($day, $dw_data) ? 1 : 0;
						}
					} else if ($code === DAT_CODE_NW) {
						$data['wf_order'] = 1;
						foreach (Configure::read('day_order_array') as $day) {
							$data['d_'.$day] = in_array($day, $nw_data) ? 1 : 0;
						}
					} else if ($code === DAT_CODE_FE) {
						$data['wf_order'] = 2;
						foreach (Configure::read('day_order_array') as $day) {
							$data['d_'.$day] = ($this->request->data('d_'.$day)>0) ? $this->request->data('d_'.$day) : 0;
						}
					}

					if ($entity === NULL) {
						$entity = $this->WatchFires->newEntity($data);
					} else {
						$entity = $this->WatchFires->patchEntity($entity, $data);
					}

					if ($this->WatchFires->save($entity) === FALSE)
					{
						Log::error($entity->errors());
						$this->set('errors', $entity->errors());
						throw new Exception();
					}
				}

				$this->WatchFires->connection()->commit();
			}
			catch (Exception $e)
			{
				$this->WatchFires->connection()->rollback();
			}
		}

		$this->set('values', $this->request->data);
	}

	/**
	 * ダウンロード
	 */
	public function download()
	{
		$this->set('sideNavi', ['watch_fire'=>'download']);
		$this->setTitle('宿日直・消防訓練', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			// 全リストをダウンロード
			$watch_fire_list = $this->getWatchFireList();
			$this->Csv->setData($watch_fire_list);
			$this->Csv->download('watch_fire', 'WFT_'.date("Ymd").'.csv');
		}
	}
}

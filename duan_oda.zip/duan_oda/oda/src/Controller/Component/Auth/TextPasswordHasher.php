<?php
namespace App\Controller\Component\Auth;

use Cake\Auth\AbstractPasswordHasher;
//App::uses('AbstractPasswordHasher', 'Controller/Component/Auth');

/**
 *
 */
class TextPasswordHasher extends AbstractPasswordHasher
{
	public function hash($password)
	{
		return $password;
	}

	public function check($password, $hashedPassword)
	{
		return ($password == $hashedPassword);
	}

	public function needsRehash($password)
	{
		return TRUE;
	}
}

<?php
namespace App\Controller\Component;

use App\Model\Table\AppTable;
use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Log\Log;
use Cake\ORM\Table;

class CsvComponent extends Component
{
//	public $request;
//	public $response;
//	public $session;

	protected $filename;
	protected $errors = array();
	protected $data = array();
	protected $total = 0;
	protected $updateValues = array();

	public function initialize(array $config)
	{
//		$controller = $this->_registry->getController();
//		$this->eventManager($controller->eventManager());
//		$this->request = $controller->request;
//		$this->response = $controller->response;
//		$this->session = $controller->request->session();
		ini_set("auto_detect_line_endings", TRUE);
    }

	public function parse(&$fp, $type, AppTable &$table, $add_values=NULL)
	{
		$error_flg = FALSE;
		$data_length = 0;
		$c = 0;
		$n = 0;
        Configure::load('csv_settings');
        $csv_settings = Configure::read('csv_settings.'.$type);
		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.'.$type);
		//$fp = fopen($this->filename, 'r');

		if (!$fp)
		{
			throw new FatalErrorException('CSVファイルが開けません。');
		}

		while (($data = fgetcsv($fp, 0, ",")) !== FALSE)
		{
			if ($c == 0)
			{
				$data_length = count($data);
			}
			else
			{
				if (count($data) < $data_length) {
					$this->setErrors($c, [
						'type' => 'dataLength',
						'message' => $c.'行目のデータ数が足りません。'
					]);
					$error_flg = TRUE;
				}
				$this->data[$n] = [];
				$i = 0;
				foreach ($csv_settings as $key)
				{
					$val = $form_settings[$key];
					if (isset($data[$i]))
					{
						if ($val['type'] === 'date') {
							$d = explode(' ', $data[$i]);
							$data[$i] = $d[0];
						} else {
							$data[$i] = mb_convert_encoding($data[$i], 'UTF-8', 'sjis-win');
						}
						if (isset($val['filter'])) {
							if (! is_array($val['filter'])) {
								$val['filter'] = array($val['filter']);
							}
							foreach ($val['filter'] as $filter) {
								$filters = explode(':', $filter);
								if ($filters[0] === 'mb_convert_kana') {
									$data[$i] = mb_convert_kana($data[$i], $filters[1]);
								} else if ($filters[0] === 'removeSpace') {
									$data[$i] = str_replace([' ', '　'], '', $data[$i]);
								} else if ($filters[0] === 'convertName') {
									$data[$i] = str_replace([',','、'], ';', $data[$i]);
								} else if ($filters[0] === 'yearMonth') {
									$data[$i] = str_replace(['-','/'], '', $data[$i]);
									$len = strlen($data[$i]);
									if ($len>0) {
										if ($len == 5) {
											$data[$i] = sprintf("%04d%02d", substr($data[$i], 0, 4), substr($data[$i], 4));
										}
									}
								} else if ($filters[0] === 'time') {
									if ($data[$i] != '') {
										$times = explode(':', $data[$i], 2);
										if (isset($times[1]) === FALSE) {
											$times[1] = 0;
										}
										$data[$i] = sprintf("%02d:%02d", $times[0], $times[1]);
									}
								}
							}
						}
						if (isset($val['default']) && $data[$i] == '') {
							$data[$i] = $val['default'];
						}
						// 修正用
						if (isset($this->updateValues[$c][$key])) {
							if ($this->updateValues[$c][$key] != $data[$i]) {
								$data[$i] = $this->updateValues[$c][$key];
							}
						}
						$this->data[$n][$key] = $data[$i];
					}
					else
					{
						if (isset($val['default'])) {
							$this->data[$n][$key] = $val['default'];
						} else {
							$this->data[$n][$key] = '';
						}
					}
					$i++;
				}
				// 追加項目
				if ($add_values !== NULL)
				{
					foreach ($add_values as $k => $v) {
						$this->data[$n][$k] = $v;
					}
				}
				// 月次タスク用
				if ($type === 'task_month')
				{
					if (empty($this->data[$n]['end_date'])) {
						$this->data[$n]['end_date'] = $this->data[$n]['start_date'];
					}
					if ($this->data[$n]['duty_type'] != '') {
						if ($this->data[$n]['duty_type'] == 'D') {
							if ($this->data[$n]['start_time'] == '') {
								$this->data[$n]['start_time'] = DAT_D_START_TIME;
							}
							if ($this->data[$n]['end_time'] == '') {
								$this->data[$n]['end_time'] = DAT_D_END_TIME;
							}
							if ($this->data[$n]['work_hours'] == '') {
								$this->data[$n]['work_hours'] = DAT_D_WORK_HOURS;
							}
						} else if ($this->data[$n]['duty_type'] == 'N') {
							if ($this->data[$n]['start_time'] == '') {
								$this->data[$n]['start_time'] = DAT_N_START_TIME;
							}
							if ($this->data[$n]['end_time'] == '') {
								$this->data[$n]['end_time'] = DAT_N_END_TIME;
							}
							if ($this->data[$n]['work_hours'] == '') {
								$this->data[$n]['work_hours'] = DAT_N_WORK_HOURS;
							}
							if ($this->data[$n]['night_work_hours'] == '') {
								$this->data[$n]['night_work_hours'] = DAT_N_NIGHT_HOURS;
							}
						}
					}
				}
				// Validation
				$entity = $table->newEntity($this->data[$n]);
				if ($entity->errors()) {
					foreach ($entity->errors() as $key => $errmsg) {
						foreach ($errmsg as $msg) {
							if ($this->data[$n][$key] != '') {
								$msg .= '['.$this->data[$n][$key].']';
							}
							$this->setErrors($c, [
								'type' => 'valid',
								'field' => $key,
								'value' => $this->data[$n][$key],
								'row' => $c,
								'message' => $msg
							]);
						}
					}
					$error_flg = TRUE;
				}
				$errors = $table->csvCheckUniqueData($this->data[$n]);
				if (count($errors)>0) {
					foreach ($errors as $key => $errmsg) {
						foreach ($errmsg as $msg) {
							if ($this->data[$n][$key] != '') {
								$msg .= '['.$this->data[$n][$key].']';
							}
							$this->setErrors($c, [
								'type' => 'valid',
								'field' => $key,
								'value' => $this->data[$n][$key],
								'row' => $c,
								'message' => $msg
							]);
						}
					}
					$error_flg = TRUE;
				}
				// 重複の確認
				$n++;
			}

			$c++;
		}

		@fclose($fp);

		$this->total = $c>0 ? $c-1 : 0;

		Log::debug($data_length.'列のデータが'.$this->total.'件');

		return $error_flg ? FALSE : TRUE;
	}

	public function import(Table &$table, $keys)
	{
		if (count($this->data) == 0)
		{
			return FALSE;
		}

		$key_list = explode(',', $keys);

		$connection = $table->connection();

		$connection->begin();

		foreach ($this->data as $row => $d)
		{
			$wh = [];
			foreach ($key_list as $key) {
				$key_arr = explode(':', $key);
				if (isset($key_arr[1])) {
					$wh[$key_arr[0]] = $key_arr[1];
				} else {
					$wh[$key_arr[0]] = $d[$key_arr[0]];
				}
			}

			$entity = $table->find()->where($wh)->first();

			if ($entity === NULL) {
				$entity = $table->newEntity($d);
			} else {
				$entity = $table->patchEntity($entity, $d);
			}
			if ($table->save($entity, ['atomic' => FALSE]) === FALSE) {
				$connection->rollback();
//$this->log($d);
//$this->log($entity);
				return FALSE;
			}
		}

		$connection->commit();

		return TRUE;
	}

	public function download($type, $fileName)
	{
		$fp = fopen('php://temp', 'r+b');

        Configure::load('csv_settings');
        $csv_settings = Configure::read('csv_settings.'.$type);
		Configure::load('form_settings');
		$form_settings = Configure::read('form_settings.'.$type);

		$headers = [];
		foreach ($csv_settings as $key) {
			if (preg_match("/^d_([0-9]+)$/", $key, $m)) {
				$headers[] = '"'.$m[1].'日"';
			} else if (isset($form_settings[$key])) {
				$val = $form_settings[$key];
				$headers[] = '"'.$val['text'].'"';
			} else {
				$headers[] = '"'.$key.'"';
				Log::error("CSV: ".$key."項目のform_settingsがありません。");
			}
		}
		fwrite($fp, implode(',', $headers)."\r\n");

		foreach ($this->data as $d)
		{
			$arr = $d->toArray();
			$lines = [];
			foreach ($csv_settings as $key)
			{
				if (isset($form_settings[$key])) {
					$val = $form_settings[$key];
				} else {
					$val = [];
				}
				if (isset($arr[$key])) {
					if (isset($val['type']) && $val['type'] === 'date') {
						$arr[$key] = substr($arr[$key], 0, 10);
					}
					if ($arr[$key]!='' && (substr($arr[$key], 0, 1) === '-' || substr($arr[$key], 0, 1) === '+')) {
						$arr[$key] = "'".$arr[$key];
					}
					$lines[] = '"'.$arr[$key].'"';
				} else {
					//$lines[] = '""';
					$lines[] = '';
				}
			}
			fwrite($fp, implode(',', $lines)."\r\n");
		}

		header("Content-type:application/vnd.ms-excel");
		header("Content-disposition:attachment;filename=".urlencode($fileName));
		rewind($fp);
		//$tmp = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
		//echo mb_convert_encoding($tmp, 'SJIS-win', 'UTF-8');
		echo mb_convert_encoding(stream_get_contents($fp), 'SJIS-win', 'UTF-8');
		exit();
	}

	public function setUpdateValues(&$values)
	{
		$this->updateValues = $values;
	}

	public function setErrors($c, array $errorData)
	{
		if (isset($this->errors[$c]) === FALSE) {
			$this->errors[$c] = array();
		}
		$this->errors[$c][] = $errorData;
	}

	public function getErrors()
	{
		return $this->errors;
	}

	public function getData()
	{
		return $this->data;
	}

	public function setData(&$data)
	{
		$this->data = $data;
	}

	public function getTotal()
	{
		return $this->total;
	}
}
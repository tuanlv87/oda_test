<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\I18n\Time;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;

use App\Controller\Component\Duty\DutyMisc;

class DutyComponent extends Component
{
	public $request;

	private $DEBUG_OPPTION = FALSE;

	private $team_bases = ['A', 'B', 'C'];
	private $team_honbu = ['X', 'Y'];
	private $task_month_preg = '/^(R|HL|ME|NE|FE|FD|OJ|SH|SE|SM|TE|MT)[0-9]+/';

	private $duty_year = 0;
	private $duty_month = 0;
	private $duty_year_month = 0;
	private $duty_fire_date = NULL;
	private $duty_team_id = NULL;
	private $duty_env_status = 0;
	private $ts = 0;
	private $start_ts = 0;
	private $end_ts = 0;
	private $max_day = 0;
	private $total_day = 0;
	private $dat_items = [];

	private $dat_bases = [];
	private $dat_temps = [];
	private $last_month_nw_list = [];
	private $kenmu_personnel_list = [];
	private $kikan_personnel_list = [];

	private $task_month_list = [];
	private $task_month_map = [];
	private $task_list = [];
	private $task_map = [];
	private $watch_fire_map = [];
	private $holiday_map = [];
	private $personnel_list = [];
	private $personnel_map = [];
	// 割り当て時間
	private $personnel_hours_map = [];
	// 時間ソート用
	private $personnel_sort_hours_map = [];
	// 前月までの勤務時間
	private $personnel_year_work_hours_map = [];
	private $check_errors = [];
	public $errors = [];

	private $fire_work_hours = 6;

	private $sort_order = SORT_ASC;

	public function initialize(array $config)
	{
		$controller = $this->_registry->getController();
        $this->request = $controller->request;

		// @TODO: とりあえず
		set_time_limit(300);
    }

	/**
	 * 一度作成した日程表データをクリアする処理
	 * 初期化メニューから作成済みの年月を指定した場合に使用
	 */
	public function clearDutyAssignment()
	{
		$this->duty_year = $this->request->data('duty_year');
		$this->duty_month = $this->request->data('duty_month');
		$this->duty_year_month = sprintf("%04d%02d", $this->duty_year, $this->duty_month);
		$this->makeYearMonth();

		$DutyAssignments = TableRegistry::get('DutyAssignments');

		$DutyAssignments->connection()->begin();

		$DutyAssignments->deleteAll([
			'da_year_month' => $this->duty_year_month
		]);

		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$DutyEnvs->deleteAll([
			'de_year_month' => $this->duty_year_month
		]);

		$DutyWorks = TableRegistry::get('DutyWorks');
		$DutyWorks->deleteAll([
			'dw_year_month' => $this->duty_year_month
		]);

		$TaskWorks = TableRegistry::get('TaskWorks');
		$TaskWorks->deleteAll([
			'tw_year_month' => $this->duty_year_month
		]);

		$TaskTables = TableRegistry::get('TaskTables');

		// 月次タスクのステータスを未処理に戻す
		$TaskMonths = TableRegistry::get('TaskMonths');
		$TaskMonths->updateAll([
			'status' => TMM_STATUS_TYPE_NOTCOMP
		], [
			'tm_year_month' => $this->duty_year_month,
			'status' => TMM_STATUS_TYPE_COMP
		]);

		$TaskTables->deleteAll([
			'tt_year_month' => $this->duty_year_month
		]);

		$DutyAssignments->connection()->commit();

		return TRUE;
	}

	/**
	 * 整合性チェック用
	 * 一旦変数に読み込む処理は作成時のものと共通
	 */
	public function checkDutyAssignment()
	{
		$duty_year_month = $this->request->data('duty_year_month');
		$this->duty_year = (int) substr($duty_year_month, 0, 4);
		$this->duty_month = (int) substr($duty_year_month, 4, 2);
		$this->duty_year_month = $duty_year_month;
		$this->makeYearMonth();
		$this->initParams();

		// 祝日
		$this->loadHolidayMap();

		// 警備員
		$this->loadPersonnelList();

		$this->loadTaskList();
		$this->loadTaskMonthList(FALSE);

		// 設定済のDATを読み込み
		$this->loadDutyAssignment(TRUE);

		$this->makeTaskData();

		$duty_base_hours = Configure::read('duty_base_hours');
		$base_hours = $duty_base_hours[$this->total_day];
		$duty_a2_base_hours = Configure::read('duty_a2_base_hours');
		$a2_base_hours = $duty_a2_base_hours[$this->total_day];

		// 宿日直・消防訓練マスタ
		$WatchFires = TableRegistry::get('WatchFires');
		$watch_fire_list = $WatchFires->find()->where([
			'wf_year_month' => $this->duty_year_month,
			'status' => WFT_STATUS_TYPE_NOTCOMP
		])->toArray();

		$check_fires = [];
		$check_nws = [];
		$check_dws = [];

		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 定期消防訓練
			$this->makeWatchFireMap($watch_fire_list);
			$this->ts += 86400;
		}

		$this->check_errors = [];

		if (count($this->dat_items) > 0)
		{
			// チェック
			foreach ($this->dat_items as $p_id => $data)
			{
				$ts = $this->start_ts;

				$is_renzoku = FALSE;

				// 長期休暇チェック
				$vacation_days = 0;
				$work_hours = 0;
				$night_work_hours = 0;

				for ($i=0; $i<$this->total_day; $i++)
				{
					if (isset($data[$ts]))
					{
						$now = $this->getDutyDatas($p_id, $ts);
						$after = $this->getDutyDatas($p_id, $ts + 86400);
						$before = $this->getDutyDatas($p_id, $ts - 86400);

						// 長期休暇チェック
						if (in_array(DAT_CODE_SHITEI, $now->types)
								|| in_array(DAT_CODE_NORMAL, $now->types)
								|| in_array(DAT_CODE_SPECIAL, $now->types)
								|| in_array(DAT_CODE_RINJI, $now->types)
								|| in_array(DAT_CODE_KOUKYU, $now->types))
						{
							$vacation_days++;
						}

						// HD1（指定休）の翌日にHD6（明け）があるか
						if (in_array(DAT_CODE_SHITEI, $now->types) && in_array(DAT_CODE_AKE, $after->types))
						{
							$this->setCheckError($p_id, $ts, 'HD1（指定休）の翌日にHD6（明け）が配置されています。');
						}

						$work_hours += $now->work_hours;
						$night_work_hours += $now->night_work_hours;

						if (in_array(DAT_CODE_D, $now->dn) && in_array(DAT_CODE_N, $now->dn))
						{
							// DN勤務の翌日は明けが無ければNG
							// DN勤務の翌日にNはOK
							if (in_array(DAT_CODE_AKE, $after->types)) {

							} else if (in_array(DAT_CODE_N, $after->dn) && in_array(DAT_CODE_D, $after->dn) === FALSE) {

							} else if (in_array(DAT_CODE_KOUKYU, $after->types)
									|| in_array(DAT_CODE_SHITEI, $after->types)
									|| in_array(DAT_CODE_RINJI, $after->types)
									|| in_array(DAT_CODE_NORMAL, $after->types)) {

							} else if (count($after->types)==0) {

							} else if (count($after->dn) > 0) {
								$this->setCheckError($p_id, $ts, 'DN勤務の翌日に（'.implode(',', $after->dn).'）が配置されています。明け（'.DAT_CODE_AKE.'）を配置してください。');
							}
						}
						else if (in_array(DAT_CODE_N, $now->dn))
						{
							// N勤務明けにD勤務はNG
							if (in_array(DAT_CODE_D, $after->dn))
							{
								$this->setCheckError($p_id, $ts, 'DNまたはN勤務の翌日にD勤務が配置されています。');
							}
						}

						if (in_array(DAT_CODE_FE00, $now->types))
						{
							if (isset($check_fires[$ts]) === FALSE) {
								$check_fires[$ts] = 0;
							}
							$check_fires[$ts]++;
						}
						else if (in_array(DAT_CODE_NW, $now->types))
						{
							if (isset($check_nws[$ts]) === FALSE) {
								$check_nws[$ts] = 0;
							}
							$check_nws[$ts]++;
						}
						else if (in_array(DAT_CODE_DW, $now->types))
						{
							if (isset($check_dws[$ts]) === FALSE) {
								$check_dws[$ts] = 0;
							}
							$check_dws[$ts]++;
						}

						// 連続勤務のチェック
						if ($is_renzoku === FALSE && $this->checkRenzoku($p_id, $ts) === FALSE)
						{
							$this->setCheckError($p_id, $ts, '7日以上の連続勤務が発生しています。');
							// 該当者はここで終了フラグ
							$is_renzoku = TRUE;
						}


					}
					$ts += 86400;
				}

				// 通常の長期休暇チェック
				$total_hours = $work_hours + $night_work_hours + ($vacation_days * DAT_PAID_VACATION);
				if ($this->personnel_list[$p_id]->title_code == 'A2')
				{
					if ($total_hours>0 && $total_hours < $a2_base_hours)
					{
						$this->setCheckError($p_id, 0, '勤務時間の合計（'.($work_hours + $night_work_hours).'時間）＋休暇日数の合計（'.$vacation_days.'日）が規定時間（'.$a2_base_hours.'時間）を下回っています。');
					}
				}
				else {
					if ($total_hours>0 && $total_hours < $base_hours)
					{
						$this->setCheckError($p_id, 0, '勤務時間の合計（'.($work_hours + $night_work_hours).'時間）＋休暇日数の合計（'.$vacation_days.'日）が規定時間（'.$base_hours.'時間）を下回っています。');
					}
				}
			}

			// 消防訓練
			$ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				if (isset($this->watch_fire_map[$ts][DAT_CODE_FE])) {
					if (isset($check_fires[$ts]) === FALSE || empty($check_fires[$ts])) {
						$this->setCheckError(0, $ts, '消防訓練が配置されていません。');
					}
				}
				if (isset($this->watch_fire_map[$ts][DAT_CODE_NW])) {
					if (isset($check_nws[$ts]) === FALSE || empty($check_nws[$ts])) {
						$this->setCheckError(0, $ts, '宿直が配置されていません。');
					}
				}
				if (isset($this->watch_fire_map[$ts][DAT_CODE_DW])) {
					if (isset($check_dws[$ts]) === FALSE || empty($check_dws[$ts])) {
						$this->setCheckError(0, $ts, '日直が配置されていません。');
					}
				}
				$ts += 86400;
			}

			$check_names = [
				'personnel' => '警備員',
				'manager' => 'マネージャー',
				'sub_manager' => 'サブ・マネージャー',
				'leader' => 'リーダー',
				'sub_leader' => 'サブ・リーダー',
				'chief' => 'チーフ',
				'sub_chief' => 'サブ・チーフ',
				'woman_only' => '女性のみ',
				//'woman_possible',
				'license_01' => 'Q1',
				'license_02' => 'Q2',
				'license_03' => 'Q3',
				'license_04' => 'Q4',
				'license_05' => 'Q5'
			];

			$DutyWorks = TableRegistry::get('DutyWorks');

			$task_counts = [];

			if (count($this->task_map)>0)
			{
				foreach ($this->task_map as $ts => $dd)
				{
					if (isset($task_counts[$ts]) === FALSE) {
						$task_counts[$ts] = [];
					}

					foreach ($dd as $d)
					{
						foreach ($check_names as $name => $text) {
							if (isset($task_counts[$ts][$name]) === FALSE) {
								$task_counts[$ts][$name] = 0;
							}
							if ($d->{$name} > 0) {
								$task_counts[$ts][$name] += $d->{$name};
							}
						}
					}
				}
			}

			$check_personnel_names = [];

			if (count($this->task_month_map)>0)
			{
				foreach ($this->task_month_map as $ts => $dd)
				{
					if (isset($task_counts[$ts]) === FALSE) {
						$task_counts[$ts] = [];
					}

					foreach ($dd as $d)
					{
						// 警備要員数としてカウントするもの
						if (preg_match("/^(R|HL)[0-9]+/", $d->tm_id))
						{
							foreach ($check_names as $name => $text) {
								if (isset($task_counts[$ts][$name]) === FALSE) {
									$task_counts[$ts][$name] = 0;
								}
								if ($name == 'personnel') {
									if ($d->personnel_names!='') {
										$name_arr = explode(';', str_replace(['；','、',','], ';', $d->personnel_names));
										//$task_counts[$ts][$name] += count($name_arr);
									} else {
										//$task_counts[$ts][$name] += $d->{$name};
									}
								} else if ($d->{$name} > 0) {
									$task_counts[$ts][$name] += $d->{$name};
								}
							}
							$duty_total = $DutyWorks->getTotal(date('Y-m-d', $ts), $d->tm_id);
							if ($duty_total < $d->personnel) {
								$this->setCheckError(0, $ts, '月次タスクID：'.$d->tm_id.'の必要人数'.$d->personnel.'名に対して'.$duty_total.'名しか配置されていません。');
							}
						}
						// 警備員名
						if ($d->personnel_names != '')
						{
							$name_arr = explode(';', str_replace(['；','、',','], ';', $d->personnel_names));
							foreach ($name_arr as $personnel_name)
							{
								$personnel_name = trim($personnel_name);

								if (empty($personnel_name)) continue;

								$notfound = TRUE;
								foreach ($this->personnel_list as $pd)
								{
									if ($pd->name == $personnel_name) {
										if (isset($check_personnel_names[$ts]) === FALSE) {
											$check_personnel_names[$ts] = [];
										}
										$check_personnel_names[$ts][$pd->p_id] = [
											'tm_id' => $d->tm_id,
											'name' => $personnel_name
										];
										$notfound = FALSE;
										//$task_counts[$ts]['personnel']++;
										break;
									}
								}
								if ($notfound) {
									$this->setCheckError(0, $ts, '月次タスク(' . $d->tm_id . ')で指定された警備員名：'.$personnel_name.'が見つかりません。');
								}
							}
						}
					}
				}
			}

			// 必要な指定休
			$count_sunday = $this->countSunday();

			$personnel_counts = [];
			$duty_personnel_checks = Configure::read('duty_personnel_checks');

			// チェック
			foreach ($this->dat_items as $p_id => $data)
			{
				$ts = $this->start_ts;
				$holiday_total = 0;
				for ($i=0; $i<$this->total_day; $i++)
				{
					if (isset($data[$ts]))
					{
						$duty_types = $this->getDutyTypes($p_id, $ts);

						$kyuuka_arr = [];
						$kinmu_arr = [];

						foreach ($duty_types as $duty_type)
						{
							if ($duty_type == DAT_CODE_NORMAL
									|| $duty_type == DAT_CODE_SPECIAL
									|| $duty_type == DAT_CODE_RINJI
									|| $duty_type == DAT_CODE_SHITEI
									|| $duty_type == DAT_CODE_KOUKYU)
							{
								$kyuuka_arr[] = $duty_type;
							}
							else if ($duty_type != DAT_CODE_FE00 && substr($duty_type, 0, 1) != "+" && substr($duty_type, 0, 1) != "-")
							{
								// 消防訓練は除く
								$kinmu_arr[] = $duty_type;
							}

							if ($duty_type == DAT_CODE_D
									|| $duty_type == DAT_CODE_N
									|| preg_match("/^(R|HL)[0-9]+/", $duty_type))
							{
								if (isset($this->personnel_list[$p_id]))
								{
									if (isset($personnel_counts[$ts]) === FALSE) {
										$personnel_counts[$ts] = [];
									}

									$personnel = $this->personnel_list[$p_id];

									foreach ($check_names as $name => $text) {
										if (isset($personnel_counts[$ts][$name]) === FALSE) {
											$personnel_counts[$ts][$name] = 0;
										}
										if ($name === 'personnel') {
											$personnel_counts[$ts][$name] += 1;
										} else if (isset($duty_personnel_checks[$name])) {
											if ($personnel->title_code == $duty_personnel_checks[$name]) {
												$personnel_counts[$ts][$name] += 1;
											}
										} else if ($name === 'woman_only') {
											if ($personnel->gender == GENDER_TYPE_WOMAN) {
												$personnel_counts[$ts][$name] += 1;
											}
										} else if ($personnel->{$name}>0) {
											$personnel_counts[$ts][$name] += 1;
										}
									}
								}
							}
							else if ($duty_type == DAT_CODE_SHITEI)
							{
								$holiday_total++;
							}
						}

						if (count($kyuuka_arr)>0 && count($kinmu_arr)>0)
						{
							$this->setCheckError($p_id, $ts, '休暇コード（'.implode(',', $kyuuka_arr).'）と勤務コード（'.implode(',',$kinmu_arr).'）が被っています。');
						}

						// 警備員名指定のチェック
						if (isset($check_personnel_names[$ts][$p_id])) {
							$tm_id = $check_personnel_names[$ts][$p_id]['tm_id'];
							$name = $check_personnel_names[$ts][$p_id]['name'];
							if (in_array($tm_id, $duty_types) === FALSE) {
								$this->setCheckError($p_id, $ts, '月次タスクマスター(' . $tm_id . ')で指定された警備員名：'.$name.'が配置されていません。');
							}
						}
					}
					$ts += 86400;
				}
				// 指定休の数
				$holiday_total = $this->getShiteiCount($p_id);
				if ($holiday_total < $count_sunday) {
					if (isset($this->personnel_list[$p_id]) && $this->personnel_list[$p_id]->status == PM_STATUS_TYPE_VALID) {
						$this->setCheckError($p_id, 0, "指定休の必要日数".$count_sunday.'日に対して'.$holiday_total.'日しか配置されていません。');
					}
				}
			}

			if (count($task_counts)>0 && count($personnel_counts)>0)
			{
				foreach ($task_counts as $ts => $counts)
				{
					foreach ($counts as $name => $c)
					{
						if ($c > 0)
						{
							// 設定されていない場合は0とする
							if (!isset($personnel_counts[$ts][$name])) {$personnel_counts[$ts][$name] = 0;}

							if ($personnel_counts[$ts][$name] < $c) {
								$this->setCheckError(0, $ts, $check_names[$name].'の必要人数'.$c.'名に対して'.$personnel_counts[$ts][$name].'名しか配置されていません。');
							}
						}
					}
				}
			}
		}

		return count($this->check_errors)>0 ? FALSE : TRUE;
	}

	private function getShiteiCount($p_id)
	{
		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work =  $DutyWorks->find()->select([
			'total' => 'COUNT(*)'
		])->where([
			'dw_year_month' => $this->duty_year_month,
			'p_id' => $p_id,
			'duty_type' => DAT_CODE_SHITEI
		])->first();
		return $duty_work->total;
	}

	private function checkRenzoku($p_id, $ts)
	{
		// 1週間以上の連続勤務は禁止
		$flag = FALSE;
		for ($i=0; $i<7; $i++)
		{
			$tts = $ts - (86400 * $i);
			if (isset($this->dat_items[$p_id][$tts]) && count($this->dat_items[$p_id][$tts])>0) {
				foreach ($this->dat_items[$p_id][$tts] as $d) {
					if (preg_match('/^HD[0-9]+/', $d['duty_type'])) {
						$flag = TRUE;
					}
				}
			} else {
				$flag = TRUE;
			}
		}

		return $flag;
	}

	private function setCheckError($p_id, $ts, $message)
	{
		if (isset($this->check_errors[$ts][$p_id]) === FALSE) {
			$this->check_errors[$ts][$p_id] = [];
		}
		if (isset($this->personnel_list[$p_id])) {
			$name = $this->personnel_list[$p_id]->name . "({$p_id})";
		} else {
			$name = '';
		}
		$this->check_errors[$ts][$p_id][] = [
			'message' => $message,
			'name' => $name
		];
	}

	public function getCheckErrors()
	{
		ksort($this->check_errors);
		return $this->check_errors;
	}

	private function makeYearMonth()
	{
		$this->duty_month -= 1;
		if ($this->duty_month == 0) {
			$this->duty_month = 12;
			$this->duty_year -= 1;
		}
	}

	/**
	 * プログラムで使用する変数の事前処理
	 */
	private function initParams()
	{
		// 開始日のタイムスタンプ
		// 2015-05 => 2015-04-21 - 2015-05-20
		$this->start_ts = mktime(0,0,0,$this->duty_month,DAT_START_DAY,$this->duty_year);
		// 対象月の月末数
		$this->max_day = date('t', mktime(0,0,0,$this->duty_month,1,$this->duty_year));
		// 対象月の日数
		$this->total_day = ($this->max_day - (DAT_START_DAY - 1)) + (DAT_START_DAY - 1);
		// 終了
		$this->end_ts = $this->start_ts + ($this->total_day * 86400) - 86400;
	}

	/**
	 * 初期化、該当月分の日程表枠を作成する
	 */
	public function initDutyAssignment()
	{
		$this->duty_year = $this->request->data('duty_year');
		$this->duty_month = $this->request->data('duty_month');
		$this->duty_year_month = sprintf("%04d%02d", $this->duty_year, $this->duty_month);
		$this->makeYearMonth();
		$this->initParams();

		// 有効な警備員だけ取得
		// チーム順：X,A,B,C,Y
		// 役職順
		// クルーID順
		// Personnel ID順
		// 社員番号順
		$Personnels = TableRegistry::get('Personnels');
		$personnel_list = $Personnels->find()->where([
			'Personnels.status' => PM_STATUS_TYPE_VALID
		])->join([
			'table' => 'titles',
			'alias' => 't',
			'type' => 'LEFT',
			'conditions' => [
				'Personnels.title_code = t.title_code',
				't.title_code != \'CHF-S\'',
				't.title_code != \'A1\'',
				't.title_code != \'A2\''
			]
		])->order([
			'Personnels.team_id=\'X\'' => 'DESC',
			'Personnels.team_id' => 'ASC',
			't.title_order IS NULL' => 'ASC',
			't.title_order' => 'ASC',
			'Personnels.crew_id' => 'ASC',
			'Personnels.personnel_id' => 'ASC',
			'Personnels.p_id' => 'ASC'
		])->toArray();

		if (count($personnel_list) > 0)
		{
			$DutyAssignments = TableRegistry::get('DutyAssignments');
			$DutyAssignments->connection()->begin();

			$document_order = 0;

			foreach ($personnel_list as $personnel)
			{
				$new_employee = $this->isNewEmployee($personnel) ? DAT_NEW_EMPLOYEE : DAT_OLD_EMPLOYEE;
				// 勤続年数の計算
				$service_years = 0;
				if ($personnel->enter_date && $personnel->enter_date->timestamp>0) {
					// 勤続日数
					$diff_days = ($this->start_ts - $personnel->enter_date->timestamp) / 86400;
					// 一ヶ月の平均日数
					$mm = 365.25 / 12;
					$yy_pass = floor($diff_days / 365.25);
					$mm_pass = floor(($diff_days - (365.25 * $yy_pass)) / $mm);
					$service_years = number_format($yy_pass + ($mm_pass / 12), 1);
				}

				$personnel_name = str_replace([' ', '　'], '', $personnel->name);

				$duty_assignment = $DutyAssignments->newEntity([
					'status' => DAT_STATUS_DEFAULT,
					'da_year_month' => $this->duty_year_month,
					'p_id' => $personnel->p_id,
					'name' => $personnel_name,
					'kana' => $personnel->kana,
					'gender' => $personnel->gender,
					'service_years' => $service_years,
					'new_employee' => $new_employee,
					'title_code' => $personnel->title_code,
					'paid_vacation' => $personnel->paid_vacation,
					'last_paid_vacation' => $personnel->last_paid_vacation,
					'team_id' => $personnel->team_id,
					'crew_id' => $personnel->crew_id,
					'personnel_id' => $personnel->personnel_id,
					'fire_id' => $personnel->fire_id,
					'd_duty' => 0,
					'n_duty' => 0,
					'dn_duty' => 0,
					'day_duty' => 0,
					'night_duty' => 0,
					'fire_plural' => 0,
					'fire_jippo' => 0,
					'acting_captain' => 0,
					'meal_allowance' => 0,
					'absence_days' => 0,
					'work_days' => 0,
					'vacation_days' => 0,
					'work_hours' => 0,
					'night_work_hours' => 0,
					'extra_work_hours' => 0,
					'extra_night_work_hours' => 0,
					'overtime25' => 0,
					'overtime35' => 0,
					'r_days' => 0,
					'hl_days' => 0,
					'hd1_days' => 0,
					'hd2_days' => 0,
					'hd3_days' => 0,
					'hd4_days' => 0,
					'hd5_days' => 0,
					'x_days' => 0,
					'y_days' => 0,
					'z_days' => 0,
					'me1_days' => 0,
					'me2_days' => 0,
					'ne1_hours' => 0,
					'ne2_hours' => 0,
					'ne3_hours' => 0,
					'ne4_hours' => 0,
					'f_hours' => 0,
					'fe_hours' => 0,
					'fd_days' => 0,
					'oj1_hours' => 0,
					'oj2_hours' => 0,
					'oj3_hours' => 0,
					'sh_days' => 0,
					'se_hours' => 0,
					'se_night_hours' => 0,
					'sm_hours' => 0,
					'sm_night_hours' => 0,
					'te_days' => 0,
					'mt_hours' => 0,
					'document_order' => $document_order
				]);

				if ($DutyAssignments->save($duty_assignment) === FALSE) {
					$DutyAssignments->connection()->rollback();
					Log::error($duty_assignment->errors());
					$this->errors = $duty_assignment->errors();
					return FALSE;
				}

				$document_order++;
			}

			$DutyAssignments->connection()->commit();
		}

		// 日程表作成の状態管理
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->newEntity([
			'de_year_month' => $this->duty_year_month,
			'status' => DE_STATUS_INIT
		]);
		$DutyEnvs->save($duty_env);

		return TRUE;
	}

	/**
	 * 日程表作成メイン処理
	 */
	public function buildDutyAssignment()
	{
		$duty_year_month = $this->request->data('duty_year_month');
		$this->duty_year = (int)substr($duty_year_month, 0, 4);
		$this->duty_month = (int)substr($duty_year_month, 4, 2);
		$this->duty_year_month = $duty_year_month;
		$this->makeYearMonth();
		$this->duty_fire_date = $this->request->data('duty_fire_date');
		$this->duty_team_id = $this->request->data('duty_team_id');
		$this->duty_env_status = $this->request->data('duty_env_status');
		$this->initParams();

		// 祝日
		$this->loadHolidayMap();

		// 警備員
		$this->loadPersonnelMap();

		$is_new_build = ($this->duty_env_status != DE_STATUS_BUILD);

		// 新規作成
		if ($is_new_build)
		{
			// タスク
			$this->loadTaskList();
			// 月次タスク
			$this->loadTaskMonthList();
		}
		// 更新
		else
		{
			$DutyEnvs = TableRegistry::get('DutyEnvs');
			$duty_env = $DutyEnvs->find()->where(['de_year_month'=>$this->duty_year_month])->first();
			if ($duty_env->start_team != '') {
				$this->duty_team_id = $duty_env->start_team;
			}
			if ($duty_env->start_fire_day > 0) {
				$this->duty_fire_date = $duty_env->start_fire_day;
			}
			// 月次タスク
			$this->loadTaskMonthList();
		}

		// 開始チームからDN日をローテーション
		$this->makeDNBase();

		// 初期化済、作成済のDATを読み込み
		$this->loadDutyAssignment();

		// タスク
		$this->makeTaskData();

		if ($is_new_build)
		{
			// 役職者休日は先に設定
			$this->assignTitleHoliday();

			// 本部の休日
			$this->assignTeamX();

			// 宿日直・消防訓練マスタ
			$WatchFires = TableRegistry::get('WatchFires');
			$watch_fire_list = $WatchFires->find()->where([
				'wf_year_month' => $this->duty_year_month,
				'status' => WFT_STATUS_TYPE_NOTCOMP
			])->toArray();

			// 先月の宿直状況
			$this->loadLastMonthNw();

			$this->ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				// 定期消防訓練
				$this->makeWatchFireMap($watch_fire_list);
				$this->assignFireTraining();
				$this->ts += 86400;
			}

			// 優先タスク
			$this->assignPriorityTask();
		}

		$this->WRITE_DEBUG_LOG("個人指定割り当て開始");
		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 個人指定タスク
			$this->assignSpecialTask();
			$this->ts += 86400;
		}
		$this->WRITE_DEBUG_LOG("個人指定割り当て終了");

		if ($is_new_build)
		{
			$this->WRITE_DEBUG_LOG("定期消防訓練後のDN配置");
			$this->ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				// 定期消防訓練後のDN配置
				$this->assignTempsTask();
				$this->ts += 86400;
			}
			$this->WRITE_DEBUG_LOG("定期消防訓練後のDN終了");
		}

		if ($is_new_build)
		{
			// 定常タスクの割り振り
			$this->assignAllTask();
		}

		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 月次タスクの割り振り
			$this->assignTaskMonth();
			$this->ts += 86400;
		}


		if ($is_new_build)
		{
			$this->ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				// 宿直の配置
				$this->assignNW();
				$this->ts += 86400;
			}

			$this->ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				// 日直の配置
				$this->assignDW();
				$this->ts += 86400;
			}

			// 兼務員、機関員の配置
			$this->assignFireKenmu();

			// 残務日の配置
			$this->assignFireZanmu();

			// フェローA2にDNを割り当てる
			$this->assignTaskDNtoA2();

			// 指定休の配置
			$this->createShiteikyu();
		}

		if (count($this->errors)>0) {
			return FALSE;
		}

		// TMT作成
		$this->createTaskTable($is_new_build);

		// DAT作成
		if ($is_new_build) {
			$this->endProc();
		}

		$this->createDutyAssignment();

		// 勤務の詳細を一時保存
		$this->createDutyWork();

		// データ管理情報を保存
		if ($is_new_build) {
			$this->updateDutyEnv();
		}

		return TRUE;
	}

	/**
	 * 月次タスクの名前指定追加用の作成
	 */
	public function buildAddDutyAssignment()
	{
		$duty_year_month = $this->request->data('duty_year_month');
		$this->duty_year = (int) substr($duty_year_month, 0, 4);
		$this->duty_month = (int) substr($duty_year_month, 4, 2);
		$this->duty_year_month = $duty_year_month;
		$this->makeYearMonth();
		//$this->duty_fire_date = $this->request->data('duty_fire_date');
		//$this->duty_team_id = $this->request->data('duty_team_id');
		$this->duty_env_status = $this->request->data('duty_env_status');
		$this->initParams();

		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'de_year_month' => $this->duty_year_month
		])->first();
		if ($duty_env->start_team != '') {
			$this->duty_team_id = $duty_env->start_team;
		}
		if ($duty_env->start_fire_day > 0) {
			$this->duty_fire_date = $duty_env->start_fire_day;
		}

		// 祝日
		$this->loadHolidayMap();

		// 警備員
		$this->loadPersonnelMap();

		// 月次タスク
		$this->loadTaskMonthList();

		// 開始チームからDN日をローテーション
		$this->makeDNBase();

		// 初期化済、作成済のDATを読み込み
		$this->loadDutyAssignment();

		// タスク
		$this->makeTaskData();

		$add_flag = FALSE;
		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 個人指定タスク
			if ($this->assignSpecialTask(true)) {
				$add_flag = TRUE;
			}
			$this->ts += 86400;
		}
		// 追加氏名が無かったのでエラーにする
		if ($add_flag === FALSE) {
			if (empty($this->errors)) {
				$this->errors[] = '名前指定で追加する月次タスクが見つかりませんでした。';
			}
			return FALSE;
		}
		if (count($this->errors)>0) {
			return FALSE;
		}

		// TMT作成
		$this->createTaskTable(FALSE);

		$this->createDutyAssignment();

		// 勤務の詳細を一時保存
		$this->createDutyWork();

		return TRUE;
	}

	/*
	 * ソート順に休暇設定時間を考慮する
	 */
	private function addHDHours()
	{
		foreach ($this->dat_items as $p_id => $data)
		{
			$ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				if (!isset($data[$ts])) {continue;}

				foreach ($data[$ts] as $d)
				{
					$duty_type = $d['duty_type'];
					if (preg_match("/^HD[2-4]$/", $duty_type))
					{
						$this->setPersonnelHoursMap($p_id, DAT_PAID_VACATION);
					}
					else if ($duty_type == DAT_CODE_PRI_KOUKYU)
					{
						// HD5は勤務時間(本来は勤務時間として考慮されないため、重みを調整してもよい)
						$this->setPersonnelHoursMap($p_id, DAT_PAID_VACATION / 2);
					}
				}
				$ts += 86400;
			}
		}
	}

	/**
	 * 休暇設定時の+D+Nなどの優先配置
	 */
	private function assignPriorityTask()
	{
		$pri_pids = [];
		// 全員分31日分をチェック
		foreach ($this->dat_items as $p_id => $data)
		{
			$this->ts = $this->start_ts;
			for ($i=0; $i<$this->total_day; $i++)
			{
				if (isset($data[$this->ts]))
				{
					foreach ($data[$this->ts] as $d)
					{
						$duty_type = $d['duty_type'];
						if ($duty_type === DAT_CODE_PRI_AKE)
						{
							// 明けを配置
							$this->setDatItem($p_id, DAT_CODE_AKE, $this->ts);
						}
						else if ($duty_type === DAT_CODE_PRI_KOUKYU)
						{
							// 公休を配置
							$this->setDatItem($p_id, DAT_CODE_KOUKYU, $this->ts);
						}
						else if ($duty_type === DAT_CODE_PRI_D
								|| $duty_type === DAT_CODE_PRI_N
								|| $duty_type === DAT_CODE_PRI_DN)
						{
							$pri_pids[] = [$p_id, $this->ts, $duty_type];
						}
					}
				}
				$this->ts += 86400;
			}
		}
		// タスクを配置
		// +Dなどの優先配置は条件は無視して良いのでisTaskOKは通さない。入力された通りに配置。
		if (count($pri_pids)>0)
		{
			foreach ($pri_pids as $arr)
			{
				$p_id = $arr[0];
				$this->ts = $arr[1];
				$duty_type = $arr[2];
				$set_types = [];

				if (isset($this->task_map[$this->ts]))
				{
					foreach ($this->task_map[$this->ts] as $i => &$task)
					{
						if ($duty_type === DAT_CODE_PRI_D) {
							if ($task->night_day !== DAT_CODE_D) {
								continue;
							}
							if (in_array(DAT_CODE_D, $set_types)) {
								continue;
							}
						} else if ($duty_type === DAT_CODE_PRI_N) {
							if ($task->night_day !== DAT_CODE_N) {
								continue;
							}
							if (in_array(DAT_CODE_N, $set_types)) {
								continue;
							}
						} else {
							if ($task->night_day === DAT_CODE_D) {
								if (in_array(DAT_CODE_D, $set_types)) {
									continue;
								}
							} else if ($task->night_day === DAT_CODE_N) {
								if (in_array(DAT_CODE_N, $set_types)) {
									continue;
								}
							}
						}

						$personnel_total = $task->personnel;
						$is_personnel = TRUE;

						$personnel = $this->getPersonnel($p_id);

						//if ($personnel_total>0 && $personnel !== NULL && $this->isTaskOK($personnel, $task))
						if ($personnel_total>0 && $personnel !== NULL)
						{
							$personnel_total--;
							// 他の条件も満たすか判定
							$this->checkTaskPersonnel($personnel, $task, TRUE);

							$this->setDatItem($personnel->p_id, $task, $this->ts);

							// DN勤務なら
							if ($this->isDN($personnel->p_id))
							{
								// 翌日：空け
								$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
								// 翌々日：公休
								$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts + 172800);
							}
							$set_types[] = $task->night_day;
						}
						$this->task_map[$this->ts][$i] = $task;
					}
				}
				if ($duty_type === DAT_CODE_PRI_D) {
					if (in_array(DAT_CODE_D, $set_types)) {
						continue;
					}
				} else if ($duty_type === DAT_CODE_PRI_N) {
					if (in_array(DAT_CODE_N, $set_types)) {
						continue;
					}
				} else {
					if (in_array(DAT_CODE_D, $set_types) && in_array(DAT_CODE_N, $set_types)) {
						continue;
					}
				}

			}
			$this->sortPersonnelHoursMap();
		}
	}

	/**
	 * 消防兼務員、機関員の配置
	 */
	private function assignFireKenmu()
	{
		// 消防兼務員の読み込み
		$this->loadFireKenmuPersonnel();

		$i = 0;
		$ts = $this->start_ts;
		if ($this->duty_fire_date == 22) {
			$i = 1;
			$ts += 86400;
		}
		for (;$i<$this->total_day; $i+=2)
		{
			// 消防兼務員は3人配置
			$km_d = 0;
			$km_n = 0;
			$km_arr = [];
			foreach ($this->kenmu_personnel_list as $n => $p) {
				$duty_types = $this->getDutyTypes($p->p_id, $ts);
				if ($km_d < 3 && in_array(DAT_CODE_D, $duty_types)
						&& in_array(DAT_CODE_FKN, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_FKD, $ts);
					$km_arr[$n] = $n;
					$km_d++;
				}
				if ($km_n < 3 && in_array(DAT_CODE_N, $duty_types)
						&& in_array(DAT_CODE_FKN, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_FKN, $ts);
					$km_arr[$n] = $n;
					$km_n++;
				}
				if ($km_d >=3 && $km_n >= 3) {
					break;
				}
			}
			if (count($km_arr)>0) {
				foreach ($km_arr as $n) {
					$this->kenmu_personnel_list[] = clone $this->kenmu_personnel_list[$n];
					unset($this->kenmu_personnel_list[$n]);
				}
			}
			// 機関員は1人配置
			$kn_d = 0;
			$kn_n = 0;
			$kn_arr = [];
			foreach ($this->kikan_personnel_list as $n => $p) {
				$duty_types = $this->getDutyTypes($p->p_id, $ts);
				if ($kn_d < 1 && in_array(DAT_CODE_D, $duty_types)
						&& in_array(DAT_CODE_FKN, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_FKD, $ts);
					$kn_arr[$n] = $n;
					$kn_d++;
				}
				if ($kn_n < 1 && in_array(DAT_CODE_N, $duty_types)
						&& in_array(DAT_CODE_FKN, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_FKN, $ts);
					$kn_arr[$n] = $n;
					$kn_n++;
				}
				if ($kn_d >=1 && $kn_n >= 1) {
					break;
				}
			}
			if (count($kn_arr)>0) {
				foreach ($kn_arr as $n) {
					$this->kikan_personnel_list[] = clone $this->kikan_personnel_list[$n];
					unset($this->kikan_personnel_list[$n]);
				}
			}
			$ts += (86400 * 2);
		}
	}

	/**
	 * 残務日の配置
	 */
	private function assignFireZanmu()
	{
		$this->loadFireKenmuPersonnel();

		$i = 0;
		$ts = $this->start_ts;
		if ($this->duty_fire_date == 21) {
			$i = 1;
			$ts += 86400;
		}
		for (;$i<$this->total_day; $i+=2)
		{
			// 消防兼務員
			$km_d = 0;
			$km_arr = [];
			foreach ($this->kenmu_personnel_list as $n => $p) {
				$duty_types = $this->getDutyTypes($p->p_id, $ts);
				if ($km_d < 3 && in_array(DAT_CODE_D, $duty_types) && in_array(DAT_CODE_EW, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_EW, $ts);
					$km_arr[] = $n;
					$km_d++;
				}
				if ($km_d >=3) {
					break;
				}
			}
			if (count($km_arr)>0) {
				foreach ($km_arr as $n) {
					$this->kenmu_personnel_list[] = clone $this->kenmu_personnel_list[$n];
					unset($this->kenmu_personnel_list[$n]);
				}
			}
			// 機関員
			$kn_d = 0;
			$kn_arr = [];
			foreach ($this->kikan_personnel_list as $n => $p) {
				$duty_types = $this->getDutyTypes($p->p_id, $ts);
				if ($kn_d < 1 && in_array(DAT_CODE_D, $duty_types) && in_array(DAT_CODE_EW, $duty_types) === FALSE) {
					$this->setDatItem($p->p_id, DAT_CODE_EW, $ts);
					$kn_arr[] = $n;
					$kn_d++;
				}
				if ($kn_d >=1) {
					break;
				}
			}
			if (count($kn_arr)>0) {
				foreach ($kn_arr as $n) {
					$this->kikan_personnel_list[] = clone $this->kikan_personnel_list[$n];
					unset($this->kikan_personnel_list[$n]);
				}
			}
			$ts += (86400 * 2);
		}
	}

	/**
	 * 消防兼務員、機関員の読み込み
	 */
	private function loadFireKenmuPersonnel()
	{
		// 兼務員、機関員を取得
		$Personnels = TableRegistry::get('Personnels');
		$personnel_list = $Personnels->find()->where([
			'status' => PM_STATUS_TYPE_VALID,
			'license_07 >' => 0
		])->toArray();

		$this->kenmu_personnel_list = [];
		$this->kikan_personnel_list = [];

		if (count($personnel_list)>0) {
			foreach ($personnel_list as $d)
			{
				if ($d->license_07 == 1) {
					$this->kenmu_personnel_list[] = $d;
				} else if ($d->license_07 == 2) {
					$this->kikan_personnel_list[] = $d;
				}
			}
		}
	}

	/**
	 * 先月の宿直情報を取得
	 * - 2ヶ月連続で宿直は割り当てない為
	 */
	private function loadLastMonthNw()
	{
		// DutyWorksから検索すれば簡単だが、あえてDutyAssignmentsから取得する
		$year = $this->duty_year;
		$month = $this->duty_month - 1;

		if ($month == 0) {
			$month = 12;
			$year -= 1;
		}

		$DutyAssignments = TableRegistry::get('DutyAssignments');
		$list = $DutyAssignments->find()->where([
			'da_year_month' => sprintf("%04d%02d", $year, $month)
		])->toArray();

		if (count($list)>0) {
			$day_order_array = Configure::read('day_order_array');
			foreach ($list as $d)
			{
				foreach ($day_order_array as $day)
				{
					$col = 'd_'.$day;
					if ($d->{$col} != '') {
						$types = explode(',', $d->{$col});
						if (in_array(DAT_CODE_NW, $types)) {
							$this->last_month_nw_list[] = $d->p_id;
							break;
						}
					}
				}
			}
		}
	}


	/**
	 * 祝日の読み込み
	 */
	private function loadHolidayMap()
	{
		$start_date = date("Y-m-d", $this->start_ts);
		$end_date = date("Y-m-d", strtotime(sprintf("%04d-%02d-%02d", $this->duty_year, $this->duty_month, DAT_START_DAY-1) . ' +1 month'));
		$this->holiday_map = TableRegistry::get('Holidays')->getHolidayMap($start_date, $end_date);
	}

	/**
	 * 開始チームからDN日を決める
	 */
	private function makeDNBase()
	{
		$duty_team_ids = array_keys(Configure::read('duty_team_ids'));
		$total = count($duty_team_ids);
		$index = array_search($this->duty_team_id, $duty_team_ids);

		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			$this->dat_bases[$ts] = [];
			// DN
			$this->dat_bases[$ts][] = $duty_team_ids[$index];
			// 公休
			$this->dat_bases[$ts][] = $duty_team_ids[$this->getNextIndex($total, $index + 1)];
			// 明け
			$this->dat_bases[$ts][] = $duty_team_ids[$this->getNextIndex($total, $index + 2)];

			$index++;
			if ($index >= $total) {
				$index = 0;
			}
			$ts += 86400;
		}
	}

	/**
	 * 21日のDNチーム以外が空欄になることを回避する処理
	 * @TODO: この処理は全体の配置が上手くいけば必要なくなるかもしれません。
	 */
	private function endProc()
	{
		// 3番目チームの調整
		$ts = $this->start_ts;
		$team_id = $this->dat_bases[$ts][2];
		foreach ($this->personnel_map[$team_id] as $p_id => $p) {
			// 明け日
			$ts = $this->start_ts;
			if (isset($this->dat_items[$p_id][$ts]) && count($this->dat_items[$p_id][$ts]) === 0) {
				$this->dat_items[$p_id][$ts][0] = $this->getDatItem($p_id, DAT_CODE_AKE, $ts);
			}
			// 公休日
			$ts = $this->start_ts + 86400;
			if (isset($this->dat_items[$p_id][$ts]) && count($this->dat_items[$p_id][$ts]) === 0) {
				$this->dat_items[$p_id][$ts][0] = $this->getDatItem($p_id, DAT_CODE_KOUKYU, $ts);
			}
		}

		// 空いているところはHD5で埋める
		for ($ts = $this->start_ts; $ts <= $this->end_ts; $ts += 86400)
		{
			foreach ($this->dat_bases[$ts] as $team_id)
			{
				foreach ($this->personnel_map[$team_id] as $p_id => $p) {
					if (isset($this->dat_items[$p_id][$ts]) && count($this->dat_items[$p_id][$ts]) === 0) {
						$this->dat_items[$p_id][$ts][0] = $this->getDatItem($p_id, DAT_CODE_KOUKYU, $ts);
					}
				}
			}
			foreach ($this->team_honbu as $team_id)
			{
				if (isset($this->personnel_map[$team_id]))
				{
					foreach ($this->personnel_map[$team_id] as $p_id => $p) {
						if (isset($this->dat_items[$p_id][$ts]) && count($this->dat_items[$p_id][$ts]) === 0) {
							$this->dat_items[$p_id][$ts][0] = $this->getDatItem($p_id, DAT_CODE_KOUKYU, $ts);
						}
					}
				}
			}
		}
	}

	/**
	 * ローテションのINDEXを取得
	 */
	private function getNextIndex($total, $next)
	{
		return $next>=$total ? $next - $total : $next;
	}

	/**
	 * 指定休の数
	 */
	private function countSunday()
	{
		$count_sunday = 0;
		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			$w = date('w', $ts);
			if ($w == 0) {
				$count_sunday++;
			}
			$ts += 86400;
		}
		return $count_sunday;
	}

	/**
	 * 定期消防訓練の読み込み
	 * @param type $watch_fire_list
	 */
	private function makeWatchFireMap(&$watch_fire_list)
	{
		if (empty($watch_fire_list)) return;

		foreach ($watch_fire_list as $d)
		{
			$col = 'd_'.date("j", $this->ts);
			if ($d->{$col} > 0) {
				$this->watch_fire_map[$this->ts][$d->wf_type] = $d->{$col};
			}
		}
	}

	/**
	 * 設定済の日程表データを読み込む
	 * 7日連続勤務を確認するため10日前からのデータを取得、7日前に変更しても良い
	 */
	private function loadDutyAssignment($is_check=FALSE)
	{
		// 10日前から読み込む
		$start_time = Time::createFromTimestamp($this->start_ts);
		$start_time->modify('-10 days');
		$start_date = $start_time->format("Y-m-d");
		$end_time = Time::createFromTimestamp($this->start_ts);
		$end_time->modify('+1 month');
		$end_date = $end_time->format("Y-m-d");

		$duty_year = $this->duty_year;
		$duty_month = $this->duty_month;
		$last_year_month = sprintf("%04d%02d", $duty_year, $duty_month);

		$DutyAssignments = TableRegistry::get('DutyAssignments');
		$duty_assignment_list = $DutyAssignments->find()->where([
			'status' => DAT_STATUS_DEFAULT,
			'OR' => [
				['da_year_month' => $this->duty_year_month],
				['da_year_month' => $last_year_month]
			]
		])->join([
			'table' => 'titles',
			'alias' => 't',
			'type' => 'LEFT',
			'conditions' => [
				'DutyAssignments.title_code = t.title_code',
				't.title_code != \'CHF-S\'',
				't.title_code != \'A1\'',
				't.title_code != \'A2\''
			]
		])->order([
			'DutyAssignments.da_year_month' => 'ASC',
			'DutyAssignments.team_id=\'X\'' => 'DESC',
			'DutyAssignments.team_id' => 'ASC',
			't.title_order IS NULL' => 'ASC',
			't.title_order' => 'ASC',
			'DutyAssignments.crew_id' => 'ASC',
			'DutyAssignments.personnel_id' => 'ASC',
			'DutyAssignments.p_id' => 'ASC'
		])->toArray();

		if (count($duty_assignment_list) > 0)
		{
			$DutyWorks = TableRegistry::get('DutyWorks');

			$duty_work_list = $DutyWorks->find()->where([
				'dw_date >=' => $start_date,
				'dw_date <' => $end_date
			])->toArray();

			$duty_work_map = [];

			if (count($duty_work_list) > 0) {
				foreach ($duty_work_list as $d)
				{
					if (isset($duty_work_map[$d->p_id][$d->dw_date->timestamp]) === FALSE) {
						$duty_work_map[$d->p_id][$d->dw_date->timestamp] = [];
					}
					$duty_work_map[$d->p_id][$d->dw_date->timestamp][] = $d;
				}
				// タスク
				$Tasks = TableRegistry::get('Tasks');
				$task_map = $Tasks->getTidMap();
				// 月次
				$TaskMonths = TableRegistry::get('TaskMonths');
				$task_month_map = $TaskMonths->getTmIdMap($this->duty_year_month);
			}

			$t = date('t', mktime(0,0,0,$this->duty_month,1,$this->duty_year));

			foreach ($duty_assignment_list as $d)
			{
				if ($d->da_year_month == $this->duty_year_month) {
					$order_arr = Configure::read('day_order_array');
					$last_flag = FALSE;
				} else {
					$order_arr = [11,12,13,14,15,16,17,18,19,20];
					$last_flag = TRUE;
				}

				foreach ($order_arr as $day)
				{
					if ($day > $t) {
						// 存在しない日は飛ばす
						continue;
					}

					$dcol = "d_".$day;
					$year = (int)substr($d->da_year_month, 0, 4);
					$month = (int)substr($d->da_year_month, 4, 2);
					if (! ($last_flag === FALSE && $day >= 1 && $day <= 20)) {
						if ($last_flag === FALSE) {
							$month -= 1;
							if ($month == 0) {
								$month = 12;
								$year -= 1;
							}
						}
					}
					$ts = mktime(0, 0, 0, $month, $day, $year);
					// ここでセットされるのは休日設定されたものだけ
					if (empty($d->{$dcol}))
					{
						$this->dat_items[$d->p_id][$ts] = [];
					}
					else if (isset($duty_work_map[$d->p_id][$ts]))
					{
						foreach ($duty_work_map[$d->p_id][$ts] as $dd)
						{
							// 過去バグの調整
							if ($last_flag === FALSE) {
								if ($dd->dw_year_month != $this->duty_year_month) {
									continue;
								}
							}
							if ($dd->task_type == DD_TYPE_TMM) {
								// 月次タスク
								if (isset($task_month_map[$dd->task_id])) {
									$task = $task_month_map[$dd->task_id];
									$this->setDatItem($d->p_id, $task, $ts, $is_check);
								}
							} else if ($dd->task_type == DD_TYPE_TM) {
								// 定常タスク
								if (isset($task_map[$dd->task_id])) {
									$task = $task_map[$dd->task_id];
									$this->setDatItem($d->p_id, $task, $ts, $is_check);
								}
							} else {
//								if ($d->p_id==5762 && date('Y-m-d',$ts)=='2015-10-21') {
//									Log::debug($dd->duty_type);
//								}
								// 休日、日直、宿直など
								$this->setDatItem($d->p_id, $dd->duty_type, $ts, $is_check);
							}
						}
					}
					else
					{
						// 休日設定、-D、-N、-DNなど
						$types = explode(',', $d->{$dcol});
						foreach ($types as $type)
						{
							// 手動入力したであろうものは弾く
							if ($type != DAT_CODE_D
									&& $type != DAT_CODE_N
									&& ! preg_match("/^(R|HL)[0-9]+/", $type))
							{
								$this->setDatItem($d->p_id, $type, $ts, $is_check);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 警備員の読み込み
	 */
	private function loadPersonnelList()
	{
		$Personnels = TableRegistry::get('Personnels');
		$this->personnel_list = $Personnels->getPidMap();
	}

	/**
	 * 警備員の取得
	 * チームごとに取得する
	 */
	private function loadPersonnelMap()
	{
		$personnel_list = $this->getPersonnelList();
		if (count($personnel_list) > 0) {
			foreach ($personnel_list as $d) {
				$this->personnel_map[$d->team_id][$d->p_id] = $d;
				// 時間でソートするための変数
				$this->personnel_hours_map[$d->team_id][$d->p_id] = 0;
				$this->personnel_sort_hours_map[$d->team_id][] = ["sort_order" => 0, "work_hours" => 0,  "renzoku" => 0,  "year_work_hours" => 0, "p_id" => $d->p_id];
			}
		}

		$personnel_year_list = $this->_getPersonnelYearList();
		if (count($personnel_year_list) > 0) {
			foreach ($personnel_year_list as $d) {
				$this->personnel_year_work_hours_map[$d->team_id][$d->p_id] = $d->work_hours;

				foreach ($this->personnel_sort_hours_map[$d->team_id] as $key => $_p)
				{
					if ($_p["p_id"] == $d->p_id)
					{
						$this->personnel_sort_hours_map[$d->team_id][$key]["year_work_hours"] = $d->work_hours;
						break;
					}
				}
			}
		}
	}

	/*
	 * ソートで考慮する時間をクリアする
	 */
	private function clearPersonnelMap()
	{
		$personnel_list = $this->getPersonnelList();
		foreach ($personnel_list as $d) {
			if ($d->title_code == 'A2') {
				continue;
			}

			$this->personnel_hours_map[$d->team_id][$d->p_id] = 0;

			foreach ($this->personnel_sort_hours_map[$d->team_id] as $key => $_p)
			{
				if ($_p["p_id"] == $d->p_id)
				{
					$this->personnel_sort_hours_map[$d->team_id][$key]["sort_order"] = 0;
					$this->personnel_sort_hours_map[$d->team_id][$key]["work_hours"] = 0;
					$this->personnel_sort_hours_map[$d->team_id][$key]["renzoku"] = 0;
					break;
				}
			}
		}
	}

	/*
	 * DN担当でDNでない勤務日数をカウントし、ソート用の変数に設定する
	 */
	private function setCountNotDNCount()
	{
		foreach ($this->personnel_sort_hours_map as $team_id => $personnels)
		{
			foreach ($personnels as $key => $_p) {
				$p_id = $_p["p_id"];

				$count = 0;
				for($ts = $this->start_ts; $ts <= $this->end_ts; $ts += 86400)
				{
					// DN担当でない場合はカウントしない
					if ($this->dat_bases[$ts][0] != $team_id) {continue;}
					if (!$this->isDN($p_id, $ts) && count($this->getDutyTypesToDN($p_id, $ts)) != 0)
					{
						$count++;
					}
				}

				$this->personnel_sort_hours_map[$team_id][$key]["sort_order"] = $count;
			}
		}
	}

	/*
	 * 連続勤務DN,明け,公休のパターンが何回続いているかを数え
	 * ソート用の変数に設定する
	 * 公休担当にD勤務を割り当てるときに使用する
	 */
	private function setRenzokuCount($current_ts)
	{
		foreach ($this->personnel_sort_hours_map as $team_id => $personnels)
		{
			// A,B,Cチーム以外は対象外
			if (!isset($this->dat_bases[$current_ts])) {continue;}
			if (!in_array($team_id, $this->dat_bases[$current_ts])) {continue;}
			// 公休担当でない場合はカウントしない
			if ($this->dat_bases[$current_ts][1] != $team_id) {continue;}
			foreach ($personnels as $key => $_p) {
				$p_id = $_p["p_id"];

				$count = 0;

				while (true)
				{
					$ake_ts = $current_ts - (3 * $count + 1) * 86400;
					$dn_ts = $current_ts - (3 * $count + 2) * 86400;
					$d_ts = $current_ts - (3 * $count + 3) * 86400;

					if ($this->isDN($p_id, $dn_ts) && $this->isD($p_id, $d_ts))
					{
						$count++;
					}
					else
					{
						break;
					}
				}

				$this->personnel_sort_hours_map[$team_id][$key]["renzoku"] = $count;
			}
		}
	}

	/*
	 * ソートで考慮する時間を再設定する
	 */
	private function resetPersonnelMap()
	{
		$this->clearPersonnelMap();

		foreach ($this->personnel_hours_map as $team_id => $personnels)
		{
			foreach ($personnels as $p_id => $hours)
			{
				// フェローA2はクリアしていないため再設定しない
				$personnel = $this->getPersonnel($p_id);
				if ($personnel->title_code == 'A2') {
					continue;
				}
				$work_hours = 0;
				for($ts = $this->start_ts; $ts <= $this->end_ts; $ts += 86400)
				{
					$dutyDates = $this->getDutyDatas($p_id, $ts);
					$work_hours += $dutyDates->work_hours;
				}
				$this->setPersonnelHoursMap($p_id, $work_hours);
			}
		}
	}

	private function getPersonnelList()
	{
		// 先月の累計時間順にする
		$time = new Time($this->start_ts);

		$Personnels = TableRegistry::get('Personnels');
		$personnel_list = $Personnels->find()
		->join([
			'table' => 'personnel_years',
			'alias' => 'py',
			'type' => 'LEFT',
			'conditions' => [
				'Personnels.p_id = py.p_id',
				'py.py_year_month' => date("Ym", $time->timestamp)
			]
		])
		->where([
			'Personnels.status' => PM_STATUS_TYPE_VALID
		])
		->order([
			'py.work_hours' => 'ASC',
			'Personnels.crew_id' => 'ASC',
			'Personnels.personnel_id' => 'ASC'
		])
		->toArray();

		return $personnel_list;
	}

	private function _getPersonnelYearList()
	{
		$time = new Time($this->start_ts);

		$PersonnelYears = TableRegistry::get('PersonnelYears');
		$personnel_list = $PersonnelYears->find()
		->join([
			'table' => 'personnels',
			'alias' => 'p',
			'type' => 'LEFT',
			'conditions' => [
				'PersonnelYears.p_id = p.p_id',
				'p.status' => PM_STATUS_TYPE_VALID
			]
		])
		->where([
			'PersonnelYears.py_year_month' => date("Ym", $time->timestamp)
		])
		->order([
			'PersonnelYears.work_hours' => 'ASC',
			'p.crew_id' => 'ASC',
			'p.id' => 'ASC'
		])
		->toArray();

		return $personnel_list;
	}

	/**
	 * 定常タスクの読み込み
	 */
	private function loadTaskList()
	{
		$Tasks = TableRegistry::get('Tasks');
		// Dから割り当てるためにnight_dayで並び替え
		$task_list = $Tasks->find()->where([
			'status' => TM_STATUS_TYPE_VALID
		])->toArray();

		if (empty($task_list) === FALSE)
		{
			foreach ($task_list as $d)
			{
				$this->task_list[$d->t_id] = $d;
			}
		}
	}

	/**
	 * 未処理の月次タスクの読み込み
	 */
	private function loadTaskMonthList($status_notcomp=TRUE)
	{
		$wh = [
			'tm_year_month' => $this->duty_year_month
		];
		// 整合性チェックの場合はすべて取得する必要があるための切り替え
		if ($status_notcomp) {
			$wh['status'] = TMM_STATUS_TYPE_NOTCOMP;
		} else {
			$wh['status !='] = TMM_STATUS_TYPE_CANCEL;
		}
		// 月次タスク
		$TaskMonths = TableRegistry::get('TaskMonths');
		$task_month_list = $TaskMonths->find()->where($wh)->order([
			'personnel_names' => 'ASC',
			'start_date' => 'ASC'
		])->toArray();

		if (empty($task_month_list) === FALSE)
		{
			foreach ($task_month_list as $d)
			{
				$this->task_month_list[$d->tm_id] = $d;
			}
		}
	}

	/**
	 * 読み込んだ定常タスク、月次タスクを日付ごとに再配置
	 */
	private function makeTaskData()
	{
		$day_names = Configure::read('day_names');

		// 新規
		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 定常タスク
			if (count($this->task_list) > 0)
			{
				$wnum = date("w", $ts);
				// 日・祝日
				if ($wnum == 0 || $this->isHoliday($ts)) {
					$day_type = 'H';
				// 土曜日
				} else if ($wnum == 6) {
					$day_type = 'S';
				// 平日
				} else {
					$day_type = 'W';
				}
				$this->task_map[$ts] = [];

				foreach ($this->task_list as $d)
				{
					if ($d->day_type === $day_type)
					{
						$d->day_name = $day_names[$wnum];
						$this->task_map[$ts][] = clone $d;
					}
				}
			}
			// 月次タスク
			if (count($this->task_month_list) > 0)
			{
				$this->task_month_map[$ts] = [];

				foreach ($this->task_month_list as $d)
				{
					if (isset($d->start_date) && isset($d->end_date)
						&& $ts >= $d->start_date->timestamp
						&& $ts <= $d->end_date->timestamp)
					{
						$this->task_month_map[$ts][] = clone $d;
					}
				}
			}
			$ts += 86400;
		}
	}

	/**
	 * 役職者：マネージャー、サブマネージャーは土日祝は休み
	 */
	private function assignTitleHoliday()
	{
		$duty_holiday_titles = Configure::read('duty_holiday_titles');
		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			$w = date('w', $ts);
			// 土日祝
			if ($w == 0 || $w == 6 || $this->isHoliday($ts)) {
				foreach ($this->personnel_map as $team_id => $p) {
					foreach ($p as $p_id => $personnel) {
						if ($personnel->title_code != '' && in_array($personnel->title_code, $duty_holiday_titles)) {
							if ($this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $ts) === FALSE) {
								Log::debug("-> 設定できませんでした");
							}
						}
					}
				}
			}
			$ts += 86400;
		}
	}

	private function isHoliday(&$ts)
	{
		return isset($this->holiday_map[$ts]);
	}

	/**
	 * 指定休の配置
	 *
	 * - 公休HD5に消防訓練があれば指定休にしない
	 */
	private function createShiteikyu()
	{
		$this->_createShiteikyu(4);
		$this->_createShiteikyu(3);
		$this->_createShiteikyu(2);
		$this->_createShiteikyu(1);
		$this->_createShiteikyu(0);
	}

	private function _createShiteikyu($interval_max)
	{
		// 日曜日の数が指定休の数
		$sunday_max = $this->countSunday();

		$duty_team_ids = Configure::read('duty_team_ids');
		$is_honbu = FALSE;

		// 本部以外のチーム
		foreach ($this->personnel_map as $team_id => $personnel_map)
		{
			if (in_array($team_id, $duty_team_ids)) {
				$is_honbu = FALSE;
			} else {
				$is_honbu = TRUE;
			}

			foreach ($personnel_map as $p_id => $personnel)
			{
				// 休暇設定で指定されている指定休の数をカウントする
				$shiteikyu = 0;
				$ts = $this->start_ts;
				for ($x=0; $x<$this->total_day; $x++)
				{
					if (isset($this->dat_items[$p_id][$ts]))
					{
						foreach ($this->dat_items[$p_id][$ts] as $i => $d)
						{
							if ($d['duty_type'] == DAT_CODE_SHITEI) {
								$shiteikyu++;
							}
						}
					}
					$ts += 86400;
				}

				$interval = 0;
				$ts = $this->start_ts - 5 * 86400;

				// 前月の指定休を考慮する
				for ($x=-5; $x<$this->total_day; $x++)
				{
					$interval++;

					$duty_types = [];
					$before_types = $this->getDutyTypesToDN($p_id, $ts - 86400);
					$after_types =  $this->getDutyTypesToDN($p_id, $ts + 86400);

					if (isset($this->dat_items[$p_id][$ts]))
					{
						foreach ($this->dat_items[$p_id][$ts] as $i => $d)
						{
							if ($d['duty_type'] != '') {
								$duty_types[] = $d['duty_type'];
							}
						}
					}

					if ($x < 0) {
						if (in_array(DAT_CODE_SHITEI, $duty_types)){
							$interval = 0;
						}
						$ts += 86400;
						continue;
					}

					if ($interval > $interval_max && $shiteikyu < $sunday_max && count($duty_types) === 1
							&& in_array(DAT_CODE_KOUKYU, $duty_types)
							&& $this->checkDuty($p_id, $ts, DAT_CODE_PRI_KOUKYU) === FALSE
							&& in_array(DAT_CODE_N, $before_types) === FALSE)
					{
						// できるだけ連続しないように次の日も見る
						if (in_array(DAT_CODE_SHITEI, $after_types) && $interval_max > 0)
						{
							$ts += 86400;
							continue;
						}

						// 公休だけがセットされている日に指定休をセット
						$key = array_search(DAT_CODE_KOUKYU, $duty_types);
						$this->dat_items[$p_id][$ts][$key] = $this->getDatItem($p_id, DAT_CODE_SHITEI, $ts);
						$shiteikyu++;
						$interval = 0;
					}
					else if ($interval > $interval_max && $shiteikyu < $sunday_max && count($duty_types) === 0
							&& $this->checkDuty($p_id, $ts, DAT_CODE_PRI_KOUKYU) === FALSE
							&& in_array(DAT_CODE_N, $before_types) === FALSE
							&& $is_honbu === FALSE)
					{
						// できるだけ連続しないように次の日も見る
						if (in_array(DAT_CODE_SHITEI, $after_types) && $interval_max > 0)
						{
							$ts += 86400;
							continue;
						}

						$this->setDatItem($p_id, DAT_CODE_SHITEI, $ts);
						$shiteikyu++;
						$interval = 0;
					}
					else if (in_array(DAT_CODE_SHITEI, $duty_types)){
						$interval = 0;
					}

					if ($shiteikyu >= $sunday_max) {
						break;
					}
					$ts += 86400;
				}
			}
		}
	}

	/**
	 * 本部所属の配置
	 */
	private function assignTeamX()
	{
		foreach ($this->team_honbu as $team_id)
		{
			if (isset($this->personnel_map[$team_id]))
			{
				foreach ($this->personnel_map[$team_id] as &$personnel)
				{
					$ts = $this->start_ts;
					for ($i=0; $i<$this->total_day; $i++)
					{
						// 土日祝は休み
						$w = date('w', $ts);
						if ($w == 0 || $w == 6 || $this->isHoliday($ts)) {
							$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $ts);
						}
						$ts += 86400;
					}
				}
			}
		}
	}

	/**
	 * 定期消防訓練の割り当て
	 * 1-20日まで
	 * 公休HD5に実施
	 * 翌日はDN勤務、それ以外は手作業
	 * 消防訓練は6時間（可変）
	 */
	private function assignFireTraining()
	{
		if (isset($this->watch_fire_map[$this->ts][DAT_CODE_FE])
				&& $this->watch_fire_map[$this->ts][DAT_CODE_FE] > 0)
		{
			$fire_id = $this->watch_fire_map[$this->ts][DAT_CODE_FE];
			$personnels = $this->getPersonnelsFireId($fire_id);
			$total = 0;
			foreach ($personnels as $personnel)
			{
				if ($this->isTaskOK($personnel, DAT_CODE_FE00, $this->ts)) {
					// 消防訓練日は公休HD5に実施
					$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts);
					$this->setDatItem($personnel->p_id, DAT_CODE_FE00, $this->ts);
					// 翌日はDNにするため仮配置
					$this->dat_temps[$this->ts + 86400][$personnel->p_id] = DAT_CODE_D;
					$total++;
				} else {
					Log::debug(date('m/d', $this->ts).'：'.$fire_id.'班'.$personnel->p_id.'の消防訓練が配置できません。');
				}
			}
			if ($total == 0) {
				Log::debug(date('m/d', $this->ts).'：'.$fire_id.'班の消防訓練が配置できません。');
			}
		}
	}

	/**
	 * 変数上でカウントされた各必要人数を実際の定常タスクに反映
	 *
	 * @param array $d_personnels
	 * @param array $n_personnels
	 */
	private function checkAllTaskPersonnel(array $d_personnels, array $n_personnels)
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		$checks = [
			'manager',
			'sub_manager',
			'leader',
			'sub_leader',
			'chief',
			'sub_chief',
			'woman_only',
			'license_01',
			'license_02',
			'license_03',
			'license_04',
			'license_05'
		];

		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_D) {
				$var_name = 'd_personnels';
			} else {
				$var_name = 'n_personnels';
			}
			foreach ($checks as $check_name)
			{
				if ($task->{$check_name} > 0) {
					if (${$var_name}[$check_name] >= $task->{$check_name}) {
						$diff = ${$var_name}[$check_name] - $task->{$check_name};
						${$var_name}[$check_name] = $diff;
						$task->{$check_name} = 0;
					} else {
						$task->{$check_name} = $task->{$check_name} - ${$var_name}[$check_name];
						${$var_name}[$check_name] = 0;
					}
				}
			}
			$this->task_map[$this->ts][$n] = $task;
		}
	}

	/**
	 * 定常タスクの配置
	 *
	 * DNチーム内では必要人数の合計だけで配置
	 */
	private function assignAllTask()
	{
		// ソートで考慮する時間をクリアする @TODO
		$this->clearPersonnelMap();
		$this->sortPersonnelHoursMap();

		$this->WRITE_DEBUG_LOG("役職者・資格05保持者割り当て開始");
		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 役職者と資格05の配置
			$this->assignTaskToTitleCodeFor1('MGR', 'manager');
			$this->assignTaskToTitleCodeFor1('MGR-S', 'sub_manager');
			$this->assignTaskToTitleCodeFor1('LDR', 'leader');
			$this->assignTaskToTitleCodeFor1('LDR-S', 'sub_leader');
			$this->assignTaskToTitleCodeFor1('CHF', 'chief');
			$this->assignTaskToTitleCodeFor1('CHF-S', 'sub_chief');
			$this->assignTaskToLicense05For1();
			$this->sortPersonnelHoursMap();

			// 役職者と資格05の配置
			$this->assignTaskToTitleCodeFor2('MGR', 'manager');
			$this->assignTaskToTitleCodeFor2('MGR-S', 'sub_manager');
			$this->assignTaskToTitleCodeFor2('LDR', 'leader');
			$this->assignTaskToTitleCodeFor2('LDR-S', 'sub_leader');
			$this->assignTaskToTitleCodeFor2('CHF', 'chief');
			$this->assignTaskToTitleCodeFor2('CHF-S', 'sub_chief');
			$this->assignTaskToLicense05For2();
			$this->ts += 86400;
			$this->sortPersonnelHoursMap();
		}
		$this->WRITE_DEBUG_LOG("役職者・資格05保持者割り当て終了");

		// ソートで考慮する時間をクリアする @TODO
		$this->clearPersonnelMap();
		$this->setCountNotDNCount();
		$this->sortPersonnelHoursMap();
		$this->ts = $this->start_ts;
		$this->WRITE_DEBUG_LOG("定常タスク割り振り１開始");
		for ($i=0; $i<$this->total_day; $i++)
		{
			// 定常タスクの割り振り
			$this->_assignAllTask1();
			$this->ts += 86400;
			$this->clearPersonnelMap();
			$this->setCountNotDNCount();
			$this->sortPersonnelHoursMap();
		}
		$this->WRITE_DEBUG_LOG("定常タスク割り振り1終了");

		$this->WRITE_DEBUG_LOG("定常タスク割り振り2開始");
		$this->ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			// タスクの消化人数を反映
			List($d_personnels, $n_personnels) = $this->_getNotSatisfyTasks();
			$this->checkAllTaskPersonnel($d_personnels, $n_personnels);

			// 定常タスクの割り振り
			$this->_assignAllTask2();
			$this->ts += 86400;
			$this->sortPersonnelHoursMap();
		}
		$this->WRITE_DEBUG_LOG("定常タスク割り振り2終了");

		$this->WRITE_DEBUG_LOG("定常タスク割り振り3開始");
		$this->ts = $this->start_ts;
		// ソート時間に考慮する時間を再設定 @TODO
		$this->resetPersonnelMap();
		// ソート順に休暇時間を足す
		$this->addHDHours();
		$this->setRenzokuCount($this->ts);
		$this->sortPersonnelHoursMap();

		for ($i=0; $i<$this->total_day; $i++)
		{
			// タスクの消化人数を反映
			List($d_personnels, $n_personnels) = $this->_getNotSatisfyTasks();
			$this->checkAllTaskPersonnel($d_personnels, $n_personnels);

			// 定常タスクの割り振り
			$this->_assignAllTask3();
			$this->ts += 86400;
			$this->setRenzokuCount($this->ts);
			$this->sortPersonnelHoursMap();
		}
		$this->WRITE_DEBUG_LOG("定常タスク割り振り3終了");

		$this->sortPersonnelHoursMap();
	}

	/*
	 * 定常タスクの”N”の条件を満たす分だけ、DN、明け、公休のパターンでチームごとに先に配置
	 * “DN”を配置する際に“N”が休暇設定や名前指定の月次タスク等の条件で満たせない場合は、
	 *（１）「明けチーム」から”N"だけではなく、”DN”単位で借りてくる。
	 *（２）但し、借りてくる「明けチーム」は殆どが前日が”DN”になっているはずなので、前日が”D”、又は「公休」になっている人を探して割り当てる。
	 *   借りてくる「明けチーム」の前日が全て”DN”の場合には”DN”ではなく、”N”のみを借りると共に、
	 *   合わせて 「公休チーム」から”D”を借りてくる。
	 *（３）借りてくるチームの中で優先すべき警備員は以下の通りとする。
	 *   １．当月の勤務時間
	 *   ２．前月までの超過勤務
	 */
	private function _assignAllTask1()
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		List($d_tasks, $n_tasks) = $this->_getTaskSum();

		// DNチームにDNを配置する
		$dn_team_id = $this->dat_bases[$this->ts][0];
		$personnel_list = $this->personnel_sort_hours_map[$dn_team_id];

		// 新人のみを先に配置する
		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_D)
			{
				foreach ($personnel_list as $_p)
				{
					$p_id = $_p["p_id"];
					if (isset($this->personnel_map[$dn_team_id][$p_id]))
					{
						$personnel = $this->personnel_map[$dn_team_id][$p_id];
						if (!$this->isNewEmployee($personnel)){continue;}

						$this->setTaskToPersonnel($personnel, $task, FALSE, TRUE, TRUE);
						if (empty($task->personnel)) {
							break;
						}
					}
				}
				$this->task_map[$this->ts][$n] = $task;
			}
		}

		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_D)
			{
				foreach ($personnel_list as $_p)
				{
					$p_id = $_p["p_id"];
					if (isset($this->personnel_map[$dn_team_id][$p_id]))
					{
						$personnel = $this->personnel_map[$dn_team_id][$p_id];
						$this->setTaskToPersonnel($personnel, $task, FALSE, TRUE, FALSE);
						if (empty($task->personnel)) {
							break;
						}
					}
				}
				$this->task_map[$this->ts][$n] = $task;
			}
		}

		$this->sortPersonnelHoursMap();
		$personnel_list = $this->personnel_sort_hours_map[$dn_team_id];
		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_N)
			{
				foreach ($personnel_list as $_p)
				{
					$p_id = $_p["p_id"];
					if (isset($this->personnel_map[$dn_team_id][$p_id]))
					{
						$personnel = $this->personnel_map[$dn_team_id][$p_id];
						$this->setTaskToPersonnel($personnel, $task, FALSE, TRUE, FALSE);
						if (empty($task->personnel)) {
							break;
						}
					}
				}
				$this->task_map[$this->ts][$n] = $task;
			}
		}

		$this->_assignAllTaskForTeamXY();

		// 明けチームにDNを配置する
		$team_id = $this->dat_bases[$this->ts][1];
		$personnel_list = $this->personnel_sort_hours_map[$team_id];

		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_D)
			{
				foreach ($personnel_list as $_p)
				{
					$p_id = $_p["p_id"];
					if (isset($this->personnel_map[$dn_team_id][$p_id]))
					{
						$personnel = $this->personnel_map[$dn_team_id][$p_id];
						$this->setTaskToPersonnel($personnel, $task, FALSE, TRUE, TRUE);
						if (empty($task->personnel)) {
							break;
						}
					}
				}
				$this->task_map[$this->ts][$n] = $task;
			}
		}
	}

	private function _assignAllTask2()
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		List($d_tasks, $n_tasks) = $this->_getTaskSum();
		List($d_personnels, $n_personnels) = $this->_getNotSatisfyTasks();

		// 足りないDをDNチームから
		$this->WRITE_DEBUG_LOG("足りないDをDNチームから");
		$d_team_id = $this->dat_bases[$this->ts][0];
		$this->assignTaskToDorN(DAT_CODE_D, $d_team_id, $d_personnels, $d_tasks);

		// 足りないNをDNチームから
		$this->WRITE_DEBUG_LOG("足りないNをDNチームから");
		$d_team_id = $this->dat_bases[$this->ts][0];
		$this->assignTaskToDorN(DAT_CODE_N, $d_team_id, $d_personnels, $d_tasks);
	}

	/*
	 * 改めて21日から時系列順に定常タスクの条件を満たせていない（不足している）”D”を以下の優先順位で借りてくる。
	 *（１）「明けチーム」の中で前日が”D”勤務となっている警備員。
	 *（２）但し、借りてくる「明けチーム」は殆どが前日が”DN”になっているはずなので、前日が ”D”、又は「公休」になっている人を割り当てる。
	 *  借りてくる「明けチーム」の前日が全て”DN”の場合には「公休チーム」から”D”を借りてくる。
	 *（３）借りてくるチームの中で優先すべき警備員は以下の通りとする。
	 *	１．当月の勤務時間（当月の勤務時間は積み上がっていくので、１度借りた人が次に割り当てられる優先順位は下がるはず）
	 *	２．前月までの超過勤務（勤務時間では勤務時間が多くて、超過が少ない場合があるため超過勤務とする)
	 */
	private function _assignAllTask3()
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		List($d_tasks, $n_tasks) = $this->_getTaskSum();
		List($d_personnels, $n_personnels) = $this->_getNotSatisfyTasks();

		// 足りないDを公休日チームから
		$this->WRITE_DEBUG_LOG("足りないDを公休日チームから");
		$d_team_id = $this->dat_bases[$this->ts][1];
		$this->assignTaskToDorN(DAT_CODE_D, $d_team_id, $d_personnels, $d_tasks, true, $this->ts - 2 * 86400);
		$this->assignTaskToDorN(DAT_CODE_D, $d_team_id, $d_personnels, $d_tasks, true, $this->ts);

		// 足りないNを明けチームから
		$this->WRITE_DEBUG_LOG("足りないNを明けチームから");
		$n_team_id = $this->dat_bases[$this->ts][2];
		$this->assignTaskToDorN(DAT_CODE_N, $n_team_id, $n_personnels, $n_tasks, true);
	}

	/*
	 * チームX,Xに定常タスクを配置する
	 */
	private function _assignAllTaskForTeamXY() {
		List($d_tasks, $n_tasks) = $this->_getTaskSum();
		List($d_personnels, $n_personnels) = $this->_getNotSatisfyTasks();

		foreach ($this->team_honbu as $team_id)
		{
			$this->assignTaskToDorN(DAT_CODE_D, $team_id, $d_personnels, $d_tasks);
			$day = date('j', $this->ts);
			if ($day >= 1 && $day <= 20) {
				$this->assignTaskToDorN(DAT_CODE_N, $team_id, $d_personnels, $d_tasks);
			}
		}
	}

	/*
	 * 定常タスクに割り当てる必要がある人数を取得
	 */
	private function _getTaskSum() {

		$checks = [
			'personnel',
			'manager',
			'sub_manager',
			'leader',
			'sub_leader',
			'chief',
			'sub_chief',
			'woman_only',
			'license_01',
			'license_02',
			'license_03',
			'license_04',
			'license_05'
		];

		// 定常タスクの各必要人数の合計を取得
		$d_tasks = DutyMisc::$task_counts;
		$n_tasks = DutyMisc::$task_counts;

		foreach ($this->task_map[$this->ts] as $n => &$task)
		{
			if ($task->night_day == DAT_CODE_D) {
				$var_name = 'd_tasks';
			} else {
				$var_name = 'n_tasks';
			}
			foreach ($checks as $check_name) {
				${$var_name}[$check_name] += $task->{$check_name}>0 ? $task->{$check_name} : 0;
			}
		}

		return [$d_tasks, $n_tasks];
	}

	/*
	 * 定常タスクで割り当てが不足しているものを取得する
	 */
	private function _getNotSatisfyTasks() {
		// 満たせていないタスクを取得
		$d_personnels = DutyMisc::$task_counts;
		$n_personnels = DutyMisc::$task_counts;
		$duty_personnel_checks_2 = Configure::read('duty_personnel_checks_2');

		if (count($personnel_list) > 0)
		{
			foreach ($personnel_list as $p_id => $hours)
			{
				if (isset($this->personnel_map[$dn_team_id][$p_id]))
				{
					$personnel = $this->personnel_map[$dn_team_id][$p_id];
					if (isset($this->dat_items[$p_id][$this->ts]))
					{
						foreach ($this->dat_items[$p_id][$this->ts] as $d)
						{
							$var_name = '';
							if ($d['duty_type'] == DAT_CODE_D) {
								$var_name = 'd_personnels';
							} else if ($d['duty_type'] == DAT_CODE_N) {
								$var_name = 'n_personnels';
							}
							if ($var_name !== '')
							{
								${$var_name}['personnel'] += 1;
								if ($personnel->title_code!='') {
									$title_name = isset($duty_personnel_checks_2[$personnel->title_code]) ? $duty_personnel_checks_2[$personnel->title_code] : '';
									if ($title_name !== '') {
										${$var_name}[$title_name] += 1;
									}
								}
								if ($personnel->gender == GENDER_TYPE_WOMAN) {
									${$var_name}['woman_only'] += 1;
								}
								foreach ([1,2,3,4,5] as $num) {
									$license = sprintf("license_%02d", $num);
									if ($personnel->{$license}>0) {
										${$var_name}[$license] += 1;
									}
								}
							}
						}
					}
				}
			}
		}

		return [$d_personnels, $n_personnels];
	}

	/*
	 * _assignAllTask1と同条件で役職者に定時タスクを割り当てる
	 */
	private function assignTaskToTitleCodeFor1($title_code, $title_name)
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		foreach ($this->dat_bases[$this->ts] as $i => $team_id)
		{
			foreach ($this->task_map[$this->ts] as $n => $task)
			{
				if ($task->personnel>0 && $task->{$title_name}>0)
				{
					$personnels = [];
					switch($i)
					{
						// DNチーム
						case 0:
							if ($task->night_day === DAT_CODE_D) {
								$personnels = $this->getPersonnelsSearch($team_id, 'title_code', $title_code);

								if (count($personnels)>0) {
									foreach ($personnels as $personnel) {
										if ($this->setTaskToPersonnel($personnel, $task, TRUE, FALSE, TRUE)) {
											if (empty($task->personnel) || empty($task->{$title_name})) {
												break;
											}
										}
									}
								}
							}
							break;
					}

					$this->task_map[$this->ts][$n] = $task;
				}
			}
		}

		$this->sortPersonnelHoursMap();
	}

	/*
	 * _assignAllTask2と同条件で役職者に定時タスクを割り当てる
	 */
	private function assignTaskToTitleCodeFor2($title_code, $title_name)
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		foreach ($this->dat_bases[$this->ts] as $i => $team_id)
		{
			foreach ($this->task_map[$this->ts] as $n => $task)
			{
				if ($task->personnel>0 && $task->{$title_name}>0)
				{
					$personnels = [];
					switch($i)
					{
						// 明けチーム
						case 0:
						case 1:
							if ($task->night_day === DAT_CODE_D) {
								$personnels = $this->getPersonnelsSearch($team_id, 'title_code', $title_code);
							}
						// 公休チーム
						case 2:
							if ($task->night_day === DAT_CODE_N) {
								$personnels = $this->getPersonnelsSearch($team_id, 'title_code', $title_code);
							}
							break;
					}

					if (count($personnels)>0) {
						foreach ($personnels as $personnel) {
							if ($this->setTaskToPersonnel($personnel, $task, TRUE, FALSE, FALSE)) {
								if (empty($task->personnel) || empty($task->{$title_name})) {
									break;
								}
							}
						}
					}
					$this->task_map[$this->ts][$n] = $task;
				}
			}
		}
	}

	/*
	 * _assignAllTask1と同条件で資格5所持者に定時タスクを割り当てる
	 */
	private function assignTaskToLicense05For1()
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		foreach ($this->dat_bases[$this->ts] as $i => $team_id)
		{
			foreach ($this->task_map[$this->ts] as $n => $task)
			{
				if ($task->personnel>0 && $task->license_05>0)
				{
					switch($i)
					{
						// DNチーム
						case 0:
							if ($task->night_day === DAT_CODE_D) {
								$personnels = $this->getPersonnelsSearch($team_id, 'license_05', 1);
								if (count($personnels)>0) {
									foreach ($personnels as $personnel) {
										if ($this->setTaskToPersonnel($personnel, $task, TRUE, FALSE, TRUE)) {
											if (empty($task->personnel) || empty($task->license_05)) {
												break;
											}
										}
									}
								}
								$this->task_map[$this->ts][$n] = $task;
							}
							break;
					}
				}
			}
		}
	}

	/*
	 * _assignAllTask2と同条件で資格5所持者に定時タスクを割り当てる
	 */
	private function assignTaskToLicense05For2()
	{
		if (empty($this->task_map) || empty($this->task_map[$this->ts])) {
			return;
		}

		foreach ($this->dat_bases[$this->ts] as $i => $team_id)
		{
			foreach ($this->task_map[$this->ts] as $n => $task)
			{
				if ($task->personnel>0 && $task->license_05>0)
				{
					switch($i)
					{
						// 明け
						case 0:
						case 1:
							if ($task->night_day === DAT_CODE_D) {
								$personnels = $this->getPersonnelsSearch($team_id, 'license_05', 1);
							}
						// 明けチーム
						case 2:
							if ($task->night_day === DAT_CODE_N) {
								$personnels = $this->getPersonnelsSearch($team_id, 'license_05', 1);
							}
							break;
					}

					if (count($personnels)>0) {
						foreach ($personnels as $personnel) {
							if ($this->setTaskToPersonnel($personnel, $task, TRUE, FALSE, FALSE)) {
								if (empty($task->personnel) || empty($task->license_05)) {
									break;
								}
							}
						}
					}
					$this->task_map[$this->ts][$n] = $task;
				}
			}
		}

		$this->sortPersonnelHoursMap();
	}

	/*
	 * フェローA2にDN勤務を割り当てる
	 * すでにDN勤務が割りあたっている場合はなにもしない
	 */
	public function assignTaskDNtoA2()
	{
		$this->sortPersonnelHoursMap(SORT_DESC);
		// フェローA2を取得
		$personnels = $this->getA2Personnels();
		// フェローA2でループ
		foreach ($personnels as $personnel)
		{
			// DN勤務が割り当たっているかチェック
			if ($this->checkExistDN($personnel->p_id)){ continue;}
			// D勤務の人を探し、N勤務を割り当てる
			for ($ts = $this->start_ts; $ts < $this->end_ts; $ts += 86400)
			{
				// 1日から20日の間にDN勤務を割り当てる
				$day = date("d", $ts);
				if ($day >= 21) { continue;}

				// 今日がD勤務で翌日が休みの日でなければDNは割り当てない
				if ($this->isD($personnel->p_id, $ts) &&
					($this->checkDuty($personnel->p_id, $ts + 86400, DAT_CODE_KOUKYU) || empty($this->dat_items[$personnel->p_id][$ts + 86400])))
				{
					// その日の資格や役職をもっていないDN勤務を取得
					$beforePersonnels = $this->getNormalPersonnelsByDN($ts, $personnel->gender);

					if (count($beforePersonnels) == 0) {continue;}

					// 最初の人のN勤務をもらう
					$beforePersonnel = $beforePersonnels[0];

					// 探したDN勤務の人からN勤務を消す
					$copyTask = NULL;
					foreach($this->dat_items[$beforePersonnel->p_id][$ts] as $i => $d) {
						if ($d["duty_type"] == DAT_CODE_N) {
							$copyTask = $this->dat_items[$beforePersonnel->p_id][$ts][$i];
							unset($this->dat_items[$beforePersonnel->p_id][$ts][$i]);
							$this->WRITE_DEBUG_LOG($beforePersonnel->p_id . "の" . date("Y-m-d", $ts) . "N勤務を渡す");
						}
					}

					// DNを割り当て
					$task = (object)([]);
					$task->id = $copyTask["id"];
					$task->t_id = $copyTask["t_id"];
					$task->night_day = DAT_CODE_N;
					$this->setDatItem($personnel->p_id, $task, $ts);

					// 翌日を明けにする
					unset($this->dat_items[$personnel->p_id][$ts + 86400]);
					$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $ts + 86400);

					break;
				}
			}
		}
	}

	/*
	 * フェローA2たちを取得する
	 */
	public function getA2Personnels()
	{
		$results = [];

		foreach ($this->team_honbu as $team_id)
		{
			if (isset($this->personnel_map[$team_id]))
			{
				foreach ($this->personnel_map[$team_id] as &$personnel)
				{
					if ($personnel->title_code == 'A2')
					{
						$results[] = $personnel;
					}
				}
			}
		}
		return $results;
	}

	/*
	 * 1ヶ月間の間にDN勤務が割りあたっているかチェックする（フェローA2のチェック用）
	 */
	public function checkExistDN($p_id)
	{
		 for ($ts = $this->start_ts; $ts < $this->end_ts; $ts += 86400)
		 {
			 if ($this->isDN($p_id, $ts))
			 {
				 return true;
			 }
		 }
		 return false;
	}

	/*
	 * 特定の日から、DNみが設定されている資格や役職者でない人を取得する
	 *
	 */
	public function getNormalPersonnelsByDN($ts, $gender)
	{
		$results = [];
		// 次のローテーションから
		foreach ([1,2,0] as $n)
		{
			$team_id = $this->dat_bases[$ts][$n];
			foreach ($this->personnel_sort_hours_map[$team_id] as $_p)
			{
				$p_id = $_p["p_id"];
				if (isset($this->personnel_map[$team_id][$p_id]))
				{
					// DN勤務以外が設定されていればNG
					if (!($this->isDN($p_id, $ts) && count($this->dat_items[$p_id][$ts]) == 2)) {continue;}

					$personnel = $this->personnel_map[$team_id][$p_id];
					// 資格や役職はNG
					if (empty($personnel->title_code) &&
						empty($personnel->license_05) &&
						$personnel->gender == $gender)
					{
						$results[] = $personnel;
					}
				}
			}
		}

		return $results;
	}

	/**
	 * 定常タスクを指定チームに必要な条件で配置する
	 *
	 * @param type $day_type
	 * @param type $team_id
	 * @param array $personnel_counts
	 * @param array $task_counts
	 */
	private function assignTaskToDorN($day_type, $team_id, array &$personnel_counts, array &$task_counts, $new_employee_ng_flag = false, $ng_dn_day = 0)
	{
		$checks = [
			'license_05',
			'manager',
			'sub_manager',
			'leader',
			'sub_leader',
			'chief',
			'sub_chief',
			'woman_only',
			'license_04',
			'license_03',
			'license_02',
			'license_01',
			'personnel'
		];
		$duty_personnel_checks = Configure::read('duty_personnel_checks');
		$personnel_list = isset($this->personnel_map[$team_id]) ? $this->personnel_map[$team_id] : [];

		$onetime_p_ids = [];

		if (count($this->task_map[$this->ts])>0 && count($personnel_list)>0)
		{
			foreach ($this->task_map[$this->ts] as $n => &$task)
			{
				if ($task->personnel>0 && $task->night_day === $day_type)
				{
					foreach ($checks as $check_name)
					{
						if ($task->{$check_name} > 0) {
							$personnels = [];
							if (in_array($check_name, ['manager', 'sub_manager', 'leader', 'sub_leader', 'chief', 'sub_chief'])) {
								$this->WRITE_DEBUG_LOG("役職者を探して割り当てる");
								$personnels = $this->getPersonnelsSearch($team_id, 'title_code', $duty_personnel_checks[$check_name]);
							} else if ($check_name === 'woman_only') {
								$this->WRITE_DEBUG_LOG("女性を探して割り当てる");
								$personnels = $this->getPersonnelsSearch($team_id, 'gender', GENDER_TYPE_WOMAN);
							} else if (preg_match("/^license_[0-9]+/", $check_name)) {
								$this->WRITE_DEBUG_LOG("資格者を探して割り当てる");
								$personnels = $this->getPersonnelsSearch($team_id, $check_name, 1);
							} else {
								$this->WRITE_DEBUG_LOG("通常の割り当て");
								$personnels = $this->getPersonnelsSearch($team_id, NULL, '');
							}
							if (count($personnels)>0) {
								foreach ($personnels as $personnel) {
									// 新人はNG
									if ($new_employee_ng_flag && $this->isNewEmployee($personnel)) {continue;}

									// 指定された日にDNが割り当てられている場合は割り当てない
									if ($ng_dn_day > 0 && $this->isDN($personnel->p_id, $ng_dn_day)) {continue;}

									if ($this->setTaskToPersonnel($personnel, $task)) {
										if (empty($task->personnel)) {
											break 2;
										}
									}
								}
							}
						}
					}
					$this->task_map[$this->ts][$n] = $task;
				}
			}
		}
	}

	/**
	 * 条件に合う警備員を検索する
	 *
	 * @param type $team_id
	 * @param type $key
	 * @param type $value
	 * @return array
	 */
	private function getPersonnelsSearch($team_id, $key, $value)
	{
		$personnels = [];
		foreach ($this->personnel_sort_hours_map[$team_id] as $_p) {
			$p_id = $_p["p_id"];
			if (isset($this->personnel_map[$team_id][$p_id])) {
				$personnel = $this->personnel_map[$team_id][$p_id];
				if ($key === NULL) {
					$personnels[] = $personnel;
				} else if (is_array($key)) {
					if ($personnel->{$key[0]} == $value[0] && $personnel->{$key[1]} == $value[1]) {
						$personnels[] = $personnel;
					}
				} else if ($personnel->{$key} == $value) {
					$personnels[] = $personnel;
				}
			}
		}
		return $personnels;
	}

	/**
	 * 月次タスクの個人名指定の配置
	 */
	private function assignSpecialTask($isUpdate = false)
	{
		$add_flag = FALSE;

		if (empty($this->task_month_map) || empty($this->task_month_map[$this->ts])) {
			return $add_flag;
		}

		foreach ($this->task_month_map[$this->ts] as $i => &$task)
		{
			// 警備員指定
			// 仕様上はpersonnelが-1ですが、氏名の入力欄のみで判断
			if ($task->personnel_names != '')
			{
				// 仕様上は;ですが、いろんな入力パターンに対応
				$names = explode(';', str_replace(['；','、',','], ';', $task->personnel_names));
				$personnel_total = 0;
				$is_err = FALSE;
				$Personnels = TableRegistry::get('Personnels');
				// 氏名で比較：氏名はユニーク
				foreach ($names as $name)
				{
					$name = trim($name);
					if ($name != '') {
						$personnel = $Personnels->find()->where(['name' => $name])->first();
						if ($personnel !== NULL) {
							$duty_tasks = $this->getDutyTasks($personnel->p_id, $this->ts);
							if (count($duty_tasks)>0) {
								$is_error = FALSE;
								$is_update = FALSE;
								$is_add = FALSE;
								foreach ($duty_tasks as $duty_task) {
									// 休暇は上書き、指定休のみ追加
									if (preg_match('/^HD[0-9]+/', $duty_task->duty_type)) {
										$is_update = TRUE;
									} else {
										if ($isUpdate) {
											if (substr($duty_task->duty_type, 0, 1) == "+" || substr($duty_task->duty_type, 0, 1) == "-") {
												continue;
											}
											if (($duty_task->start_time <= $task['start_time'] && $task['start_time'] < $duty_task->end_time) ||
												($duty_task->start_time < $task['end_time'] && $task['end_time'] <= $duty_task->end_time) ||
												($task['start_time'] <= $duty_task->start_time && $duty_task->start_time < $task['end_time']) ||
												($task['start_time'] < $duty_task->end_time && $duty_task->end_time <= $task['end_time'])
												)
											{
												$this->errors[] = '月次タスク「'.$task->tm_id.'」：既に「'.$personnel->p_id.':'.$name.'」には'.$duty_task->duty_type.'が配置済みです。';
												$is_error = TRUE;
											}
											else
											{
												$is_update = TRUE;
											}
										}
										else {
											$this->errors[] = '月次タスク「'.$task->tm_id.'」：既に「'.$personnel->p_id.':'.$name.'」には'.$duty_task->duty_type.'が配置済みです。';
											$is_error = TRUE;
										}
									}
								}
								if ($is_error === FALSE)
								{
									if ($is_update) {
										// 指定休、明け、公休、以外の休暇設定を削除
										foreach ($duty_tasks as $x => $duty_task) {
											if ($duty_task->duty_type == DAT_CODE_NORMAL
													|| $duty_task->duty_type == DAT_CODE_SPECIAL
													|| $duty_task->duty_type == DAT_CODE_RINJI) {
												unset($this->dat_items[$personnel->p_id][$this->ts][$x]);
											}
										}
									}
									$this->checkTaskPersonnel($personnel, $task);
									$this->setDatItem($personnel->p_id, $task, $this->ts);
									$personnel_total++;
								}
							} else {
								// 他の条件も満たすか判定
								$this->checkTaskPersonnel($personnel, $task);
								$this->setDatItem($personnel->p_id, $task, $this->ts);
								$personnel_total++;
							}
						} else {
							Log::error("該当者が見つかりません。（".date("Y-m-d", $this->ts)."） > ".$name);
							$this->errors[] = '月次タスク「'.$task->tm_id.'」：入力された氏名の警備員が見つかりません。（'.$name.'）';
							$is_err = TRUE;
						}
						$add_flag = TRUE;
					}
				}
				if ($is_err === FALSE) {
					// 割り当て終了
					// 完了状態をステータスで管理
					$task->status = TMM_STATUS_TYPE_COMP;
				}
				$task->personnel = 0;
				$this->task_month_map[$this->ts][$i] = $task;
			}
		}

		return $add_flag;
	}

	/**
	 * 月次タスクの配置
	 */
	private function assignTaskMonth()
	{
		if (empty($this->task_month_map) || empty($this->task_month_map[$this->ts])) {
			return FALSE;
		}

		foreach ($this->task_month_map[$this->ts] as $i => &$task)
		{
			// 個人指定分は除く
			if ($task->personnel > 0 && empty($task->personnel_names))
			{
				$personnel_total = $task->personnel;
				// カウントするもの
				$is_personnel = preg_match('/^(R|HL)[0-9]+/', $task->tm_id);

				// 臨時タスクは別チームから
				if (preg_match('/^(R|HL)[0-9]+/', $task->tm_id))
				{
					if (isset($this->dat_bases[$this->ts]))
					{
						// 次のローテーションから
						foreach ([1,2,0] as $n)
						{
							$team_id = $this->dat_bases[$this->ts][$n];
							$this->assignPersonnel($task, $personnel_total, $is_personnel, $team_id);
							if ($personnel_total <= 0) {
								break;
							}
						}
					}
				}
				else
				{
					if (isset($this->dat_bases[$this->ts]))
					{
						// DN日のチームから配置
						foreach ($this->dat_bases[$this->ts] as $team_id)
						{
							$this->assignPersonnel($task, $personnel_total, $is_personnel, $team_id);
							if ($personnel_total <= 0) {
								break;
							}
						}
					}
				}

				$this->task_month_map[$this->ts][$i] = $task;

				$this->sortPersonnelHoursMap();
			}
		}
	}

	/**
	 * 定期消防訓練日の翌日をDN勤務にする
	 */
	private function assignTempsTask()
	{
		if (isset($this->dat_temps[$this->ts]) && isset($this->task_map[$this->ts]))
		{
			// DからNを確認
			foreach ([DAT_CODE_D, DAT_CODE_N] as $night_day)
			{
				foreach ($this->task_map[$this->ts] as $i => &$task)
				{
					$personnel_total = $task->personnel;

					if ($task->night_day == $night_day && $personnel_total > 0)
					{
						// 消防訓練の仮配置からDN配置する
						foreach ($this->dat_temps[$this->ts] as $p_id => $duty_type)
						{
							$personnel = $this->getPersonnel($p_id);
							if ($personnel !== NULL)
							{
								if ($this->isTaskOK($personnel, $task))
								{
									$personnel_total--;
									// 他の条件も満たすか判定
									$this->checkTaskPersonnel($personnel, $task);
									$this->setDatItem($personnel->p_id, $task, $this->ts);
									// DN勤務なら
									if ($this->isDN($personnel->p_id))
									{
										$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
										$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts + 172800);
										// DN配置できたものは削除
										unset($this->dat_temps[$this->ts][$p_id]);
									}
									if (empty($personnel_total)) {
										continue;
									}
								}
								else
								{
									//Log::debug("@.仮配置（".$p_id." ".date("Y-m-d", $this->ts)."）を配置できない＞".$task->night_day);
								}
							}
						}
						$this->task_map[$this->ts][$i] = $task;
					}
				}
			}
		}
	}

	/**
	 * 宿直
	 * - 当日D勤務で
	 * - 女性、新入社員(6ヶ月、3ヶ月)、役職者以外
	 * - 2ヶ月連続して割り当てない
	 * - 翌日はDN勤務
	 * - 同じ月に日直を割り当てない
	 */
	private function assignNW()
	{
		if (isset($this->watch_fire_map[$this->ts][DAT_CODE_NW]) && $this->watch_fire_map[$this->ts][DAT_CODE_NW]>0)
		{
			$dn_p_ids = [];
			$not_p_ids = [];

			//Log::debug(date("Y-m-d", $this->ts)."@宿直を配置します。");
			// 翌日DNのためには公休日チームから
			$d_team_id = $this->dat_bases[$this->ts][1];
			$this->sortPersonnelHoursMap();
			$personnel_list = $this->personnel_sort_hours_map[$d_team_id];

			foreach ($personnel_list as $_p)
			{
				$p_id = $_p["p_id"];
				// 翌日はDN勤務
				if ($this->isDN($p_id, $this->ts + 86400) || $this->ts == $this->end_ts)
				{
					// 当日D勤務
					if ($this->isD($p_id, $this->ts)
							&& isset($this->personnel_map[$d_team_id][$p_id]))
					{
						$personnel = $this->personnel_map[$d_team_id][$p_id];

						if (in_array($personnel->p_id, $this->last_month_nw_list) === FALSE
								&& $personnel->gender != GENDER_TYPE_WOMAN
								&& $personnel->title_code == ''
								&& $this->isNewEmployee($personnel) === FALSE
								&& $this->searchNwDw($personnel))
						{
							$this->setDatItem($personnel->p_id, DAT_CODE_NW, $this->ts);
							//Log::debug(DAT_CODE_NW."宿直の配置（".date("Y-m-d", $this->ts)."）");
							$this->watch_fire_map[$this->ts][DAT_CODE_NW] = 0;
							return;
						}
						else
						{
							//Log::debug($personnel->enter_date);
						}
					}
					else
					{
						// 翌日DNだけど当日Dではない人を保持しておく
						$dn_p_ids[] = $p_id;
					}
				}
			}

			if (count($dn_p_ids)>0)
			{
				$dn_team_id = $this->dat_bases[$this->ts][0];
				$this->sortPersonnelHoursMap(SORT_DESC);
				$personnel_list = $this->personnel_sort_hours_map[$dn_team_id];
				foreach ($personnel_list as $_p)
				{
					$p_id = $_p["p_id"];
					if (isset($this->personnel_map[$dn_team_id][$p_id])) {
						$personnel = $this->personnel_map[$dn_team_id][$p_id];
						if ($personnel->title_code != ''
								|| $personnel->license_05>0
								|| $personnel->gender == GENDER_TYPE_WOMAN
								|| $this->isNewEmployee($personnel))
						{
							continue;
						}
						if ($this->isDN($p_id, $this->ts))
						{
							$not_p_ids[] = $p_id;
						}
					}
				}
			}

			// 保持した候補者から探す
			if (count($dn_p_ids) > 0 && count($not_p_ids) > 0)
			{
				foreach ($dn_p_ids as $nw_p_id)
				{
					$duty_types = $this->getDutyTypes($nw_p_id, $this->ts);
					$before = $this->getDutyDatas($nw_p_id, $this->ts - 86400);
					// 前日がNは駄目
					if (in_array(DAT_CODE_N, $before->dn) === FALSE
							&& $this->checkDuty($nw_p_id, $this->ts, DAT_CODE_PRI_KOUKYU) === FALSE
							&& (count($duty_types) == 0
							|| in_array(DAT_CODE_KOUKYU, $duty_types))
							&& $this->isTM($nw_p_id, $this->ts) === FALSE)
					{
						$personnel = $this->getPersonnel($nw_p_id, TRUE);
						if ($personnel !== NULL
								&& in_array($personnel->p_id, $this->last_month_nw_list) === FALSE
								&& $personnel->gender != GENDER_TYPE_WOMAN
								&& $personnel->title_code == ''
								&& $this->isNewEmployee($personnel) === FALSE
								&& $this->searchNwDw($personnel))
						{
							// 当日DN、D勤務の人から探す
							foreach ($not_p_ids as $not_p_id)
							{
								$duty_types = $this->getDutyTypes($not_p_id, $this->ts);
								if (in_array(DAT_CODE_D, $duty_types))
								{
									$personnel2 = $this->getPersonnel($not_p_id, TRUE);
									if ($personnel2 !== NULL) {
										// 役職者からは移動させない
										if ($personnel2->title_code!='' || $personnel2->license_05>0) {
											continue;
										}
										foreach ($this->dat_items[$not_p_id][$this->ts] as $key => $d) {
											if ($d['duty_type'] === DAT_CODE_D) {
												// 当日Dの人からDを移す
												if (isset($this->dat_items[$nw_p_id][$this->ts]) === FALSE) {
													$this->dat_items[$nw_p_id][$this->ts] = [];
												}
												$this->dat_items[$nw_p_id][$this->ts][] = $this->dat_items[$not_p_id][$this->ts][$key];

												unset($this->dat_items[$not_p_id][$this->ts][$key]);
												$this->setPersonnelHoursMap($not_p_id, DAT_WORK_HOURS_D * -1);

												$this->setDatItem($nw_p_id, DAT_CODE_NW, $this->ts);
												$this->watch_fire_map[$this->ts][DAT_CODE_NW] = 0;
												return;
											}
										}
									}
								}
							}
						}
					}
				}
			}

			Log::debug(date("Y-m-d", $this->ts)."@宿直の再配置に失敗。");
		}
	}

	/**
	 * 日直
	 * - DNかN勤務明け
	 * - 女性、新入社員(6ヶ月、3ヶ月)、役職者以外
	 * - 2ヶ月連続して割り当てない
	 * - 同じ月に日直を割り当てない
	 */
	private function assignDW()
	{
		if (isset($this->watch_fire_map[$this->ts][DAT_CODE_DW]) && $this->watch_fire_map[$this->ts][DAT_CODE_DW]>0)
		{
			foreach ($this->personnel_map as $team_id => $d)
			{
				if (in_array($team_id, $this->team_honbu)) {
					continue;
				}
				foreach ($d as $p_id => $personnel)
				{
					if (isset($this->dat_items[$p_id][$this->ts]))
					{
						// 前日がDN or N勤務か
						$flag = FALSE;
						$before_duty_tasks = $this->getDutyTasks($personnel->p_id, $this->ts - 86400);
						if (count($before_duty_tasks) > 0) {
							foreach ($before_duty_tasks as $d) {
								if ($d->duty_type === DAT_CODE_N) {
									$flag = TRUE;
									break;
//								} else if ($d->start_ts >= $this->timeToTimestamp(DAT_N_START_TIME, $this->ts)
//										&& $d->work_hours >= 8) {
//									$flag = TRUE;
//									break;
								}
							}
						}
						if ($flag) {
							$duty_types = $this->getDutyTypes($personnel->p_id, $this->ts);
							// Nの翌日はN勤務の可能性があるので確認
							if (in_array(DAT_CODE_N, $duty_types)) {
								$flag = FALSE;
							}
						}
						if ($flag && $personnel->gender != GENDER_TYPE_WOMAN
								&& $personnel->title_code == ''
								&& $this->isNewEmployee($personnel) === FALSE
								&& $this->searchNwDw($personnel)) {
							// @todo: 2ヶ月連続をどうする？
							$this->setDatItem($personnel->p_id, DAT_CODE_DW, $this->ts);
							//Log::debug(DAT_CODE_DW."日直の配置（".date("Y-m-d", $this->ts)."）");
							$this->watch_fire_map[$this->ts][DAT_CODE_DW] = 0;
							return;
						}
					}
				}
			}
			Log::error("日直の未配置（".date("Y-m-d", $this->ts)."）");
		}
	}

	/**
	 * 当月の中でNWとDWは2回行わない
	 * @param type $personnel
	 * @return boolean
	 */
	private function searchNwDw(&$personnel)
	{
		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			$duty_types = $this->getDutyTypes($personnel->p_id, $ts);
			if (in_array(DAT_CODE_DW, $duty_types) || in_array(DAT_CODE_NW, $duty_types)) {
				return FALSE;
			}
			$ts += 86400;
		}
		return TRUE;
	}

	/**
	 * 渡した人のリストから時間数の少ないものから返す
	 *
	 * @param type $p_id_arr
	 * @param type $team_id
	 * @return type
	 */
	private function getPersonnelDataByHours(&$p_id_arr, $team_id)
	{
		$personnels = [];
		if (isset($this->personnel_sort_hours_map[$team_id]) && count($p_id_arr)>0) {
			foreach ($this->personnel_sort_hours_map[$team_id] as $_p) {
				$p_id = $_p["p_id"];
				foreach ($p_id_arr as $p) {
					if ($p->p_id == $p_id && isset($this->personnel_map[$team_id][$p_id])) {
						$personnels[] = $this->personnel_map[$team_id][$p_id];
						break;
					}
				}
			}
		}
		return $personnels;
	}

	/**
	 * 要員配置
	 * 結果的に月次タスクの配置用になっています。
	 *
	 * @param type $task
	 * @param type $personnel_total
	 * @param type $is_personnel
	 * @param type $team_id
	 * @return boolean
	 */
	private function assignPersonnel(&$task, &$personnel_total, $is_personnel, $team_id)
	{

		if (isset($task->tm_id) && $personnel_total > 0)
		{
			$duty_personnel_checks = Configure::read('duty_personnel_checks');

			foreach ($duty_personnel_checks as $title_type => $title_code)
			{
				// 役職
				if ($task->{$title_type} > 0)
				{
					$Personnels = TableRegistry::get('Personnels');
					$p_id_arr = $Personnels->find()->select(['p_id'])->where([
						'team_id' => $team_id,
						'title_code' => $title_code,
						'status' => PM_STATUS_TYPE_VALID
					])->toArray();

					$personnels = $this->getPersonnelDataByHours($p_id_arr, $team_id);

					if (count($personnels)>0)
					{
						foreach ($personnels as $personnel)
						{
							$this->setPersonnelItem($personnel, $task, $personnel_total, $is_personnel);

							// タスクの割り当てが終了したら次へ
							if ($task->{$title_type} <= 0) {
								break;
							}
							if ($personnel_total <= 0) {
								return TRUE;
							}
						}
					}
				}
			}
			if ($personnel_total <= 0) {
				return TRUE;
			}
		}

		if (isset($task->tm_id) && $personnel_total > 0)
		{
			if ($task->woman_only > 0)
			{
				$Personnels = TableRegistry::get('Personnels');
				$p_id_arr = $Personnels->find()->select(['p_id'])->where([
					'team_id' => $team_id,
					'gender' => GENDER_TYPE_WOMAN,
					'status' => PM_STATUS_TYPE_VALID
				])->toArray();

				$personnels = $this->getPersonnelDataByHours($p_id_arr, $team_id);

				if (count($personnels)>0)
				{
					foreach ($personnels as $personnel)
					{
						$this->setPersonnelItem($personnel, $task, $personnel_total, $is_personnel);

						if ($task->woman_only <= 0) {
							break;
						}
						if ($personnel_total <= 0) {
							return TRUE;
						}
					}
				}
			}
		}

		if (isset($task->tm_id) && $personnel_total > 0)
		{
			//foreach (['05', '01', '02', '03', '04'] as $suffix)
			foreach (['01', '02', '03', '04', '05'] as $suffix)
			{
				$license = 'license_'.$suffix;
				// 資格
				if ($task->{$license} > 0)
				{
					$Personnels = TableRegistry::get('Personnels');
					$p_id_arr = $Personnels->find()->select(['p_id'])->where([
						'team_id' => $team_id,
						$license.' >' => 0,
						'status' => PM_STATUS_TYPE_VALID
					])->toArray();

					$personnels = $this->getPersonnelDataByHours($p_id_arr, $team_id);

					if (count($personnels)>0)
					{
						foreach ($personnels as $personnel)
						{
							$this->setPersonnelItem($personnel, $task, $personnel_total, $is_personnel);

							// タスクの割り当てが終了したら次へ
							if ($task->{$license} <= 0) {
								break;
							}
							if ($personnel_total <= 0) {
								return TRUE;
							}
						}
					}
				}
			}
		}

		if ($personnel_total > 0 && isset($this->personnel_sort_hours_map[$team_id]))
		{
			foreach ($this->personnel_sort_hours_map[$team_id] as $_p)
			{
				$p_id = $_p["p_id"];
				$personnel = $this->personnel_map[$team_id][$p_id];

				if (isset($task->tm_id) && $personnel->title_code != '') {
					//continue;
				}

				if ($this->setPersonnelItem($personnel, $task, $personnel_total)) {
					if (empty($personnel_total)) {
						break;
					}
				}
			}
		}

		if (empty($personnel_total)) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	/**
	 * 警備員とタスクから配置可能かを判断
	 * 満たしている条件の消し込み
	 *
	 * @param type $personnel
	 * @param type $task
	 * @param type $check_task
	 * @param type $dn_task
	 * @return boolean
	 */
	private function setTaskToPersonnel(&$personnel, &$task, $check_task = FALSE, $dn_task=FALSE, $set_dn=FALSE)
	{
		if ($dn_task) {
			$task_checks=['license_05'=>FALSE];
		} else {
			$task_checks=['license_05'=>TRUE];
		}

		if ($this->isTaskOK($personnel, $task, $this->ts, FALSE, $task_checks)
			&& ($set_dn == FALSE || ($set_dn == TRUE && $this->checkAssignTaskN($personnel)))
		)
		{
			$this->checkTaskPersonnel($personnel, $task, $check_task);

			$this->setDatItem($personnel->p_id, $task, $this->ts);

			// DNを合わせて設定する
			if ($set_dn) {
				$this->assignTaskN($personnel, $check_task);
			}

			// DN勤務なら
			if ($this->isDN($personnel->p_id))
			{
				// 翌日：空け
				$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
				// 翌々日：公休
				$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts + 172800);
			}
			else if ($this->isN($personnel->p_id))
			{
				// 翌日：空け
				$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
			}
			return TRUE;
		} else {
			return FALSE;
		}
	}

	/**
	 * setTaskToPersonnelとほぼ同じ処理、共通化できると思います
	 *
	 * @param type $personnel
	 * @param type $task
	 * @param type $personnel_total
	 * @param type $is_personnel
	 * @return boolean
	 */
	private function setPersonnelItem(&$personnel, &$task, &$personnel_total, $is_personnel=TRUE)
	{
		if ($this->isTaskOK($personnel, $task, $this->ts))
		{
			$personnel_total--;

			// 他の条件も満たすか判定
			$this->checkTaskPersonnel($personnel, $task);

			$this->setDatItem($personnel->p_id, $task, $this->ts);

			// DN日でDの場合、同じ勤務場所のNを探して配置
			if (isset($task->night_day) && $task->night_day === DAT_CODE_D
					&& isset($personnel->team_id) && $this->dat_bases[$this->ts][0] == $personnel->team_id)
			{
				$this->assignTaskN($personnel);
			}

			// DN勤務なら
			if ($this->isDN($personnel->p_id))
			{
				// 翌日：空け
				$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
				// 翌々日：公休
				$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts + 172800);
			}
			else if ($this->isN($personnel->p_id))
			{
				// 翌日：空け
				$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
			}
			return TRUE;
		} else {
			return FALSE;
		}
	}

	/**
	 * N勤務が配置できるかチェック
	 *
	 * @param type $personnel
	 */
	private function checkAssignTaskN(&$personnel)
	{
		if (count($this->task_map[$this->ts])>0)
		{
			foreach ($this->task_map[$this->ts] as $n => &$t)
			{
				if ($t->night_day === DAT_CODE_N && $t->personnel > 0)
				{
					return True;
				}
			}
		}

		return false;
	}

	/**
	 * N勤務を配置
	 *
	 * @param type $personnel
	 * @param type $task
	 * @param type $check_task
	 */
	private function assignTaskN(&$personnel, $check_task = FALSE)
	{
		if (count($this->task_map[$this->ts])>0)
		{
			foreach ($this->task_map[$this->ts] as $n => &$t)
			{
				if ($t->night_day === DAT_CODE_N && $t->personnel > 0)
				{
					if ($this->isTaskOK($personnel, $t, $this->ts))
					{
						$this->checkTaskPersonnel($personnel, $t, $check_task);
						$this->setDatItem($personnel->p_id, $t, $this->ts);
						// DN勤務なら
						if ($this->isDN($personnel->p_id))
						{
							// 翌日：空け
							$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
							// 翌々日：公休
							$this->setDatItem($personnel->p_id, DAT_CODE_KOUKYU, $this->ts + 172800);
						}
						else if ($this->isN($personnel->p_id))
						{
							// 翌日：空け
							$this->setDatItem($personnel->p_id, DAT_CODE_AKE, $this->ts + 86400);
						}

						$this->task_map[$this->ts][$n] = $t;
					}
				}
			}
		}
	}

	/**
	 * 読み込む済みの変数から警備員を返す
	 *
	 * @param type $p_id
	 * @param type $omitX
	 * @return type
	 */
	private function getPersonnel($p_id, $omitX=FALSE)
	{
		if (empty($p_id)) {
			return NULL;
		}
		$personnel = NULL;
		foreach ($this->personnel_map as $team_id => $p) {
//			if ($omitX && $team_id == 'X') {
//				continue;
//			}
			if (isset($p[$p_id])) {
				$personnel = $p[$p_id];
				break;
			}
		}
		if ($personnel === NULL) {
			Log::error("Personnelが取得できない[p_id=]".$p_id);
		}
		return $personnel;
	}

	/**
	 * 消防班員を返す
	 *
	 * @param type $fire_id
	 * @return type
	 */
	private function getPersonnelsFireId($fire_id)
	{
		if (empty($fire_id)) {
			return NULL;
		}
		$duty_team_ids = array_keys(Configure::read('duty_team_ids'));
		$personnels = [];
		foreach ($duty_team_ids as $team_id) {
			foreach ($this->personnel_map[$team_id] as $p) {
				if ($p->fire_id == $fire_id) {
					$personnels[] = $p;
				}
			}
		}
		return $personnels;
	}


	/**
	 * タスクの必要人数をカウント
	 *
	 * @param type $personnel
	 * @param type $task
	 * @param type $check_task TRUEなら定常タスクの条件を対象にする
	 * @return boolean
	 */
	private function checkTaskPersonnel(&$personnel, &$task, $check_task = FALSE)
	{
		$duty_personnel_checks = Configure::read('duty_personnel_checks');
		$ret = FALSE;
		if (isset($task->t_id)) {
			if ($task->personnel > 0) {
				$task->personnel--;
				$ret = TRUE;
			}
			if ($check_task)
			{
				// 役職
				foreach ($duty_personnel_checks as $title_type => $title_code)
				{
					if ($task->{$title_type} > 0 && $personnel->title_code == $title_code)
					{
						$task->{$title_type}--;
						$ret = TRUE;
						break;
					}
				}
				// 資格1〜5
				foreach (['01', '02', '03', '04', '05'] as $suffix)
				{
					$license = 'license_'.$suffix;
					if ($task->{$license} > 0 && $personnel->{$license} > 0)
					{
						$task->{$license}--;
						$ret = TRUE;
					}
				}
			}

			// 女性のみ
			if ($task->woman_only > 0 && $personnel->gender == GENDER_TYPE_WOMAN)
			{
				$task->woman_only--;
				$ret = TRUE;
			}
			// 女性でも可
			if ($task->woman_possible > 0 && $personnel->gender == GENDER_TYPE_WOMAN)
			{
				$task->woman_possible--;
				$ret = TRUE;
			}
		} else if (isset($task->tm_id)) {
			// 役職
			foreach ($duty_personnel_checks as $title_type => $title_code)
			{
				if ($task->{$title_type} > 0 && $personnel->title_code == $title_code)
				{
					$task->{$title_type}--;
					$ret = TRUE;
					break;
				}
			}
			// 女性のみ
			if ($task->woman_only > 0 && $personnel->gender == GENDER_TYPE_WOMAN)
			{
				$task->woman_only--;
				$ret = TRUE;
			}
			// 女性でも可
			if ($task->woman_possible > 0 && $personnel->gender == GENDER_TYPE_WOMAN)
			{
				$task->woman_possible--;
				$ret = TRUE;
			}
			// 資格1〜5
			foreach (['01', '02', '03', '04', '05'] as $suffix)
			{
				$license = 'license_'.$suffix;
				if ($task->{$license} > 0 && $personnel->{$license} > 0)
				{
					$task->{$license}--;
					$ret = TRUE;
				}
			}
			if ($task->personnel > 0 && preg_match('/^(R|HL)[0-9]+/', $task->tm_id)) {
				$task->personnel--;
				$ret = TRUE;
			}
		}
		return $ret;
	}

	/**
	 * タスクの配置を前後関係を考慮して確認
	 *
	 * @param Personnel $personnel
	 * @param Task $task
	 * @return boolean
	 */
	private function isTaskOK(&$personnel, $task, $ts=0, $is_goon=FALSE, $task_checks=['license_05'=>TRUE])
	{
		if ($ts == 0) {
			$ts = $this->ts;
		}

		$duty_types = $this->getDutyTypes($personnel->p_id, $ts);
		$before_duty_types = $this->getDutyTypes($personnel->p_id, $ts - 86400);
		$after_duty_types = $this->getDutyTypes($personnel->p_id, $ts + 86400);

		$is_debug = FALSE;

		// 特定の人や日付だけでデバッグするとき用のロジック
		if ($this->DEBUG_OPPTION) {
			if (in_array($personnel->p_id, [5772]) && in_array(date('Y-m-d', $ts), ["2015-11-28"])) {
				$is_debug = TRUE;
				Log::debug("警備員：" . $personnel->p_id . ",日付:" . date('Y-m-d', $ts) .",タスクID:" .$task->t_id . $task->tm_id);
			}
		}

		// 既に普通休暇、特別休暇、臨時休暇があればNG
		if (in_array(DAT_CODE_NORMAL, $duty_types)
				|| in_array(DAT_CODE_SPECIAL, $duty_types)
				|| in_array(DAT_CODE_RINJI, $duty_types)) {
			if ($is_debug) {
				Log::debug("既に普通休暇、特別休暇、臨時休暇");
			}
			return FALSE;
		}

		// 公休HD5に消防訓練が配置済みなら終了
		if (in_array(DAT_CODE_KOUKYU, $duty_types)
				&& in_array(DAT_CODE_FE00, $duty_types)) {
			if ($is_debug) {
				Log::debug("公休HD5に消防訓練が配置済み");
			}
			return FALSE;
		}

		// MGR,MGR-Sは土日祝は休み（公休）
		if ($personnel->title_code === 'MGR' || $personnel->title_code === 'MGR-S') {
			$w = date('w', $ts);
			if ($w == 0 || $w == 6 || $this->isHoliday($ts)) {
				if ($is_debug) {
					Log::debug("MGR,MGR-Sは土日祝は休み");
				}
				return FALSE;
			}
		}

		// フェローA2
		$is_a2 = ($personnel->title_code === 'A2') ? TRUE : FALSE;

		// 新入社員
		$is_new_employee = $this->isNewEmployee($personnel);

		// タスクを時間で確認する準備
		$dn_type = '';
		$start_time = '';
		$end_time = '';
		$work_hours = 0;

		$normal_task_flag = FALSE;
		$task_month_flag = FALSE;

		$title_checks = [
			'manager' => 'MGR',
			'sub_manager' => 'MGR-S',
			'leader' => 'LDR',
			'sub_leader' => 'LDR-S',
			'chief' => 'CHF',
			'sub_chief' => 'CHF-S'
		];

		if (isset($task->t_id))
		{
			$normal_task_flag = TRUE;
			$type_name = 'night_day';
			$duty_type = $task->night_day;
			if ($duty_type == DAT_CODE_D) {
				$start_time = DAT_D_START_TIME;
				$end_time = DAT_D_END_TIME;
				$work_hours = DAT_WORK_HOURS_D;
				$dn_type = DAT_CODE_D;
			} else if ($duty_type == DAT_CODE_N) {
				$start_time = DAT_N_START_TIME;
				$end_time = DAT_N_END_TIME;
				$work_hours = DAT_WORK_HOURS_N;
				$dn_type = DAT_CODE_N;
			}
//			if (empty($task->woman_only) && empty($task->woman_possible) && $personnel->gender == GENDER_TYPE_WOMAN) {
//				// 女性でも可が空の場合、女性はNG
//				if ($is_debug) {
//					Log::debug("女性：woman_only=".$task->woman_only."/woman_possible=".$task->woman_possible);
//				}
//				return FALSE;
//			}
			// 資格05は必要が無ければNG
			/*
			if ($task_checks['license_05']) {
				if ($personnel->license_05>0 && empty($task->license_05)) {
					if ($is_debug) {
						Log::debug("資格05は必要が無ければNG");
					}
					return FALSE;
				}
			}
			*/
//			// DN日以外のチーム
//			if ($this->dat_bases[$ts][0] != $personnel->team_id) {
//				if ($personnel->title_code=='CHF-S' && empty($task->sub_chief)) {
//					return FALSE;
//				} else if ($personnel->title_code=='CHF' && empty($task->chief)) {
//					return FALSE;
//				} else if ($personnel->title_code=='LDR-S' && empty($task->sub_leader)) {
//					return FALSE;
//				}
//			}
			if (in_array(DAT_CODE_DW, $duty_types)) {
				// 日直が配置済
				if ($is_debug) {
					Log::debug("日直が配置済NG");
				}
				return FALSE;
			}
//			if (in_array(DAT_CODE_AKE, $duty_types) && $is_new_employee) {
//				// 明けには配置しない
//				return FALSE;
//			}
		}
		else if (isset($task->tm_id))
		{
			$task_month_flag = TRUE;
			$type_name = 'duty_type';
			$duty_type = $task->tm_id;
			if ($task->duty_type == DAT_CODE_D) {
				$start_time = DAT_D_START_TIME;
				$end_time = DAT_D_END_TIME;
				$work_hours = DAT_WORK_HOURS_D;
				$dn_type = DAT_CODE_D;
			} else if ($task->duty_type == DAT_CODE_N) {
				$start_time = DAT_N_START_TIME;
				$end_time = DAT_N_END_TIME;
				$work_hours = DAT_WORK_HOURS_N;
				$dn_type = DAT_CODE_N;
			} else {
				$start_time = $task->start_time;
				$end_time = $task->end_time;
				$work_hours = $task->work_hours;
				if ($this->isTimeToD($start_time, $end_time)) {
					$dn_type = DAT_CODE_D;
				} else if ($this->isTimeToN($start_time, $end_time)) {
					$dn_type = DAT_CODE_N;
				}
			}
			if (empty($task->woman_only) && empty($task->woman_possible) && $personnel->gender == GENDER_TYPE_WOMAN) {
				// 女性でも可が空の場合、女性はNG
				if ($is_debug) {
					Log::debug("女性：woman_only=".$task->woman_only."/woman_possible=".$task->woman_possible);
				}
				return FALSE;
			}
			// 資格05は必要が無ければNG
			if ($personnel->license_05>0 && empty($task->license_05)) {
				if ($is_debug) {
					Log::debug("資格05は必要が無ければNG");
				}
				return FALSE;
			}
			if (in_array(DAT_CODE_DW, $duty_types)) {
				// 日直が配置済
				if ($is_debug) {
					Log::debug("日直が配置済");
				}
				return FALSE;
			}
		}
		else
		{
			$duty_type = $task;
			$dn_type = $task;
			// 休日系を同じ時間にしてみる
			$start_time = '00:00';
			$end_time = '24:00';
		}

		// 既に同じタスクが配置されていたらNG
		if ($is_goon === FALSE && in_array($duty_type, $duty_types))
		{
			if ($is_debug) {
				Log::debug('3.既に同じタスクが設定済：'.$duty_type.'＞'.implode(',', $duty_types));
			}
			return FALSE;
		}

		// A2の場合
		if ($is_a2)
		{
			// A2は100時間以内(DNが設定されていない場合はN分の時間を空けておく)
			$total_work_hours = $this->getTotalWorkHours($personnel->p_id);
			if (($total_work_hours + $work_hours > 100 && $this->checkToN($personnel->p_id, $ts)) ||
				($total_work_hours + $work_hours > 91 && !$this->checkToN($personnel->p_id, $ts) && $dn_type !== DAT_CODE_N)) {
				if ($is_debug) {
					Log::debug('A2は100時間いないの勤務');
				}
				return FALSE;
			}
			// DN勤務は1-20日に1回のみ
			$day = date('j', $ts);
			if ($dn_type === DAT_CODE_N) {
				if ($day >= 21 && $day <= 31) {
					if ($is_debug) {
						Log::debug('A2,DN勤務対象外の日');
					}
					return FALSE;
				} else if ($this->checkToN($personnel->p_id, $ts)) {
					if ($is_debug) {
						Log::debug('A2はDNは月1回まで');
					}
					return FALSE;
				} else if (in_array(DAT_CODE_D, $duty_types) === FALSE) {
					if ($is_debug) {
						Log::debug('A2でNのみの勤務はない');
					}
					return FALSE;
				}
			}

			if ($this->a2Kinmu($personnel->p_id, $ts) === FALSE) {
				if ($is_debug) {
					Log::debug('週4以上の勤務になるからNG');
				}
				return FALSE;
			}

			if ($this->checkRenzokuKinmu($personnel->p_id, $ts, 2) === FALSE) {
				if ($is_debug) {
					Log::debug('連続勤務になるからNG1');
				}
				return FALSE;
			}
		}
		else
		{
			if ($is_new_employee)
			{
				if ($this->checkRenzokuKinmu($personnel->p_id, $ts, 5) === FALSE) {
					if ($is_debug) {
						Log::debug('連続勤務になるからNG2');
					}
					return FALSE;
				}
			}
			if ($this->checkRenzokuKinmu($personnel->p_id, $ts, 6) === FALSE) {
				if ($is_debug) {
					Log::debug('連続勤務になるからNG3');
				}
				return FALSE;
			}
		}

//		// 1週間以上の連続勤務は禁止
//		$flag = FALSE;
//		for ($i=1; $i<=$renzoku_max; $i++) {
//			$temp_duty_types = $this->getDutyTypes($personnel->p_id, $ts - (86400 * $i));
//			if (count($temp_duty_types) === 0) {
//				$flag = TRUE;
//				break;
//			}
//			// 明けHD6は休日扱いにしない
//			foreach ($temp_duty_types as $temp_type) {
//				if (preg_match('/^HD[0-5]+/', $temp_type)) {
//					$flag = TRUE;
//					break 2;
//				}
//			}
//		}
//		if ($flag === FALSE) {
//			if ($is_debug) {
//				Log::debug('連続勤務になるからNG');
//			}
//			return FALSE;
//		}
//		// 後3日分も確認
//		if ($is_a2 === FALSE)
//		{
//			$flag = FALSE;
//			for ($i=1; $i<=3; $i++) {
//				$temp_duty_types = $this->getDutyTypes($personnel->p_id, $ts + (86400 * $i));
//				if (count($temp_duty_types) === 0) {
//					$flag = TRUE;
//					break;
//				}
//				// 明けHD6は休日扱いにしない
//				foreach ($temp_duty_types as $temp_type) {
//					if ($is_debug) {
//						//Log::debug($temp_type);
//					}
//					if (preg_match('/^HD[0-5]+/', $temp_type)) {
//						$flag = TRUE;
//						break 2;
//					}
//				}
//			}
//			if ($flag === FALSE) {
//				if ($is_debug) {
//					Log::debug('連続勤務になるからNG');
//				}
//				return FALSE;
//			}
//		}

		if ($personnel->team_id=='X' && $personnel->title_code!='A2')
		{
			if ($dn_type == DAT_CODE_N) {
				if ($is_debug) {
					Log::debug("本部チームまたはA2");
				}
				return FALSE;
			}
		}

		// 優先勤務の確認
		if (in_array(DAT_CODE_PRI_D, $duty_types)) {
			if ($duty_type === DAT_CODE_D) {
				return TRUE;
			} else {
				if ($is_debug) {
					Log::debug("優先勤務あり");
				}
				return FALSE;
			}
		} else if (in_array(DAT_CODE_PRI_N, $duty_types)) {
			if ($duty_type === DAT_CODE_N) {
				return TRUE;
			} else {
				if ($is_debug) {
					Log::debug("優先勤務あり");
				}
				return FALSE;
			}
		} else if (in_array(DAT_CODE_PRI_DN, $duty_types)) {
			if ($duty_type === DAT_CODE_D || $duty_type === DAT_CODE_N) {
				return TRUE;
			} else {
				if ($is_debug) {
					Log::debug("優先勤務あり");
				}
				return FALSE;
			}
		} else if (in_array(DAT_CODE_PRI_KOUKYU, $duty_types)) {
			// +HD5の場合、HD5は配置済み、合わせて配置可能なのは消防訓練のみ
			if ($duty_type !== DAT_CODE_FE00) {
				if ($is_debug) {
					Log::debug("+HD5の場合、HD5は配置済み、合わせて配置可能なのは消防訓練のみ");
				}
				return FALSE;
			}
		}

//if (in_array('MT01', $duty_types) && date("Ymd", $this->ts) == '20150424') {
//	$is_debug = TRUE;
//}
		$now_duty = $this->getDutyDatas($personnel->p_id, $ts);
		$before_duty = $this->getDutyDatas($personnel->p_id, $ts - 86400);
		$after_duty = $this->getDutyDatas($personnel->p_id, $ts + 86400);

		// 既に月次タスクが配置済みの場合、定常タスクは配置しない
		if ($normal_task_flag) {
			if (in_array('task_month', $now_duty->task_types)) {
				if ($is_debug) {
					Log::debug("月次タスクが配置済みの場合、定常タスクは配置しない");
				}
				return FALSE;
			}
		} else if ($task_month_flag) {
			if (in_array('task', $now_duty->task_types)) {
				if ($is_debug) {
					Log::debug("定常タスクが配置済みの場合、月次タスクは配置しない");
				}
				return FALSE;
			}
		}

		// DNで確認
		if ($dn_type === DAT_CODE_D) {
			// 休暇設定した-DがあればNG
			if (in_array(DAT_CODE_NOT_D, $duty_types) || in_array(DAT_CODE_NOT_DN, $duty_types)) {
				if ($is_debug) {
					Log::debug("休暇設定した-DがあればNG");
				}
				return FALSE;
			}
			// 前日にNがあればNG
			if (in_array(DAT_CODE_N, $before_duty->dn)) {
				if ($is_debug) {
					Log::debug("#前日にNがあればNG");
				}
				return FALSE;
			}
			// 宿直で、DがなければOK
			if (in_array(DAT_CODE_NW, $duty_types) && in_array(DAT_CODE_D, $duty_types) === FALSE) {
				if ($is_debug) {
					Log::debug("#2");
				}
				return TRUE;
			}
			// 公休日をDNにしない
			if (in_array(DAT_CODE_KOUKYU, $now_duty->dn)
					&& in_array(DAT_CODE_N, $now_duty->dn))
			{
				if ($is_debug) {
					Log::debug("休公休日をDNにしない");
				}
				return FALSE;
			}
			if (in_array(DAT_CODE_N, $now_duty->dn))
			{
				// DN日以外をDNにしない
				// 前日が消防訓練の場合は例外
				if (isset($this->dat_bases[$ts][0])
						&& $this->dat_bases[$ts][0] != $personnel->team_id
						&& in_array(DAT_CODE_FE00, $before_duty->dn) === FALSE
						&& $is_a2 === FALSE)
				{
					if ($is_debug) {
						Log::debug("DN日以外はDNにしない");
					}
					return FALSE;
				}
			}
			// DはDN日と公休日
			if (isset($this->dat_bases[$ts][2])
					&& $this->dat_bases[$ts][2] == $personnel->team_id) {
				if ($is_debug) {
					Log::debug('明け日にD勤務は配置しない');
				}
				return FALSE;
			}
		} else if ($dn_type === DAT_CODE_N) {
			// 休暇設定した-NがあればNG
			if (in_array(DAT_CODE_NOT_N, $duty_types) || in_array(DAT_CODE_NOT_DN, $duty_types)) {
				if ($is_debug) {
					Log::debug("休暇設定した-NがあればNG");
				}
				return FALSE;
			}
			// 翌日にDがあればNG
			if (in_array(DAT_CODE_D, $after_duty->dn)) {
				if ($is_debug) {
					Log::debug("翌日にDがあればNG");
				}
				return FALSE;
			}
			// 宿直があればN勤務は無し
			if (in_array(DAT_CODE_NW, $duty_types)) {
				if ($is_debug) {
					Log::debug("宿直があればN勤務は無し");
				}
				return FALSE;
			}
			// 明日に宿直が配置されていれば今日はN勤務無し
			if (in_array(DAT_CODE_NW, $after_duty_types)) {
				if ($is_debug) {
					Log::debug("明日に宿直が配置されていれば今日はN勤務無し");
				}
				return FALSE;
			}
			// 公休日をDNにしない
			if (in_array(DAT_CODE_KOUKYU, $now_duty->dn)
					&& in_array(DAT_CODE_D, $now_duty->dn))
			{
				if ($is_debug) {
					Log::debug("公休日をDNにしない");
				}
				return FALSE;
			}
			if (in_array(DAT_CODE_D, $now_duty->dn))
			{
				// DN日以外をDNにしない
				// 前日が消防訓練の場合は例外
				if (isset($this->dat_bases[$ts][0])
						&& $this->dat_bases[$ts][0] != $personnel->team_id
						&& in_array(DAT_CODE_FE00, $before_duty->dn) === FALSE
						&& $is_a2 === FALSE)
				{
					if ($is_debug) {
						Log::debug("DN日以外はDNにしない");
					}
					return FALSE;
				}
			}
			// 翌日が消防訓練なら公休HD5なので
			if (in_array(DAT_CODE_FE00, $after_duty->dn))
			{
				if ($is_debug) {
					Log::debug("翌日が消防訓練なら公休HD5");
				}
				return FALSE;
			}
			// NはDN日と明け日
			if (isset($this->dat_bases[$ts][1])
					&& $this->dat_bases[$ts][1] == $personnel->team_id) {
				if ($is_debug) {
					Log::debug('公休日にN勤務は配置しない');
				}
				return FALSE;
			}
		}

		if (! preg_match('/^HD[0-9]+/', $duty_type)
				&& $personnel->team_id != $this->dat_bases[$ts][0]
				&& $personnel->team_id != 'X')
		{
			// 休日以外の連続を避ける
			if (in_array($duty_type, $before_duty->types)
					&& ! (in_array(DAT_CODE_D, $before_duty->types) && in_array(DAT_CODE_N, $before_duty->types))) {
				if ($is_debug) {
					Log::debug("昨日と同じ勤務が設定されています。".implode(',', $before_duty->types));
				}
				return FALSE;
			}
		}

		// タイムスタンプで確認
		$start_ts = $this->timeToTimestamp($start_time, $ts);
		$end_ts = $this->timeToTimestamp($end_time, $ts);

		// 消防訓練
		$is_fire = FALSE;
		if (isset($task->tm_id)) {
			$is_fire = preg_match('/^(FE|FD)[0-9]+/', $task->tm_id);
		}

		// 消防訓練の場合は既にFE00が設定済
		if ($is_fire)
		{
			if (in_array(DAT_CODE_FE00, $duty_types)) {
				return TRUE;
			}
		}

		// 前後の配置状況
		$duty_tasks = $this->getDutyTasks($personnel->p_id, $ts);
		$before_tasks = $this->getDutyTasks($personnel->p_id, $ts - 86400);
		$after_tasks = $this->getDutyTasks($personnel->p_id, $ts + 86400);

		if (count($duty_tasks) > 0)
		{
			foreach ($duty_tasks as $d)
			{
				// 公休に割り当てできるのは新入社員以外
				if ($d->duty_type == DAT_CODE_KOUKYU) {
					// 新入社員は公休はNG
					if (($is_new_employee || $is_a2)
							&& in_array(DAT_CODE_FE00, $duty_types) === FALSE)
					{
						if ($is_debug) {
							Log::debug("6.新入社員の公休勤務はNG");
						}
						return FALSE;
					}
				} else {
					// 7:30-17:30, 17:30-7:30
					if (($start_ts >= $d->start_ts && $start_ts < $d->end_ts)
							|| ($end_ts > $d->start_ts && $end_ts <= $d->end_ts)
							|| ($start_ts < $d->start_ts && $end_ts > $d->end_ts))
					{
						if ($is_new_employee === FALSE && $d->duty_type == DAT_CODE_AKE && $duty_type == DAT_CODE_N) {
							continue;
						}
						if ($is_debug) {
							Log::debug("1.既に".$d->duty_type."（".$d->start_time."-".$d->end_time."）が割り当て済み：".$duty_type."（".$start_time."-".$end_time."）");
						}
						return FALSE;
					}
				}
			}
		}

		// 前日
		if (count($before_tasks) > 0)
		{
			// 前日AM7:00まで勤務していたら今日は7:00から勤務はNG
			// ただし、消防訓練はOK
			if ($is_fire)
			{
				foreach ($before_tasks as $d)
				{
					// 前日が明け・休日なら消防訓練は行わない
					//if (preg_match('/^HD[0-9]+/', $d->duty_type)) {
					//	return FALSE;
					//}
					// 消防訓練はN（〜7:30）明けにおこなう
					// 17:30〜開始するのはN勤務、MT
					//
					if ($d->end_ts >= $this->timeToTimestamp(DAT_N_END_TIME, $ts - 86400)) {
						return TRUE;
					}
				}
				// 消防訓練でここを通る場合はNG
				if ($is_debug) {
					Log::debug("消防訓練でここを通る場合はNG");
				}
				return FALSE;
			}
			else
			{
				foreach ($before_tasks as $d)
				{
					// 前日と同じ臨時タスクは配置しない
					if (preg_match('/^R[0-9]+/', $duty_type) && $d->duty_type == $duty_type) {
						if ($is_debug) {
							Log::debug("5.前日と同じ臨時タスクは配置しない（".$d->start_time."-".$d->end_time."）：".$d->duty_type." < ".$duty_type);
						}
						return FALSE;
					}
					// 前日の終了時間が今日の開始と被っていたらNG
					if (! preg_match('/^HD/', $d->duty_type) &&  $d->end_ts > $start_ts) {
						if ($is_debug) {
							Log::debug("2.前日に".$d->duty_type."（".$d->start_time."-".$d->end_time."）が割り当て済み：".$duty_type);
						}
						return FALSE;
					}
				}
			}

		} else {
			// 前日が不明の場合
			return TRUE;
		}

		// 翌日
		if (count($after_tasks) > 0)
		{
			foreach ($after_tasks as $d)
			{
				// 翌日が明けならN以外はNG
				if ($d->duty_type == DAT_CODE_AKE)
				{
					if ($end_ts < $this->timeToTimestamp(DAT_N_END_TIME, $ts)) {
						if ($is_debug) {
							Log::debug($d->duty_type."はNG");
						}
						return FALSE;
					}
				}
			}
		} else {
			return TRUE;
		}

		return TRUE;
	}

	/**
	 * 金曜日時点で週3日以内か確認
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @return boolean
	 */
	private function a2Kinmu($p_id, $ts)
	{
		$w = date('w', $ts);
		if ($w != 5 && $w != 4) {
			return TRUE;
		}
		$kinmu = 0;
		for ($i=1; $i<=5; $i++) {
			$temp_duty_types = $this->getDutyTypes($p_id, $ts - (86400 * $i));
			if (in_array(DAT_CODE_D, $temp_duty_types)) {
				$kinmu++;
			}
		}

		$wnum = date('W', $ts);

		if (($wnum % 2) == 1) {
			$daynum = 3;
		} else {
			$daynum = 2;
		}

		if ($kinmu >= $daynum) {
			return FALSE;
		} else {
			return TRUE;
		}
	}

	/**
	 * 連続勤務のチェック
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @param type $renzoku_max
	 * @return type
	 */
	private function checkRenzokuKinmu($p_id, $ts, $renzoku_max)
	{
		// 1週間以上の連続勤務は禁止
		$flag1 = FALSE;
		$flag2 = FALSE;
		$after = $renzoku_max;
		for ($i=1; $i<=$renzoku_max; $i++) {
			$check_ts = $ts - (86400 * $i);
			$temp_duty_types = $this->getDutyTypes($p_id, $check_ts);
			if (count($temp_duty_types) === 0) {
				$flag1 = TRUE;
				$after = $after - $i;
				break;
			}
			if ($check_ts < $this->start_ts) {
				$flag1 = TRUE;
				$after = $after - $i;
				break;
			}
			$hd_flag = FALSE;
			foreach ($temp_duty_types as $temp_type) {
				if (preg_match("/^HD[0-6]+/", $temp_type)) {
					$hd_flag = TRUE;
				} else if ($temp_type == DAT_CODE_D
						|| $temp_type == DAT_CODE_N
						|| preg_match($this->task_month_preg, $temp_type)) {
					$hd_flag = FALSE;
					break;
				}
			}
			if ($hd_flag) {
				$flag1 = TRUE;
				$after = $after - $i;
				break;
			}
		}
		if ($renzoku_max >= 6)
		{
			if ($after>0 && $after < $renzoku_max) {
				for ($i=1; $i<=$after; $i++) {
					$temp_duty_types = $this->getDutyTypes($p_id, $ts + (86400 * $i));
					if (count($temp_duty_types) === 0) {
						$flag2 = TRUE;
						break;
					}
					$hd_flag = FALSE;
					foreach ($temp_duty_types as $temp_type) {
						if (preg_match("/^HD[0-6]+/", $temp_type)) {
							$hd_flag = TRUE;
						} else if ($temp_type == DAT_CODE_D
								|| $temp_type == DAT_CODE_N
								|| preg_match($this->task_month_preg, $temp_type)) {
							$hd_flag = FALSE;
							break;
						}
					}
					if ($hd_flag) {
						$flag2 = TRUE;
						break;
					}
				}
			} else {
				$flag2 = TRUE;
			}
			return $flag1 && $flag2;
		} else {
			return $flag1;
		}
	}
	/**
	 * 連続勤務のチェック
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @param type $renzoku_max
	 * @return type
	 */
/*
	private function checkRenzokuKinmu($p_id, $ts, $renzoku_max)
	{
		$count = 0;
		$max_count = 0;

		for ($i= -$renzoku_max; $i<=$renzoku_max; $i++) {
			if ($i == 0) {
				$count++;
				continue;
			}
			$check_ts = $ts + (86400 * $i);
			$temp_duty_types = $this->getDutyTypes($p_id, $check_ts);
			if (count($temp_duty_types) === 0) {
				$max_count = max($count, $max_count);
				$count = 0;
			}

			// 明けHD6は休日扱いにしない
			$hd_flag = FALSE;
			foreach ($temp_duty_types as $temp_type) {
				if (preg_match("/^HD[0-5]+/", $temp_type)) {
					$hd_flag = TRUE;
				} else if ($temp_type == DAT_CODE_D
						|| $temp_type == DAT_CODE_N
						|| preg_match($this->task_month_preg, $temp_type)) {
					$hd_flag = FALSE;
					break;
				}
			}
			if ($hd_flag) {
				$max_count = max($count, $max_count);
				$count = 0;
			} else {
				$count++;
			}
		}

		return ($renzoku_max >= $max_count && $max_count <= 6);
	}

	/**
	 * N勤務の有無をチェック
	 *
	 * @param type $p_id
	 * @param type $end_ts
	 * @return boolean
	 */
	private function checkToN($p_id, $end_ts)
	{
		$is_n = FALSE;
		$ts = $this->start_ts;
		for ($i=0; $i<$this->total_day; $i++)
		{
			$day = date('j', $ts);
			if ($day >= 1 && $day <= 20) {
				$duty_types = $this->getDutyTypes($p_id, $ts);
				if (in_array(DAT_CODE_N, $duty_types)) {
					$is_n = TRUE;
				}
			}
			$ts += 86400;
			if ($ts > $end_ts) {
				break;
			}
		}
		return $is_n;
	}

	/**
	 * 1ヶ月分の勤務時間
	 * @param type $p_id
	 * @return type
	 */
	private function getTotalWorkHours($p_id)
	{
		$work_hours = 0;
		if (isset($this->dat_items[$p_id])) {
			for ($ts = $this->start_ts; $ts <= $this->end_ts; $ts += 86400) {
				$items = $this->dat_items[$p_id][$ts];
				foreach ($items as $d) {
					if (isset($d['work_hours']) && $d['work_hours']>0) {
						$work_hours += $d['work_hours'];
					}
				}
			}
		}
		return $work_hours;
	}

	private function isTimeToD($start_time, $end_time)
	{
		// 開始時間と終了時間が12時を挟んでいたらD
		$st = explode(':', $start_time);
		$et = explode(':', $end_time);
		if ((int)$st[0] < 12 && (int)$et[0] > 12) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	private function isTimeToN($start_time, $end_time)
	{
		// 開始時間と終了時間が24時を挟んでいたらN
		$st = explode(':', $start_time);
		$et = explode(':', $end_time);
		if (isset($et[0]) && $et[0] < $st[0]) {
			$et[0] += 24;
		}
		if ((int)$st[0] < 24 && (int)$et[0] > 24) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	public function timeToTimestamp($time, $ts=0)
	{
		$hour = 0;
		$min = 0;
		$arr = explode(':', $time);
		if (isset($arr[0])) {
			$hour = (int)$arr[0];
		}
		if (isset($arr[1])) {
			$min = (int)$arr[1];
		}
		$s = $hour * 3600;
		$s += $min * 60;
		return ($ts + $s);
	}

	/**
	 * 新入社員か確認
	 * - 新卒入社から6ヶ月以内
	 * - 中途入社から3ヶ月以内
	 * @param Personnel $personnel
	 */
	private function isNewEmployee(&$personnel)
	{
		if ($personnel->employee_type == 1)
		{
			// 新卒
			if ($personnel->enter_date) {
				if ($personnel->enter_date->timestamp >= strtotime('-6 month')) {
					return TRUE;
				}
			}
		}
		else
		{
			// 中途
			if ($personnel->enter_date) {
				if ($personnel->enter_date->timestamp >= strtotime('-3 month')) {
					return TRUE;
				}
			}
		}
		return FALSE;
	}

	/**
	 * DN確認
	 * @param int $p_id
	 * @param int $ts
	 * @return boolean
	 */
	private function isDN($p_id, $ts=0)
	{
		$ts = ($ts>0) ? $ts : $this->ts;
		$duty_types = $this->getDutyTypes($p_id, $ts);
		return (in_array(DAT_CODE_D, $duty_types) && in_array(DAT_CODE_N, $duty_types));
//		$duty = $this->getDutyDatas($p_id, $ts);
//		return (in_array(DAT_CODE_D, $duty->dn) && in_array(DAT_CODE_N, $duty->dn));
	}

	/**
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @return boolean
	 */
	private function isD($p_id, $ts=0)
	{
		if ($ts == 0) {
			$ts = $this->ts;
		}
		$duty_types = $this->getDutyTypes($p_id, $ts);
		return (in_array(DAT_CODE_D, $duty_types) && in_array(DAT_CODE_N, $duty_types) === FALSE);
//		$duty = $this->getDutyDatas($p_id, $ts);
//		return (in_array(DAT_CODE_D, $duty->dn) && in_array(DAT_CODE_N, $duty->dn) === FALSE);
	}

	/**
	 * N勤務の有無
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @return boolean
	 */
	private function isN($p_id, $ts=0)
	{
		if ($ts == 0) {
			$ts = $this->ts;
		}
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d) {
				if ($d['duty_type'] == DAT_CODE_N) {
					return TRUE;
				}
			}
		}
		return FALSE;
	}

	/**
	 * 月次タスクが配置済みかどうかを確認
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @return boolean
	 */
	private function isTM($p_id, $ts=0)
	{
		if ($ts == 0) {
			$ts = $this->ts;
		}
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d) {
				if ($d['duty_type'] != ''
						&& preg_match($this->task_month_preg, $d['duty_type'])) {
					return TRUE;
				}
			}
		}
		return FALSE;
	}

	/**
	 * 勤務種別をDNで返す
	 * @param type $p_id
	 * @param type $ts
	 * @return type
	 */
	private function getDutyTypesToDN($p_id, $ts)
	{
		$duty_types = [];
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d) {
				if ($d['duty_type'] != '') {
					if ($d['duty_type'] == DAT_CODE_D
							|| $d['duty_type'] == DAT_CODE_N
							|| preg_match("/^FE[0-9]+/", $d['duty_type'])
							|| preg_match("/^HD[0-9]+/", $d['duty_type'])) {
						$duty_types[] = $d['duty_type'];
					} else if (isset($d['start_time']) && isset($d['end_time']) && $d['start_time'] != '' && $d['end_time'] != '') {
						if ($this->isTimeToD($d['start_time'], $d['end_time'])) {
							$duty_types[] = DAT_CODE_D;
						} else if ($this->isTimeToN($d['start_time'], $d['end_time'])) {
							$duty_types[] = DAT_CODE_N;
						}
					}
				}
			}
		}
		return $duty_types;
	}

	/**
	 *
	 * @param type $p_id
	 * @param type $ts
	 * @return object
	 */
	private function getDutyDatas($p_id, $ts)
	{
		$duty = (object)[
			'dn' => [],
			'types' => [],
			'work_hours' => 0,
			'night_work_hours' => 0,
			'task_types' => []
		];
		if (isset($this->dat_items[$p_id][$ts]))
		{
			foreach ($this->dat_items[$p_id][$ts] as $d)
			{
				if ($d['duty_type'] != '')
				{
					$duty->types[] = $d['duty_type'];
					$duty->work_hours += isset($d['work_hours']) ? $d['work_hours'] : 0;
					$duty->night_work_hours += isset($d['night_work_hours']) ? $d['night_work_hours'] : 0;
					$duty->task_types[] = $d['_type'];

					if ($d['duty_type'] == DAT_CODE_D
							|| $d['duty_type'] == DAT_CODE_N
							|| preg_match("/^FE[0-9]+/", $d['duty_type'])
							|| preg_match("/^HD[0-9]+/", $d['duty_type']))
					{
						$duty->dn[] = $d['duty_type'];
					}
					else if (isset($d['start_time']) && isset($d['end_time']) && $d['start_time'] != '' && $d['end_time'] != '')
					{
						if ($this->isTimeToD($d['start_time'], $d['end_time'])) {
							$duty->dn[] = DAT_CODE_D;
						} else if ($this->isTimeToN($d['start_time'], $d['end_time'])) {
							$duty->dn[] = DAT_CODE_N;
						}
					}
				}
			}
		}
		return $duty;
	}

	private function getDutyTypes($p_id, $ts)
	{
		$duty_types = [];
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d) {
				if ($d['duty_type'] != '') {
					$duty_types[] = $d['duty_type'];
				}
			}
		}
		return $duty_types;
	}

	private function getDutyTasks($p_id, $ts)
	{
		$duty_tasks = [];
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d) {
				if ($d['duty_type'] != '') {
					$task = [];
					$task['duty_type'] = $d['duty_type'];
					if (isset($d['start_time']) && isset($d['end_time']) && $d['start_time'] != '' && $d['end_time'] != '') {
						$task['start_time'] = $d['start_time'];
						$task['end_time'] = $d['end_time'];
						$task['start_ts'] = $this->timeToTimestamp($d['start_time'], $ts);
						$task['end_ts'] = $this->timeToTimestamp($d['end_time'], $ts);
						$task['work_hours'] = ($task['end_ts'] - $task['start_ts']) / 3600;
					} else {
						// 休暇などは24時間扱い
						$task['start_time'] = '00:00';
						$task['end_time'] = '24:00';
						$task['start_ts'] = $ts;
						$task['end_ts'] = $ts + 86400;
						$task['work_hours'] = 0;
					}
					$duty_tasks[] = (object)$task;
				}
			}
		}
		return $duty_tasks;
	}

	/**
	 * 配置データのセット
	 *
	 * @param int $p_id
	 * @param object or string $task
	 * @param int $ts
	 * @return boolean
	 */
	private function setDatItem($p_id, $task, $ts, $is_check=FALSE)
	{
		$start_time = '';
		$end_time = '';
		$work_hours = 0;
		$night_hours = 0;
		$dat = [];
		$duty_types = $this->getDutyTypes($p_id, $ts);

		if (is_object($task))
		{
			if (isset($task->t_id))
			{
				/**
				 * 定常タスク
				 */

				//$duty_type = mb_convert_kana($task->night_day, 'a');
				$duty_type = $task->night_day;

				if ($duty_type == DAT_CODE_D) {
					$start_time = DAT_D_START_TIME;
					$end_time = DAT_D_END_TIME;
					$work_hours = DAT_D_WORK_HOURS;
					$night_hours = 0;
				} else {
					$start_time = DAT_N_START_TIME;
					$end_time = DAT_N_END_TIME;
					$work_hours = DAT_N_WORK_HOURS;
					$night_hours = DAT_N_NIGHT_HOURS;
				}

				$dat = [
					'_type' => 'task',
					'_date' => date("Y-m-d", $ts),
					'id' => $task->id,
					't_id' => $task->t_id,
					'duty_type' => $duty_type,
					'start_time' => $start_time,
					'end_time' => $end_time,
					'work_hours' => $work_hours,
					'night_hours' => $night_hours,
					'meal_allowance' => 0
				];
			}
			else
			{
				/**
				 * 月次タスク
				 */

				//$duty_type = ($task->duty_type != '') ? $task->duty_type : $task->show_mark;
				//$duty_type = mb_convert_kana($task->tm_id, 'a');
				$duty_type = $task->tm_id;

				if ($task->duty_type == DAT_CODE_D) {
					$start_time = DAT_D_START_TIME;
					$end_time = DAT_D_END_TIME;
					$work_hours = DAT_D_WORK_HOURS;
					$night_hours = 0;
				} else if ($task->duty_type == DAT_CODE_N) {
					$start_time = DAT_N_START_TIME;
					$end_time = DAT_N_END_TIME;
					$work_hours = DAT_N_WORK_HOURS;
					$night_hours = DAT_N_NIGHT_HOURS;
				} else {
					$start_time = $task->start_time;
					$end_time = $task->end_time;
					$work_hours = $task->work_hours;
					$night_hours = $task->night_work_hours;
				}

				$dat = [
					'_type' => 'task_month',
					'_date' => date("Y-m-d", $ts),
					'id' => $task->id,
					'tm_id' => $task->tm_id,
					'duty_type' => $duty_type,
					'start_time' => $start_time,
					'end_time' => $end_time,
					'work_hours' => $work_hours,
					'night_hours' => $night_hours,
					'meal_allowance' => $task->meal_allowance
				];
			}

			// タスク設定時に休日があれば削除する
			if ($is_check === FALSE)
			{
				for ($i=0; $i<count($duty_types); $i++) {
					if (DAT_CODE_NORMAL == $duty_types[$i]
							|| DAT_CODE_SPECIAL == $duty_types[$i]
							|| DAT_CODE_RINJI == $duty_types[$i]
							|| DAT_CODE_KOUKYU == $duty_types[$i])
					{
						unset($this->dat_items[$p_id][$ts][$i]);
						//Log::debug(date("Y-m-d", $ts)." ".$this->dat_items[$p_id][$ts][$i]['duty_type']." ＞変更：".$duty_type);

					}
				}
			}

		}
		else
		{
			// 同じものはセットしない
			if (in_array($task, $duty_types)) {
				return FALSE;
			}
//			if ($task === DAT_CODE_NORMAL) {
//				Log::debug(date("Y-m-d", $ts)." ".DAT_CODE_NORMAL."が設定要求");
//			}
			// 休暇設定時
			// 既に勤務、臨時警備、休暇が設定されていれば登録しない
			if ($is_check === FALSE)
			{
				// 明けをセットした場合に公休があれば公休を消す
				if ($task == DAT_CODE_AKE) {
					for ($i=0; $i<count($duty_types); $i++) {
						if ($duty_types[$i] == DAT_CODE_KOUKYU) {
							unset($this->dat_items[$p_id][$ts][$i]);
							break;
						}
					}
				} else if (preg_match('/^HD[0-9]+/', $task)) {
					for ($i=0; $i<count($duty_types); $i++) {
						if ($duty_types[$i] == DAT_CODE_D
								|| $duty_types[$i] == DAT_CODE_N
								|| $duty_types[$i] == DAT_CODE_NW
								|| $duty_types[$i] == DAT_CODE_DW
								|| preg_match('/^HD[0-9]+/', $duty_types[$i])
								|| preg_match($this->task_month_preg, $duty_types[$i]))
						{
							//Log::debug(date("Y-m-d", $ts)." ".$duty_types[$i]."が設定済 : ".$task);
							return FALSE;
						}
						else if ($task === DAT_CODE_KOUKYU && preg_match('/^FD[0-9]+/', $duty_types[$i]))
						{
							// 隊長代行訓練配置済みの公休指定はしない
							return FALSE;
						}
					}
				} else if ($task == DAT_CODE_NW
						|| $task == DAT_CODE_DW) {
					for ($i=0; $i<count($duty_types); $i++) {
						if (DAT_CODE_NORMAL == $duty_types[$i]
								|| DAT_CODE_SPECIAL == $duty_types[$i]
								|| DAT_CODE_RINJI == $duty_types[$i]
								|| DAT_CODE_KOUKYU == $duty_types[$i])
						{
							unset($this->dat_items[$p_id][$ts][$i]);
						}
					}
				}
			}

			if ($task == DAT_CODE_D) {
				$start_time = DAT_D_START_TIME;
				$end_time = DAT_D_END_TIME;
				$work_hours = DAT_D_WORK_HOURS;
				$night_hours = 0;
			} else if ($task == DAT_CODE_N) {
				$start_time = DAT_N_START_TIME;
				$end_time = DAT_N_END_TIME;
				$work_hours = DAT_N_WORK_HOURS;
				$night_hours = DAT_N_NIGHT_HOURS;
			} else if ($task == DAT_CODE_FE00) {
				$work_hours = $this->fire_work_hours;
			}

			$dat = $this->getDatItem($p_id, $task, $ts, $start_time, $end_time, $work_hours, $night_hours);
		}

		if (isset($this->dat_items[$p_id][$ts]) === FALSE) {
			$this->dat_items[$p_id][$ts] = [];
		}
		$this->dat_items[$p_id][$ts][] = $dat;

		$this->setPersonnelHoursMap($p_id, $work_hours);

		return TRUE;
	}

	/**
	 * ソートに反映するための勤務時間を追加
	 * @param type $p_id
	 * @param type $work_hours
	 */
	private function setPersonnelHoursMap($p_id, $work_hours)
	{
		foreach ($this->personnel_hours_map as $team_id => $p) {
			if (isset($this->personnel_hours_map[$team_id][$p_id])) {
				$this->personnel_hours_map[$team_id][$p_id] += $work_hours;

				foreach ($this->personnel_sort_hours_map[$team_id] as &$_p)
				{
					if ($_p["p_id"] == $p_id)
					{
						$_p["work_hours"] = $this->personnel_hours_map[$team_id][$p_id];
						break;
					}
				}
				break;
			}
		}
	}

	/**
	 * 警備員の休暇設定されておらず、割り当て可能な日数
	 */
	private function getRestPersonnelDays($p_id, $ts) {
		$result = 0;
		for ($_ts = $ts + 86400;  $_ts <= $this->end_ts; $_ts += 86400) {
			if (isset($this->personnel_rest_map[$d->team_id][$d->p_id][$ts])) {
				$result += $this->personnel_rest_map[$d->team_id][$d->p_id][$ts];
			} else {
				$duties = $this->getDutyDatas($p_id, $ts);
				if (!preg_grep("/HD[0-9]/", $duties->types)) {
					$this->personnel_rest_map[$d->team_id][$d->p_id][$ts] = 1;
					$result++;
				} else {
					$this->personnel_rest_map[$d->team_id][$d->p_id][$ts] = 0;
				}
			}
		}
		return $result;
	}

	/**
	 * 警備員の並び替え
	 */
	private function sortPersonnelHoursMap($type = SORT_ASC)
	{
		foreach ($this->personnel_sort_hours_map as $team_id => $p) {
			$sort_orders = [];
			$work_hours = [];
			$renzokus = [];
			$year_work_hours = [];
			$p_ids = [];
			foreach ($this->personnel_sort_hours_map[$team_id] as $key => $row) {
				$sort_orders[$key] = $row['sort_order'];
				$work_hours[$key]  = $row['work_hours'];
				$renzokus[$key]    = $row['renzoku'];
				$year_work_hours[$key] = $row['year_work_hours'];
			}
			array_multisort($work_hours, $type, $sort_orders, SORT_DESC, $year_work_hours, $type, $renzokus, SORT_ASC, $this->personnel_sort_hours_map[$team_id]);
		}
	}

	private function getDatItem($p_id, $task, $ts, $start_time='', $end_time='', $work_hours=0, $night_hours=0)
	{
		$dat = [
			'_type' => $task,
			'_date' => date("Y-m-d", $ts),
			'duty_type' => $task,
			'start_time' => $start_time,
			'end_time' => $end_time,
			'work_hours' => $work_hours,
			'night_hours' => $night_hours,
			'meal_allowance' => 0
		];
		return $dat;
	}

	/**
	 * タスクマスタの保存
	 */
	private function createTaskTable($is_new_build=TRUE)
	{
		// タスクワークデータは一旦削除
		// トランザクション非対応なので外で削除
		if ($is_new_build) {
			$this->resetTaskWork();
		}

		$TaskTables = TableRegistry::get('TaskTables');
		$task_table_map = $TaskTables->getTableMap($this->duty_year_month);

		$TaskTables->connection()->begin();

		$ts = $this->start_ts;

		for ($i=0; $i<$this->total_day; $i++)
		{
			$t_ids = [];
			$t_ids_end = [];
			$tm_ids = [];
			$tm_ids_end = [];

			if (isset($this->task_map[$ts]) && count($this->task_map[$ts])>0)
			{
				foreach ($this->task_map[$ts] as &$task)
				{
					// すべて処理済か確認
					if ($this->isCompTask($task, $ts)) {
						$t_ids_end[] = $task->t_id;
						// 完了タスクも一時データに格納
						//$this->createTaskWork($task, $ts, TMT_STATUS_TYPE_COMP);
					} else {
						$t_ids[] = $task->t_id;
						// 未完了タスクを一時データに格納
						$this->createTaskWork($task, $ts, TMT_STATUS_TYPE_NOTCOMP);
					}
				}
			}

			if (isset($this->task_month_map[$ts]) && count($this->task_month_map[$ts])>0)
			{
				foreach ($this->task_month_map[$ts] as &$task)
				{
					// すべて処理済か確認
					if ($this->isCompTask($task, $ts)) {
						$tm_ids_end[] = $task->tm_id;
						// 完了タスクも一時データに格納
						//$this->createTaskWork($task, $ts, TMT_STATUS_TYPE_COMP);
						// 対象の月次タスクを処理済へ
						$this->compTaskMonth($task->tm_id);
					} else {
						$tm_ids[] = $task->tm_id;
						// 未完了タスクを一時データに格納
						$this->createTaskWork($task, $ts, TMT_STATUS_TYPE_NOTCOMP);
					}
				}
			}

			if (count($t_ids) === 0 && count($tm_ids) === 0) {
				$status = TMT_STATUS_TYPE_COMP;
				// 対象が無い場合は未処理テーブルにしておく
				if (count($t_ids_end) === 0 && count($tm_ids_end) === 0) {
					$status = TMT_STATUS_TYPE_NOTCOMP;
				}
			} else {
				$status = TMT_STATUS_TYPE_NOTCOMP;
			}

			if (isset($task_table_map[$ts]))
			{
				// 更新
				$task_table = $task_table_map[$ts];
				if ($task_table)
				{
					$ori_tm_ids = explode(',', $task_table->tm_ids);
					$tm_ids = $this->_addTids($ori_tm_ids, $tm_ids);
					$ori_tm_ids_end = explode(',', $task_table->tm_ids_end);
					$tm_ids_end = $this->_addTids($ori_tm_ids_end, $tm_ids_end);
				}

				$task_table = $TaskTables->patchEntity($task_table, [
					'tm_ids' => implode(',', $tm_ids),
					'tm_ids_end' => implode(',', $tm_ids_end)
				]);
			}
			else
			{
				// 新規
				$day_names = Configure::read('day_names');

				$task_table = $TaskTables->newEntity([
					'status' => $status,
					'tt_year_month' => $this->duty_year_month,
					'tt_date' => date("Y-m-d", $ts),
					'day_name' => $day_names[date("w", $ts)],
					't_ids' => implode(',', $t_ids),
					't_ids_end' => implode(',', $t_ids_end),
					'tm_ids' => implode(',', $tm_ids),
					'tm_ids_end' => implode(',', $tm_ids_end)
				]);
			}
			if ($TaskTables->save($task_table) === FALSE) {
				$TaskTables->connection()->rollback();
				Log::error($task_table->errors());
				return FALSE;
			}
			$ts += 86400;
		}

		$TaskTables->connection()->commit();

		return TRUE;
	}

	/**
	 * 処理済の月次タスクのステータス変更
	 * @param string $tm_id
	 */
	private function compTaskMonth($tm_id)
	{
		$TaskMonths = TableRegistry::get('TaskMonths');
		$TaskMonths->updateAll([
			'status' => TMM_STATUS_TYPE_COMP
		], [
			'tm_id' => $tm_id,
			'tm_year_month' => $this->duty_year_month
		]);
	}

	/**
	 * 配列を重複を除いて連結
	 */
	private function _addTids($ori_t_ids, $t_ids)
	{
		$new_t_ids = [];
		if (count($ori_t_ids) === 0) {
			return $t_ids;
		} else if (count($t_ids) === 0) {
			return $ori_t_ids;
		}
		foreach ($ori_t_ids as $t_id) {
			if ($t_id != '') {
				$new_t_ids[] = $t_id;
			}
		}
		foreach ($t_ids as $t_id) {
			if ($t_id != '') {
				if (in_array($t_id, $new_t_ids) === FALSE) {
					$new_t_ids[] = $t_id;
				}
			}
		}
		return $new_t_ids;
	}

	/**
	 * タスクの完了状況をチェック
	 *
	 * @param type $task
	 * @param type $ts
	 * @return boolean
	 */
	private function isCompTask(&$task, $ts)
	{
		$date = date("Y-m-d", $ts);

		$t_id = '';
		if (isset($task->t_id)) {
			$t_id = $task->t_id;
		} else if (isset($task->tm_id)) {
			$t_id = $task->tm_id;
			if (! preg_match(TMM_COUNT_TM_ID, $task->tm_id)) {
				return TRUE;
			}
		}
		// マネージャー〜サブ・チーフ
		$duty_personnel_checks = Configure::read('duty_personnel_checks');
		foreach ($duty_personnel_checks as $title_type => $title_code)
		{
			if ($task->{$title_type} > 0)
			{
				//Log::error('未配置の'.$title_type.'があります。('.$date.')'.$t_id.'：'.$task->{$title_type});
				//return FALSE;
			}
		}
		// 女性のみ
		if ($task->woman_only > 0)
		{
			//Log::error('未配置の女性のみがあります。('.$date.')'.$t_id.'：'.$task->woman_only);
			//return FALSE;
		}
		// 資格1〜5
		foreach (['01', '02', '03', '04', '05'] as $suffix)
		{
			//license_01
			$license = 'license_'.$suffix;
			if ($task->{$license} > 0)
			{
				//Log::error('未配置の'.$license.'があります。('.$date.')'.$t_id.'：'.$task->{$license});
				//return FALSE;
			}
		}
		if ($task->personnel > 0) {
			//Log::error('未配置の警備員があります。('.$date.')'.$t_id.'：'.$task->personnel);
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 一旦削除
	 * @TODO: 作成時に削除する必要ないが、仕様変更前のなごりで残す
	 */
	private function resetTaskWork()
	{
		$TaskWorks = TableRegistry::get('TaskWorks');
		//$TaskWorks->query('TRUNCATE task_works');
		$TaskWorks->deleteAll([
			'tw_year_month' => $this->duty_year_month
		]);
	}

	/**
	 * 配置できなかったタスク情報を保存
	 * @TODO: 全体件数でみる場合の個別の未配置情報に意味はないので保存する必要はないかもしれません。
	 *
	 * @param type $task
	 * @param type $ts
	 * @param type $status
	 * @return type
	 */
	private function createTaskWork(&$task, $ts, $status)
	{
		$TaskWorks = TableRegistry::get('TaskWorks');

		$tw_type = 0;
		$task_id = '';

		if (isset($task->tm_id)) {
			$tw_type = TW_TYPE_TMM;
			$task_id = $task->tm_id;
		} else {
			$tw_type = TW_TYPE_TM;
			$task_id = $task->t_id;
		}

		if ($task_id == '') {
			Log::write('error', 'task_idが取得できません。');
			return;
		}

		$data = [
			'status' => $status,
			'tw_year_month' => $this->duty_year_month,
			'tw_date' => date("Y-m-d", $ts),
			'tw_type' => $tw_type,
			'task_id' => $task_id,
			'personnel' => $task->personnel,
			'manager' => $task->manager,
			'sub_manager' => $task->sub_manager,
			'leader' => $task->leader,
			'sub_leader' => $task->sub_leader,
			'chief' => $task->chief,
			'sub_chief' => $task->sub_chief,
			'woman_only' => $task->woman_only,
			'woman_possible' => $task->woman_possible,
			'license_01' => $task->license_01,
			'license_02' => $task->license_02,
			'license_03' => $task->license_03,
			'license_04' => $task->license_04,
			'license_05' => $task->license_05,
			'license_06' => $task->license_06,
			'license_07' => $task->license_07,
			'license_08' => $task->license_08,
			'license_09' => $task->license_09,
			'license_10' => $task->license_10
		];

		// 月次タスクだけ
		if (isset($task->personnel_names)) {
			$data['personnel_names'] = $task->personnel_names;
		}

		$task_work = $TaskWorks->newEntity($data);
		if (! $TaskWorks->save($task_work)) {
			Log::write('error', $task_work->errors());
		}
	}

	/**
	 * 日程表の作成
	 *
	 * @return boolean
	 */
	private function createDutyAssignment()
	{
		if (empty($this->dat_items)) {
			return TRUE;
		}

		$DutyAssignments = TableRegistry::get('DutyAssignments');
		$DutyAssignments->connection()->begin();

		$order = 0;
		foreach ($this->dat_items as $p_id => $data)
		{
			$personnel = $this->getPersonnel($p_id);
			if ($personnel !== NULL)
			{
				if ($this->createDat($DutyAssignments, $personnel, $order) === FALSE) {
					$DutyAssignments->connection()->rollback();
					return FALSE;
				}
				$order++;
			}
		}

		$DutyAssignments->connection()->commit();
		return TRUE;
	}

	public function buildRetotalize()
	{
		$duty_year_month = $this->request->data('duty_year_month');

		$this->loadPersonnelList();
		foreach ($this->personnel_list as $p)
		{
			$this->reTotalize($duty_year_month, $p->p_id);
		}
	}

	/**
	 * DutyWorkの値で再集計
	 *
	 * @param int $year_month YYYYMM
	 * @param int $p_id 社員番号
	 * @return boolean
	 */
	public function reTotalize($year_month, $p_id)
	{
		$this->duty_year = (int)substr($year_month, 0, 4);
		$this->duty_month = (int)substr($year_month, 4, 2);
		$this->duty_year_month = $year_month;
		$this->makeYearMonth();
		$this->initParams();

		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work_list = $DutyWorks->find()->where([
			'dw_year_month' => $year_month,
			'p_id' => $p_id
		])->toArray();

		if (count($duty_work_list)>0)
		{
			$sums = DutyMisc::$sums;
			$data = [];
			$duty_base_hours = Configure::read('duty_base_hours');
			$base_hours = $duty_base_hours[$this->total_day];
			$duty_a2_base_hours = Configure::read('duty_a2_base_hours');
			$a2_base_hours = $duty_a2_base_hours[$this->total_day];

			foreach ($duty_work_list as $d)
			{
				$ts = strtotime($d->dw_date);
				if ($ts > 0) {
					if (isset($data[$ts]) === FALSE) {
						$data[$ts] = [];
					}
					$data[$ts][] = [
						'duty_type' => $d->duty_type,
						'start_time' => $d->start_time,
						'end_time' => $d->end_time,
						'work_hours' => $d->work_hours,
						'night_hours' => $d->night_work_hours,
						'meal_allowance' => $d->meal_allowance
					];
				}
			}

			foreach ($data as $ts => $items)
			{
				$this->dutyTypeTotalize($sums, $items);
			}

			// 超過勤務時間（超過勤務 25%）の計算
			if ($sums['work_hours']>0) {
				if ($this->personnel_list[$p_id]->title_code == 'A2')
				{
					$overtime25 = $sums['work_hours'] - $a2_base_hours;
					if ($overtime25 > 0) {
						$sums['overtime25'] = $overtime25;
					}
				}
				else
				{
					$overtime25 = $sums['work_hours'] - $base_hours;
					if ($overtime25 > 0) {
						$sums['overtime25'] = $overtime25;
					}
				}

			}

			$DutyAssignments = TableRegistry::get('DutyAssignments');
			$duty_assignment = $DutyAssignments->find()->where([
				'da_year_month' => $year_month,
				'p_id' => $p_id
			])->first();

			if ($duty_assignment !== NULL)
			{
				$duty_assignment = $DutyAssignments->patchEntity($duty_assignment,[
					'd_duty' => $sums['d_duty'],
					'n_duty' => $sums['n_duty'],
					'dn_duty' => $sums['dn_duty'],
					'day_duty' => $sums['day_duty'],
					'night_duty' => $sums['night_duty'],
					'fire_plural' => $sums['fire_plural'],
					'meal_allowance' => $sums['meal_allowance'],
					'work_days' => $sums['work_days'],
					'vacation_days' => $sums['vacation_days'],
					'work_hours' => $sums['work_hours'],
					'night_work_hours' => $sums['night_work_hours'],
					'extra_work_hours' => $sums['extra_work_hours'],
					'extra_night_work_hours' => $sums['extra_night_work_hours'],
					'overtime25' => $sums['overtime25'] - $sums['overtime35'],
					'overtime35' => $sums['overtime35'],
					'r_days' => $sums['r_days'],
					'hl_days' => $sums['hl_days'],
					'hd1_days' => $sums['hd1_days'],
					'hd2_days' => $sums['hd2_days'],
					'hd3_days' => $sums['hd3_days'],
					'hd4_days' => $sums['hd4_days'],
					'hd5_days' => $sums['hd5_days'],
					'x_days' => $sums['x_days'],
					'y_days' => $sums['y_days'],
					'z_days' => $sums['z_days'],
					'me1_days' => $sums['me1_days'],
					'me2_days' => $sums['me2_days'],
					'ne1_hours' => $sums['ne1_hours'],
					'ne2_hours' => $sums['ne2_hours'],
					'ne3_hours' => $sums['ne3_hours'],
					'ne4_hours' => $sums['ne4_hours'],
					'f_hours' => $sums['f_hours'],
					'fe_hours' => $sums['fe_hours'],
					'fd_days' => $sums['fd_days'],
					'oj1_hours' => $sums['oj1_hours'],
					'oj2_hours' => $sums['oj2_hours'],
					'oj3_hours' => $sums['oj3_hours'],
					'sh_days' => $sums['sh_days'],
					'se_hours' => $sums['se_hours'],
					'se_night_hours' => $sums['se_night_hours'],
					'sm_hours' => $sums['sm_hours'],
					'sm_night_hours' => $sums['sm_night_hours'],
					'te_days' => $sums['te_days'],
					'mt_hours' => $sums['mt_hours']
				]);

				if ($DutyAssignments->save($duty_assignment) === FALSE) {
					Log::error($duty_assignment->errors());
					return FALSE;
				}
			}
		}

		return TRUE;
	}

	/**
	 * 集計データの計算
	 *
	 * @param type $sums
	 * @param type $data
	 * @return type
	 */
	private function dutyTypeTotalize(&$sums, &$data)
	{
		$work_hours = 0;
		$night_hours = 0;
		$duty_types = [];

		$fire_plural_days = [];

		foreach ($data as $d)
		{
			$duty_types[] = $d['duty_type'];

			if ($d['duty_type'] == DAT_CODE_D)
			{
				$sums['d_duty']++;
			}
			else if ($d['duty_type'] == DAT_CODE_N)
			{
				$sums['n_duty']++;
			}
			else if ($d['duty_type'] == DAT_CODE_DW)
			{
				$sums['day_duty']++;
			}
			else if ($d['duty_type'] == DAT_CODE_NW)
			{
				$sums['night_duty']++;
			}
			else if ($d['duty_type'] == DAT_CODE_FKD
					|| $d['duty_type'] == DAT_CODE_FKN)
			{
				// 同じ日のFKD,FKNは1回とカウントする
				if (!isset($fire_plural_days[$d['_date']]))
				{
					$fire_plural_days[$d['_date']] = 1;
					$sums['fire_plural']++;
				}
			}
			else if ($d['duty_type'] == DAT_CODE_SHITEI
					|| $d['duty_type'] == DAT_CODE_KOUKYU
					|| $d['duty_type'] == 'X')
			{
				$key = strtolower($d['duty_type']) . '_days';
				if (isset($sums[$key])) {
					$sums[$key]++;
				}
			}
			else if ($d['duty_type'] == DAT_CODE_NORMAL
					|| $d['duty_type'] == DAT_CODE_SPECIAL
					|| $d['duty_type'] == DAT_CODE_RINJI
					)
			{
				$key = strtolower($d['duty_type']) . '_days';
				if (isset($sums[$key])) {
					$sums[$key]++;
				}

				// HD2, HD3, HD4は9.0時間を勤務時間に計上する
				$sums['work_hours'] += 9.0;
			}
			else if (preg_match("/^(R|HL|Y|Z|ME1|ME2|FD|SH|TE)[0-9]+/", $d['duty_type'], $m))
			{
				if (isset($m[1]) && $m[1])
				{
					$key = strtolower($m[1]) . '_days';
					if (isset($sums[$key])) {
						$sums[$key]++;
					}
				}
			}
			else if (preg_match("/^(NE1|NE2|NE3|NE4|FE|OJ1|OJ2|OJ3|SE|SM|MT)[0-9]+/", $d['duty_type'], $m))
			{
				if (isset($m[1]) && $m[1]!='')
				{
					if ($d['duty_type'] == DAT_CODE_FE00) {
						$key = 'f_hours';
					} else {
						$key = strtolower($m[1]) . '_hours';
					}
					if (isset($sums[$key])) {
						$sums[$key] += $d['work_hours'];
					}
					// 深夜時間
					if ($m[1] == 'SE' || $m[1] == 'SM') {
						$key = strtolower($m[1]) . '_night_hours';
						if (isset($sums[$key])) {
							$sums[$key] += $d['night_hours'];
						}
					}
				}
			}

			if ($d['work_hours']>0) {
				$sums['work_hours'] += $d['work_hours'];
				$work_hours += $d['work_hours'];
			}
			if ($d['night_hours']>0) {
				$sums['night_work_hours'] += $d['night_hours'];
				$night_hours += $d['night_hours'];
			}
			// 臨時警備の勤務時間
			if (preg_match("/^R[0-9]+/", $d['duty_type'])) {
				if ($d['work_hours']>0) {
					$sums['extra_work_hours'] += $d['work_hours'];
				}
				if ($d['night_hours']>0) {
					$sums['extra_night_work_hours'] += $d['night_hours'];
				}
			}
			// 勤務日としてカウントする日
			if ($d['duty_type'] === DAT_CODE_D
				|| $d['duty_type'] === DAT_CODE_N
				|| preg_match("/^(R|HL|ME|NE|FE|FD|OJ|SH|SE|SM|TE|MT)[0-9]+/", $d['duty_type']))
			{
				$sums['work_days']++;
			}
			else if ($d['duty_type'] === DAT_CODE_SHITEI
					|| $d['duty_type'] === DAT_CODE_NORMAL
					|| $d['duty_type'] === DAT_CODE_SPECIAL
					|| $d['duty_type'] === DAT_CODE_RINJI
					|| $d['duty_type'] === DAT_CODE_KOUKYU)
			{
				$sums['vacation_days']++;
			}
		}

		// DN数
		if (in_array(DAT_CODE_D, $duty_types) && in_array(DAT_CODE_N, $duty_types)) {
			$sums['dn_duty']++;
			$sums['d_duty']--;
			$sums['n_duty']--;
			// 順番がN,Dとなるのを防ぐ
			// D,+DN,Nの場合もあるのでDNを先頭に
			$new_arr = [DAT_CODE_D,DAT_CODE_N];
			foreach ($duty_types as $tmp_type) {
				if ($tmp_type != DAT_CODE_D && $tmp_type != DAT_CODE_N) {
					$new_arr[] = $tmp_type;
				}
			}
			$duty_types = $new_arr;
		}

		// 休日出勤（超過勤務 35%）の計算
		if (in_array(DAT_CODE_SHITEI, $duty_types) ||
			in_array(DAT_CODE_NORMAL, $duty_types) ||
			in_array(DAT_CODE_SPECIAL, $duty_types) ||
			in_array(DAT_CODE_RINJI, $duty_types) ||
			in_array(DAT_CODE_KOUKYU, $duty_types)
		) {
			$sums['overtime35'] += $work_hours;

			if (in_array(DAT_CODE_FE00, $duty_types)) {
				$sums['overtime35'] -= $this->fire_work_hours;
			}
		}

		$sums['meal_allowance'] += $d['meal_allowance'];

		return $duty_types;
	}

	/**
	 * 日程表の登録
	 *
	 * @param DutyAssignmentsTable $DutyAssignments
	 * @param Personnel $personnel
	 * @param int $order
	 * @return boolean
	 */
	private function createDat(&$DutyAssignments, &$personnel, $order)
	{
		$sums = DutyMisc::$sums;

		$days = [];
		$ts = $this->start_ts;
		$duty_base_hours = Configure::read('duty_base_hours');
		$base_hours = $duty_base_hours[$this->total_day];
		$duty_a2_base_hours = Configure::read('duty_a2_base_hours');
		$a2_base_hours = $duty_a2_base_hours[$this->total_day];

		for ($i=0; $i<$this->total_day; $i++)
		{
			$day = (int)date("j", $ts);
			$days[$day] = NULL;

			if (isset($this->dat_items[$personnel->p_id][$ts]))
			{
				$duty_types = $this->dutyTypeTotalize($sums, $this->dat_items[$personnel->p_id][$ts]);
				$days[$day] = implode(',', $duty_types);
			}

			if (empty($days[$day])) {
				$days[$day] = DAT_CODE_KOUKYU;
			}

			$ts += 86400;
		}

		// 超過勤務時間（超過勤務 25%）の計算
		if ($sums['work_hours']>0) {
			if ($personnel->title_code == 'A2')
			{
				$overtime25 = $sums['work_hours'] - $a2_base_hours;
				if ($overtime25 > 0) {
					$sums['overtime25'] = $overtime25;
				}
			}
			else
			{
				$overtime25 = $sums['work_hours'] - $base_hours;
				if ($overtime25 > 0) {
					$sums['overtime25'] = $overtime25;
				}
			}
		}

		// 予防処置
		if (isset($days[29]) === FALSE) $days[29] = NULL;
		if (isset($days[30]) === FALSE) $days[30] = NULL;
		if (isset($days[31]) === FALSE) $days[31] = NULL;

		// ここでは更新しか発生しない
		$duty_assignment = $DutyAssignments->find()->where([
			'p_id' => $personnel->p_id,
			'da_year_month' => $this->duty_year_month
		])->first();

		if ($duty_assignment !== NULL)
		{
			$duty_assignment = $DutyAssignments->patchEntity($duty_assignment,[
				'd_duty' => $sums['d_duty'],
				'n_duty' => $sums['n_duty'],
				'dn_duty' => $sums['dn_duty'],
				'day_duty' => $sums['day_duty'],
				'night_duty' => $sums['night_duty'],
				'fire_plural' => $sums['fire_plural'],
				'meal_allowance' => $sums['meal_allowance'],
				'work_days' => $sums['work_days'],
				'vacation_days' => $sums['vacation_days'],
				'work_hours' => $sums['work_hours'],
				'night_work_hours' => $sums['night_work_hours'],
				'extra_work_hours' => $sums['extra_work_hours'],
				'extra_night_work_hours' => $sums['extra_night_work_hours'],
				'overtime25' => $sums['overtime25'] - $sums['overtime35'],
				'overtime35' => $sums['overtime35'],
				'r_days' => $sums['r_days'],
				'hl_days' => $sums['hl_days'],
				'hd1_days' => $sums['hd1_days'],
				'hd2_days' => $sums['hd2_days'],
				'hd3_days' => $sums['hd3_days'],
				'hd4_days' => $sums['hd4_days'],
				'hd5_days' => $sums['hd5_days'],
				'x_days' => $sums['x_days'],
				'y_days' => $sums['y_days'],
				'z_days' => $sums['z_days'],
				'me1_days' => $sums['me1_days'],
				'me2_days' => $sums['me2_days'],
				'ne1_hours' => $sums['ne1_hours'],
				'ne2_hours' => $sums['ne2_hours'],
				'ne3_hours' => $sums['ne3_hours'],
				'ne4_hours' => $sums['ne4_hours'],
				'f_hours' => $sums['f_hours'],
				'fe_hours' => $sums['fe_hours'],
				'fd_days' => $sums['fd_days'],
				'oj1_hours' => $sums['oj1_hours'],
				'oj2_hours' => $sums['oj2_hours'],
				'oj3_hours' => $sums['oj3_hours'],
				'sh_days' => $sums['sh_days'],
				'se_hours' => $sums['se_hours'],
				'se_night_hours' => $sums['se_night_hours'],
				'sm_hours' => $sums['sm_hours'],
				'sm_night_hours' => $sums['sm_night_hours'],
				'te_days' => $sums['te_days'],
				'mt_hours' => $sums['mt_hours'],
//				'document_order' => $order,
				'd_21' => $days[21],
				'd_22' => $days[22],
				'd_23' => $days[23],
				'd_24' => $days[24],
				'd_25' => $days[25],
				'd_26' => $days[26],
				'd_27' => $days[27],
				'd_28' => $days[28],
				'd_29' => $days[29],
				'd_30' => $days[30],
				'd_31' => $days[31],
				'd_1' => $days[1],
				'd_2' => $days[2],
				'd_3' => $days[3],
				'd_4' => $days[4],
				'd_5' => $days[5],
				'd_6' => $days[6],
				'd_7' => $days[7],
				'd_8' => $days[8],
				'd_9' => $days[9],
				'd_10' => $days[10],
				'd_11' => $days[11],
				'd_12' => $days[12],
				'd_13' => $days[13],
				'd_14' => $days[14],
				'd_15' => $days[15],
				'd_16' => $days[16],
				'd_17' => $days[17],
				'd_18' => $days[18],
				'd_19' => $days[19],
				'd_20' => $days[20]
			]);

			if ($DutyAssignments->save($duty_assignment) === FALSE) {
				Log::error($duty_assignment->errors());
				return FALSE;
			}
		}
		else
		{
			Log::error("保存するための日程表データが見つかりません。[p_id=".$personnel->p_id."]");
			return FALSE;
		}

		return TRUE;
	}

	/**
	 * 日程表作成時の情報を保存
	 *
	 * @return boolean
	 */
	private function updateDutyEnv()
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$duty_env = $DutyEnvs->find()->where([
			'de_year_month' => $this->duty_year_month
		])->first();

		$duty_env = $DutyEnvs->patchEntity($duty_env, [
			'status' => DE_STATUS_BUILD,
			'start_team' => $this->duty_team_id,
			'start_fire_day' => $this->duty_fire_date
		]);

		if ($DutyEnvs->save($duty_env) === FALSE) {
			Log::error($duty_env->errors());
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * 勤務の詳細データを登録
	 *
	 * @return boolean
	 */
	private function createDutyWork()
	{
		$DutyWorks = TableRegistry::get('DutyWorks');

		//$DutyWorks->query('TRUNCATE duty_works');

		$DutyWorks->connection()->begin();

		// 更新時は一旦削除
		$DutyWorks->deleteAll([
			'dw_year_month' => $this->duty_year_month
		]);

		if (count($this->dat_items) > 0) {
			foreach ($this->dat_items as $p_id => $ddd) {
				$ts = $this->start_ts;
				for ($i=0; $i<$this->total_day; $i++) {
					if (isset($ddd[$ts]))
					{
						foreach ($ddd[$ts] as $d)
						{
							$task_type = 0;
							$task_id = '';
							if ($d['_type'] === 'task_month') {
								$task_type = DD_TYPE_TMM;
								$task_id = $d['tm_id'];
							} else if ($d['_type'] === 'task') {
								$task_type = DD_TYPE_TM;
								$task_id = $d['t_id'];
							}

							$duty_work = $DutyWorks->newEntity([
								'dw_year_month' => $this->duty_year_month,
								'dw_date' => date("Y-m-d", $ts),
								'p_id' => $p_id,
								'task_type' => $task_type,
								'task_id' => $task_id,
								'start_date' => isset($d['start_date'])?$d['start_date']:NULL,
								'end_date' => isset($d['end_date'])?$d['end_date']:NULL,
								'duty_type' => $d['duty_type'],
								'start_time' => isset($d['start_time'])?$d['start_time']:'',
								'end_time' => isset($d['end_time'])?$d['end_time']:'',
								'work_hours' => isset($d['work_hours'])?$d['work_hours']:0,
								'night_work_hours' => isset($d['night_hours'])?$d['night_hours']:0,
								'meal_allowance' => isset($d['meal_allowance'])?$d['meal_allowance']:0
							]);

							if ($DutyWorks->save($duty_work) === FALSE) {
								$DutyWorks->connection()->rollback();
								Log::error($duty_work->errors());
								return FALSE;
							}
						}
					}
					$ts += 86400;
				}
			}
		}

		$DutyWorks->connection()->commit();

		return TRUE;
	}

	/*
	 * 指定した勤務コードが設定されているかチェックする
	 */
	private function checkDuty($p_id, $ts, $duty_type)
	{
		if (isset($this->dat_items[$p_id][$ts])) {
			foreach ($this->dat_items[$p_id][$ts] as $d)
			{
				if ($d['duty_type'] == $duty_type) {
					return TRUE;
				}
			}
		}

		return false;
	}

	private function WRITE_DEBUG_LOG($message)
	{
		if ($this->DEBUG_OPPTION)
		{
			Log::debug($message);
		}
	}
}

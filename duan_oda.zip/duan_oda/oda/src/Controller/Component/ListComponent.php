<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
class ListComponent extends Component{

    /**
     * 連想配列から指定した項目をキーとしたリストにする
     *
     * @datas 連想配列
     * @key 連想配列の要素名
     * @return リスト
     */
    static function createList(array $datas, $key) {
        $result = array();
        foreach($datas as $data) {
            $result[$data[$key]] = $data;
        }
        
        return $result;
    }
}
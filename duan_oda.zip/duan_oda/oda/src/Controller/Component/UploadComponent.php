<?php
namespace App\Controller\Component;

use Cake\Controller\Component;

class UploadComponent extends Component
{
	public $request;
	public $response;
	public $session;
	public $uploadname = 'file';
	protected $errorMessage;

	public function initialize(array $config)
	{
		$controller = $this->_registry->getController();
//		$this->eventManager($controller->eventManager());
        $this->request = $controller->request;
//		$this->response = $controller->response;
//		$this->session = $controller->request->session();
    }

	public function isError()
	{
		if (isset($this->request->data[$this->uploadname]['error']))
		{
			switch ($this->request->data[$this->uploadname]['error'])
			{
				case UPLOAD_ERR_OK:
					return FALSE;
				case UPLOAD_ERR_INI_SIZE:
					$this->errorMessage = 'アップロードされたファイルは、php.ini の upload_max_filesize ディレクティブの値を超えています。';
					break;
			}
		}
		return TRUE;
	}

	public function getFile($name)
	{
		$upload_file = TMP . $name . '_' . date("YmdHis") . '.csv';

		if (move_uploaded_file($this->request->data[$this->uploadname]['tmp_name'], $upload_file))
		{
			return $upload_file;
		}
		return FALSE;
	}

	public function getErrorMessage()
	{
		return $this->errorMessage;
	}
}
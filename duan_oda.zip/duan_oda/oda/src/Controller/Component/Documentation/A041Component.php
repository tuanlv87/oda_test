<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A041 勤務要員集計表の作成
 */
class A041Component extends ExcelComponent{

    protected $documentType = "A041";
    protected $templateType = "A041";

    /*
     * A041 勤務要員集計表を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        $dutyAssignmentDatas = $dutyAssignments->find("all")
                                               ->hydrate(false)
                                               ->join(['table' => 'personnels',
                                                       'alias' => 'Personnels',
                                                       'type'  => 'INNER',
                                                       'conditions' => [
                                                       'DutyAssignments.p_id = Personnels.p_id'
                                                      ]])
                                               ->select(["DutyAssignments.da_year_month"
                                                        ,"DutyAssignments.gender"
                                                        ,"DutyAssignments.title_code"
                                                        ,"DutyAssignments.d_21"
                                                        ,"DutyAssignments.d_22"
                                                        ,"DutyAssignments.d_23"
                                                        ,"DutyAssignments.d_24"
                                                        ,"DutyAssignments.d_25"
                                                        ,"DutyAssignments.d_26"
                                                        ,"DutyAssignments.d_27"
                                                        ,"DutyAssignments.d_28"
                                                        ,"DutyAssignments.d_29"
                                                        ,"DutyAssignments.d_30"
                                                        ,"DutyAssignments.d_31"
                                                        ,"DutyAssignments.d_1"
                                                        ,"DutyAssignments.d_2"
                                                        ,"DutyAssignments.d_3"
                                                        ,"DutyAssignments.d_4"
                                                        ,"DutyAssignments.d_5"
                                                        ,"DutyAssignments.d_6"
                                                        ,"DutyAssignments.d_7"
                                                        ,"DutyAssignments.d_8"
                                                        ,"DutyAssignments.d_9"
                                                        ,"DutyAssignments.d_10"
                                                        ,"DutyAssignments.d_11"
                                                        ,"DutyAssignments.d_12"
                                                        ,"DutyAssignments.d_13"
                                                        ,"DutyAssignments.d_14"
                                                        ,"DutyAssignments.d_15"
                                                        ,"DutyAssignments.d_16"
                                                        ,"DutyAssignments.d_17"
                                                        ,"DutyAssignments.d_18"
                                                        ,"DutyAssignments.d_19"
                                                        ,"DutyAssignments.d_20"
                                                        ,"Personnels.license_01"
                                                        ,"Personnels.license_02"
                                                        ,"Personnels.license_03"
                                                        ,"Personnels.license_04"
                                                        ,"Personnels.license_05"
                                                        ,"Personnels.license_06"
                                                        ,"Personnels.license_07"
                                                        ,"Personnels.license_08"
                                                        ,"Personnels.license_09"
                                                        ,"Personnels.license_10"
                                                        ])
                                               ->where(["da_year_month" => $req["ymTarget"]])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // DNがD,NとなっているためDNに置換する
        foreach($dutyAssignmentDatas as &$dutyAssignmentData) {
            for($i = 1; $i <= 31; $i ++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        $result = [];

        $result["dutyAssignmentDatas"] = $dutyAssignmentDatas;

        // 日ごとにデータを集計する
        for ($i = 1; $i <= 31; $i++) {
            // 初期化
            $result[$i] = [];
            $result[$i]["MGR_D"]    = 0;
            $result[$i]["MGR_N"]    = 0;
            $result[$i]["MGR_DN"]   = 0;
            $result[$i]["M-S_D"]    = 0;
            $result[$i]["M-S_N"]    = 0;
            $result[$i]["M-S_DN"]   = 0;
            $result[$i]["LDR_D"]    = 0;
            $result[$i]["LDR_N"]    = 0;
            $result[$i]["LDR_DN"]   = 0;
            $result[$i]["L-S_D"]    = 0;
            $result[$i]["L-S_N"]    = 0;
            $result[$i]["L-S_DN"]   = 0;
            $result[$i]["CHF_D"]    = 0;
            $result[$i]["CHF_N"]    = 0;
            $result[$i]["CHF_DN"]   = 0;
            $result[$i]["C-S_D"]    = 0;
            $result[$i]["C-S_N"]    = 0;
            $result[$i]["C-S_DN"]   = 0;
            $result[$i]["D"]        = 0;
            $result[$i]["N"]        = 0;
            $result[$i]["DN"]       = 0;
            $result[$i]["HD5"]      = 0;
            $result[$i]["HD1"]      = 0;
            $result[$i]["WOMAN_D"]  = 0;
            $result[$i]["WOMAN_N"]  = 0;
            $result[$i]["WOMAN_DN"] = 0;
            $result[$i]["FK_D"]     = 0;
            $result[$i]["FK_N"]     = 0;
            $result[$i]["FK_DN"]    = 0;
            $result[$i]["KIKAN_D"]  = 0;
            $result[$i]["KIKAN_N"]  = 0;
            $result[$i]["KIKAN_DN"] = 0;
            $result[$i]["Q01_D"]    = 0;
            $result[$i]["Q01_N"]    = 0;
            $result[$i]["Q01_DN"]   = 0;
            $result[$i]["Q02_D"]    = 0;
            $result[$i]["Q02_N"]    = 0;
            $result[$i]["Q02_DN"]   = 0;
            $result[$i]["Q03_D"]    = 0;
            $result[$i]["Q03_N"]    = 0;
            $result[$i]["Q03_DN"]   = 0;
            $result[$i]["Q04_D"]    = 0;
            $result[$i]["Q04_N"]    = 0;
            $result[$i]["Q04_DN"]   = 0;
            $result[$i]["Q05_D"]    = 0;
            $result[$i]["Q05_N"]    = 0;
            $result[$i]["Q05_DN"]   = 0;
            $result[$i]["REMARK"]   = 0;


            foreach($dutyAssignmentDatas as $row) {

                $workArray = explode(",", $row["d_{$i}"]);
                $personal = $row["Personnels"];

                // D勤、N勤などの集計
                foreach ($workArray as $work) {
                    switch ($work) {
                        case "D":
                            $result[$i]["D"]++;

                            // 役職者数の集計
                            switch ($row["title_code"]) {
                                // マネージャ
                                case "MGR" :
                                    $result[$i]["MGR_D"]++;
                                    break;
                                case "MGR-S" :
                                    $result[$i]["M-S_D"]++;
                                    break;
                                case "LDR" :
                                    $result[$i]["LDR_D"]++;
                                    break;
                                case "LDR-S" :
                                    $result[$i]["L-S_D"]++;
                                    break;
                                case "CHF" :
                                    $result[$i]["CHF_D"]++;
                                    break;
                                case "CHF-S" :
                                    $result[$i]["C-S_D"]++;
                                    break;
                                default:
                                    // なにもしない
                            }

                            // 女性の集計
                            if ($row["gender"] == 2) {
                                $result[$i]["WOMAN_D"]++;
                            }
                            // 機関の集計
                            if ($personal["license_07"] == 2) {
                                $result[$i]["KIKAN_D"]++;
                            }

                            // 資格情報の集計
                            for ($j = 1; $j <= 5; $j++) {
                                $key1 = "license_" . sprintf('%02d', $j);
                                $key2 = "Q" . sprintf('%02d', $j) . "_D";

                                if ($personal[$key1] != 0) {
                                    $result[$i][$key2] ++;
                                }
                            }

                            break;
                        case "N":
                            $result[$i]["N"]++;
                            // 役職者数の集計
                            switch ($row["title_code"]) {
                                // マネージャ
                                case "MGR" :
                                    $result[$i]["MGR_N"]++;
                                    break;
                                case "MGR-S" :
                                    $result[$i]["M-S_N"]++;
                                    break;
                                case "LDR" :
                                    $result[$i]["LDR_N"]++;
                                    break;
                                case "LDR-S" :
                                    $result[$i]["L-S_N"]++;
                                    break;
                                case "CHF" :
                                    $result[$i]["CHF_N"]++;
                                    break;
                                case "CHF-S" :
                                    $result[$i]["C-S_N"]++;
                                    break;
                                default:
                                    // なにもしない
                            }

                            // 女性の集計
                            if ($row["gender"] == 2) {
                                $result[$i]["WOMAN_N"]++;
                            }
                            // 機関の集計
                            if ($personal["license_07"] == 2) {
                                $result[$i]["KIKAN_N"]++;
                            }

                            // 資格情報の集計
                            for ($j = 1; $j <= 5; $j++) {
                                $key1 = "license_" . sprintf('%02d', $j);
                                $key2 = "Q" . sprintf('%02d', $j) . "_N";

                                if ($personal[$key1] != 0) {
                                    $result[$i][$key2] ++;
                                }
                            }
                            break;
                        case "DN":
                            $result[$i]["DN"]++;
                            switch ($row["title_code"]) {
                                // マネージャ
                                case "MGR" :
                                    $result[$i]["MGR_DN"]++;
                                    break;
                                case "MGR-S" :
                                    $result[$i]["M-S_DN"]++;
                                    break;
                                case "LDR" :
                                    $result[$i]["LDR_DN"]++;
                                    break;
                                case "LDR-S" :
                                    $result[$i]["L-S_DN"]++;
                                    break;
                                case "CHF" :
                                    $result[$i]["CHF_DN"]++;
                                    break;
                                case "CHF-S" :
                                    $result[$i]["C-S_DN"]++;
                                    break;
                                default:
                                    // なにもしない
                            }

                            // 女性の集計
                            if ($row["gender"] == 2) {
                                $result[$i]["WOMAN_DN"]++;
                            }
                            // 機関の集計
                            if ($personal["license_07"] == 2) {
                                $result[$i]["KIKAN_DN"]++;
                            }

                            // 資格情報の集計
                            for ($j = 1; $j <= 5; $j++) {
                                $key1 = "license_" . sprintf('%02d', $j);
                                $key2 = "Q" . sprintf('%02d', $j) . "_DN";

                                if ($personal[$key1] != 0) {
                                    $result[$i][$key2] ++;
                                }
                            }
                            break;
                        case "HD5":
                            $result[$i]["HD5"]++;
                            break;
                        case "HD1":
                            $result[$i]["HD1"]++;
                            break;
                        case "FKD":
                            if (!in_array("FKN", $workArray)) {
                                $result[$i]["FK_D"]++;
                            }
                            break;
                        case "FKN":
                            if (!in_array("FKD", $workArray)) {
                                $result[$i]["FK_N"]++;
                            } else {
                                $result[$i]["FK_DN"]++;
                            }
                            break;
                    }
                }
            }
        }


        return $result;
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {

        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ymTarget = $req["ymTarget"];
        $ymStart = date("Ym", strtotime($req["ymStart"] . "01"));

        ///////////////////////////////////////////////////////////////////////
        // 行の数をカレンダーに合わせて動的にする
        ///////////////////////////////////////////////////////////////////////
        // 不要な日の行を削除
        $endDay = date("t", strtotime($ymStart . "01"));
        if ((31 - $endDay) > 0) {
            $this->sheet->removeRow(39 - 3 * (31 - $endDay) , 3 * (31 - $endDay));
        }

        ///////////////////////////////////////////////////////////////////////
        // 日ごとに集計した結果を出力する
        ///////////////////////////////////////////////////////////////////////
        $row = 8;
        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );

        for ($i = 0; $i < 31; $i++) {
            // 曜日を求めて出力する
            $w = date("w" , strtotime($ymStart . "21" . " +{$i} days"));
            $this->sheet->getCellByColumnAndRow(1, $row + 1)->setValue($weekday[$w]);

            // 21日はじまりのため
            $yobi = (20 + $i) % 31 + 1;

            if ($yobi > $endDay) {
                continue;
            }

            // 21日の場合は月を表示する
            if ($yobi == 21) {
                $m = date("n" , strtotime($ymStart . "21" . " +{$i} days"));
                $this->sheet->getCellByColumnAndRow(0, $row)->setValue($m);
            }

            // 1日の場合は月とタイトルを表示する
            if ($yobi == 1) {
                $m = date("n" , strtotime($ymStart . "21" . " +{$i} days"));
                $this->sheet->getCellByColumnAndRow(0, $row)->setValue($m);
                $this->sheet->getCellByColumnAndRow(10, 1)->setValue($m . "月度");
            }


            // MGRの集計結果を出力
            $this->sheet->getCellByColumnAndRow(3, $row)->setValue($data[$yobi]["MGR_D"]);
            $this->sheet->getCellByColumnAndRow(3, $row + 1)->setValue($data[$yobi]["MGR_N"]);
            $this->sheet->getCellByColumnAndRow(3, $row + 2)->setValue($data[$yobi]["MGR_DN"]);
            // MGR-Sの集計結果を出力
            $this->sheet->getCellByColumnAndRow(4, $row)->setValue($data[$yobi]["M-S_D"]);
            $this->sheet->getCellByColumnAndRow(4, $row + 1)->setValue($data[$yobi]["M-S_N"]);
            $this->sheet->getCellByColumnAndRow(4, $row + 2)->setValue($data[$yobi]["M-S_DN"]);
            // LDRの集計結果を出力
            $this->sheet->getCellByColumnAndRow(5, $row)->setValue($data[$yobi]["LDR_D"]);
            $this->sheet->getCellByColumnAndRow(5, $row + 1)->setValue($data[$yobi]["LDR_N"]);
            $this->sheet->getCellByColumnAndRow(5, $row + 2)->setValue($data[$yobi]["LDR_DN"]);
            // LDR-Sの集計結果を出力
            $this->sheet->getCellByColumnAndRow(6, $row)->setValue($data[$yobi]["L-S_D"]);
            $this->sheet->getCellByColumnAndRow(6, $row + 1)->setValue($data[$yobi]["L-S_N"]);
            $this->sheet->getCellByColumnAndRow(6, $row + 2)->setValue($data[$yobi]["L-S_DN"]);
            // CHFの集計結果を出力
            $this->sheet->getCellByColumnAndRow(7, $row)->setValue($data[$yobi]["CHF_D"]);
            $this->sheet->getCellByColumnAndRow(7, $row + 1)->setValue($data[$yobi]["CHF_N"]);
            $this->sheet->getCellByColumnAndRow(7, $row + 2)->setValue($data[$yobi]["CHF_DN"]);
            // CGF-Sの集計結果を出力
            $this->sheet->getCellByColumnAndRow(8, $row)->setValue($data[$yobi]["C-S_D"]);
            $this->sheet->getCellByColumnAndRow(8, $row + 1)->setValue($data[$yobi]["C-S_N"]);
            $this->sheet->getCellByColumnAndRow(8, $row + 2)->setValue($data[$yobi]["C-S_DN"]);
            // Dの集計結果を出力
            $this->sheet->getCellByColumnAndRow(9, $row)->setValue($data[$yobi]["D"]);
            // Nの集計結果を出力
            $this->sheet->getCellByColumnAndRow(9, $row + 1)->setValue($data[$yobi]["N"]);
            // DNの集計結果を出力
            $this->sheet->getCellByColumnAndRow(9, $row + 2)->setValue($data[$yobi]["DN"]);
            // 公休の集計結果を出力
            $this->sheet->getCellByColumnAndRow(10, $row)->setValue($data[$yobi]["HD5"]);
            $this->sheet->getCellByColumnAndRow(10, $row + 1)->setValue("-");
            $this->sheet->getCellByColumnAndRow(10, $row + 2)->setValue("-");
            // 指定の集計結果を出力
            $this->sheet->getCellByColumnAndRow(11, $row)->setValue($data[$yobi]["HD1"]);
            $this->sheet->getCellByColumnAndRow(11, $row + 1)->setValue("-");
            $this->sheet->getCellByColumnAndRow(11, $row + 2)->setValue("-");
            // 女性の集計結果を出力
            $this->sheet->getCellByColumnAndRow(12, $row)->setValue($data[$yobi]["WOMAN_D"]);
            $this->sheet->getCellByColumnAndRow(12, $row + 1)->setValue($data[$yobi]["WOMAN_N"]);
            $this->sheet->getCellByColumnAndRow(12, $row + 2)->setValue($data[$yobi]["WOMAN_DN"]);
            // 兼務の集計結果を出力
            $this->sheet->getCellByColumnAndRow(13, $row)->setValue($data[$yobi]["FK_D"]);
            $this->sheet->getCellByColumnAndRow(13, $row + 1)->setValue($data[$yobi]["FK_N"]);
            $this->sheet->getCellByColumnAndRow(13, $row + 2)->setValue($data[$yobi]["FK_DN"]);
            // 機関
            $this->sheet->getCellByColumnAndRow(14, $row)->setValue($data[$yobi]["KIKAN_D"]);
            $this->sheet->getCellByColumnAndRow(14, $row + 1)->setValue($data[$yobi]["KIKAN_N"]);
            $this->sheet->getCellByColumnAndRow(14, $row + 2)->setValue($data[$yobi]["KIKAN_DN"]);
            // Q01の集計結果を出力
            $this->sheet->getCellByColumnAndRow(15, $row)->setValue($data[$yobi]["Q01_D"]);
            $this->sheet->getCellByColumnAndRow(15, $row + 1)->setValue($data[$yobi]["Q01_N"]);
            $this->sheet->getCellByColumnAndRow(15, $row + 2)->setValue($data[$yobi]["Q01_DN"]);
            // Q02の集計結果を出力
            $this->sheet->getCellByColumnAndRow(16, $row)->setValue($data[$yobi]["Q02_D"]);
            $this->sheet->getCellByColumnAndRow(16, $row + 1)->setValue($data[$yobi]["Q02_N"]);
            $this->sheet->getCellByColumnAndRow(16, $row + 2)->setValue($data[$yobi]["Q02_DN"]);
            // Q03の集計結果を出力
            $this->sheet->getCellByColumnAndRow(17, $row)->setValue($data[$yobi]["Q03_D"]);
            $this->sheet->getCellByColumnAndRow(17, $row + 1)->setValue($data[$yobi]["Q03_N"]);
            $this->sheet->getCellByColumnAndRow(17, $row + 2)->setValue($data[$yobi]["Q03_DN"]);
            // Q04の集計結果を出力
            $this->sheet->getCellByColumnAndRow(18, $row)->setValue($data[$yobi]["Q04_D"]);
            $this->sheet->getCellByColumnAndRow(18, $row + 1)->setValue($data[$yobi]["Q04_N"]);
            $this->sheet->getCellByColumnAndRow(18, $row + 2)->setValue($data[$yobi]["Q04_DN"]);
            // Q05の集計結果を出力
            $this->sheet->getCellByColumnAndRow(19, $row)->setValue($data[$yobi]["Q05_D"]);
            $this->sheet->getCellByColumnAndRow(19, $row + 1)->setValue($data[$yobi]["Q05_N"]);
            $this->sheet->getCellByColumnAndRow(19, $row + 2)->setValue($data[$yobi]["Q05_DN"]);

            $row += 3;
        }

        return true;
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * S010 勤務表ログリストの作成
 */
class S010Component extends ExcelComponent{

    protected $documentType = "S010";
    protected $templateType = "S010";

    /*
     * S010 勤務表ログリストを作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {

        switch($req["type"]) {
            case "all":
                $dutyLogs = TableRegistry::get('duty_logs');
                $dutyLogDatas = $dutyLogs->find()
                                         ->where(["dl_year_month" => $req["ymTarget"]])
                                         ->order(['log_id' => 'ASC', 'date' => 'ASC', 'change_date' => 'ASC'])
                                         ->toArray();
                break;

            case "date":
                $day = date("Y") . "/" . $req["Date_Month"] . "/". $req["Date_Day"];
                $dutyLogs = TableRegistry::get('duty_logs');
                $dutyLogDatas = $dutyLogs->find()
                                         ->where(['modified >=' => $day, "dl_year_month" => $req["ymTarget"]])
                                         ->order(['log_id' => 'ASC', 'date' => 'ASC', 'change_date' => 'ASC'])
                                         ->toArray();
                break;

            default;
                $error = $this->errorMessages["E001"];
                return false;
        }

        // 出力対象データがない場合はエラーとする
        if (count($dutyLogDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }


        return array("dutyLogDatas" => $dutyLogDatas);
    }

    /*
     * EXCELへの書き込み
     * 
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $dutyLogDatas = $data["dutyLogDatas"];

        // タイトル部分の表示
        $month = date('n', strtotime($req["ymTarget"] . "01"));
        $this->sheet->getCell("K2")->setValue("ログリスト {$month}月度");

        $startRow = 5;

        $rowCount = count($dutyLogDatas);

        // 行を動的追加する
        if ($rowCount > 2) {
            // 表示する行数に合わせて行をコピーする
            $this->copy($this->sheet, 5, 5, 27, 6, $rowCount - 1);

            // セルの結合と罫線の削除を行う
            $row = $startRow;
            for($i = 1; $i <= $rowCount; $i++) {
                // 上の罫線を削除
                if ($i != 1) {
                    for ($j = 2; $j < 25; $j++) {
                        $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_NONE);
                    }
                }

                // 下の罫線を削除
                if ($i != $rowCount) {
                    for ($j = 2; $j < 25; $j++) {
                        $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getBottom()->setBorderStyle(\PHPExcel_Style_Border::BORDER_NONE);
                    }
                }

                if ($i != 1) {
                    $this->sheet->mergeCells("C{$row}:E{$row}");
                    $this->sheet->mergeCells("F{$row}:G{$row}");
                    $this->sheet->mergeCells("H{$row}:J{$row}");
                    $this->sheet->mergeCells("K{$row}:O{$row}");
                    $this->sheet->mergeCells("P{$row}:V{$row}");
                    $this->sheet->mergeCells("W{$row}:Y{$row}");
                }

                $row++;
            }

            $row = $startRow;
            $currentLogNo = NULL;
            $currentDate = NULL;
            foreach($dutyLogDatas as $dutyLogData) {
                if ($currentDate == NULL || ($currentLogNo !== $dutyLogData["log_id"] || $currentDate != $dutyLogData["date"])) {
                    $currentDate = $dutyLogData["date"];
                    $this->sheet->setCellValue("F{$row}", date("n/j", strtotime($currentDate)));
                }

                if ($currentLogNo == NULL || $currentLogNo !== $dutyLogData["log_id"]) {
                    $currentLogNo = (int)$dutyLogData["log_id"];
                    $this->sheet->setCellValue("C{$row}", $currentLogNo);

                    for ($j = 2; $j < 25; $j++) {
                        $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                    }
                }

                // 社員番号
                $this->sheet->setCellValue("H{$row}", $dutyLogData["p_id"]);

                // 社員名
                $this->sheet->setCellValue("K{$row}", $dutyLogData["name"]);

                // DNはD,Nで登録されているためDNに置換する
                $dutyLogData["before_type"] = preg_replace("/D,N$/", "DN" , $dutyLogData["before_type"]);
                $dutyLogData["before_type"] = str_replace("D,N,", "DN," , $dutyLogData["before_type"]);

                $dutyLogData["after_type"] = preg_replace("/D,N$/", "DN" , $dutyLogData["after_type"]);
                $dutyLogData["after_type"] = str_replace("D,N,", "DN," , $dutyLogData["after_type"]);

                // 変更前コード→変更後コード
                $val = (strlen($dutyLogData["before_type"]) > 0) ? $dutyLogData["before_type"] : "□";
                $val .= "→";
                $val .= (strlen($dutyLogData["after_type"]) > 0) ? $dutyLogData["after_type"] : "□";
                $this->sheet->setCellValue("P{$row}", $val);

                // 更新日時
                $this->sheet->setCellValue("W{$row}", date("n/j h:i", strtotime($dutyLogData["modified"])));
                $row++;
            }
        }

        

        return true;
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * B010 宿日直日程表の作成
 */
class B010Component extends ExcelComponent{

    protected $documentType = "B010";
    protected $templateType = "B010";

    /*
     * B010 宿日直日程表を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $dutyAssignments = TableRegistry::get('DutyAssignments');
        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->where(["da_year_month" => $req["ymTarget"]])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // DNがD,NとなっているためDNに置換する
        foreach($dutyAssignmentDatas as &$dutyAssignmentData) {
            for($i = 1; $i <= 31; $i ++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        return ["dutyAssignmentDatas" => $dutyAssignmentDatas];
    }

    /*
     * EXCELへの書き込み
     * 
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ymStart = $req["ymStart"];

        // タイトル設定
        $val = date("Y月n月", strtotime($req["ymTarget"] . "01")) . "度の宿日直勤務表";
        $this->sheet->getCellByColumnAndRow(10, 1)->setValue($val);

        // 不要な日の列を削除
        $endDay = date("t", strtotime($ymStart . "01"));
        if ((31 - $endDay) > 0) {
            $this->sheet->removeRow($endDay - 15, 31 - $endDay);
        }

        // 曜日設定
        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
        for ($i = 0; $i < $endDay; $i++) {
            $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));
            $day = date("d" , strtotime($ymStart . "21" . " +{$i} days"));

            if ($day == 21 || $day == 1) {
                $month = date("n" , strtotime($ymStart . "21" . " +{$i} days"));
                $this->sheet->getCellByColumnAndRow(2, $i + 5)->setValue($month);
            }

            $this->sheet->getCellByColumnAndRow(4, $i + 5)->setValue($weekday[$yobi]);
        }

        ////////////////////////////////////////////////////////////////////////
        // 宿直・日直の設定
        ////////////////////////////////////////////////////////////////////////
        foreach ($dutyAssignmentDatas as $data) {
            $row = 5;
            for ($i = 0; $i < 31; $i++) {
                // 21日はじまりのため
                $day = (20 + $i) % 31 + 1;

                if ($day > $endDay) {
                    continue;
                }

                $works = explode(",", $data["d_{$day}"]);

                // 日直かどうか
                if (in_array("DW", $works)) {
                    $this->sheet->getCellByColumnAndRow(5, $row)->setValue($data["name"]);
                } else if (in_array("NW", $works)) {
                    $this->sheet->getCellByColumnAndRow(14, $row)->setValue($data["name"]);
                }

                $row++;
            }
        }

        return true;
    }
}

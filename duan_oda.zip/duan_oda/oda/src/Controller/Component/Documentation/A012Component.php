<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A012 勤務日程表-3の作成
 */
class A012Component extends ExcelComponent{

    protected $documentType = "A012";
    protected $templateType = "A012";

    var $components = array('List', 'Documentation/A010');
    /*
     * A012 勤務日程表-3を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        // A010のメソッドを呼ぶ
        $this->{"Documentation/A010"}->sheet = $this->sheet;

        if (!$this->{"Documentation/A010"}->_writeExcel($data, $req, $error)) {
            return false;
        }

        // タイトル行の表示
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];
        $ymTarget = $dutyAssignmentDatas[0]["da_year_month"];
        $this->sheet->setCellValue("N1", date('Y年n月', strtotime($req["ymTarget"] .'01')) ."度の日程表(クルー別)");

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        ///////////////////////////////////////////////////////////////////////
        // 出力するデータの取得
        ///////////////////////////////////////////////////////////////////////
        $taskMonths = TableRegistry::get('TaskMonths');
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        // 月次タスクマスターデータ
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"]])
                                     ->order(["show_mark" => "ASC"])
                                     ->toArray();

        // tm_idをキーとしたリストにする
        $taskMonthList = $this->List->createList($taskMonthDatas, 'tm_id');

        // 画面からのリクエストデータを元にwhere句を設定する
        $where = [];
        $where["da_year_month"] = $req["ymTarget"];

        switch($req["type"]) {
            case "ALL":
                // すべての場合は条件無し
                break;
            case "A":
            case "B":
            case "C":
                $where["team_id"] = $req["type"];
                break;
            case "OPTION":
                $where["team_id"] = $req["team_id"];
                if (strlen($req["crew_id"]) > 0)
                {
                    $where["crew_id"] = $req["crew_id"];
                }
                else
                {
                    $where[] = "crew_id is null";
                }
                break;
            default:
                throw new \Exception();
        }

        // チームID指定
        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->where($where)
                                               ->order(["document_order" => "ASC"])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        return array("taskMonthDatas" => $taskMonthDatas, "taskMonthList" => $taskMonthList, "dutyAssignmentDatas" => $dutyAssignmentDatas);
    }
}

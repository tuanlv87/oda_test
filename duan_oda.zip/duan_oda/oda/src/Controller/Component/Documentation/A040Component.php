<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A040 勤務時間集計表の作成
 */
class A040Component extends ExcelComponent{

    protected $documentType = "A040";
    protected $templateType = "A040";

    /*
     * A040 勤務時間集計表を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->where(["da_year_month" => $req["ymTarget"]])
                                               ->order(["document_order" => "ASC"])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // DNはD,Nで登録されているためDNに置換する
        foreach($dutyAssignmentDatas as &$dutyAssignmentData) {
            for ($i = 1; $i <= 31; $i++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        return array("dutyAssignmentDatas" => $dutyAssignmentDatas);
    }

    /*
     * EXCELへの書き込み
     * 
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {

        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ym = $dutyAssignmentDatas[0]["da_year_month"];
        $val = date("n月度", strtotime($ym . "01"));
        $this->sheet->setCellValue("I1", $val);

        $row = 9;

        // 表示する行数に合わせて行をコピーする
        $this->copy($this->sheet, $row, $row, 28, $row+1, count($dutyAssignmentDatas) - 1);

        // 社員ごとの勤務表を設定する
        foreach($dutyAssignmentDatas as $data) {
            // 勤務内容を集計する
            $dutyCalcs = $this->getCalcDuty($data);

            // 社員番号
            $this->sheet->setCellValue("A{$row}", $data["p_id"]);
            // G-ID
            $val = (strlen($data["crew_id"]) > 0) ? $data["team_id"] . "-" . $data["crew_id"] : $data["team_id"];
            $this->sheet->setCellValue("B{$row}", $val);
            // 氏名
            $this->sheet->setCellValue("C{$row}", $data["name"]);
            // 役職
            $this->sheet->setCellValue("D{$row}", $this->titleList[$data["title_code"]]["title_display"]);
            // 勤務時間（D）
            $this->sheet->setCellValue("E{$row}", $data["d_duty"] * $this->working_hours["D"]);
            // 勤務時間（N）
            $this->sheet->setCellValue("F{$row}", $data["n_duty"] * $this->working_hours["N"]);
            // 勤務時間（DN）
            $this->sheet->setCellValue("G{$row}", $data["dn_duty"] * $this->working_hours["DN"]);
            // 深夜時間（DN）
            $this->sheet->setCellValue("H{$row}", $data["dn_duty"] * $this->night_working_hours["DN"]);
            // 深夜時間（N）
            $this->sheet->setCellValue("I{$row}", $data["n_duty"] * $this->night_working_hours["N"]);
            // 臨時警備（臨警）
            $this->sheet->setCellValue("J{$row}", $data["extra_work_hours"]);
            // 臨時警備（深夜）
            $this->sheet->setCellValue("K{$row}", $data["extra_night_work_hours"]);
            // 総時間数（勤務）
            $this->sheet->setCellValue("L{$row}", $data["work_hours"]);
            // 総時間数（深夜）
            $this->sheet->setCellValue("M{$row}", $data["night_work_hours"]);
            // 総時間数（超勤25）
            $this->sheet->setCellValue("N{$row}", $data["overtime25"]);
            // 総時間数（超勤35）
            $this->sheet->setCellValue("O{$row}", $data["overtime35"]);
            // 休暇（休）
            $this->sheet->setCellValue("P{$row}", isset($dutyCalcs["HD2"]) ? $dutyCalcs["HD2"] : 0);
            // 休暇（特）
            $this->sheet->setCellValue("Q{$row}", isset($dutyCalcs["HD3"]) ? $dutyCalcs["HD3"] : 0);
            // 休暇（臨）
            $this->sheet->setCellValue("R{$row}", isset($dutyCalcs["HD4"]) ? $dutyCalcs["HD4"] : 0);
            // 教育（OE）
            $val = $data["oj1_hours"] + $data["oj2_hours"] + $data["oj3_hours"];
            $this->sheet->setCellValue("S{$row}", $val);
            // 教育（NE）
            $val = $data["ne1_hours"] + $data["ne2_hours"] + $data["ne3_hours"] + $data["ne4_hours"];
            $this->sheet->setCellValue("T{$row}", $val);
            // 教育（FE）
            $val = $data["fe_hours"];
            $this->sheet->setCellValue("U{$row}", $val);
            // 教育（SE）
            $val = $data["se_hours"];
            $this->sheet->setCellValue("V{$row}", $val);
            // 教育（SE深）
            $val = $data["se_night_hours"];
            $this->sheet->setCellValue("W{$row}", $val);
            // その他（M）
            $val = $data["mt_hours"];
            $this->sheet->setCellValue("X{$row}", $val);
            // その他（SM）
            $val = $data["sm_hours"];
            $this->sheet->setCellValue("Y{$row}", $val);
            // その他（SM深）
            $val = $data["sm_night_hours"];
            $this->sheet->setCellValue("Z{$row}", $val);
            // 消防（兼務）
            $this->sheet->setCellValue("AA{$row}", $data["fire_plural"]);
            // 消防（発報）
            $this->sheet->setCellValue("AB{$row}", $data["fire_jippo"]);

            $row++;
        }


        return true;
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * B020 消防兼務・訓練日程表の作成
 */
class B020Component extends ExcelComponent{

    protected $documentType = "B020";
    protected $templateType = "B020";

    /*
     * B020 消防兼務・訓練日程表を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $dutyAssignments = TableRegistry::get('DutyAssignments');
        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->hydrate(false)
                                               ->join(['table' => 'personnels',
                                                       'alias' => 'Personnels',
                                                       'type'  => 'INNER',
                                                       'conditions' => [
                                                       'DutyAssignments.p_id = Personnels.p_id'
                                                      ]])
                                               ->select([
                                                         'DutyAssignments.da_year_month',
                                                         'DutyAssignments.p_id',
                                                         'DutyAssignments.name',
                                                         'DutyAssignments.team_id',
                                                         'DutyAssignments.crew_id',
                                                         'DutyAssignments.personnel_id',
                                                         'DutyAssignments.fire_plural',
                                                         'DutyAssignments.d_21',
                                                         'DutyAssignments.d_22',
                                                         'DutyAssignments.d_23',
                                                         'DutyAssignments.d_24',
                                                         'DutyAssignments.d_25',
                                                         'DutyAssignments.d_26',
                                                         'DutyAssignments.d_27',
                                                         'DutyAssignments.d_28',
                                                         'DutyAssignments.d_29',
                                                         'DutyAssignments.d_30',
                                                         'DutyAssignments.d_31',
                                                         'DutyAssignments.d_1',
                                                         'DutyAssignments.d_2',
                                                         'DutyAssignments.d_3',
                                                         'DutyAssignments.d_4',
                                                         'DutyAssignments.d_5',
                                                         'DutyAssignments.d_6',
                                                         'DutyAssignments.d_7',
                                                         'DutyAssignments.d_8',
                                                         'DutyAssignments.d_9',
                                                         'DutyAssignments.d_10',
                                                         'DutyAssignments.d_11',
                                                         'DutyAssignments.d_12',
                                                         'DutyAssignments.d_13',
                                                         'DutyAssignments.d_14',
                                                         'DutyAssignments.d_15',
                                                         'DutyAssignments.d_16',
                                                         'DutyAssignments.d_17',
                                                         'DutyAssignments.d_18',
                                                         'DutyAssignments.d_19',
                                                         'DutyAssignments.d_20',
                                                         'Personnels.license_07'
                                               ])
                                               ->where(["da_year_month" => $req["ymTarget"],
                                                    "OR" => [
                                                        ["d_1 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_1 )" , "FIND_IN_SET('FKN' ,d_1 )",
                                                        ["d_2 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_2 )" , "FIND_IN_SET('FKN' ,d_2 )",
                                                        ["d_3 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_3 )" , "FIND_IN_SET('FKN' ,d_3 )",
                                                        ["d_4 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_4 )" , "FIND_IN_SET('FKN' ,d_4 )",
                                                        ["d_5 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_5 )" , "FIND_IN_SET('FKN' ,d_5 )",
                                                        ["d_6 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_6 )" , "FIND_IN_SET('FKN' ,d_6 )",
                                                        ["d_7 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_7 )" , "FIND_IN_SET('FKN' ,d_7 )",
                                                        ["d_8 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_8 )" , "FIND_IN_SET('FKN' ,d_8 )",
                                                        ["d_9 like " => "%FE%"],  "FIND_IN_SET('FKD' ,d_9 )" , "FIND_IN_SET('FKN' ,d_9 )",
                                                        ["d_10 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_10)" , "FIND_IN_SET('FKN' ,d_10)",
                                                        ["d_11 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_11)" , "FIND_IN_SET('FKN' ,d_11)",
                                                        ["d_12 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_12)" , "FIND_IN_SET('FKN' ,d_12)",
                                                        ["d_13 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_13)" , "FIND_IN_SET('FKN' ,d_13)",
                                                        ["d_14 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_14)" , "FIND_IN_SET('FKN' ,d_14)",
                                                        ["d_15 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_15)" , "FIND_IN_SET('FKN' ,d_15)",
                                                        ["d_16 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_16)" , "FIND_IN_SET('FKN' ,d_16)",
                                                        ["d_17 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_17)" , "FIND_IN_SET('FKN' ,d_17)",
                                                        ["d_18 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_18)" , "FIND_IN_SET('FKN' ,d_18)",
                                                        ["d_19 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_19)" , "FIND_IN_SET('FKN' ,d_19)",
                                                        ["d_20 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_20)" , "FIND_IN_SET('FKN' ,d_20)",
                                                        ["d_21 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_21)" , "FIND_IN_SET('FKN' ,d_21)",
                                                        ["d_22 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_22)" , "FIND_IN_SET('FKN' ,d_22)",
                                                        ["d_23 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_23)" , "FIND_IN_SET('FKN' ,d_23)",
                                                        ["d_24 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_24)" , "FIND_IN_SET('FKN' ,d_24)",
                                                        ["d_25 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_25)" , "FIND_IN_SET('FKN' ,d_25)",
                                                        ["d_26 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_26)" , "FIND_IN_SET('FKN' ,d_26)",
                                                        ["d_27 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_27)" , "FIND_IN_SET('FKN' ,d_27)",
                                                        ["d_28 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_28)" , "FIND_IN_SET('FKN' ,d_28)",
                                                        ["d_29 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_29)" , "FIND_IN_SET('FKN' ,d_29)",
                                                        ["d_30 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_30)" , "FIND_IN_SET('FKN' ,d_30)",
                                                        ["d_31 like" => "%FE%"],  "FIND_IN_SET('FKD' ,d_31)" , "FIND_IN_SET('FKN' ,d_31)"
                                                    ]
                                                ])
                                               ->order(["DutyAssignments.document_order" => "ASC"])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // DNがD,NとなっているためDNに置換する
        foreach($dutyAssignmentDatas as &$dutyAssignmentData) {
            for($i = 1; $i <= 31; $i ++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        return ["dutyAssignmentDatas" => $dutyAssignmentDatas];
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ymStart = $req["ymStart"];

        // タイトル設定
        $val = date("Y月n月", strtotime($req["ymTarget"] . "01")) . "度の消防兼務・訓練日程表";
        $this->sheet->getCellByColumnAndRow(27, 1)->setValue($val);

        // 不要な日の列を削除
        $endDay = date("t", strtotime($ymStart . "01"));
        if ((31 - $endDay) > 0) {
            $this->sheet->removeColumnByIndex(27 - (31 - $endDay) * 2, (31 - $endDay) * 2);
        }

        // 曜日設定
        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
        for ($i = 0; $i < $endDay; $i++) {
            $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));

            $this->sheet->getCellByColumnAndRow($i * 2 + 5, 8)->setValue($weekday[$yobi]);

            // 背景色を交互に設定
            if ($i % 2 == 1) {
                $this->sheet->getStyleByColumnAndRow($i * 2 + 5, 7)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                $this->sheet->getStyleByColumnAndRow($i * 2 + 5, 7)->getFill()->getStartColor()->setRGB("f8cbad");
                $this->sheet->getStyleByColumnAndRow($i * 2 + 5, 8)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                $this->sheet->getStyleByColumnAndRow($i * 2 + 5, 8)->getFill()->getStartColor()->setRGB("f8cbad");
            }
        }

        // 表示行が13よりも多い場合は行をコピー
        if (count($dutyAssignmentDatas) > 13) {
            // 表示する行数に合わせて行をコピーする
            $this->copy($this->sheet, 21, 21, 67, 22, count($dutyAssignmentDatas) - 13);
        }

        $row = 9;
        foreach ($dutyAssignmentDatas as $data) {
            // チーム名設定
            $val = $data["team_id"];
            $this->sheet->getCellByColumnAndRow(0, $row)->setValue($val);

            // 資格の設定
            if ($data["Personnels"]["license_07"] == 2) {
                $val = "機";
                $this->sheet->getCellByColumnAndRow(1, $row)->setValue($val);
            }

            // 社員番号の設定
            $this->sheet->getCellByColumnAndRow(2, $row)->setValue($data["p_id"]);

            // 名前の設定
            $this->sheet->getCellByColumnAndRow(3, $row)->setValue($data["name"]);

            // 兼務日の回数
            $this->sheet->getCellByColumnAndRow(4, $row)->setValue($data["fire_plural"]);

            $col = 0;
            for($i = 0; $i < 31; $i++) {
                // 21日はじまりのため
                $day = (20 + $i) % 31 + 1;

                if ($day > $endDay) {
                    continue;
                }

                $works = explode(",", $data["d_{$day}"]);

                foreach ($works as $work) {
                    switch($work) {
                        case "D":
                            // D勤務時間帯兼務日
                            if (in_array("FKD", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue($objRichText);
                            }  else if (in_array("EW", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('0000FF');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue($objRichText);
                            } else {
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue("D");
                            }
                            break;

                        case "N":
                            // N勤務時間帯兼務日
                            if (in_array("FKN", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5 + 1, $row)->setValue($objRichText);
                            } else {
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5 + 1, $row)->setValue("N");
                            }
                            break;

                        case "DN":
                            // D勤務時間帯兼務日
                            if (in_array("FKD", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue($objRichText);
                            } else if (in_array("EW", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('0000FF');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue($objRichText);
                            } else {
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue("D");
                            }

                            // N勤務時間帯兼務日
                            if (in_array("FKN", $works)) {
                                $objRichText = new \PHPExcel_RichText();
                                $objRichText->createText('');
                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5 + 1, $row)->setValue($objRichText);
                            } else {
                                $this->sheet->getCellByColumnAndRow($col * 2 + 5 + 1, $row)->setValue("N");
                            }
                            break;
                    }

                    if (substr($work, 0, 2) === "FE") {
                        $this->sheet->getStyleByColumnAndRow($col * 2 + 5, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                        $this->sheet->getStyleByColumnAndRow($col * 2 + 5, $row)->getFill()->getStartColor()->setRGB("fce4d6");
                        $this->sheet->getCellByColumnAndRow($col * 2 + 5, $row)->setValue("F");
                    }
                }
                $col++;
            }

            $row++;
        }

        return true;
    }
}

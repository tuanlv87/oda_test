<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * C010 勤務表の作成
 */
class C010Component extends ExcelComponent{

    protected $documentType = "C010";
    protected $templateType = "C010";

    private $duty_work_list = null;
    /*
     * C010 時間管理簿を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $taskMonths = TableRegistry::get('TaskMonths');
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->where(["da_year_month" => $req["ymTarget"]])
                                               ->order(["document_order" => "ASC"])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // 月次タスクマスターデータ
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"]])
                                     ->order(["task_name" => "ASC"])
                                     ->toArray();

        // tm_idをキーとしたリストにする
        $taskMonthList = $this->List->createList($taskMonthDatas, 'tm_id');

        return array("taskMonthDatas" => $taskMonthDatas, "taskMonthList" => $taskMonthList, "dutyAssignmentDatas" => $dutyAssignmentDatas);
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $taskMonthDatas = $data["taskMonthDatas"];
        $taskMonthList = $data["taskMonthList"];
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ymTarget = $dutyAssignmentDatas[0]["da_year_month"];
        $ymStart = date("Ym", strtotime($dutyAssignmentDatas[0]["da_year_month"] . "01 -1month"));

        $endDay = date("t", strtotime($ymStart ."01"));

        $DutyWorks = TableRegistry::get('DutyWorks');
        $this->duty_work_list = $DutyWorks->find()
            ->select(["task_id", "work_hours"])
            ->where(['dw_year_month' => $ymTarget])
            ->group(["task_id", "work_hours"])
            ->toArray();

        // タイトル設定
        $val = date("Y年n月度時間割管理", strtotime($ymTarget. "01"));
        $this->sheet->getCell("U1")->setValue($val);

        $this->sheet->getCell("B7")->setValue("規定時間" .PHP_EOL. $this->prescribed_hours[$endDay]);

        $row = 10;

        foreach ($dutyAssignmentDatas as $index => $data) {
            // 上下段に振り分ける
            $this->allocationUpDown($data, $endDay, $taskMonthList, $ymStart);

            if ($index != 0) {
                $this->copy($this->sheet, 10, 12, 48, $row, 1);

                $row_m = $row+1;
                $row_e = $row+2;
                $this->sheet->mergeCells("B{$row}:E{$row_e}");
            }
            $row += 3;
        }

        $row = 10;
        $count = 0;

        $overTextArray = [];
        $overRichTextArray = [];

        foreach ($dutyAssignmentDatas as $data) {
            // 社員番号、チーム、役職、名前
            $val = $data["p_id"] . "　" .$data["team_id"] .PHP_EOL;
            $val.= $this->titleList[$data["title_code"]]["title_display"] .PHP_EOL;
            $val.= $data["name"];
            $this->sheet->setCellValue("B{$row}", $val);

            // 各日付毎の勤務内容を設定
            for ($i = 0; $i < 31; $i++) {
                $day = ($i + 21 - 1) % 31 + 1;

                // 勤務内容
                $this->writeWorks($this->sheet, $data["d_{$day}"], $data["d_{$day}"], $i + 5, $row, $taskMonthList, $overTextArray, $overRichTextArray);

                // 勤務内容上段
                //$this->writeWorks($this->sheet, $data["d_{$day}"], $data["d_{$day}_up"], $i + 5, $row + 1, $taskMonthList, $overTextArray, $overRichTextArray);
                if (strlen($data["d_{$day}_up"]) > 0) {
                    $this->sheet->getCellByColumnAndRow($i + 5, $row + 1)->setValue($this->getWorksTime(explode(",", $data["d_{$day}_up"]), $ymTarget, $day));
                }

                // 勤務内容下段
                //$this->writeWorks($this->sheet, $data["d_{$day}"], $data["d_{$day}_down"], $i + 5, $row + 2, $taskMonthList, $overTextArray, $overRichTextArray);
                if (strlen($data["d_{$day}_down"]) > 0) {
                    $this->sheet->getCellByColumnAndRow($i + 5, $row + 2)->setValue($this->getWorksTime(explode(",", $data["d_{$day}_down"]), $ymTarget, $day));
                }
            }

            // 合計
            $val = $data["work_hours"];
            $this->sheet->getCell("AK{$row}")->setValue($val);

            // 標準
            $val = $data["work_hours_up"];
            $this->sheet->getCell("AK" .($row+1))->setValue($val);

            // 標準外
            $val = $data["work_hours_down"];
            $this->sheet->getCell("AK" .($row+2))->setValue($val);

            // 超勤
            $val = $data["overtime25"] + $data["overtime35"];
            $this->sheet->getCell("AL" .($row))->setValue($val);

            // 25%
            $val = $data["overtime25"];
            $this->sheet->getCell("AL" .($row + 1))->setValue($val);

            // 35%
            $val = $data["overtime35"];
            $this->sheet->getCell("AL" .($row + 2))->setValue($val);

            // 深夜
            $val = $data["night_work_hours"];
            $this->sheet->getCell("AM{$row}")->setValue($val);

            // 休暇
            $val = $data["hd2_days"];
            $this->sheet->getCell("AM" .($row+1))->setValue($val * 9.0);

            // 特別休暇
            $val = ($data["hd3_days"] + $data["hd4_days"]);
            $this->sheet->getCell("AM" .($row+2))->setValue($val * 9.0);

            // 宿直
            $val = $data["night_duty"];
            $this->sheet->getCell("AN" .($row))->setValue($val);

            // 日直
            $val = $data["day_duty"];
            $this->sheet->getCell("AN" .($row + 1))->setValue($val);

            // 食事
            $val = $data["meal_allowance"];
            $this->sheet->getCell("AN" .($row + 2))->setValue($val);

            // 兼務
            $val = $data["fire_plural"];
            $this->sheet->getCell("AO" .($row))->setValue($val);

            // 実報
            $val = $data["fire_jippo"];
            $this->sheet->getCell("AO" .($row + 1))->setValue($val);

            // 代行
            $val = $data["acting_captain"];
            $this->sheet->getCell("AO" .($row + 2))->setValue($val);

            // 勤務
            $val = $data["d_duty"] + $data["n_duty"] + $data["dn_duty"];
            $this->sheet->getCell("AP{$row}")->setValue($val);

            // 指定休
            $val = $data["hd1_days"];
            $this->sheet->getCell("AP" .($row + 1))->setValue($val);

            // 欠勤
            $val = $data["x_days"] * 9.0;
            $this->sheet->getCell("AP" .($row + 2))->setValue($val);

            $row += 3;
            $count++;
        }

        // 不要な日付の行を削除する
        if ((31 - $endDay) > 0) {
            $this->sheet->removeColumnByIndex($endDay - 15, 31 - $endDay);
        }


        // 曜日を設定
        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
        for ($i = 0; $i < $endDay; $i++) {
            $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));
            $this->sheet->getCellByColumnAndRow($i + 5, 8)->setValue($weekday[$yobi]);
        }

        // 最終行の略したものを表示する
        foreach($overRichTextArray as $index => $overRichText) {
            if ($index > 0 && ($index) % 8 == 0) {
                $row++;
            }
            $cell = $index % 8;

            $this->sheet->getCellByColumnAndRow(4 * $cell + 5, $row)->setValue("#" . ($index + 1) . ":");
            $this->sheet->getCellByColumnAndRow(4 * $cell + 6, $row)->setValue($overRichText);
        }

        return true;
    }


    /*
     * 上下段に振り分ける
     * @param data 勤務表データ
     * @param endDay 最終日
     */
    public function allocationUpDown(&$data, $endDay, $taskMonthList, $ymStart) {

        // 勤務時間を取得
        $data["work_hours_up"] = $data["work_hours"];
        $data["work_hours_down"] = 0.0;

        // 上下段に格納するために初期化
        for ($i = 1; $i <= 31; $i++) {
            $data["d_{$i}"] = preg_replace("/D,N$/", "DN" , $data["d_{$i}"]);
            $data["d_{$i}"] = str_replace("D,N,", "DN," , $data["d_{$i}"]);
            $data["d_{$i}_up"] = $data["d_{$i}"] ;
            $data["d_{$i}_down"] = "";
        }

        // 規定時間を取得
        if ($data["title_code"] === "A2") {
            $prescribedHour = $this->prescribed_a2_hours[$endDay];
        } else {
            $prescribedHour = $this->prescribed_hours[$endDay];
        }
        // 無条件に下段に割り振るものは下段に割り振る
        for ($i = 0; $i < $endDay; $i++) {
            $day = date("j" , strtotime($ymStart . "21" . " +{$i} days"));

            $workArray = explode(",", $data["d_{$day}_up"]);
            $workUpArray = [];
            $workDownArray = [];

            foreach ($workArray as $work) {
                if (isset($this->codes2[$this->getCode2Key($work)])) {
                    if ($this->codes2[$this->getCode2Key($work)]["up"] == 0 && $this->codes2[$this->getCode2Key($work)]["down"] == 1) {
                        $workDownArray[] = $work;
                        $data["work_hours_up"] -= $this->getWorkTime($work);
                        $data["work_hours_down"] += $this->getWorkTime($work);
                    } else {
                        $workUpArray[] = $work;
                    }
                } else {
                    $workUpArray[] = $work;
                }
            }

            $data["d_{$day}_up"] = implode("," , $workUpArray);
            $data["d_{$day}_down"] = implode("," , $workDownArray);
        }

        // 規定時間を下回った段階で処理を終了
        if ($data["work_hours_up"] <= $prescribedHour) return ;

        // 指定休に働いている場合は下段に割り振る
        for ($i = 0; $i < $endDay; $i++) {
            $day = date("j" , strtotime($ymStart . "21" . " +{$i} days"));

            $workArray = explode(",", $data["d_{$day}_up"]);
            $workUpArray = [];
            if (strlen($data["d_{$day}_down"]) > 0) {
                $workDownArray = explode(",", $data["d_{$day}_down"]);
            } else {
                $workDownArray = [];
            }

            foreach ($workArray as $work) {
                if ($data["work_hours_up"] <= $prescribedHour) {
                    $workUpArray[] = $work;
                    continue;
                }

                if (isset($this->codes2[$this->getCode2Key($work)])) {
                    if ($this->codes2[$this->getCode2Key($work)]["up"] == 1 &&
                        $this->codes2[$this->getCode2Key($work)]["down"] == 1 &&
                        in_array("HD1", $workUpArray)
                    ) {
                        $workDownArray[] = $work;
                        $data["work_hours_up"] -= $this->getWorkTime($work);
                        $data["work_hours_down"] += $this->getWorkTime($work);

                    } else {
                        $workUpArray[] = $work;
                    }
                } else {
                    $workUpArray[] = $work;
                }
            }

            $data["d_{$day}_up"] = implode("," , $workUpArray);
            $data["d_{$day}_down"] = implode("," , $workDownArray);

            // 規定時間を下回った段階で処理を終了
            if ($data["work_hours_up"] <= $prescribedHour) return ;
        }

        // 規定時間を下回った段階で処理を終了
        if ($data["work_hours_up"] <= $prescribedHour) return ;

        // 上記の処理を行っても超過している場合は順番に下段に割り振る
        for ($i = 0; $i < $endDay; $i++) {
            $day = date("j" , strtotime($ymStart . "21" . " +{$i} days"));

            $workArray = explode(",", $data["d_{$day}_up"]);
            $workUpArray = [];
            if (strlen($data["d_{$day}_down"]) > 0) {
                $workDownArray = explode(",", $data["d_{$day}_down"]);
            } else {
                $workDownArray = [];
            }

            foreach ($workArray as $work) {
                if ($data["work_hours_up"] <= $prescribedHour) {
                    $workUpArray[] = $work;
                    continue;
                }

                if (isset($this->codes2[$this->getCode2Key($work)])) {
                    if ($this->codes2[$this->getCode2Key($work)]["up"] == 1 &&
                        $this->codes2[$this->getCode2Key($work)]["down"] == 1
                    ) {
                        $workDownArray[] = $work;
                        $data["work_hours_up"] -= $this->getWorkTime($work);
                        $data["work_hours_down"] += $this->getWorkTime($work);

                    } else {
                        $workUpArray[] = $work;
                    }
                } else {
                    $workUpArray[] = $work;
                }
            }

            $data["d_{$day}_up"] = implode("," , $workUpArray);
            $data["d_{$day}_down"] = implode("," , $workDownArray);

            // 規定時間を下回った段階で処理を終了
            if ($data["work_hours_up"] <= $prescribedHour) return ;
        }

        // 規定時間を下回った段階で処理を終了
        if ($data["work_hours_up"] <= $prescribedHour) return ;

        // 上記の処理を行っても超過している場合はDNを分解してNを下段に割り振る
        // 偏らないようにする
        foreach ([21,22,23,1,2,3,11,12,13,24,25,26,4,5,6,14,15,16,27,28,29,7,8,9,17,18,19,30,31,10,20] as $day)
        {
            $workArray = explode(",", $data["d_{$day}_up"]);
            $workUpArray = [];
            if (strlen($data["d_{$day}_down"]) > 0) {
                $workDownArray = explode(",", $data["d_{$day}_down"]);
            } else {
                $workDownArray = [];
            }

            foreach ($workArray as $work) {
                if ($data["work_hours_up"] <= $prescribedHour) {
                    $workUpArray[] = $work;
                    continue;
                }

                if ($work == "DN")
                {
                    $workDownArray[] = "N";
                    $data["work_hours_up"] -= $this->getWorkTime("N");
                    $data["work_hours_down"] += $this->getWorkTime("N");
                    $workUpArray[] = "D";

                } else {
                    $workUpArray[] = $work;
                }
            }

            $data["d_{$day}_up"] = implode("," , $workUpArray);
            $data["d_{$day}_down"] = implode("," , $workDownArray);

            // 規定時間を下回った段階で処理を終了
            if ($data["work_hours_up"] <= $prescribedHour) return ;
        }
        
        if ($data["work_hours_up"] <= $prescribedHour) return ;
        
        // 上下段の割り振り方法がない月次タスクを下段に割り振る
        for ($i = 0; $i < $endDay; $i++) {
            $day = date("j" , strtotime($ymStart . "21" . " +{$i} days"));

            $workArray = explode(",", $data["d_{$day}_up"]);
            $workUpArray = [];
            if (strlen($data["d_{$day}_down"]) > 0) {
                $workDownArray = explode(",", $data["d_{$day}_down"]);
            } else {
                $workDownArray = [];
            }

            foreach ($workArray as $work) {
                if ($data["work_hours_up"] <= $prescribedHour) {
                    $workUpArray[] = $work;
                    continue;
                }

                if (isset($taskMonthList[$work]) && !isset($this->codes2[$this->getCode2Key($work)])) {
                    $workDownArray[] = $work;
                    $data["work_hours_up"] -= $this->getWorkTime($work);
                    $data["work_hours_down"] += $this->getWorkTime($work);
                } else {
                    $workUpArray[] = $work;
                }
            }

            $data["d_{$day}_up"] = implode("," , $workUpArray);
            $data["d_{$day}_down"] = implode("," , $workDownArray);

            // 規定時間を下回った段階で処理を終了
            if ($data["work_hours_up"] <= $prescribedHour) return ;
        }
    }

    /*
     * 勤務時間を返却する
     * 現状、固定で9時間
     * 詳細に時間を求める場合は、
     * ここで、勤務コード毎に時間を計算する
     * @param $work 勤務コード
     */
    private function getWorkTime($work) {
        if ($work === "DN") {
            return 18.0;
        }

        if ($work === "FE00") {
            return 6.0;
        }

        if ($work === "D" || $work === "N" || $work === "HD2" || $work === "HD3" || $work === "HD4") {
            return 9.0;
        }

        foreach($this->duty_work_list as $duty_work) {
            if ($duty_work->task_id == $work) {
                return $duty_work->work_hours;
            }
        }
    }

    /*
     * 勤務時間を返却する
     * @param $work 勤務コードの配列
     */
    private function getWorksTime($works, $yearMonth, $day) {
        $result = 0;

        foreach($works as $work) {
            $result += $this->getWorkTime($work);
        }

        if ($result > 0) {
            return $result;
        } else {
            return "";
        }
    }

    /*
     * カンマ区切りになっている勤務コードを
     * 指定のセルに表示する
     * @param $sheet:シートオブジェクト
     * @param $allWorks:その日の全ての勤務コード
     * @param $works:表示する段の全ての勤務コード
     * @param $col:列
     * @param $row:行
     */
    private function writeWorks($sheet, $allWorks, $works, $col, $row, $taskMonthList, &$overTextArray, &$overRichTextArray) {
        $workArray = explode("," , $works);
        $allWorksArray = explode("," , $allWorks);

        $prefix = "";
        $backgroundHolidayFlag = false; // 休日の背景色を優先するために使用するフラグ
        $backgroundColor = "";

        $objRichText = new \PHPExcel_RichText();
        $objRichText->createText('');

        foreach ($workArray as $work) {
            if (isset($taskMonthList[$work])) {
                // 月次タスクマスタに設定されている場合
                if ($taskMonthList[$work]["show_mark"] != "") {
                    $text = $objRichText->createTextRun($prefix . $taskMonthList[$work]["show_mark"]);
                    $text->getFont()->setSize(9);
                    $text->getFont()->setName("ゴシック");
                    $prefix = ",";
                }

                // 背景色が設定されている場合は設定する
                if ($taskMonthList[$work]["frame_color"] != "" && !$backgroundHolidayFlag) {
                    $backgroundColor = $taskMonthList[$work]["frame_color"];
                }
            } else if (isset($this->codes1[$this->getCode1Key($work)])) {
                // 通常のタスクに設定されている場合
                if ($this->getCode1Disp($work) != "") {
                    if ($work == "D" && in_array("EW", $allWorksArray)) {
                        // D勤のみの残務日の場合
                        $objBlue = $objRichText->createTextRun('D');
                        $objBlue->getFont()->getColor()->setRGB('0000FF');
                        $objBlue->getFont()->setSize(9);
                        $objBlue->getFont()->setName("ゴシック");
                    } else if ($work == "DN" && in_array("EW", $allWorksArray)) {
                        // DN勤の残務日の場合
                        $objBlue = $objRichText->createTextRun('D');
                        $objBlue->getFont()->getColor()->setRGB('0000FF');
                        $objBlue->getFont()->setSize(9);
                        $objBlue->getFont()->setName("ゴシック");
                        $text = $objRichText->createTextRun('N');
                        $text->getFont()->setSize(9);
                        $text->getFont()->setName("ゴシック");
                    } else if ($work == "D" &&  in_array("FKD", $allWorksArray)) {
                        // D勤でD勤務帯兼務
                        $objRed = $objRichText->createTextRun('D');
                        $objRed->getFont()->getColor()->setRGB('FF0000');
                        $objRed->getFont()->setSize(9);
                        $objRed->getFont()->setName("ゴシック");
                    } else if ($work == "N" &&  in_array("FKN", $allWorksArray)) {
                        // N勤でN勤務帯兼務
                        $objRed = $objRichText->createTextRun('N');
                        $objRed->getFont()->getColor()->setRGB('FF0000');
                        $objRed->getFont()->setSize(9);
                        $objRed->getFont()->setName("ゴシック");
                    } else if ($work == "DN" && in_array("FKD", $allWorksArray) && in_array("FKN", $allWorksArray)) {
                        // DN勤でDN勤務帯兼務
                        $objRed = $objRichText->createTextRun('DN');
                        $objRed->getFont()->getColor()->setRGB('FF0000');
                        $objRed->getFont()->setSize(9);
                        $objRed->getFont()->setName("ゴシック");
                    } else if ($work == "DN" && in_array("FKD", $allWorksArray)) {
                        // DN勤でD勤務帯兼務
                        $objRed = $objRichText->createTextRun('D');
                        $objRed->getFont()->getColor()->setRGB('FF0000');
                        $objRed->getFont()->setSize(9);
                        $objRed->getFont()->setName("ゴシック");
                        $text = $objRichText->createTextRun('N');
                        $text->getFont()->setSize(9);
                        $text->getFont()->setName("ゴシック");
                    } else if ($work == "DN" && in_array("FKN", $allWorksArray)) {
                        // DN勤でN勤務帯兼務
                        $text = $objRichText->createTextRun('D');
                        $text->getFont()->setSize(9);
                        $text->getFont()->setName("ゴシック");

                        $objRed = $objRichText->createTextRun('N');
                        $objRed->getFont()->getColor()->setRGB('FF0000');
                        $objRed->getFont()->setSize(9);
                        $objRed->getFont()->setName("ゴシック");
                    } else {
                        $text = $objRichText->createTextRun($prefix . $this->getCode1Disp($work));
                        $text->getFont()->setSize(9);
                        $text->getFont()->setName("ゴシック");
                    }
                    $prefix = ",";
                }

                // 背景色が設定されている場合は設定する
                if ($this->codes1[$this->getCode1Key($work)]["color"] != "" && !$backgroundHolidayFlag) {
                    if ($work !== "HD5") {
                        $backgroundColor = $this->codes1[$this->getCode1Key($work)]["color"];
                    } else {
                        $backgroundColor = "FFFFB2";
                    }

                    // 休みの場合
                    if (substr($this->getCode1Key($work), 0, 2) == "HD") {
                        $backgroundHolidayFlag = true;
                    }
                }
            } else {
                // 月次・通常どちらのタスクにも設定されていない場合
                // このケースは兼務日(FKD,FKN)と残務日(EW)
            }
        }

        $sheet->getCellByColumnAndRow($col, $row)->setValue($objRichText);
        if ($backgroundColor != "") {
            $sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
            $sheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setRGB($backgroundColor);
        }

        // ここで文字数を取得する
        $workStr = $this->sheet->getCellByColumnAndRow($col, $row)->getValue();
        // 文字数が4文字を超える場合
        if (mb_strlen($workStr) > 4) {
            $index = null;
            if (!in_array($workStr, $overTextArray)) {
                $overTextArray[] = $workStr;
                $overRichTextArray[] = clone $objRichText;
                $index = count($overTextArray);
            } else {
                $index = array_search($workStr, $overTextArray) + 1;
            }

            $objRichText = new \PHPExcel_RichText();
            $text = $objRichText->createTextRun("#{$index}");
            $text->getFont()->setSize(9);
            $text->getFont()->setName("ゴシック");
            $this->sheet->getCellByColumnAndRow($col, $row)->setValue($objRichText);
        }
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A010 勤務日程表-1（確認用）の作成
 */
class A010DComponent extends ExcelComponent{

    protected $documentType = "A010";
    protected $templateType = "A010";

    var $components = array('List', 'Documentation/A010');
    /*
     * A011 勤務日程表-2を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        // A010のメソッドを呼ぶ
        $this->{"Documentation/A010"}->sheet = $this->sheet;
        $this->{"Documentation/A010"}->debug = true;

        if (!$this->{"Documentation/A010"}->_writeExcel($data, $req, $error)) {
            return false;
        }

        // タイトル行の表示
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];
        $ymTarget = $dutyAssignmentDatas[0]["da_year_month"];
        $this->sheet->setCellValue("N1", date('Y年n月', strtotime($req["ymTarget"] .'01')) ."度の日程表(チーム別)");

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {

        ///////////////////////////////////////////////////////////////////////
        // 出力するデータの取得
        ///////////////////////////////////////////////////////////////////////
        $taskMonths = TableRegistry::get('TaskMonths');
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        // 月次タスクマスターデータ
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"]])
                                     ->order(["show_mark" => "ASC"])
                                     ->toArray();

        // tm_idをキーとしたリストにする
        $taskMonthList = $this->List->createList($taskMonthDatas, 'tm_id');


        // 全員
        $dutyAssignmentDatas = $dutyAssignments->find()
                                               ->where(["da_year_month" => $req["ymTarget"]])
                                               ->order(["document_order" => "ASC"])
                                               ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // DNはD,Nで登録されているため、DNに置換する
        foreach ($dutyAssignmentDatas as &$dutyAssignmentData) {
            for ($i = 1; $i <= 31; $i++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        return array("taskMonthDatas" => $taskMonthDatas, "taskMonthList" => $taskMonthList, "dutyAssignmentDatas" => $dutyAssignmentDatas);
    }
}

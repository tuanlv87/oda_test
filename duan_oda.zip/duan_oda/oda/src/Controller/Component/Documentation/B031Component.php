<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * B031 月次タスク日程表の作成
 */
class B031Component extends ExcelComponent{

    protected $documentType = "B031";
    protected $templateType = "B031";

    /*
     * B031 月次タスク日程表を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        $taskMonths = TableRegistry::get('TaskMonths');

        // 月次タスクマスターデータ
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"]])
                                     ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($taskMonthDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        return array("taskMonthDatas" => $taskMonthDatas);
    }

    /*
     * EXCELへの書き込み
     * 
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $taskMonthDatas = $data["taskMonthDatas"];

        // セルをコピーする
        if (count($taskMonthDatas) >= 2) {
            $this->copy($this->sheet, 6, 6, 36, 7, count($taskMonthDatas) - 1);
        }

        $ymStart = $req["ymStart"];

        // タイトル部分の設定
        $val = date("Y年n月度の月次タスク日程表", strtotime($req["ymTarget"] . "01"));
        $this->sheet->getCellByColumnAndRow(12, 1)->setValue($val);

        ///////////////////////////////////////////////////////////////////////
        // 列の数をカレンダーに合わせて動的にする
        ///////////////////////////////////////////////////////////////////////
        // 不要な日の列を削除
        $endDay = date("t", strtotime($ymStart . "01"));
        if ((31 - $endDay) > 0) {
            $this->sheet->removeColumnByIndex($endDay - 15, 31 - $endDay);
        }
        
        // 曜日を設定する
        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
        for ($i = 0; $i < $endDay; $i++) {
            $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));

            $this->sheet->getCellByColumnAndRow($i + 5, 5)->setValue($weekday[$yobi]);
        }

        $row = 6;
        foreach ($taskMonthDatas as $taskMonthData) {
            // ID
            $this->sheet->getCellByColumnAndRow(0, $row)->setValue($taskMonthData["tm_id"]);

            // 表示
            $this->sheet->getCellByColumnAndRow(1, $row)->setValue($taskMonthData["show_mark"]);

            // タスク名称
            $this->sheet->getCellByColumnAndRow(2, $row)->setValue($taskMonthData["task_name"]);

            // 期間
            $val = date("n/j", strtotime($taskMonthData["start_date"]));
            if ($taskMonthData["end_date"] !== "") {
                $val .= " - " . date("n/j", strtotime($taskMonthData["end_date"]));
            }
            $this->sheet->getCellByColumnAndRow(3, $row)->setValue($val);

            // 人数
            $this->sheet->getCellByColumnAndRow(4, $row)->setValue($taskMonthData["personnel"]);

            // スケジュール部分
            $startCol = (strtotime($taskMonthData["start_date"]) - strtotime($ymStart . "21")) / (24 * 60 * 60) + 5;
            if ($taskMonthData["end_date"] !== "") {
                $endCol = (strtotime($taskMonthData["end_date"]) - strtotime($ymStart . "21")) / (24 * 60 * 60) + 5;
            } else {
                $endCol = $startCol;
            }

            for ($i = $startCol; $i <= $endCol; $i++) {
                $this->sheet->getStyleByColumnAndRow($i, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                $this->sheet->getStyleByColumnAndRow($i, $row)->getFill()->getStartColor()->setRGB("f8cbad");
            }

            $row++;
        }

        return true;
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A030 勤務日程表-5の作成
 */
class A030Component extends ExcelComponent{

    protected $documentType = "A030";
    protected $templateType = "A030";

    var $components = array('List', 'Documentation/A010');

    /*
     * A030 勤務日程表-5を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {
        // A010のメソッドをコールしてデータを取得する
        $req["type"] = "all";
        $data = $this->{"Documentation/A010"}->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    public function _writeExcel($data, $req, &$error) {

        $taskMonthDatas = $data["taskMonthDatas"];
        $taskMonthList = $data["taskMonthList"];
        $dutyAssignmentDatas = $data["dutyAssignmentDatas"];

        $ymStart = date("Ym", strtotime($req["ymStart"] . "01"));

        ///////////////////////////////////////////////////////////////////////
        // 列の数をカレンダーに合わせて動的にする
        ///////////////////////////////////////////////////////////////////////
        // 不要な日の列を削除
        $endDay = date("t", strtotime($ymStart . "01"));
        if ((31 - $endDay) > 0) {
            $this->sheet->removeColumnByIndex($endDay - 9, 31 - $endDay);
        }

        ///////////////////////////////////////////////////////////////////////
        // 標記事例の表示
        ///////////////////////////////////////////////////////////////////////
        $row = 2;

        // 標記事例の数が7よりも多い場合は行を追加する
        if (count($taskMonthDatas) > 7) {
            $this->sheet->insertNewRowBefore(8, count($taskMonthDatas) - 7);
            // 表示する行数に合わせて行をコピーする
            $this->copy($this->sheet, $row, $row, 42, 8, count($taskMonthDatas) - 7);
        }

        foreach ($taskMonthDatas as $data) {
            // 月次タスクコードを表示
            $val = (strlen($data["show_mark"]) > 0) ? $data["show_mark"] : $data["tm_id"];
            $this->sheet->getCellByColumnAndRow(9, $row)->setValue($val);

            $startCol = ((strtotime($data["start_date"]) - strtotime($ymStart . "21")) / (24 * 60 * 60)) + 11;
            $endCol =  ((strtotime($data["end_date"]) - strtotime($ymStart. "21")) / (24 * 60 * 60)) + 11;

            $disp = (strlen($data["show_name"]) > 0) ? $data["show_name"] : $data["task_name"];
            $this->sheet->getCellByColumnAndRow($startCol, $row)->setValue($disp);

            // 背景色を設定
            if ($data["frame_color"] != "") {
                for ($i = $startCol; $i <= $endCol; $i++) {
                    $this->sheet->getStyleByColumnAndRow($i, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($i, $row)->getFill()->getStartColor()->setRGB($data["frame_color"]);
                }
            }

            $row++;
        }

        ///////////////////////////////////////////////////////////////////////
        // カレンダーに合わせて曜日を設定する
        ///////////////////////////////////////////////////////////////////////
        // 曜日の行の計算
        if (count($taskMonthDatas) > 7) {
            $row = 10 + count($taskMonthDatas) - 7;
        } else {
            $row = 10;
        }

        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
        for ($i = 0; $i < $endDay; $i++) {
            $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));

            $this->sheet->getCellByColumnAndRow($i + 11, $row)->setValue($weekday[$yobi]);
        }

        ///////////////////////////////////////////////////////////////////////
        // 個々の勤務表の表示
        ///////////////////////////////////////////////////////////////////////
        // 開始行の計算
        if (count($taskMonthDatas) > 7) {
            $row = 11 + count($taskMonthDatas) - 7;
        } else {
            $row = 11;
        }

        // 表示する行数に合わせて行をコピーする
        $this->copy($this->sheet, $row, $row, 42, $row+1, count($dutyAssignmentDatas) - 1);

        // 文字数オーバー格納用
        $overTextArray = [];
        $overRichTextArray = [];

        // 社員ごとの勤務表を設定する
        foreach($dutyAssignmentDatas as $data) {
            // 社員番号
            $this->sheet->setCellValue("A{$row}", $data["p_id"]);
            // G-ID
            $val = (strlen($data["crew_id"]) > 0) ? $data["team_id"] . "-" . $data["crew_id"] : $data["team_id"];
            $this->sheet->setCellValue("B{$row}", $val);
            // 氏名
            $this->sheet->setCellValue("C{$row}", $data["name"]);
            // 役職
            $this->sheet->setCellValue("D{$row}", $this->titleList[$data["title_code"]]["title_display"]);
            // 勤務時間
            $val = $data["work_hours"];
            $this->sheet->setCellValue("E{$row}", $val);
            // 超過時間
            $this->sheet->setCellValue("F{$row}", $data["overtime25"] + $data["overtime35"]);

            ///////////////////////////////////////////////////////////////////////
            // 各日毎の勤務内容を設定
            ///////////////////////////////////////////////////////////////////////

            // 各日はL列目から始まるため
            $col = 11;
            for ($i = 0; $i < 31; $i++) {
                // 21日はじまりのため
                $yobi = (20 + $i) % 31 + 1;

                if ($yobi > $endDay) {
                    continue;
                }

                $workArray = explode("," , $data["d_{$yobi}"]);

                $prefix = "";
                $backgroundHolidayFlag = false; // 休日の背景色を優先するために使用するフラグ
                $backgroundColor = "";

                $objRichText = new \PHPExcel_RichText();
                $objRichText->createText('');

                foreach ($workArray as $work) {
                    if (isset($taskMonthList[$work])) {
                        // 月次タスクマスタに設定されている場合
                        if ($taskMonthList[$work]["show_mark"] != "") {
                            $text = $objRichText->createTextRun($prefix . $taskMonthList[$work]["show_mark"]);
                            $text->getFont()->setSize(9);
                            $text->getFont()->setName("ゴシック");
                            $prefix = ",";
                        }

                        // 背景色が設定されている場合は設定する
                        if ($taskMonthList[$work]["frame_color"] != "" && !$backgroundHolidayFlag) {
                            $backgroundColor = $taskMonthList[$work]["frame_color"];
                        }
                    } else if (isset($this->codes1[$this->getCode1Key($work)])) {
                        // 通常のタスクに設定されている場合
                        if ($this->getCode1Disp($work) != "") {
                            if ($work == "D" && in_array("EW", $workArray)) {
                                // D勤のみの残務日の場合
                                $objBlue = $objRichText->createTextRun('D');
                                $objBlue->getFont()->getColor()->setRGB('0000FF');
                                $objBlue->getFont()->setSize(9);
                                $objBlue->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("EW", $workArray)) {
                                // DN勤の残務日の場合
                                $objBlue = $objRichText->createTextRun('D');
                                $objBlue->getFont()->getColor()->setRGB('0000FF');
                                $objBlue->getFont()->setSize(9);
                                $objBlue->getFont()->setName("ゴシック");
                                $text = $objRichText->createTextRun('N');
                                $text->getFont()->setSize(9);
                                $text->getFont()->setName("ゴシック");
                            } else if ($work == "D" &&  in_array("FKD", $workArray)) {
                                // D勤でD勤務帯兼務
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "N" &&  in_array("FKN", $workArray)) {
                                // N勤でN勤務帯兼務
                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("FKD", $workArray) && in_array("FKN", $workArray)) {
                                // DN勤でDN勤務帯兼務
                                $objRed = $objRichText->createTextRun('DN');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("FKD", $workArray)) {
                                // DN勤でD勤務帯兼務
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                                $text = $objRichText->createTextRun('N');
                                $text->getFont()->setSize(9);
                                $text->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("FKN", $workArray)) {
                                // DN勤でN勤務帯兼務
                                $text = $objRichText->createTextRun('D');
                                $text->getFont()->setSize(9);
                                $text->getFont()->setName("ゴシック");

                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(9);
                                $objRed->getFont()->setName("ゴシック");
                            } else {
                                $text = $objRichText->createTextRun($prefix . $this->getCode1Disp($work));
                                $text->getFont()->setSize(9);
                                $text->getFont()->setName("ゴシック");
                            }
                            $prefix = ",";
                        }

                        // 背景色が設定されている場合は設定する
                        if ($this->codes1[$this->getCode1Key($work)]["color"] != "" && !$backgroundHolidayFlag) {
                            $backgroundColor = $this->codes1[$this->getCode1Key($work)]["color"];

                            // 休みの場合
                            if (substr($this->getCode1Key($work), 0, 2) == "HD") {
                                $backgroundHolidayFlag = true;
                            }
                        }
                    } else {
                        // 月次・通常どちらのタスクにも設定されていない場合
                        // このケースは兼務日(FKD,FKN)と残務日(EW)
                    }
                }

                $this->sheet->getCellByColumnAndRow($col, $row)->setValue($objRichText);
                if ($backgroundColor != "") {
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setRGB($backgroundColor);
                }

                // ここで文字数を取得する
                $workStr = $this->sheet->getCellByColumnAndRow($col, $row)->getValue();

                // 文字数が4文字を超える場合
                if (mb_strlen($workStr) > 4) {
                    $index = null;
                    if (!in_array($workStr, $overTextArray)) {
                        $overTextArray[] = $workStr;
                        $overRichTextArray[] = clone $objRichText;
                        $index = count($overTextArray);
                    } else {
                        $index = array_search($workStr, $overTextArray) + 1;
                    }

                    $objRichText = new \PHPExcel_RichText();
                    $text = $objRichText->createTextRun("#{$index}");
                    $text->getFont()->setSize(9);
                    $text->getFont()->setName("ゴシック");
                    $this->sheet->getCellByColumnAndRow($col, $row)->setValue($objRichText);
                }

                $col++;
            }

            $row++;
        }

        // 最終行の略したものを表示する
        foreach($overRichTextArray as $index => $overRichText) {
            if ($index > 0 && ($index) % 8 == 0) {
                $row++;
            }
            $cell = $index % 8;

            $this->sheet->getCellByColumnAndRow(4 * $cell + 11, $row)->setValue("#" . ($index + 1) . ":");
            $this->sheet->getCellByColumnAndRow(4 * $cell + 12, $row)->setValue($overRichText);
        }

        return true;
    }
}

<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * B030 月次タスク一覧（掲示用）
 */
class B030Component extends ExcelComponent{

    protected $documentType = "B030";
    protected $templateType = "B030";

    /*
     * B030 月次タスク一覧（掲示用）を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {

        // 月次タスクマスターデータ
        $taskMonths = TableRegistry::get('TaskMonths');
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"], "show_mark like" => "R%"])
                                     ->order(['tm_id' => 'ASC'])
                                     ->toArray();

        // 出力対象データがない場合はエラーとする
        if (count($taskMonthDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        return array("taskMonthDatas" => $taskMonthDatas);
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $taskMonthDatas = $data["taskMonthDatas"];

        $ymStart = $req["ymStart"];

        // タイトル部分の設定
        $val = date("Y年n月度の臨時警備勤務詳細", strtotime($req["ymTarget"] . "01"));
        $this->sheet->getCellByColumnAndRow(13, 2)->setValue($val);

        $endDay = date("t", strtotime($ymStart . "01"));

        $row = 5;

        $weekday = array( "日", "月", "火", "水", "木", "金", "土" );

        $rowCount = 0;

        for ($i = 0; $i < $endDay; $i++) {
            $dispFlag = false;

            // なんかひどい実装
            foreach ($taskMonthDatas as $taskMonthData) {
                $currentDate = date("Y/m/d", strtotime($ymStart . "21 +{$i} days"));

                $day = date("j", strtotime($currentDate));

                if (strtotime($taskMonthData["start_date"]) <= strtotime($currentDate) &&
                    ($taskMonthData["end_date"] == "" || strtotime($currentDate) <= strtotime($taskMonthData["end_date"]))) {

                    // セルのスタイルを設定
                    if ($rowCount > 1) {
                        for ($j = 0; $j <= 22; $j++) {
                            $copyCell = $this->sheet->getStyleByColumnAndRow($j, 5);
                            $pasteCell = \PHPExcel_Cell::stringFromColumnIndex($j) . (string)($row);
                            $this->sheet->duplicateStyle($copyCell, $pasteCell);
                        }

                        $this->sheet->getStyleByColumnAndRow(1, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                        $this->sheet->getStyleByColumnAndRow(2, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(3, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(4, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                        $this->sheet->getStyleByColumnAndRow(13, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                        $this->sheet->getStyleByColumnAndRow(15, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(16, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(17, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(18, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(19, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        $this->sheet->getStyleByColumnAndRow(20, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                        $this->sheet->getStyleByColumnAndRow(21, $row)->getBorders()->getLeft()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);

                        for ($j = 1; $j <= 2; $j++) {
                            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_NONE);
                            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getBottom()->setBorderStyle(\PHPExcel_Style_Border::BORDER_NONE);
                        }

                        for ($j = 3; $j <= 22; $j++) {
                            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getBottom()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                        }
                    }

                    // IDの表示
                    $this->sheet->getCell("D{$row}")->setValue($taskMonthData["tm_id"]);

                    // 件名
                    $this->sheet->getCell("E{$row}")->setValue($taskMonthData["task_name"]);

                    // 時間(TODO：表示方法を変える）
                    $val = $taskMonthData["start_time"] . "-" . $taskMonthData["end_time"];
                    $this->sheet->getCell("N{$row}")->setValue($val);

                    // 待機
                    $fromSec = strtotime($taskMonthData["start_time"]);
                    $toSec   = strtotime($taskMonthData["end_time"]);
                    $differences = $toSec - $fromSec;
                    $val = gmdate("H:i", $differences) ;
                    $differences = strtotime($val) - strtotime($this->doubletimeToChar($taskMonthData["work_hours"]));
                    $val = gmdate("H:i", $differences) ;
                    $this->sheet->getCell("P{$row}")->setValue($val);

                    // 拘束
                    $fromSec = strtotime($taskMonthData["start_time"]);
                    $toSec   = strtotime($taskMonthData["end_time"]);
                    $differences = $toSec - $fromSec;
                    $val = gmdate("H:i", $differences) ;
                    $this->sheet->getCell("Q{$row}")->setValue($val);

                    // 実働
                    $val = $this->doubletimeToChar($taskMonthData["work_hours"]);
                    $this->sheet->getCell("R{$row}")->setValue($val);

                    // 弁当
                    $val = ($taskMonthData["meal_allowance"] == 1) ? "有" : "";
                    $this->sheet->getCell("S{$row}")->setValue($val);

                    // 人数
                    $this->sheet->getCell("T{$row}")->setValue($taskMonthData["personnel"]);

                    // 勤務者
                    $workers = $this->_getWorkers($req["ymTarget"], $day, $taskMonthData["tm_id"]);
                    if (!empty($workers)) {
                        $this->sheet->getCell("U{$row}")->setValue(implode(",", $workers));
                    }

                    if (!$dispFlag) {
                        // 日付部分の表示
                        $monthDay = date("n.j", strtotime($currentDate));
                        $this->sheet->setCellValueExplicit("B{$row}", $monthDay, \PHPExcel_Cell_DataType::TYPE_STRING );

                        $yobi = date("w" , strtotime($currentDate));
                        $this->sheet->getCell("C{$row}")->setValue($weekday[$yobi]);

                        for ($j = 1; $j <= 22; $j++) {
                            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
                        }
                        $dispFlag = true;
                    }

                    $row++;
                    $rowCount++;
                }
            }
        }

        for ($j = 1; $j <= 22; $j++) {
            $this->sheet->getStyleByColumnAndRow($j, $row)->getBorders()->getTop()->setBorderStyle(\PHPExcel_Style_Border::BORDER_MEDIUM);
        }

        return true;
    }

    private function _getWorkers($ym, $day, $tmId) {
        $this->log($ym);
        $dutyAssignments = TableRegistry::get('DutyAssignments');
        $workers = $dutyAssignments->find()
                                   ->hydrate(false)
                                   ->join(['table' => 'titles',
                                           'alias' => 'Titles',
                                           'type'  => 'LEFT',
                                           'conditions' => [
                                           'DutyAssignments.title_code = Titles.title_code'
                                          ]])
                                   ->where(["da_year_month" => $ym, "FIND_IN_SET('{$tmId}' ,d_{$day})"])
                                   ->order(["Titles.title_order" => "IS NULL ASC", "Titles.title_order " => "ASC", "document_order" => "ASC"])
                                   ->toArray();

        $result = array();
        foreach($workers as $worker) {
            $result[] = $worker["name"];
        }

        return $result;
    }

    private function doubletimeToChar($doubleTime) {
        return gmdate("H:i", $doubleTime * 60 * 60);
    }
}

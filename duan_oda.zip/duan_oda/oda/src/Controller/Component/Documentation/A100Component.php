<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A100 補勤者リストの作成
 */
class A100Component extends ExcelComponent{

    protected $documentType = "A100";
    protected $templateType = "A100";

    private $dutyAssignmentData = null;

    public function setDutyAssignmentDatas($dutyAssignmentDatas) {
        $this->dutyAssignmentDatas = $dutyAssignmentDatas;
    }

    private $day = null;

    public function setDay($day) {
        $this->day = $day;
    }

    /*
     * A100 補勤者リストを作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        return array();
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $dutyAssignments = TableRegistry::get('DutyAssignments');

        $createCount = 0;
        for ($i = 0; $i < 31; $i++) {

            $day = (20 + $i) % 31 + 1;

            if ($req["type"] == "date" && $day != $req["Date_Day"]) {
                continue;
            }

            $dutyAssignmentDatas = $dutyAssignments->find()
                                                   ->hydrate(false)
                                                   ->join(['table' => 'personnels',
                                                           'alias' => 'Personnels',
                                                           'type'  => 'INNER',
                                                           'conditions' => [
                                                           'DutyAssignments.p_id = Personnels.p_id'
                                                          ]])
                                                   ->join(['table' => 'titles',
                                                           'alias' => 'Titles',
                                                           'type'  => 'LEFT',
                                                           'conditions' => [
                                                           'DutyAssignments.title_code = Titles.title_code'
                                                          ]])
                                                   ->select(["DutyAssignments.da_year_month"
                                                            ,"DutyAssignments.p_id"
                                                            ,"DutyAssignments.name"
                                                            ,"DutyAssignments.team_id"
                                                            ,"DutyAssignments.crew_id"
                                                            ,"DutyAssignments.personnel_id"
                                                            ,"DutyAssignments.gender"
                                                            ,"DutyAssignments.title_code"
                                                            ,"DutyAssignments.d_{$day}"
                                                            ,"Personnels.license_01"
                                                            ,"Personnels.license_02"
                                                            ,"Personnels.license_03"
                                                            ,"Personnels.license_04"
                                                            ,"Personnels.license_05"
                                                            ,"Personnels.license_06"
                                                            ,"Personnels.license_07"
                                                            ,"Personnels.license_08"
                                                            ,"Personnels.license_09"
                                                            ,"Personnels.license_10"
                                                            ])
                                                   ->where(["OR" => [["d_{$day}" => "HD1"],
                                                                     ["d_{$day}" => "+HD1,HD1"],
                                                                     ["d_{$day}" => "HD5"],
                                                                     ["d_{$day}" => "+HD5,HD5"]],
                                                            "da_year_month" => $req["ymTarget"]])
                                                   ->order(["Titles.title_order" => "IS NULL ASC", "Titles.title_order " => "ASC", "DutyAssignments.document_order" => "ASC"])
                                                   ->toArray();

            if (count($dutyAssignmentDatas) == 0) {
                // 件数が0の場合は何もしない
                continue;
            }

            // DNはD,Nで登録されているためDNに置換する
            foreach($dutyAssignmentDatas as &$dutyAssignmentData) {
                $dutyAssignmentData["d_{$day}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$day}"]);
                $dutyAssignmentData["d_{$day}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$day}"]);
            }

            $this->setDay($day);
            $this->setDutyAssignmentDatas($dutyAssignmentDatas);

            // 日付の計算
            $ym = $req["ymStart"];
            if ($this->day < 21) {
                $ym = date("Ym", strtotime($ym . "01 +1month"));
            }
            $diff = $this->day - 1;
            $ymd = date("Ymd", strtotime($ym . "01  +{$diff}day"));

            // シートをコピーする
            $objSource = $this->sheet->copy();
            $objSource->setTitle(date("Y月n月j日", strtotime($ymd)));
            $objSource = $this->xl->addSheet($objSource, $createCount + 1);
            $this->sheet = $this->xl->getSheet($createCount + 1);

            // 日付の表示
            $val = date("Y月n月j日", strtotime($ymd));

            $weekday = array( "日", "月", "火", "水", "木", "金", "土" );
            $val .= "(" . $weekday[date("w", strtotime($ymd))] .")";

            $this->sheet->setCellValue("B3", $val);

            // 行をコピーする
            $row = 5;
            $this->copy($this->sheet, $row, $row, 21, $row+1, count($this->dutyAssignmentDatas) - 1);

            foreach($this->dutyAssignmentDatas as $cnt => $dutyAssignmentData) {
                // No.
                $this->sheet->setCellValue("B{$row}", $cnt+1);
                // 社員番号
                $this->sheet->setCellValue("C{$row}", $dutyAssignmentData["p_id"]);
                // 名前
                $this->sheet->setCellValue("D{$row}", $dutyAssignmentData["name"]);
                // チーム
                if (strlen($dutyAssignmentData["crew_id"]) > 0)
                {
                    $val = $dutyAssignmentData["team_id"] . "-" . $dutyAssignmentData["crew_id"];
                }
                else
                {
                    $val = $dutyAssignmentData["team_id"];
                }
                $this->sheet->setCellValue("G{$row}", $val);
                // 役職
                $this->sheet->setCellValue("H{$row}", $this->titleList[$dutyAssignmentData["title_code"]]["title_display"]);
                // 性別
                $val = ($dutyAssignmentData["gender"] == 1) ? "M" : "F";
                $this->sheet->setCellValue("I{$row}", $val);
                // Q1
                $val = ($dutyAssignmentData["Personnels"]["license_01"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("J{$row}", $val);
                // Q2
                $val = ($dutyAssignmentData["Personnels"]["license_02"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("K{$row}", $val);
                // Q3
                $val = ($dutyAssignmentData["Personnels"]["license_03"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("L{$row}", $val);
                // Q4
                $val = ($dutyAssignmentData["Personnels"]["license_04"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("M{$row}", $val);
                // Q5
                $val = ($dutyAssignmentData["Personnels"]["license_05"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("N{$row}", $val);
                // Q6
                $val = ($dutyAssignmentData["Personnels"]["license_06"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("O{$row}", $val);
                // Q7
                $this->sheet->setCellValue("P{$row}", $dutyAssignmentData["Personnels"]["license_07"]);
                // Q8
                $val = ($dutyAssignmentData["Personnels"]["license_08"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("Q{$row}", $val);
                // Q9
                $val = ($dutyAssignmentData["Personnels"]["license_09"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("R{$row}", $val);
                // Q10
                $val = ($dutyAssignmentData["Personnels"]["license_10"] == 1) ? "レ" : "";
                $this->sheet->setCellValue("S{$row}", $val);


                $row++;
            }

            $createCount++;
        }

        // 作成件数が0の場合はエラーとする
        if ($createCount == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        $this->xl->removeSheetByIndex(0);

        return true;
    }
}

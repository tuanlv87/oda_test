<?php
namespace App\Controller\Component\Documentation;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use App\Controller\Component\ExcelComponent;

/**
 * A020 勤務日程表-4の作成
 */
class A020Component extends ExcelComponent{

    protected $documentType = "A020";
    protected $templateType = "A020";
    // 警備員ID
    private $dutyAssignmentData = null;

    /*
     * A020 勤務日程表-4を作成する
     *
     * @param $req リクエストデータ
     * @param $fineName 作成ファイル名
     * @param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     */
    protected function _createExcel($req, &$fileName, &$error) {

        $data = $this->_getData($req, $error);

        if ($data === false) {
            return false;
        }

        if (!$this->_writeExcel($data, $req, $error)) {
            return false;
        }

        $fileName = $this->documentType;
        return true;
    }

    /*
     * エクセルへ出力するデータを取得する
     *
     * @param $req リクエストデータ
     * @param $error エラーメッセージ
     * @return data
     */
    public function _getData($req, &$error) {
        ///////////////////////////////////////////////////////////////////////
        // 出力するデータの取得
        ///////////////////////////////////////////////////////////////////////
        $dutyAssignments = TableRegistry::get('DutyAssignments');
        switch($req["type"]) {
            case "all":
                // 全員
                $dutyAssignmentDatas = $dutyAssignments->find()
                                                       ->where(["da_year_month" => $req["ymTarget"]])
                                                       ->order(["document_order" => "ASC"])
                                                       ->toArray();
                break;

            case "person":
                // 個人指定
                $dutyAssignmentDatas = $dutyAssignments->find()
                                       ->where(["p_id" => $req["p_id"], "da_year_month" => $req["ymTarget"]])
                                       ->order(["document_order" => "ASC"])
                                       ->toArray();
                break;

            case "date":
                // 日付指定
                $day = date("Y") . "/" . $req["Date_Month"] . "/". $req["Date_Day"];
                $dutyAssignmentDatas = $dutyAssignments->find()
                                        ->where(["modified >= " => $day, "da_year_month" => $req["ymTarget"]])
                                        ->order(["document_order" => "ASC"])
                                        ->toArray();
                break;

            default;
                $error = $this->errorMessages["E001"];
                return false;
        }

        // 出力対象データがない場合はエラーとする
        if (count($dutyAssignmentDatas) == 0) {
            $error = $this->errorMessages["E002"];
            return false;
        }

        // 月次タスクマスターデータ
        $taskMonths = TableRegistry::get('TaskMonths');
        $taskMonthDatas = $taskMonths->find()
                                     ->where(["tm_year_month" => $req["ymTarget"]])
                                     ->order(["tm_id" => "ASC"])
                                     ->toArray();

        // tm_idをキーとしたリストにする
        $taskMonthList = $this->List->createList($taskMonthDatas, 'tm_id');

        $dutyEnvs = TableRegistry::get('duty_envs');
        $dutyEnvDatas = $dutyEnvs->find()
                                 ->where(["de_year_month" => $req["ymTarget"]])
                                 ->toArray();

        $dutyLogs = TableRegistry::get('duty_logs');

        if (count($dutyEnvDatas) > 0) {
            $dutyLogDatas = $dutyLogs->find()
                                     ->where(["dl_year_month" => $req["ymTarget"],
                                              "change_date >" => $dutyEnvDatas[0]["publish_date"],
                                              "p_id" => $this->dutyAssignmentData["p_id"]
                                             ])
                                     ->toArray();
        } else {
            $dutyLogDatas = [];
        }

        // DNはD,Nで登録されているためDNに置換する
        foreach ($dutyAssignmentDatas as &$dutyAssignmentData) {
            for ($i = 1; $i <= 31; $i++) {
                $dutyAssignmentData["d_{$i}"] = preg_replace("/D,N$/", "DN" , $dutyAssignmentData["d_{$i}"]);
                $dutyAssignmentData["d_{$i}"] = str_replace("D,N,", "DN," , $dutyAssignmentData["d_{$i}"]);
            }
        }

        return array("taskMonthDatas"      => $taskMonthDatas,
                     "taskMonthList"       => $taskMonthList,
                     "dutyAssignmentDatas" => $dutyAssignmentDatas,
                     "dutyEnvDatas"        => $dutyEnvDatas,
                     "dutyLogDatas"        => $dutyLogDatas
                    );
    }

    /*
     * EXCELへの書き込み
     *
     * @param $data エクセルへ出力するデータ
     * $param $error エラーメッセージ
     * @return 真偽値 true:作成成功、false:作成失敗
     *
     */
    public function _writeExcel($data, $req, &$error) {
        $taskMonthDatas = $data["taskMonthDatas"];
        $taskMonthList = $data["taskMonthList"];
        $dutyAssignmentDatas= $data["dutyAssignmentDatas"];
        $dutyLogDatas = $data["dutyLogDatas"];
        $dutyEnvDatas = $data["dutyEnvDatas"];

        $ymTarget = $req["ymStart"];
        $ymStart = date("Ym", strtotime($req["ymStart"] . "01"));

        // 最終日を取得
        $endDay = date("t", strtotime($ymStart . "01"));

        $targetMonth = date("n", strtotime($dutyAssignmentDatas[0]["da_year_month"] . "01"));

        ///////////////////////////////////////////////////////////////////////
        // カレンダーの行数を設定する
        ///////////////////////////////////////////////////////////////////////
        // 日曜日始まりの場合は30日以上あると5行
        // 土曜日始まりの場合は31日あると5行
        $startYobi = date("w", strtotime($dutyAssignmentData[0]["da_year_month"] . "21"));
        if (($startYobi == 0 && $endDay >= 30) || ($startYobi == 6 && $endDay == 31)) {
            $this->copy($this->sheet, 16, 17, 22, 18, 1, false);
            $this->copy($this->sheet, 43, 44, 22, 45, 1, false);

            $this->sheet->mergeCells('B13:D13');
            $this->sheet->mergeCells('E13:G13');
            $this->sheet->mergeCells('H13:J13');
            $this->sheet->mergeCells('K13:M13');
            $this->sheet->mergeCells('N13:P13');
            $this->sheet->mergeCells('Q13:S13');
            $this->sheet->mergeCells('T13:V13');
            $this->sheet->getRowDimension(13)->setRowHeight(30.75);

            $this->sheet->mergeCells('B40:D40');
            $this->sheet->mergeCells('E40:G40');
            $this->sheet->mergeCells('H40:J40');
            $this->sheet->mergeCells('K40:M40');
            $this->sheet->mergeCells('N40:P40');
            $this->sheet->mergeCells('Q40:S40');
            $this->sheet->mergeCells('T40:V40');
            $this->sheet->getRowDimension(40)->setRowHeight(30.75);

            $this->sheet->removeRow(44, 1);
            $this->sheet->removeRow(17, 1);

            // 下部ページの開始行
            $underPageStartRow = 31;

            $monthTaskStartRow = 18;
        } else {
            // 下部ページの開始行
            $underPageStartRow = 32;
            $monthTaskStartRow = 19;
        }

        foreach ($dutyAssignmentDatas as $index => $dutyAssignmentData) {
            if ($index != 0) {
                $objSource = $this->sheet->copy();
                $objSource->setTitle($dutyAssignmentData["p_id"]);
                $objSource = $this->xl->addSheet($objSource, $index + 1);
            } else {
                $this->sheet->setTitle($dutyAssignmentData["p_id"]);
            }
        }

        foreach ($dutyAssignmentDatas as $index => $dutyAssignmentData) {
            $this->sheet = $this->xl->getSheet($index);
            ///////////////////////////////////////////////////////////////////////
            // ヘッダ部分の設定
            ///////////////////////////////////////////////////////////////////////
            // 日付
            $val = $targetMonth . "月度";
            $this->sheet->getCell("B7")->setValue($val);
            $this->sheet->getCell("B" . (7 + $underPageStartRow - 5))->setValue($val);

            $val = date("Y.n.j", strtotime($ymStart . "21")) . "-" . $targetMonth . ".20";
            $this->sheet->getCell("D7")->setValue($val);
            $this->sheet->getCell("D" . (7 + $underPageStartRow - 5))->setValue($val);

            // 右上のYYYY-mm-nnnの表示
            $val = date("Y-n", strtotime($dutyAssignmentData["da_year_month"] . "01"));
            $val .= "-" . $dutyAssignmentData["document_order"];
            $this->sheet->getCell("T1")->setValue($val);
            $this->sheet->getCell("T" . (1 + $underPageStartRow))->setValue($val);

            // 社員番号
            $val = $dutyAssignmentData["p_id"];
            $this->sheet->getCell("B10")->setValue($val);
            $this->sheet->getCell("B" . (10 + $underPageStartRow - 5))->setValue($val);
            // チーム
            $val = (strlen($dutyAssignmentData["crew_id"]) > 0) ? $dutyAssignmentData["team_id"] . "-" . $dutyAssignmentData["crew_id"] : $dutyAssignmentData["team_id"];
            $this->sheet->getCell("D10")->setValue($val);
            $this->sheet->getCell("D" . (10 + $underPageStartRow - 5))->setValue($val);
            // 名前
            $val = $dutyAssignmentData["name"];
            $this->sheet->getCell("F10")->setValue($val);
            $this->sheet->getCell("F" . (10 + $underPageStartRow - 5))->setValue($val);

            // 日数
            $val = $dutyAssignmentData["work_days"];
            $this->sheet->getCell("I10")->setValue($val);
            $this->sheet->getCell("I" . (10 + $underPageStartRow - 5))->setValue($val);

            // 時間
            $val = $dutyAssignmentData["work_hours"];
            $this->sheet->getCell("K10")->setValue($val);
            $this->sheet->getCell("K" . (10 + $underPageStartRow - 5))->setValue($val);

            // 超勤
            $val = $dutyAssignmentData["overtime25"] + $dutyAssignmentData["overtime35"];
            $this->sheet->getCell("M10")->setValue($val);
            $this->sheet->getCell("M" . (10 + $underPageStartRow - 5))->setValue($val);

            // 深夜
            $val = $dutyAssignmentData["night_work_hours"];
            $this->sheet->getCell("O10")->setValue($val);
            $this->sheet->getCell("O" . (10 + $underPageStartRow - 5))->setValue($val);

            // 休暇
            $val = $dutyAssignmentData["hd2_days"] + $dutyAssignmentData["hd3_days"] + $dutyAssignmentData["hd4_days"];
            $this->sheet->getCell("Q10")->setValue($val);
            $this->sheet->getCell("Q" . (10 + $underPageStartRow - 5))->setValue($val);

            // 日直
            $val = $dutyAssignmentData["day_duty"];
            $this->sheet->getCell("S10")->setValue($val);
            $this->sheet->getCell("S" . (10 + $underPageStartRow - 5))->setValue($val);

            // 宿直
            $val = $dutyAssignmentData["night_duty"];
            $this->sheet->getCell("U10")->setValue($val);
            $this->sheet->getCell("U" . (10 + $underPageStartRow - 5))->setValue($val);

            $row = 13;

            // カレンダー部分の表示
            for ($i = 0; $i < $endDay; $i++) {
                $yobi = date("w" , strtotime($ymStart . "21" . " +{$i} days"));
                $day =  date("j" , strtotime($ymStart . "21" . " +{$i} days"));

                $col = (($yobi + 6) % 7) * 3 + 1;

                $objRichText = new \PHPExcel_RichText();
                $objRichText->createText($day . "　");
                $prefix = "";
                $backgroundHolidayFlag = false;
                $backgroundColor = "";

                $workArray = explode("," , $dutyAssignmentData["d_{$day}"]);

                foreach ($workArray as $work) {
                    if (isset($taskMonthList[$work])) {
                        // 月次タスクマスタに設定されている場合
                        if ($taskMonthList[$work]["show_mark"] != "") {
                            $text = $objRichText->createTextRun($prefix . $taskMonthList[$work]["show_mark"]);
                            $text->getFont()->setSize(11);
                            $text->getFont()->setName("ゴシック");
                            $text->getFont()->getColor()->setRGB('000000');
                            $prefix = ",";
                        }

                        // 背景色が設定されている場合は設定する
                        if ($taskMonthList[$work]["frame_color"] != "" && !$backgroundHolidayFlag) {
                            $backgroundColor = $taskMonthList[$work]["frame_color"];
                        }
                    } else if (isset($this->codes1[$this->getCode1Key($work)])) {
                        // 通常のタスクに設定されている場合
                        if ($this->getCode1Disp($work) != "") {
                            if ($work == "D" && in_array("EW", $workArray)) {
                                // D勤のみの残務日の場合
                                $objBlue = $objRichText->createTextRun('D');
                                $objBlue->getFont()->getColor()->setRGB('0000FF');
                                $objBlue->getFont()->setSize(11);
                                $objBlue->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("EW", $workArray)) {
                                // DN勤の残務日の場合
                                $objBlue = $objRichText->createTextRun('D');
                                $objBlue->getFont()->getColor()->setRGB('0000FF');
                                $objBlue->getFont()->setSize(11);
                                $objBlue->getFont()->setName("ゴシック");
                                $text = $objRichText->createTextRun('N');
                                $text->getFont()->setSize(11);
                                $text->getFont()->setName("ゴシック");
                                $text->getFont()->getColor()->setRGB('000000');
                            } else if ($work == "D" &&  in_array("FKD", $workArray)) {
                                // D勤でD勤務帯兼務
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(11);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "N" &&  in_array("FKN", $workArray)) {
                                // N勤でN勤務帯兼務
                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(11);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("FKD", $workArray) && in_array("FKN", $workArray)) {
                                // DN勤でDN勤務帯兼務
                                $objRed = $objRichText->createTextRun('DN');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(11);
                                $objRed->getFont()->setName("ゴシック");
                            } else if ($work == "DN" && in_array("FKD", $workArray)) {
                                // DN勤でD勤務帯兼務
                                $objRed = $objRichText->createTextRun('D');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(11);
                                $objRed->getFont()->setName("ゴシック");
                                $text = $objRichText->createTextRun('N');
                                $text->getFont()->setSize(11);
                                $text->getFont()->setName("ゴシック");
                                $text->getFont()->getColor()->setRGB('000000');
                            } else if ($work == "DN" && in_array("FKN", $workArray)) {
                                // DN勤でN勤務帯兼務
                                $text = $objRichText->createTextRun('D');
                                $text->getFont()->setSize(11);
                                $text->getFont()->setName("ゴシック");
                                $text->getFont()->getColor()->setRGB('000000');

                                $objRed = $objRichText->createTextRun('N');
                                $objRed->getFont()->getColor()->setRGB('FF0000');
                                $objRed->getFont()->setSize(11);
                                $objRed->getFont()->setName("ゴシック");
                            } else {
                                $text = $objRichText->createTextRun($prefix . $this->getCode1Disp($work));
                                $text->getFont()->setSize(11);
                                $text->getFont()->setName("ゴシック");
                                $text->getFont()->getColor()->setRGB('000000');
                            }
                            $prefix = ",";
                        }

                        // 背景色が設定されている場合は設定する
                        if ($this->codes1[$this->getCode1Key($work)]["color"] != "" && !$backgroundHolidayFlag) {
                            if ($work !== "HD1") {
                                $backgroundColor = $this->codes1[$this->getCode1Key($work)]["color"];
                            } else {
                                $backgroundColor = "CCCCCC";
                            }

                            // 休みの場合
                            if (substr($this->getCode1Key($work), 0, 2) == "HD") {
                                $backgroundHolidayFlag = true;
                            }
                        }
                    } else {
                        // 月次・通常どちらのタスクにも設定されていない場合
                        // このケースは兼務日(FKD,FKN)と残務日(EW)
                    }
                }

                $this->sheet->getCellByColumnAndRow($col, $row)->setValue($objRichText);
                $this->sheet->getCellByColumnAndRow($col, $row + $underPageStartRow - 5)->setValue($objRichText);
                if ($backgroundColor != "") {
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setRGB($backgroundColor);
                    $this->sheet->getStyleByColumnAndRow($col, $row + $underPageStartRow - 5)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($col, $row + $underPageStartRow - 5)->getFill()->getStartColor()->setRGB($backgroundColor);
                }

                // 勤務内容が変更になっていなかチェック
                $changeFlag = false;

                foreach ($dutyLogDatas as $dutyLogData) {
                    if (strtotime($dutyLogData["date"]) == strtotime($ymStart . "21" . " +{$i} days")) {
                        $changeFlag = true;
                        break;
                    }
                }

                if ($changeFlag) {
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setRGB("B3FFB3");

                    $this->sheet->getStyleByColumnAndRow($col, $row + $underPageStartRow - 5)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
                    $this->sheet->getStyleByColumnAndRow($col, $row + $underPageStartRow - 5)->getFill()->getStartColor()->setRGB("B3FFB3");
                }

                if ($yobi == 0) {
                    $row++;
                }
            }

            ///////////////////////////////////////////////////////////////////////
            // 個人に設定されている月次マスタの表示
            ///////////////////////////////////////////////////////////////////////
            // 月次マスタの表示開始位置を設定
            $row = $monthTaskStartRow;

            for ($i = 0; $i < $endDay; $i++) {
                $day =  date("j" , strtotime($ymStart . "21" . " +{$i} days"));
                foreach ($taskMonthDatas as $taskMonthData) {
                    $works = explode(",", $dutyAssignmentData["d_{$day}"]);
                    foreach ($works as $work) {
                        if ($work === $taskMonthData["tm_id"]) {
                            $val = $taskMonthData["show_mark"] . " : ";
                            $val .= (strlen($taskMonthData["show_name"]) > 0) ? $taskMonthData["show_name"] : $taskMonthData["task_name"];
                            $val .= "   " .  date("n/j" , strtotime($ymStart . "21" . " +{$i} days"));

                            $val .= " " . $taskMonthData["start_time"] . " - " .$taskMonthData["end_time"];


                            $this->sheet->getCell("B" . $row)->setValue($val);
                            $this->sheet->getCell("B" . ($row + $underPageStartRow - 5))->setValue($val);

                            $row++;
                        }
                    }
                }
            }
        }
        return true;
    }
}

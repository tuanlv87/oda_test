<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;

class BackupComponent extends Component
{
	public $errors = [];

	public $debug_file = ".debug";

	public function createBackup($mtype, $myear_month=NULL)
	{
		$backup_path = Configure::read('backup_dir_path');
		if ($mtype > BACKUP_TYPE_NORMAL) {
			$backup_name = date('ymd').'_'.date('His').'_'.$mtype.'.dmp';
		} else {
			$backup_name = date('ymd').'_'.date('His').'.dmp';
		}

		if (file_exists($backup_path) === FALSE) {
			mkdir($backup_path, 0777, TRUE);
		}

		$Maintenances = TableRegistry::get('Maintenances');

		$Maintenances->connection()->begin();

		$data = [
			'mdate' => date('Y-m-d H:i:s'),
			'mname' => $backup_name,
			'mtype' => $mtype
		];

		if ($myear_month !== NULL) {
			$data['myear_month'] = $myear_month;
		}

		$maintenance = $Maintenances->newEntity($data);

		if ($Maintenances->save($maintenance) === FALSE)
		{
			$Maintenances->connection()->rollback();
			$this->errors = $maintenance->errors();
			Log::error($maintenance->errors());
			return FALSE;
		}
		else
		{
			// バックアップ前にコミットする
			$Maintenances->connection()->commit();

			$config = $Maintenances->connection()->config();

			$backup_file = $backup_path.'/'.$backup_name;
			$backup_cmd = Configure::read('backup_dump_cmd');
			$command = sprintf($backup_cmd, $config['database'], $config['host'], $config['username'], $config['password'], $backup_file);
			//Log::debug($command);
			// 実行
			$last_line = system($command, $retval);
			//Log::debug($last_line);

			$backup_cmd = Configure::read('backup_debug_dump_cmd');
			$command = sprintf($backup_cmd, $config['database'], $config['host'], $config['username'], $config['password'], $backup_file . $this->debug_file);
			$last_line = system($command, $retval);

			if (! file_exists($backup_file) || filesize($backup_file) == 0)
			{
				//$Maintenances->connection()->rollback();
				$this->errors = ['error'=>['バックアップに失敗しました。['.$retval.']']];
				Log::error('バックアップに失敗しました。['.$retval.']');
				return FALSE;
			}
			else
			{
				// 成功した場合、古いバックアップを削除する
				$maintenance_list = $Maintenances->find()->order([
					'mdate' => 'DESC'
				])->toArray();
				if (count($maintenance_list) > BACKUP_MAX_HISTORY)
				{
					for ($i=BACKUP_MAX_HISTORY; $i<count($maintenance_list); $i++) {
						$maintenance = $maintenance_list[$i];
						$backup_file = $backup_path.'/'.$maintenance->mname;
						$Maintenances->delete($maintenance);
						if (file_exists($backup_file)) {
							@unlink($backup_file);
						}
						if (file_exists($backup_file . $this->debug_file)) {
							@unlink($backup_file . $this->debug_file);
						}
					}
				}
			}
		}
		return TRUE;
	}

	public function errors()
	{
		return $this->errors;
	}
}

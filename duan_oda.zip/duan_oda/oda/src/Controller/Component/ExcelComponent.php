<?php
// Excel出力用ライブラリ
namespace App\Controller\Component;

use Cake\Core\Configure;
use Cake\Controller\Component;
use Cake\ORM\TableRegistry;

define('EXCEL_SHEET_PATH', ROOT.DS. 'excel' .DS);

class ExcelComponent extends Component{
    var $components = array('List');

    private $_xl;

    private $_extensions = array('Excel5' => '.xls',
                                 'Excel2007' => '.xlsx');


    public function initialize(array $config) {
        parent::initialize($config);

        // メッセージの取得
        Configure::load('message_settings');
        $this->errorMessages = Configure::read('message_settings.error_messages');

        // 設定値を取得
        Configure::load('documentation_settings');
        $this->codes1 = Configure::read('documentation_settings.codes1');
        $this->codes2 = Configure::read('documentation_settings.codes2');
        $this->prescribed_hours = Configure::read('documentation_settings.prescribed_hours');
        $this->prescribed_a2_hours = Configure::read('documentation_settings.prescribed_a2_hours');
        $this->working_hours = Configure::read('documentation_settings.working_hours');
        $this->night_working_hours = Configure::read('documentation_settings.night_working_hours');


        // 役職テーブルのデータを取得する
        $titles = TableRegistry::get('Titles');
        $titleDatas = $titles->find()->toArray();
        $this->titleList = $this->List->createList($titleDatas, "title_code");
        // 役職なしのデータも追加する
        $this->titleList[""] = ["title_display" => ""];
    }

    /**
     * テンプレートファイルを読み込む
     *
     * @param $templateFileName テンプレートファイル名
     * @param $type EXCELファイルの種類
     * @return PHPExcelオブジェクト
     */
    public function loadTemplate($templateFileName, $type) {
        // テンプレートを読み込んで、PHPExcelオブジェクトを生成する。
        $readSheet = EXCEL_SHEET_PATH . $templateFileName . $this->_extensions[$type];
        $reader = \PHPExcel_IOFactory::createReader($type);
        $this->_xl = $reader->load($readSheet);
        return $this->_xl;
    }

    /**
     * EXCELファイル作成する
     *
     * @param $userId ユーザID
     * @param $fileName ファイル名
     * @param $type EXCELファイルの種類
     * @return なし
     */
    public function makeExcel($userId, $fileName, $type) {
        // 指定した形式で出力
        $writer = \PHPExcel_IOFactory::createWriter($this->_xl, $type);

        // ファイル作成用のディレクトリ作成
        $tmpDir = $this->_createDirectory($userId);

        // 指定パスに出力
        $writer->save($tmpDir . $fileName . $this->_extensions[$type]);
    }

    /**
     * EXCELファイルを読み込みダウンロード出力する
     *
     * @param $userId ユーザID
     * @param $fileName ファイル名
     * @param $type EXCELファイルの種類
     * @return なし
     */
    public function downloadExcel($userId, $fileName, $type) {
        $filePath = $this->_getDirectory($userId) . $fileName . $this->_extensions[$type];

        if (!file_exists($filePath)) {
            throw new \Exception('指定したファイルのダウンロードに失敗しました。');
        }

        header('Content-Type: application/octet-stream');
        //ダウンロードするファイル名を設定
        header('Content-Disposition: attachment;filename="'. $fileName . $this->_extensions[$type] . '"');
        header("Content-Length:".filesize($filePath));
        readfile($filePath);
        exit();
    }

    /**
     * ユーザ毎にEXCELファイル格納フォルダのパスを返却する
     *
     * @param $userId ユーザID
     * @return ディレクトリパス
     */
    public function _getDirectory($userId) {
        return sys_get_temp_dir() .DS. $userId . DS;
    }

    /**
     * ユーザ毎にEXCELファイル格納フォルダを作成する
     *
     * @param $userId ユーザID
     * @return ディレクトリパス
     */
    private function _createDirectory($userId) {
        $tmpDir = $this->_getDirectory($userId);
        if (!file_exists($tmpDir)) {
            if (!mkdir($tmpDir)) {
                throw new \Exception('ディレクトリの作成に失敗しました({$tmpDir})');
            }
        }
        return $tmpDir;
    }

    /**
     * EXCELの行をコピーする
     * @param $sheet エクセルシートオブジェクト
     * @param $copyStartRow コピー元の開始行(0始まり)
     * @param $copyEndRow コピー元の終了行(0始まり)
     * @param $copyColNum コピーするカラム数
     * @param $pasteStartRow コピー先の開始行数(0始まり)
     * @param $pasteNum 複製する数
     * @param $valueCopyFlag 値もコピーするかどうかのフラグ
     * @return なし
     */
    public function copy(&$sheet, $copyStartRow, $copyEndRow, $copyColNum, $pasteStartRow, $pasteNum, $valueCopyFlag = false) {
        $count = 0;

        for ($i = 0; $i < $pasteNum; $i++) {
            for ($row = $copyStartRow; $row <= $copyEndRow; $row++) {
                for ($col = 0; $col < $copyColNum; $col++) {
                    $copyCell = $sheet->getStyleByColumnAndRow($col, $row);
                    $pasteCell = \PHPExcel_Cell::stringFromColumnIndex($col) . (string)($pasteStartRow + $count);

                    // スタイルをコピーする
                    $sheet->duplicateStyle($copyCell, $pasteCell);

                    if ($valueCopyFlag) {
                        $copyVal = $sheet->getCellByColumnAndRow($col, $row)->getValue();
                        $sheet->getCellByColumnAndRow($col, ($pasteStartRow + $count))->setValue($copyVal);
                    }
                }

                // 行の高さを設定する
                $rowHeight = $sheet->getRowDimension($row)->getRowHeight();
                $sheet->getRowDimension($pasteStartRow + $count)->setRowHeight($rowHeight);

                // TODO:結合が必要な場合はここで処理する
                $count++;
            }
        }
    }

    /*
     * EXCELファイルを作成する
     * （A010Componentを参考に個別に_createExcel()を作成する必要がある）
     *
     * @param $req リクエストデータ
     * @param $userId ユーザID
     * @param $fileName ファイル名
     * @error $error エラーメッセージ
     * @return 真偽値 true:ファイル作成成功 false:ファイル作成失敗
     */
    public function createExcel($req, $userId, &$fileName, &$error) {


        // テンプレートファイルの読み込み
        $this->xl = $this->loadTemplate($this->templateType, "Excel2007");

        // シートの選択
        $this->xl->setActiveSheetIndex(0);
        $this->sheet = $this->xl->getActiveSheet();

        $result = $this->_createExcel($req, $fileName, $error);

        if ($result) {
            // カーソルの位置をA1にする
            $this->sheet->setSelectedCells('A1');

            // ファイルの出力
            $this->makeExcel($userId, $fileName, "Excel2007");

            unset($this->xl);
            return true;
        } else {
            unset($this->xl);
            return false;
        }
    }

    /*
     * code1のコードを取得する
     * ME1nnなどように下２桁が連番になる場合があるため、
     * ME101-ME199 => ME1nnに変換する
     *
     * @param $code1（連番の状態）
     * @return コード
     */
    public function getCode1Key($code1) {
        // FE00, FD00は特殊なため、除外する
        if (preg_match("/[0-9]{2}$/", $code1) && $code1 !== "FE00" && $code2 !== "FD00") {
            return preg_replace("/[0-9]{2}$/", "nn", $code1);
        } else {
            return $code1;
        }
    }

    /*
     * code2のコードを取得する
     * ME1nnなどように下２桁が連番になる場合があるため、
     * ME101-ME199 => ME1nnに変換する
     *
     * @param $code2（連番の状態）
     * @return コード
     */
    public function getCode2Key($code2) {
        // FE00, FDXXは特殊なため、除外する
        if (preg_match("/[0-9]{2}$/", $code2) && $code2 !== "FE00" && !preg_match("/^FD[0-9]{2}$/", $code2)) {
            return preg_replace("/[0-9]{2}$/", "nn", $code2);
        } else if (preg_match("/^FD[0-9]{2}$/", $code2)) {
            $no = substr($code2, 2);
            if ($no <= 50) {
                return "FDmm";
            } else {
                return "FDnn";
            }
        } else {
            return $code2;
        }
    }

    /*
     * code1の表示を取得する
     * Hnnのように連番になる場合は連番で表示する
     *
     * @param $code1（連番の状態）
     * @return 表示
     */
    public function getCode1Disp($code1) {
        $code1Key = $this->getCode1Key($code1);

        $disp = $this->codes1[$code1Key]["disp"];

        if (preg_match("/nn$/", $disp)) {
            return substr($disp, 0, -2) . substr($code1, -2);
        } else {
            return $disp;
        }
    }

    /*
     * 勤務内容をコード毎に集計する
     *
     * @param $data 勤務表テーブルのレコード
     * @return 集計後のデータ
     */
    public function getCalcDuty($data) {
        $result = [];

        for ($i = 1; $i <= 31; $i++) {
            $duty = $data["d_{$i}"];
            $duties = explode(",", $duty);

            foreach($duties as $val) {
                $code = $this->getCode1Key($val);
                $result[$code] = (isset($result[$code])) ? $result[$code] + 1 : 1;
            }
        }

        return $result;
    }
}

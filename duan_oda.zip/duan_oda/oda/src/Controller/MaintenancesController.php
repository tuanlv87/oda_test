<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Validation\Validator;

/**
 * Maintenance Controller
 */
class MaintenancesController extends AppController
{
	public $components = [
		'Backup'
	];

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

    /**
     * Index page
     */
	public function index()
	{
		$this->set('sideNavi', array('maintenance'=>'index'));
		$this->setTitle('システム保守', '');
	}

    /**
     * Backup page
     */
	public function backup()
	{
		$this->set('sideNavi', array('maintenance'=>'backup'));
		$this->setTitle('システム保守', 'バックアップ');

		if ($this->request->is('POST'))
		{
			if ($this->Backup->createBackup(BACKUP_TYPE_NORMAL) === FALSE) {
				$this->set('errors', $this->Backup->errors());
			}
//			$backup_path = Configure::read('backup_dir_path');
//			$backup_name = date('ymd').'_'.date('His').'.dmp';
//
//			if (file_exists($backup_path) === FALSE) {
//				mkdir($backup_path, 0777, TRUE);
//			}
//
//			$maintenance = $this->Maintenances->newEntity([
//				'mdate' => date('Y-m-d H:i:s'),
//				'mname' => $backup_name
//			]);
//
//			if ($this->Maintenances->save($maintenance) === FALSE)
//			{
//				$this->set('errors', $maintenance->errors());
//				Log::error($maintenance->errors());
//			}
//			else
//			{
//				$config = $this->Maintenances->connection()->config();
//
//				$backup_file = $backup_path.'/'.$backup_name;
//				$backup_cmd = Configure::read('backup_dump_cmd');
//				$command = sprintf($backup_cmd, $config['database'], $config['host'], $config['username'], $config['password'], $backup_file);
//				//Log::debug($command);
//				// 実行
//				$last_line = system($command, $retval);
//				//Log::debug($last_line);
//
//				if (! file_exists($backup_file) || filesize($backup_file) == 0)
//				{
//					$this->set('errors', ['error'=>['バックアップに失敗しました。['.$retval.']']]);
//					Log::error($retval);
//					$this->Maintenances->delete($maintenance);
//				}
//				else
//				{
//					// 成功した場合、古いバックアップを削除する
//					$maintenance_list = $this->Maintenances->find()->order([
//						'mdate' => 'DESC'
//					])->toArray();
//					if (count($maintenance_list) > BACKUP_MAX_HISTORY)
//					{
//						for ($i=BACKUP_MAX_HISTORY; $i<count($maintenance_list); $i++) {
//							$maintenance = $maintenance_list[$i];
//							$backup_file = $backup_path.'/'.$maintenance->mname;
//							$this->Maintenances->delete($maintenance);
//							if (file_exists($backup_file)) {
//								@unlink($backup_file);
//							}
//						}
//					}
//				}
//			}
			return $this->render('backup_save');
		}
	}

    /**
     * Restore page
     */
	public function restore()
	{
		set_time_limit(6000);
		$this->set('sideNavi', array('maintenance'=>'restore'));
		$this->setTitle('システム保守', 'リストア');

		if ($this->request->is('POST'))
		{
			// 交代要員社員番号の入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('mdate', TRUE, '日付を選択してください。');

			$errors = $validator->errors($this->request->data());

			if ($errors)
			{
				$this->set('errors', $errors);
			}
			else
			{
				$id = $this->request->data('mdate');
				$maintenance = $this->Maintenances->get($id);

				if ($maintenance !== NULL)
				{
					$backup_path = Configure::read('backup_dir_path');
					$backup_name = $maintenance->mname;

					$config = $this->Maintenances->connection()->config();

					$backup_file = $backup_path.'/'.$backup_name;

					if (file_exists($backup_file))
					{
						$backup_cmd = Configure::read('backup_restore_cmd');
						$command = sprintf($backup_cmd, $config['database'], $config['host'], $config['username'], $config['password'], $backup_file);

						// 実行
						$last_line = system($command, $retval);
					}
					else
					{
						$last_line = FALSE;
						$retval = 'バックアップファイルが存在しません。'.$backup_file;

					}

					if ($last_line === FALSE) {
						$this->set('errors', ['error'=>['リストアに失敗しました。['.$retval.']']]);
						Log::error($retval);
					}
				}
				return $this->render('restore_save');
			}
		}

		$maintenance_list = $this->Maintenances->find()->order([
			'mdate' => 'DESC'
		])->limit(BACKUP_MAX_HISTORY)->toArray();

		$this->set('maintenance_list', $maintenance_list);
	}

	public function debug_download()
	{
		$this->set('sideNavi', ['maintenance'=>'index']);
		$this->setTitle('システム保守', 'デバッグ用ダウンロード');

		if ($this->request->is('POST'))
		{
			// 交代要員社員番号の入力チェック
			$validator = new Validator();
			$validator
				->requirePresence('mdate', TRUE, '日付を選択してください。');

			$errors = $validator->errors($this->request->data());

			if ($errors)
			{
				$this->set('errors', $errors);
			}
			else
			{
				$id = $this->request->data('mdate');
				$maintenance = $this->Maintenances->get($id);

				if ($maintenance !== NULL)
				{
					$backup_path = Configure::read('backup_dir_path');
					$backup_name = $maintenance->mname;

					$config = $this->Maintenances->connection()->config();

					$backup_file = $backup_path.'/'.$backup_name . $this->Backup->debug_file;
					$download_file = TMP . $backup_name;

					$last_line = TRUE;

					if (file_exists($backup_file))
					{
						$this->loadModel('Personnels');
						$personnel_team_keys = [];
						$personnel_list = $this->Personnels->find()->toArray();
						if (count($personnel_list)>0) {
							foreach ($personnel_list as $d) {
								$personnel_team_keys[$d->p_id] = $d->team_id;
							}
						}

						$r_fp = @fopen($backup_file, 'r');
						$w_fp = @fopen($download_file, 'w');

						if ($r_fp && $w_fp)
						{
							$pdata = [];
							while (($line = fgets($r_fp)) !== FALSE)
							{
								// 氏名の変換
								if (substr($line, 0, 31) === 'INSERT INTO `duty_assignments` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),([\-0-9]+),([0-9]+),'([^']+)','([^']+)','([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[4];
										$mask_name = $personnel_team_keys[$m[4]] . $mask_id;

										$ostr = " VALUES (".$m[1].",".$m[2].",".$m[3].",'".$m[4]."','".$m[5]."','".$m[6]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",".$m[3].",'".$mask_id."','".$mask_name."','".$mask_name."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 25) === 'INSERT INTO `duty_works` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),([0-9]+),'([^']+)','([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[4];

										$ostr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$mask_id."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 24) === 'INSERT INTO `duty_logs` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),([0-9]+),'([^']+)','([^']+)','([^']+)','([^']+)','([^']*)','([^']*)','([^']+)','([^']+)','([^']*)','([^']*)','([^']+)','([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[5];
										$mask_name = $personnel_team_keys[$m[5]] . $mask_id;
										$mask_id1 = 10000 - $m[9];
										$mask_name1 = $personnel_team_keys[$m[9]] . $mask_id1;
										$mask_id2 = 10000 - $m[13];
										$mask_name2 = $personnel_team_keys[$m[13]] . $mask_id2;

										$ostr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."','".$m[5]."','".$m[6]."','".$m[7]."','".$m[8]."','".$m[9]."','".$m[10]."','".$m[11]."','".$m[12]."','".$m[13]."','".$m[14]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."','".$mask_id."','".$mask_name."','".$m[7]."','".$m[8]."','".$mask_id1."','".$mask_name1."','".$m[11]."','".$m[12]."','".$mask_id2."','".$mask_name2."',";
										$line = str_replace($ostr, $cstr, $line);
									}
									else if (preg_match("/ VALUES \(([0-9]+),([0-9]+),'([^']+)','([^']+)','([^']+)','([^']+)','([^']*)','([^']*)','([^']+)','([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[5];
										$mask_name = $personnel_team_keys[$m[5]] . $mask_id;
										$mask_id1 = 10000 - $m[9];
										$mask_name1 = $personnel_team_keys[$m[9]] . $mask_id1;

										$ostr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."','".$m[5]."','".$m[6]."','".$m[7]."','".$m[8]."','".$m[9]."','".$m[10]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."','".$mask_id."','".$mask_name."','".$m[7]."','".$m[8]."','".$mask_id1."','".$mask_name1."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 25) === 'INSERT INTO `personnels` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),([\-0-9]+),'([^']+)','([^']+)','([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[3];
										$mask_name = $personnel_team_keys[$m[3]] . $mask_id;

										if ($m[4]) {
											// 変換前日本語名をキーにしている
											$name_key = str_replace([' ','　'], '', $m[4]);
											$pdata[$name_key] = $mask_name;
										}

										$ostr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."','".$m[4]."','".$m[5]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",'".$mask_id."','".$mask_name."','".$mask_name."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 30) === 'INSERT INTO `personnel_years` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),([\-0-9]+),'([^']+)',/", $line, $m))
									{
										$mask_id = 10000 - $m[3];
										$mask_name = $personnel_team_keys[$m[3]] . $mask_id;

										$ostr = " VALUES (".$m[1].",".$m[2].",'".$m[3]."',";
										$cstr = " VALUES (".$m[1].",".$m[2].",'".$mask_id."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 26) === 'INSERT INTO `task_months` ')
								{
									if (preg_match("/,'([^']+)','([^']+)','([^']+)','([^']+)','([^']+)'\);/", $line, $m))
									{
										$new_str ='';
										if ($m[1]!='')
										{
											$arr = explode(';', str_replace(['；','、',','], ';', $m[1]));
											foreach ($arr as $i => $str)
											{
												$str = str_replace([' ','　'], '', $str);
												if (isset($pdata[$str])) {
													$arr[$i] = $pdata[$str];
												}
											}
											$new_str = implode(';', $arr);
										}

										$ostr = ",'".$m[1]."','".$m[2]."','".$m[3]."','".$m[4]."','".$m[5]."');";
										$cstr = ",'".$new_str."','".$m[2]."','".$m[3]."','".$m[4]."','".$m[5]."');";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								else if (substr($line, 0, 20) === 'INSERT INTO `users` ')
								{
									if (preg_match("/ VALUES \(([0-9]+),'([^']+)',([0-9]+),'([^']+)','([^']+)',/", $line, $m))
									{
										$ostr = " VALUES (".$m[1].",'".$m[2]."',".$m[3].",'".$m[4]."','".$m[5]."',";
										$cstr = " VALUES (".$m[1].",'".$m[2]."',".$m[3].",'".$m[2]."','".$m[2]."',";
										$line = str_replace($ostr, $cstr, $line);
									}
								}
								fwrite($w_fp, $line);
							}
							fclose($w_fp);
							fclose($r_fp);
						}
					}
					else
					{
						$last_line = FALSE;
						$retval = 'バックアップファイルが存在しません。'.$backup_file;

					}

					if ($last_line === FALSE || ! file_exists($download_file) || ! filesize($download_file)) {
						$this->set('errors', ['error'=>['ダウンロードに失敗しました。']]);
						Log::error($retval);
					}
					else
					{
						// ダウンロード
						header("Content-Type: application/octet-stream");
						header("Content-Disposition: attachment; filename=".$backup_name);
						readfile($download_file);
						exit;
					}
				}
				return $this->render('debug_download_save');
			}
		}

		$maintenance_list = $this->Maintenances->find()->order([
			'mdate' => 'DESC'
		])->limit(BACKUP_MAX_HISTORY)->toArray();

		$this->set('maintenance_list', $maintenance_list);
	}
}

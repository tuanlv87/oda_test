<?php
namespace App\Controller;

use App\Model\Table\DutyWorksTable;
use Cake\Core\Configure;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;

/**
 *
 */
class HolidayController extends AppController
{
	public $components = [
		'Duty'
	];

	public $default_year;
	public $default_month;
	public $errors = [];
	public $warnings = [];
	public $task_errors = [];

	/**
	 * 0:休暇設定、1:日程表編集
	 *
	 * @var int
	 */
	public $edit_mode = 0;

	public function initialize()
	{
		parent::initialize();

		$this->loadModel('DutyAssignments');
		$this->loadModel('DutyEnvs');

		$this->set('sideNavi', ['holiday'=>'form']);
		$this->setTitle('日程表管理', '休暇設定');

		$this->default_year = date('Y');
		$this->default_month = date('n');

		$year_options = [];
		for ($i=0; $i<5; $i++) {
			$year_options[SELECT_START_YEAR + $i] = SELECT_START_YEAR + $i;
		}
		$this->set('year_options', $year_options);
		$this->set('month_options', Configure::read('select_month_list'));

		$this->set('duty_env_list', $this->getDutyEnvsList(DE_STATUS_INIT));
	}

	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	public function form()
	{

	}

	private function getDutyEnvsList($status)
	{
		$DutyEnvs = TableRegistry::get('DutyEnvs');
		// 初期化済で今月以降のもの
		$duty_env_list = $DutyEnvs->find()->where([
			'status' => $status
		])->order([
			'de_year_month' => 'DESC'
		])->limit(10)->toArray();

		return $duty_env_list;
	}

	public function edit()
	{
		Configure::load('form_settings');

        if ($this->edit_mode == 1) {
            $this->set('form_settings', Configure::read('form_settings.duty_update'));
        } else {
            $this->set('form_settings', Configure::read('form_settings.duty_assignment'));
        }

		$duty_assignment = NULL;
		$year_month = 0;
		$year = 0;
		$month = 0;
		$p_id = NULL;
		$ret = '';
		$log_id = 0;
		$new_flag = 0;

		if ($this->request->is('POST'))
		{
			$year = $this->request->data('_year');
			$month = $this->request->data('_month');
			$p_id = $this->request->data('_p_id');
			$ret = $this->request->data('ret');
			$log_id = $this->request->data('_log_id');
			$new_flag = $this->request->data('_new_flag');
		}
		else
		{
			$year_month = $this->request->query('year_month');
			if (strlen($year_month)>=6) {
				$year = (int) substr($year_month, 0, 4);
				$month = (int) substr($year_month, 4, 2);
			} else {
				$year = $this->request->query('year');
				$month = $this->request->query('month');
				if ($this->edit_mode == 1) {
					if (empty($year) || empty($month)) {
						$year = $this->default_year;
						$month = $this->default_month;
					}
				}
			}
			$p_id = $this->request->query('p_id');
			$ret = $this->request->query('ret');
			$log_id = $this->request->query('log_id');
			$new_flag = $this->request->query('new_flag');
		}

		if ($this->edit_mode == 1)
		{
			// 一覧から編集を開いた場合
			if (empty($log_id))
			{
				$DutyLogs = TableRegistry::get('DutyLogs');
				$log_id = $DutyLogs->getValidLogId(sprintf('%04d%02d', $year, $month));
				if ($log_id > 0) {
					// 継続ログNOがある場合
					$new_flag = 0;
				} else {
					$url = "/duty_update/form_pid?year=".$year."&month=".$month."&p_id=".$p_id;
					if ($ret!='') {
						$url .= '&ret='.$ret;
					}
					$this->redirect($url);
				}
			}
		}

		if ($p_id) {
			// 最新の日程表
			$duty_assignment = $this->DutyAssignments->find()->where([
				'da_year_month' => sprintf('%04d%02d', $year, $month),
				'p_id' => $p_id
			])->first();
		}

		if ($duty_assignment === NULL)
		{
			if ($this->edit_mode == 1)
			{
				if (empty($p_id)) {
					$this->set('errors', ['p_id' => ['編集更新する社員番号を入力してください。']]);
				} else {
					$this->set('errors', ['p_id' => ['該当する社員番号は存在しません。']]);
					$this->set('p_id', $p_id);
				}
				$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);
				return $this->render('form_pid');
			}
			else
			{
				if (empty($p_id)) {
					$this->set('errors', ['p_id' => ['休暇設定する社員番号を入力してください。']]);
				} else if (empty($year)) {
					$this->set('errors', ['year' => ['休暇設定する年を選択してください。']]);
					$this->set('errors', ['year_month' => ['休暇設定する年月を選択してください。']]);
				} else if (empty($month)) {
					$this->set('errors', ['month' => ['休暇設定する月を選択してください。']]);
					$this->set('errors', ['year_month' => ['休暇設定する年月を選択してください。']]);
				} else {
					$this->set('errors', ['p_id' => ['該当する社員番号は存在しません。']]);
					$this->set('p_id', $p_id);
				}
				$this->set('year_selected', $year);
				$this->set('month_selected', $month);
				return $this->render('form');
			}
		}
		else if ($this->request->is('POST'))
		{
			$this->set('values', $this->request->data);
			$this->set('duty_assignment', $duty_assignment);
		}
		else
		{
			$this->set('values', $duty_assignment);
			$this->set('duty_assignment', $duty_assignment);
		}

		$this->set('_p_id', $p_id);
		$this->set('_year', $year);
		$this->set('_month', $month);
		$this->set('ret', $this->createReturnUrl($ret, 'form'));
		$this->set('_log_id', $log_id);
		$this->set('_new_flag', $new_flag);

		$DutyEnvs = TableRegistry::get('DutyEnvs');
		$dut_env = $DutyEnvs->find()->where(['de_year_month'=>sprintf('%04d%02d', $year, $month)])->first();
		$this->set('env_status', $dut_env->status);

		if ($this->edit_mode == 1) {
			$this->getLogList(sprintf('%04d%02d', $year, $month), $log_id);
		}
	}

	public function edit_confirm()
	{
		$this->_edit('confirm');
	}

	public function edit_save()
	{
		$this->_edit('save');
	}

	private function _edit($mode)
	{
		if ($this->request->is('POST') === FALSE) {
			return $this->redirect(['action' => 'form']);
		}

		Configure::load('form_settings');

        if ($this->edit_mode == 1) {
            $this->set('form_settings', Configure::read('form_settings.duty_update'));
        } else {
            $this->set('form_settings', Configure::read('form_settings.duty_assignment'));
        }

		$year = $this->request->data('_year');
		$month = $this->request->data('_month');
		$p_id = $this->request->data('_p_id');
		$ret = $this->request->data('ret');
		$end_log = $this->request->data('end_log');
		$originals = NULL;

		if (empty($p_id)) {
			throw new FatalErrorException("p_idの指定がありません。");
		}

		// 最新の日程表
		$duty_assignment = $this->DutyAssignments->find()->where([
			'da_year_month' => sprintf('%04d%02d', $year, $month),
			'p_id' => $p_id
		])->first();

		if ($duty_assignment === NULL) {
			throw new FatalErrorException("日程表が見つかりません。");
		}

//		$DutyEnvs = TableRegistry::get('DutyEnvs');
//		$dut_env = $DutyEnvs->find()->where(['de_year_month'=>sprintf('%04d%02d', $year, $month)])->first();

		$change_flag = FALSE;

		// 編集更新時のみ実行
		if ($this->edit_mode == 1)
		{
			$change_flag = $this->changeTaskCode($p_id, sprintf('%04d%02d', $year, $month), $mode==='save'?TRUE:FALSE, $duty_assignment->name);
			if (count($this->errors)>0)
			{
				$this->set('duty_assignment', $duty_assignment);
				$this->set('errors', ['duty_days' => $this->errors]);
				$this->set('values', $this->request->data);
				$this->set('_p_id', $p_id);
				$this->set('_year', $year);
				$this->set('_month', $month);
				$this->set('_log_id', $this->request->data('_log_id'));
				$this->set('ret', $ret);
				return $this->render('edit');
			}

			$this->set('warnings', $this->warnings);

			if ($end_log > 0)
			{
				$this->set('task_errors', $this->task_errors);
			}
		}

		$originals = clone $duty_assignment;

		$duty_assignment_entity = $this->DutyAssignments->patchEntity($duty_assignment, $this->request->data);

		if ($duty_assignment_entity->errors())
		{
			$this->set('duty_assignment', $duty_assignment);
			$this->set('errors', $duty_assignment->errors());

			$this->set('values', $this->request->data);
			$this->set('_p_id', $p_id);
			$this->set('_year', $year);
			$this->set('_month', $month);
			$this->set('ret', $ret);
			if ($this->edit_mode == 1) {
				$this->set('_log_id', $this->request->data('_log_id'));
			}
			return $this->render('edit');
		}
		else if ($mode === 'save')
		{
			//$this->DutyAssignments->connection()->begin();
			$is_err = FALSE;

			if ($this->DutyAssignments->save($duty_assignment_entity) === FALSE) {
				$this->DutyAssignments->connection()->rollback();
				Log::error($duty_assignment_entity->errors());
				Log::error('保存に失敗しました。');
				$is_err = TRUE;
			}

			// 再集計
			if ($change_flag) {
				if ($this->Duty->reTotalize(sprintf('%04d%02d', $year, $month), $p_id) === FALSE) {
					//$this->DutyAssignments->connection()->rollback();
					Log::error('再集計に失敗しました。');
					$is_err = TRUE;
				}
			}

			if ($is_err === FALSE) {

				if ($this->edit_mode == 0) {
					$env_set = [
						'holiday_flag' => 1
					];
				} else {
					$env_set = [
						'update_flag' => 1
					];
				}

				$query = $this->DutyEnvs->query();
				$query->update()->set($env_set)->where([
					'de_year_month' => $duty_assignment->da_year_month
				])->execute();

				//$this->DutyAssignments->connection()->commit();
			}
		}

		$this->set('duty_assignment', $duty_assignment);
		$this->set('originals', $originals);
		$this->set('values', $this->request->data);
		$this->set('_p_id', $p_id);
		$this->set('ret', $this->createReturnUrl($ret));
	}

	private function checkDutyType($year_month)
	{
		$DutyWorks = TableRegistry::get('DutyWorks');
		$duty_work_map = $DutyWorks->getDayMap($year_month);

		foreach ($duty_work_map as $day => $dd)
		{
			$col = 'd_'.$day;
			$d_val = $this->request->data($col);
			$d_arr = ($d_val !== NULL) ? explode(',', $d_val) : [];
			$o_arr = [];
			foreach ($dd as $duty_type => $d)
			{
				if (in_array($duty_type, $d_arr) === FALSE) {
					// 無い場合はどこかから追加されたもの
					if (preg_match("/^HD[0-9]+/", $subject)) {
						// 休日の追加はOK
					}
				}

				$o_arr[] = $duty_type;
			}
		}

		foreach (Configure::read('day_order_array') as $day)
		{
			$col = 'd_'.$day;
			$d_val = $this->request->data($col);
			if ($d_val !== NULL) {

			}
		}
	}

	private function changeTaskCode($p_id, $year_month, $save_flag, $name)
	{
		$Tasks = TableRegistry::get('Tasks');
		$TaskMonths = TableRegistry::get('TaskMonths');
		$DutyWorks = TableRegistry::get('DutyWorks');
		$DutyLogs = TableRegistry::get('DutyLogs');
		$DutyAssignments = TableRegistry::get('duty_assignments');

		$error_flag = FALSE;
		$change_flag = FALSE;
		$change_days = [];
		$check_days = [];
		$log_id = $this->request->data('_log_id');
		$end_log = $this->request->data('end_log');
		$duty_update_code_list = Configure::read("duty_update_code_list");

		if ($save_flag)
		{
			$DutyWorks->connection()->begin();
		}

		foreach ([21,22,23,24,25,26,27,28,29,30,31,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] as $day)
		{
			$d_name = 'd_'.$day;
			$d_val = $this->request->data($d_name);
			$is_change = FALSE;

			$add_duty_list = [];

			$duty_type_map = $DutyWorks->getDutyTypeMap($p_id, $year_month, $day);
			$copy_duty_type_map = $duty_type_map;

			if ($d_val != '')
			{
				$d_val = mb_convert_kana($d_val, 'a');
				$d_arr = explode(',', $d_val);

				$check_days[$day] = [];

				foreach ($d_arr as $duty_type)
				{
					$duty_type = trim($duty_type);

					if ($duty_type != '')
					{
						// 新規追加分
						if (isset($duty_type_map[$duty_type]) === FALSE)
						{
							if (preg_match("/^HD[0-9]+/", $duty_type))
							{
								if ($save_flag)
								{
									$duty_work = $this->changeTaskWork($DutyWorks, $duty_type, $p_id, $year_month, $day);
									if ($duty_work!==TRUE && $duty_work->errors()) {
										Log::error($duty_work->errors());
										$error_flag = TRUE;
										break 2;
									}
								}
								$change_flag = TRUE;
								$is_change = TRUE;
								continue;
							}
							$task = $Tasks->getTask($duty_type);
							if ($task !== NULL)
							{
								// 定常タスクの追加
								$add_duty_list[] = $duty_type;

								if ($save_flag)
								{
									$duty_work = $this->changeTaskWork($DutyWorks, $task, $p_id, $year_month, $day);
									if ($duty_work!==TRUE && $duty_work->errors()) {
										Log::error($duty_work->errors());
										$error_flag = TRUE;
										break 2;
									}
								}
								$check_days[$day][$duty_type] = 1;
								// 定常タスクはタスクIDをD or Nに変換する
								$d_val = str_replace($duty_type, $task->night_day, $d_val);
								$change_flag = TRUE;
								$is_change = TRUE;
								continue;
							}
							$task = $TaskMonths->getTaskMonth($duty_type, $year_month);
							if ($task !== NULL)
							{
								if ($save_flag)
								{
									$duty_work = $this->changeTaskWork($DutyWorks, $task, $p_id, $year_month, $day);
									if ($duty_work!==TRUE && $duty_work->errors()) {
										Log::error($duty_work->errors());
										$error_flag = TRUE;
										break 2;
									}
								}
								$check_days[$day][$duty_type] = 1;
								$change_flag = TRUE;
								$is_change = TRUE;
								continue;
							}
							if (isset($duty_update_code_list[$duty_type])) {
								if ($save_flag)
								{
									$duty_work = $this->changeTaskWork($DutyWorks, $duty_type, $p_id, $year_month, $day);
									if ($duty_work!==TRUE && $duty_work->errors()) {
										Log::error($duty_work->errors());
										$error_flag = TRUE;
										break 2;
									}
								}

								$change_flag = TRUE;
								$is_change = TRUE;
								continue;
							}
							// 存在しないコードを入力された場合
							$this->errors[] = $day.'日の「'.$duty_type.'」は存在しないタスクのIDです。';
 						}
						else
						{
							// 登録済み変更なし
							$duty_type_map[$duty_type] = NULL;
							unset($duty_type_map[$duty_type]);
						}
					}
				}
			}
			// 残っているものは削除対象
			if (count($duty_type_map)>0)
			{
				foreach ($duty_type_map as $key => $delete_duty_work)
				{
					if (preg_match("/^[+-]/", trim($key))){
						$this->errors[] = $day."日の".$key ."を削除することはできません。";
						continue;
					}

					if ($delete_duty_work)
					{
						if ($save_flag)
						{
							$DutyWorks->delete($delete_duty_work);
						}

						$check_days[$day][$delete_duty_work->task_id] = -1;
						$change_flag = TRUE;
						$is_change = TRUE;
					}
				}
			}

			// 簡易チェック
			if ($d_val != '')
			{
				$d_tmp_arr = explode(',', $d_val);
				$d_arr = [];

				foreach ($d_tmp_arr as $d_tmp)
				{
					if (!preg_match('/^[+-]/', $d_tmp))
					{
						$d_arr[] = $d_tmp;
					}
				}

				// D or Nが重複していないかチェック
				$d_check = 0;
				$n_check = 0;
				$hd_check = 0;
				$hd1_check = false;
				$hd5_check = false;
				$hd6_check = false;
				$task_month_check = 0;
				$task_months = [];
				$check_flag = false;
				$task_times = [];
				$tasks = [];
				$dw_flag = false;
				$nw_flag = false;
				$fkd_flag = false;
				$fkn_flag = false;
				$ew_flag = false;
				$fe00_flag = false;

				foreach ($d_arr as $d_tmp)
				{
					// D勤務
					if (trim($d_tmp) === DAT_CODE_D) {
						$d_check++;
						$task_times[] = ["start_time" => DAT_D_START_TIME, "end_time" => DAT_D_END_TIME];
					// N勤務
					}
					else if (trim($d_tmp) === DAT_CODE_N) {
						$n_check++;
						$task_times[] = ["start_time" => DAT_N_START_TIME, "end_time" => DAT_N_END_TIME];
					}
					// 休暇
					else if (preg_match('/^HD[0-9]+$/', trim($d_tmp) )) {
						$hd_check++;
						if (trim($d_tmp) == DAT_CODE_SHITEI) {
							$hd1_check = true;
						}
						if (trim($d_tmp) == DAT_CODE_KOUKYU) {
							$hd5_check = true;
						}
						if (trim($d_tmp) == DAT_CODE_AKE) {
							$hd6_check = true;
						}
					}
					// 月次タスク
					else if ($task = $TaskMonths->getTaskMonth(trim($d_tmp), $year_month)) {
						$task_month_check++;
						$task_month[] = $task;
						if (strlen($task->start_time) > 0 && strlen($task->end_time) > 0) {
							$task_times[] = ["start_time" => $task->start_time, "end_time" => $task->end_time];
						} else if ($task->duty_type == "D") {
							$task_times[] = ["start_time" => DAT_D_START_TIME, "end_time" => DAT_D_END_TIME];
						} else if ($task->duty_type == "N") {
							$task_times[] = ["start_time" => DAT_N_START_TIME, "end_time" => DAT_N_END_TIME];
						} else {
							// 時間が不明なのでチェックできない
						}
					}
					// 日直
					else if (trim($d_tmp) == DAT_CODE_DW) {
						$dw_flag = true;
					}
					// 宿直
					else if (trim($d_tmp) == DAT_CODE_NW) {
						$nw_flag = true;
					}
					// 兼務日(D)
					else if (trim($d_tmp) == DAT_CODE_FKD) {
						$fkd_flag = true;
					}
					// 兼務日(N)
					else if (trim($d_tmp) == DAT_CODE_FKN) {
						$fkn_flag = true;
					}
					// 残務日
					else if (trim($d_tmp) == DAT_CODE_EW) {
						$ew_flag = true;
					}
					// 定期消防訓練
					else if (trim($d_tmp) == DAT_CODE_FE00) {
						$fe00_flag = true;
					}

					// 重複チェック
					if (isset($tasks[$d_tmp])) {
						$tasks[$d_tmp]++;
					} else {
						$tasks[$d_tmp] = 1;
					}
				}

				if (count($add_duty_list) > 0) {
					if ($day >= 21) {
						$target_date = date("Y/m/01", strtotime($year_month."01 -1 month"));
						$target_date = date("Y/m/d", strtotime($target_date . "+ ".$day . "day"));
						$target_date = date("Y/m/d", strtotime($target_date . "-1 day"));
					} else {
						$target_date = date("Y/m/d", strtotime(sprintf("%d%02d", $year_month, $day)));
					}
					$removeTaskList = $this->removeTaskList($log_id, $target_date);
					foreach ($add_duty_list as $add_duty) {
						$check = false;
						foreach ($removeTaskList as $removeTask) {
							if ($removeTask["value"] == $add_duty) {
								$check = true;
							}
						}

						if (!$check) {
							$this->warnings[] = $day."日に定時タスク(". $add_duty .")を追加することはできません。";
						}
					}
				}

				foreach ($tasks as $task_cd => $count) {
					if ($count > 1) {
						$this->errors[] = $day."日に{$task_cd}が重複しています。";
						$check_flag = true;
					}
				}

				if ($hd_check > 1) {
					$this->errors[] = $day.'日に複数の休暇が設定されています。';
				}

				// HD1以外の休暇は他のタスクと共存できない
				if (($hd_check == 1 && !$hd1_check && !$hd5_check && !$hd6_check) && count($d_arr) > 1) {
					$this->warnings[] = $day.'日に休暇と勤務が設定されています。';
				}

				// HD5とFE00は一緒に設定可能
				if ($hd_check == 1 && $hd5_check &&
					(count($d_arr) > 2 || (count($d_arr) == 2 && !in_array(DAT_CODE_FE00, $d_arr)))) {
					$this->warnings[] = $day.'日に休暇と勤務が設定されています。';
				}

				// HD6と日直は設定可能
				if ($hd_check == 1 && $hd6_check &&
					(count($d_arr) > 2 || (count($d_arr) == 2 && !in_array(DAT_CODE_DW, $d_arr)))) {
					$this->warnings[] = $day.'日に休暇と勤務が設定されています。';
				}

				if ($d_check == 0 && $fkd_flag) {
					$this->warnings[] = $day.'日にD勤務を設定せずに兼務日(D)が設定されています。';
				}

				if ($n_check == 0 && $fkn_flag) {
					$this->warnings[] = $day.'日にN勤務を設定せずに兼務日(N)が設定されています。';
				}

				if ($d_check == 0 && $ew_flag) {
					$this->warnings[] = $day.'日にD勤務を設定せずに残務日が設定されています。';
				}

				if ($fe00_flag && !$hd5_check) {
					$this->warnings[] = $day.'日に公休を設定せずに定期消防訓練が設定されています。';
				}

				if (!$check_flag) {
					for ($task_cnt1 = 0; $task_cnt1 < count($task_times) -1; $task_cnt1++) {
						$task1_start_time = $this->Duty->timeToTimestamp($task_times[$task_cnt1]["start_time"]);
						$task1_end_time = $this->Duty->timeToTimestamp($task_times[$task_cnt1]["end_time"]);
						for ($task_cnt2 = $task_cnt1 + 1; $task_cnt2 < count($task_times); $task_cnt2++) {
							$task2_start_time = $this->Duty->timeToTimestamp($task_times[$task_cnt2]["start_time"]);
							$task2_end_time = $this->Duty->timeToTimestamp($task_times[$task_cnt2]["end_time"]);

							if (($task1_start_time <= $task2_start_time && $task2_start_time < $task1_end_time) ||
								($task1_start_time < $task2_end_time && $task2_end_time <= $task1_end_time) ||
								($task2_start_time <= $task1_start_time && $task1_start_time < $task2_end_time) ||
								($task2_start_time < $task1_end_time && $task1_end_time <= $task2_end_time)
							) {
								$this->errors[] = $day. '日に勤務時間が重なっているものがあります。';
								break 2;
							}
						}
					}
				}
			}

			if ($is_change)
			{
				// 変更前のDutyWorkリスト
				$change_days[$day] = ($copy_duty_type_map===NULL) ? [] : $copy_duty_type_map;
			}

			// 定常タスクはタスクIDをD or Nに変換する
			if ($save_flag && $d_val != $this->request->data($d_name))
			{
				$this->request->data[$d_name] = $d_val;
			}
		}

		$dutyAssignment = $DutyAssignments->find()->where(['da_year_month' => $year_month, 'p_id' => $p_id])->first();
		if ($dutyAssignment->fire_jippo != $this->request->data('fire_jippo') ||
			$dutyAssignment->acting_captain != $this->request->data('acting_captain') ||
			$dutyAssignment->meal_allowance != $this->request->data('meal_allowance') ||
			$dutyAssignment->absence_days != $this->request->data('absence_days')
		) {
			$change_flag = true;

			if ($save_flag)
			{
				$beforeNum = [];
				$afterNum = [];

				if ($dutyAssignment->fire_jippo != $this->request->data('fire_jippo')) {
					$beforeNum[] = "消防実報:" . $dutyAssignment->fire_jippo;
					$afterNum[] = "消防実報:" . $this->request->data('fire_jippo');
				}

				if ($dutyAssignment->acting_captain != $this->request->data('acting_captain')) {
					$beforeNum[] = "隊長代行:" . $dutyAssignment->acting_captain;
					$afterNum[] = "隊長代行:" . $this->request->data('acting_captain');
				}

				if ($dutyAssignment->meal_allowance != $this->request->data('meal_allowance')) {
					$beforeNum[] = "食事手当:" . $dutyAssignment->meal_allowance;
					$afterNum[] = "食事手当:" . $this->request->data('meal_allowance');
				}

				if ($dutyAssignment->absence_days != $this->request->data('absence_days')) {
					$beforeNum[] = "欠勤日:" . $dutyAssignment->absence_days;
					$afterNum[] = "欠勤日:" . $this->request->data('absence_days');
				}

				$dutyAssignment->fire_jippo = $this->request->data('fire_jippo');
				$dutyAssignment->acting_captain = $this->request->data('acting_captain');
				$dutyAssignment->meal_allowance = $this->request->data('meal_allowance');
				$dutyAssignment->absence_days = $this->request->data('absence_days');
				$DutyAssignments->save($DutyAssignments->newEntity($dutyAssignment));

				if ($end_log > 0) {
					$end_flag = TRUE;
				} else {
					$end_flag = FALSE;
				}

				$DutyLogs->changeLog($year_month, NULL, $log_id, $p_id, $name, implode("\n", $beforeNum), implode("\n", $afterNum), $end_flag);
			}
		}

		if ($save_flag)
		{
			if ($error_flag) {
				$DutyWorks->connection()->rollback();
			} else {
				$DutyWorks->connection()->commit();

				// 変更ログ
				if (count($change_days)>0)
				{
					foreach ($change_days as $day => $before_duty_work_map)
					{
						// 変更前
						$before_duty_type_arr = [];
						if (count($before_duty_work_map)>0) {
							foreach ($before_duty_work_map as $d) {
								if (isset($d->task_id) && $d->task_id != '') {
									$before_duty_type_arr[] = $d->task_id;
								} else if (isset($d->duty_type) && $d->duty_type != '') {
									$before_duty_type_arr[] = $d->duty_type;
								}
							}
						}

						// 変更後
						$after_duty_type_arr = [];
						$after_duty_work_map = $DutyWorks->getDutyTypeMap($p_id, $year_month, $day);
						if (count($after_duty_work_map)>0) {
							foreach ($after_duty_work_map as $d) {
								if (isset($d->task_id) && $d->task_id != '') {
									$after_duty_type_arr[] = $d->task_id;
								} else if (isset($d->duty_type) && $d->duty_type != '') {
									$after_duty_type_arr[] = $d->duty_type;
								}
							}
						}

						if ($end_log > 0) {
							$end_flag = TRUE;
						} else {
							$end_flag = FALSE;
						}
						$DutyLogs->changeLog($year_month, $day, $log_id, $p_id, $name, implode(',', $before_duty_type_arr), implode(',', $after_duty_type_arr), $end_flag);
					}
				}
				else
				{
					// 変更ログが無い場合でもログ終了は実行
					if ($end_log > 0) {
						$DutyLogs->endLog($log_id);
					}
				}
			}
		}
		else
		{
			if ($end_log > 0)
			{
				// タスク数チェック
				$duty_log_map = $DutyLogs->getDayMap($year_month, $log_id);

				if (count($duty_log_map)>0)
				{
					foreach ($duty_log_map as $tmp_day => $arr)
					{
						$check_tasks = [];
						foreach ($arr as $tmp_p_id => $d)
						{
							if ($d->before_type != '') {
								$after_type_arr = explode(',', $d->before_type);
								foreach ($after_type_arr as $type) {
									if ($type != '') {
										if (in_array($type, $check_tasks) === FALSE) {
											$check_tasks[] = $type;
										}
									}
								}
							}
							if ($d->after_type != '') {
								$after_type_arr = explode(',', $d->after_type);
								foreach ($after_type_arr as $type) {
									if ($type != '') {
										if (in_array($type, $check_tasks) === FALSE) {
											$check_tasks[] = $type;
										}
									}
								}
							}
						}
						foreach ($check_tasks as $task_id)
						{
							$over_short = 0;
							if (isset($check_days[$tmp_day][$task_id])) {
								$over_short = $check_days[$tmp_day][$task_id];
								unset($check_days[$tmp_day][$task_id]);
							}
							if ($this->isTaskPersonnel($task_id, $year_month, $tmp_day, $over_short) === FALSE) {
								// タスク数にエラーがあった場合
							}
						}
					}
				}
				if (count($check_days)>0)
				{
					foreach ($check_days as $tmp_day => $arr)
					{
						foreach ($arr as $type => $over_short)
						{
							if ($this->isTaskPersonnel($type, $year_month, $tmp_day, $over_short) === FALSE) {
								// タスク数にエラーがあった場合
							}
						}
					}
				}
			}
		}

		if (!$change_flag && count($this->errors) == 0) {
			$this->errors[] = "日程表が変更されていません。";
		}

		return $change_flag;
	}

	private function isTaskPersonnel($task_id, $year_month, $day, $over_short, $date=NULL)
	{
		if ($date === NULL) {
			$year = (int) substr($year_month, 0, 4);
			$month = (int) substr($year_month, 4, 2);
			if ($day>=21 && $day <= 31) {
				$month -= 1;
				if ($month == 0) {
					$month = 12;
					$year -= 1;
				}
			}
			$date = sprintf("%04d-%02d-%02d", $year, $month, $day);
		} else {
			$date = substr($date, 0, 10);
		}

		$Tasks = TableRegistry::get('Tasks');
		$TaskMonths = TableRegistry::get('TaskMonths');
		$DutyWorks = TableRegistry::get('DutyWorks');

		$task = $Tasks->getTask($task_id);

		if ($task !== NULL)
		{
			// 必要人数
			$personnel = $task->personnel;

			$duty_work = $DutyWorks->find()->select(['total'=>'COUNT(*)'])->where([
				'dw_date' => $date,
				'task_id' => $task_id
			])->first();

			$total = $duty_work->total + $over_short;

			if ($total == $personnel) {
				return TRUE;
			} else if ($total > $personnel) {
				$this->task_errors[] = str_replace('-', '/', $date).'　'.$task_id.'：必要人数'.$personnel.'人に対して'.($total-$personnel).'人過剰に配置されています。';
				return FALSE;
			} else {
				$this->task_errors[] = str_replace('-', '/', $date).'　'.$task_id.'：必要人数'.$personnel.'人に対して'.($personnel-$total).'人不足しています。';
				return FALSE;
			}
		}

		$task = $TaskMonths->getTaskMonth($task_id, $year_month);

		if ($task !== NULL)
		{
			// 必要人数
			$personnel = $task->personnel;

			$duty_work = $DutyWorks->find()->select(['total'=>'COUNT(*)'])->where([
				'dw_date' => $date,
				'task_id' => $task_id
			])->first();

			$total = $duty_work->total + $over_short;

			if ($total == $personnel) {
				return TRUE;
			} else if ($total > $personnel) {
				$this->task_errors[] = str_replace('-', '/', $date).'　'.$task_id.'：必要人数'.$personnel.'人に対して'.($total-$personnel).'人過剰に配置されています。';
				return FALSE;
			} else {
				$this->task_errors[] = str_replace('-', '/', $date).'　'.$task_id.'：必要人数'.$personnel.'人に対して'.($personnel-$total).'人不足しています。';
				return FALSE;
			}
		}
		return TRUE;
	}

	private function changeTaskWork(DutyWorksTable &$DutyWorks, &$task, $p_id, $year_month, $day)
	{
		$year = (int)substr($year_month, 0, 4);
		$month = (int)substr($year_month, 4, 2);
		if ($day>=21 && $day <= 31) {
			$month -= 1;
			if ($month == 0) {
				$month = 12;
				$year -= 1;
			}
		}

		$task_type = 0;
		$task_id = '';
		$start_date = NULL;
		$end_date = NULL;
		$duty_type = '';
		$start_time = '';
		$end_time = '';
		$work_hours = 0;
		$night_work_hours = 0;
		$meal_allowance = 0;
		if (isset($task->tm_id)) {
			$task_type = TW_TYPE_TMM;
			$task_id = $task->tm_id;
			$duty_type = $task->tm_id;
			$start_date = isset($task->start_date) ? $task->start_date->i18nFormat('YYYY-MM-dd') : NULL;
			$end_date = isset($task->end_date) ? $task->end_date->i18nFormat('YYYY-MM-dd') : NULL;
			if ($task->duty_type === DAT_CODE_D) {
				$start_time = DAT_D_START_TIME;
				$end_time = DAT_D_END_TIME;
				$work_hours = DAT_D_WORK_HOURS;
			} else if ($task->duty_type === DAT_CODE_N) {
				$start_time = DAT_N_START_TIME;
				$end_time = DAT_N_END_TIME;
				$work_hours = DAT_N_WORK_HOURS;
				$night_work_hours = DAT_N_NIGHT_HOURS;
			} else {
				$start_time = $task->start_time;
				$end_time = $task->end_time;
				$work_hours = $task->work_hours;
				$night_work_hours = $task->night_work_hours;
			}
			$meal_allowance = $task->meal_allowance;
		} else if (isset($task->t_id)) {
			$task_type = TW_TYPE_TM;
			$task_id = $task->t_id;
			$duty_type = $task->night_day;
			if ($duty_type === DAT_CODE_D) {
				$start_time = DAT_D_START_TIME;
				$end_time = DAT_D_END_TIME;
				$work_hours = DAT_D_WORK_HOURS;
			} else if ($duty_type === DAT_CODE_N) {
				$start_time = DAT_N_START_TIME;
				$end_time = DAT_N_END_TIME;
				$work_hours = DAT_N_WORK_HOURS;
				$night_work_hours = DAT_N_NIGHT_HOURS;
			}
		} else {
			$duty_type = $task;
		}

		$duty_work = $DutyWorks->newEntity([
			'dw_year_month' => $year_month,
			'dw_date' => sprintf("%04d-%02d-%02d", $year, $month, $day),
			'p_id' => $p_id,
			'task_type' => $task_type,
			'task_id' => $task_id,
			'start_date' => $start_date,
			'end_date' => $end_date,
			'duty_type' => $duty_type,
			'start_time' => $start_time,
			'end_time' => $end_time,
			'work_hours' => $work_hours,
			'night_work_hours' => $night_work_hours,
			'meal_allowance' => $meal_allowance
		]);

		if ($DutyWorks->save($duty_work) === FALSE) {
			return $duty_work;
		} else {
			return TRUE;
		}
	}

	protected function removeTaskList($log_no, $date) {
		$ts = strtotime($date);
		$items = [];

		if ($ts !== FALSE)
		{
			$Tasks = TableRegistry::get('Tasks');
			$Holidays = TableRegistry::get('Holidays');
			$dutyLogs = TableRegistry::get('DutyLogs');

			$holiday_map = $Holidays->getHolidayMap($date, $date);

			$w = date('w', $ts);
			$day_type = 'W';

			if ($w == 0 || count($holiday_map)>0) {
				$day_type = 'H';
			} else if ($w == 6) {
				$day_type = 'S';
			}

			$task_list = $Tasks->find()->where([
				'day_type' => $day_type
			])->order([
				't_id' => 'ASC'
			])->toArray();

			$log_list = $dutyLogs->find()->where([
				'log_id' => $log_no,
				'date' => $date
			])->toArray();

			$log_task_list = [];

			foreach ($log_list as $row) {
				// 変更前
				foreach (explode("," ,$row["before_type"]) as $beforeTask) {
					$log_task_list[$beforeTask] = isset($log_task_list[$beforeTask]) ?  $log_task_list[$beforeTask] + 1 : 1;
				}

				// 変更後
				foreach (explode("," ,$row["after_type"]) as $afterTask) {
					$log_task_list[$afterTask] = isset($log_task_list[$afterTask]) ?  $log_task_list[$afterTask] - 1 : -1;
				}
			}

			if (count($task_list)>0)
			{
				foreach ($task_list as $d)
				{
					// 減らした定常タスクのみ選択できるようにする
					if (isset($log_task_list[$d->t_id]) && $log_task_list[$d->t_id] > 0) {
						$items[] = ['value' => $d->t_id, 'name' => $d->t_id.' ('.$d->guard_name.' - '.$d->night_day.')'];
					}
				}
			}
		}

		return $items;
	}

//	public function checkToAlert($year_month, $log_id)
//	{
//		$DutyLogs = TableRegistry::get('DutyLogs');
//		$duty_log_list = $DutyLogs->find()->where([
//			'dl_year_month' => $year_month,
//			//'end_flag' => 0
//		])->order(['date'=>'ASC'])->toArray();
//
//		if (count($duty_log_list)>0)
//		{
//			$arr = [];
//			foreach ($duty_log_list as $d)
//			{
//				$date = substr($d->date, 0, 10);
//				if ($d->before_type != '') {
//					$tmp_arr = explode(',', $d->before_type);
//					foreach ($tmp_arr as $task_id) {
//						if ($task_id != '') {
//							if (isset($arr[$date]) === FALSE) {
//								$arr[$date] = [];
//							}
//							if (in_array($task_id, $arr[$date]) === FALSE) {
//								$arr[$date][] = $task_id;
//							}
//						}
//					}
//				}
//				if ($d->after_type != '') {
//					$tmp_arr = explode(',', $d->after_type);
//					foreach ($tmp_arr as $task_id) {
//						if ($task_id != '') {
//							if (isset($arr[$date]) === FALSE) {
//								$arr[$date] = [];
//							}
//							if (in_array($task_id, $arr[$date]) === FALSE) {
//								$arr[$date][] = $task_id;
//							}
//						}
//					}
//				}
//			}
//			if (count($arr)>0) {
//				foreach ($arr as $date => $tmp_arr) {
//					foreach ($tmp_arr as $task_id) {
//						$this->isTaskPersonnel($task_id, 0, 0, 0, $date);
//					}
//				}
//			}
//		}
//
//		$duty_log_list = $DutyLogs->find()->where([
//			'log_id' => $log_id,
//			'end_flag' => 0
//		])->toArray();
//
//		$this->set('duty_log_list', $duty_log_list);
//		$this->set('task_errors', $this->task_errors);
//	}

//	public function taskOverShort($task_id, $date)
//	{
//		$Tasks = TableRegistry::get('Tasks');
//		$TaskMonths = TableRegistry::get('TaskMonths');
//		$DutyWorks = TableRegistry::get('DutyWorks');
//
//		$task = $Tasks->getTask($task_id);
//
//		if ($task !== NULL)
//		{
//			// 必要人数
//			$personnel = $task->personnel;
//
//			$duty_work = $DutyWorks->find()->select(['total'=>'COUNT(*)'])->where([
//				'dw_date' => $date,
//				'task_id' => $task_id
//			])->first();
//
//			$total = $duty_work->total;
//
//			if ($total == $personnel) {
//				return '';
//			} else if ($total > $personnel) {
//				return ' +'.($total-$personnel);
//			} else {
//				return ' -'.($personnel-$total);
//			}
//		}
//
//		$task = $TaskMonths->getTaskMonth($task_id, $year_month);
//
//		if ($task !== NULL)
//		{
//			// 必要人数
//			$personnel = $task->personnel;
//
//			$duty_work = $DutyWorks->find()->select(['total'=>'COUNT(*)'])->where([
//				'dw_date' => sprintf("%04d-%02d-%02d", $year, $month, $day),
//				'task_id' => $task_id
//			])->first();
//
//			$total = $duty_work->total + $over_short;
//
//			if ($total == $personnel) {
//				return '';
//			} else if ($total > $personnel) {
//				return ' +'.($total-$personnel);
//			} else {
//				return ' -'.($personnel-$total);
//			}
//		}
//
//		return '';
//	}
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\PersonnelYearsTable;
use Cake\Error\FatalErrorException;
use Cake\Event\Event;
use Cake\Log\Log;

/**
 * PersonnelYears Controller
 *
 * @property PersonnelYearsTable $PersonnelYears
 */
class PersonnelYearsController extends AppController
{
	public $components = [
		'Upload',
		'Csv'
	];

	public function initialize()
	{
		parent::initialize();

		$this->loadModel('PersonnelYears');
	}
	
	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}

	/**
	 * トップ画面
	 */
	public function index()
	{
		$this->set('sideNavi', ['personnel_year'=>'index']);
		$this->setTitle('年次警備員マスター', 'トップ');
	}

	/**
	 * 一括登録
	 */
	public function batch()
	{
		$this->set('sideNavi', ['personnel_year'=>'batch']);
		$this->setTitle('年次警備員マスター', '一括登録');

//		$tmp_csv_file = '';
//
//		if ($this->request->is('POST'))
//		{
//			if (isset($this->request->data['file']))
//			{
//				// アップロード時
//				if ($this->Upload->isError())
//				{
//					Log::write('error', $this->Upload->getErrorMessage());
//				}
//				else
//				{
//					$tmp_csv_file = $this->Upload->getFile('PM');
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//			else if (isset($this->request->data['tmp_csv_file']) && isset($this->request->data['values']))
//			{
//				// エラー変更時
//				$tmp_csv_file = $this->request->data['tmp_csv_file'];
//				if (file_exists($tmp_csv_file))
//				{
//					$this->Csv->setUpdateValues($this->request->data['values']);
//					$fp = fopen($tmp_csv_file, 'r');
//					if ($this->Csv->parse($fp, 'personnel', $this->Personnels) === FALSE)
//					{
//						$this->set('csv_errors', $this->Csv->getErrors());
//						Log::debug($this->Csv->getErrors());
//					}
//				}
//			}
//		}
//
//		$this->set('tmp_csv_file', $tmp_csv_file);
	}

	public function batch_confirm()
	{
		$this->set('sideNavi', ['personnel_year'=>'batch']);
		$this->setTitle('年次警備員マスター', '一括登録');

		$tmp_csv_file = '';
		$data = [];

		if ($this->request->is('POST'))
		{
			if (isset($this->request->data['file']))
			{
				if (empty($this->request->data['file'])
						|| $this->request->data['file']['size'] == 0)
				{
					$this->set('errors', ['file' => ['アップロードするファイルを選択してください。']]);
					return $this->render('batch');
				}
				else if ($this->Upload->isError())
                {
                    Log::error($this->Upload->getErrorMessage());
					$this->set('errors', ['file' => [$this->Upload->getErrorMessage()]]);
					return $this->render('batch');
                }
				else
				{
					$tmp_csv_file = $this->Upload->getFile('PMY');
					$fp = fopen($tmp_csv_file, 'r');
					if ($this->Csv->parse($fp, 'personnel_year', $this->PersonnelYears) === FALSE)
					{
						$this->set('csv_errors', $this->Csv->getErrors());
						Log::debug($this->Csv->getErrors());
					}
					$data = $this->Csv->getData();
				}
			}
		}

		$this->set('tmp_csv_file', $tmp_csv_file);
		$this->set('data', $data);
	}

	public function batch_save()
	{
		$this->set('sideNavi', ['personnel_year'=>'batch']);
		$this->setTitle('年次警備員マスター', '一括登録');

		$tmp_csv_file = $this->request->data['tmp_csv_file'];
		if (empty($tmp_csv_file) || ! file_exists($tmp_csv_file))
		{
			throw new FatalErrorException("一時ファイルが見つかりません。");
		}
		$fp = fopen($tmp_csv_file, 'r');
		if ($this->Csv->parse($fp, 'personnel_year', $this->PersonnelYears) === FALSE)
		{
			$this->set('csv_errors', $this->Csv->getErrors());
			Log::debug($this->Csv->getErrors());
			$this->set('tmp_csv_file', $tmp_csv_file);
			$this->set('data', $this->Csv->getData());
			return $this->render('batch_confirm');
		}
		else
		{
			$this->Csv->import($this->PersonnelYears, 'p_id,py_year_month');
			$this->set('total', $this->Csv->getTotal());
		}
	}

	public function download()
	{
		$this->set('sideNavi', ['personnel_year'=>'download']);
		$this->setTitle('年次警備員マスター', 'ダウンロード');

		if ($this->request->is('POST'))
		{
			$list = $this->PersonnelYears->find()->order([
				'p_id' => 'ASC'
			])->toArray();
			$this->Csv->setData($list);
			$this->Csv->download('personnel_year', 'PMY_'.date("Ymd").'.csv');
		}
	}
}
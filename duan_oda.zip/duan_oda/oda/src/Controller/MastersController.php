<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;

/**
 * Masters Controller
 */
class MastersController extends AppController
{
	public function beforeFilter(Event $event)
	{
		parent::beforeFilter($event);
		$this->isAuthorityRead();
	}
	
    /**
     * Index method
     *
     * @return void
     */
	public function index()
	{
		$this->set('sideNavi', array('master'=>'index'));
		$this->setTitle('マスターファイル管理', 'トップ画面');
	}
}

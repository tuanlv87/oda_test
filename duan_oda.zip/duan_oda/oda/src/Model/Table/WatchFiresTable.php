<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\Entity;
use Cake\Validation\Validator;

/**
 * WatchFires Model
 */
class WatchFiresTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('watch_fires');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('status', 'valid', ['rule' => 'numeric'])
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        $validator
            ->add('wf_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('wf_year_month', 'create')
            ->notEmpty('wf_year_month');

        $validator
            ->add('wf_year', 'valid', ['rule' => 'numeric'])
            ->requirePresence('wf_year', 'create')
            ->notEmpty('wf_year');

        $validator
            ->add('wf_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('wf_month', 'create')
            ->notEmpty('wf_month');

        $validator
            ->add('wf_order', 'valid', ['rule' => 'numeric'])
            ->requirePresence('wf_order', 'create')
            ->notEmpty('wf_order');
            
        $validator
            ->requirePresence('wf_type', 'create')
            ->notEmpty('wf_type');
            
        $validator
            ->add('d_21', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_21');
            
        $validator
            ->add('d_22', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_22');
            
        $validator
            ->add('d_23', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_23');
            
        $validator
            ->add('d_24', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_24');
            
        $validator
            ->add('d_25', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_25');
            
        $validator
            ->add('d_26', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_26');
            
        $validator
            ->add('d_27', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_27');
            
        $validator
            ->add('d_28', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_28');
            
        $validator
            ->add('d_29', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_29');
            
        $validator
            ->add('d_30', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_30');
            
        $validator
            ->add('d_31', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_31');
            
        $validator
            ->add('d_1', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_1');
            
        $validator
            ->add('d_2', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_2');
            
        $validator
            ->add('d_3', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_3');
            
        $validator
            ->add('d_4', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_4');
            
        $validator
            ->add('d_5', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_5');
            
        $validator
            ->add('d_6', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_6');
            
        $validator
            ->add('d_7', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_7');
            
        $validator
            ->add('d_8', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_8');
            
        $validator
            ->add('d_9', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_9');
            
        $validator
            ->add('d_10', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_10');
            
        $validator
            ->add('d_11', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_11');
            
        $validator
            ->add('d_12', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_12');
            
        $validator
            ->add('d_13', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_13');
            
        $validator
            ->add('d_14', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_14');
            
        $validator
            ->add('d_15', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_15');
            
        $validator
            ->add('d_16', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_16');
            
        $validator
            ->add('d_17', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_17');
            
        $validator
            ->add('d_18', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_18');
            
        $validator
            ->add('d_19', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_19');
            
        $validator
            ->add('d_20', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('d_20');

        return $validator;
    }

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}

	/**
	 * タイプ別に取得
	 * 
	 * @param type $year_month
	 * @return type
	 */
	public function getTypeMap($year_month)
	{
		$list = $this->find()->where([
			'wf_year_month' => $year_month
		])->toArray();

		$data = [];
		if (count($list)>0) {
			foreach ($list as $d) {
				$data[$d->wf_type] = $d;
			}
		}

		return $data;
	}
}

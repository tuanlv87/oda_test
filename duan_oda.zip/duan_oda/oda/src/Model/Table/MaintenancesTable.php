<?php
namespace App\Model\Table;

use App\Model\Entity\Maintenance;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Maintenances Model
 */
class MaintenancesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('maintenances');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('mdate', 'valid', ['rule' => 'datetime'])
            ->requirePresence('mdate', 'create')
            ->notEmpty('mdate');
            
        $validator
            ->requirePresence('mname', 'create')
            ->notEmpty('mname');
		
        $validator
			->add('mtype', 'valid', ['rule' => 'numeric'])
            ->notEmpty('mtype');

        $validator
			->add('myear_month', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('myear_month');

        return $validator;
    }
}

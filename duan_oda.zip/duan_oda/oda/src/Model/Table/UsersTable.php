<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\Entity;
use Cake\ORM\RulesChecker;
use Cake\Validation\Validator;

/**
 * Users Model
 */
class UsersTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
		$this->table('users');
		$this->displayField('u_id');
		$this->primaryKey('id');
		$this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
	public function validationDefault(Validator $validator)
	{
		return $validator
			->requirePresence('u_id')
			->notEmpty('u_id', 'IDを入力してください。')
			->add('u_id', [
				'lengthBetween' => [
					'rule' => ['lengthBetween', 5, 12],
					'message' => 'IDは5文字以上、12文字以下で入力してください。'
				],
				'custom' => [
					'rule' => ['custom', "/^[0-9a-zA-Z\-\._]+$/"],
					'message' => 'IDは半角英数字、「-（ハイフン）.（ピリオド）_（アンダーバー）」で入力してください。'
				]
			])
			->requirePresence('auth_type')
			->notEmpty('auth_type', '権限を選択してください。')
			->requirePresence('name')
			->notEmpty('name', '氏名を入力してください。')
			->allowEmpty('rname')
			->requirePresence('password')
			->notEmpty('password', 'パスワードを入力してください。')
			->add('password', [
				'lengthBetween' => [
					'rule' => ['lengthBetween', 8, 12],
					'message' => 'パスワードは8文字以上、12文字以下で入力してください。'
				],
			])
			->allowEmpty('email')
			->add('email', [
				'email' => [
					'rule' => 'email',
					'message' => 'E-mailを正しい書式で入力してください。'
				]
			]);
	}

	public function validationCustom(Validator $validator)
	{
		return $validator
			->requirePresence('u_id')
			->notEmpty('u_id', 'IDを入力してください。')
			->add('u_id', [
				'lengthBetween' => [
					'rule' => ['lengthBetween', 5, 12],
					'message' => 'IDは5文字以上、12文字以下で入力してください。'
				],
				'custom' => [
					'rule' => ['custom', "/^[0-9a-zA-Z\-\._]+$/"],
					'message' => 'IDは半角英数字、「-（ハイフン）.（ピリオド）_（アンダーバー）」で入力してください。'
				]
			])
			->requirePresence('auth_type')
			->notEmpty('auth_type', '権限を選択してください。')
			->requirePresence('name')
			->notEmpty('name', '氏名を入力してください。')
			->allowEmpty('rname')
			->requirePresence('password')
			->notEmpty('password', 'パスワードを入力してください。')
			->add('password', [
				'lengthBetween' => [
					'rule' => ['lengthBetween', 8, 12],
					'message' => 'パスワードは8文字以上、12文字以下で入力してください。'
				],
			])
			->requirePresence('password_confirm')
			->notEmpty('password_confirm', 'パスワード（確認）を入力してください。')
			->add('password_confirm', [
				'equalToPassword' => [
					'rule' => [$this, 'equalToPassword'],
					'message' => 'パスワードの値を一致させてください。'
				],
			])
			->allowEmpty('email')
			->add('email', [
				'email' => [
					'rule' => 'email',
					'message' => 'E-mailを正しい書式で入力してください。'
				]
			]);
	}

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param RulesChecker $rules The rules object to be modified.
     * @return RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['u_id'], 'このIDは既に登録されています。'));
		//$rules->add($rules->isUnique(['name'], 'この氏名は既に登録されています。'));
        return $rules;
    }

	public function equalToPassword($password, $req)
	{
		return (!empty($password) && $password == $req['data']['password']);
	}

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}
}

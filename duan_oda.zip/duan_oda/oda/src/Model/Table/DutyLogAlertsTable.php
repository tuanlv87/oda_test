<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\Entity;
use Cake\Validation\Validator;

/**
 * DutyLogs Model
 */
class DutyLogAlertsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('duty_log_alerts');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->add('dla_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('dla_year_month', 'create')
            ->notEmpty('dla_year_month');

        $validator
            ->add('log_id', 'valid', ['rule' => 'numeric'])
            ->requirePresence('log_id', 'create')
            ->notEmpty('log_id');

        $validator
            ->add('sort_order', 'valid', ['rule' => 'numeric'])
            ->requirePresence('sort_order', 'create')
            ->notEmpty('sort_order');

        $validator
            ->requirePresence('message', 'create')
            ->notEmpty('message');

        return $validator;
    }

    public function saveAlertMessages($log_id, $ym , $messages)
    {
        foreach ($messages as $index => $message)
        {
            $data = [];
            $data["dla_year_month"] = $ym;
            $data["log_id"] = $log_id;
            $data["sort_order"] = $index + 1;
            $data["message"] = $message;

            $entity = $this->newEntity($data);

            if ($this->save($entity)=== FALSE) {
                Log::error($entity->errors());
                return FALSE;
            }
        }
        return TRUE;
    }

    public function getMapForLogId($ym)
    {
        $result = [];
        $datas = $this->find()
                      ->where(["dla_year_month" => $ym])
                      ->order(["log_id" => "ASC", "sort_order" => "ASC"]);

        $current_log_id = NULL;
        foreach ($datas as $row) {
            if ($current_log_id == NULL || $row->log_id != $current_log_id) {
                $result[$row->log_id] = [];
                $current_log_id = $row->log_id;
            }
            $result[$current_log_id][] = $row->message;
        }
        return $result;
    }
}

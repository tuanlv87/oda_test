<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\Entity;
use Cake\Validation\Validator;
/**
 * WatchFires Model
 */
class SettingsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('settings');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */

    /**
     * 登録者ID、更新者IDの登録
     * @param Event $event
     * @param Entity $entity
     */
    public function beforeSave(Event $event, Entity $entity)
    {
        if ($entity->isNew()) {
            $entity->set('created_user',  Configure::read('logged_u_id'));
        }
        $entity->set('modified_user',  Configure::read('logged_u_id'));
    }




}

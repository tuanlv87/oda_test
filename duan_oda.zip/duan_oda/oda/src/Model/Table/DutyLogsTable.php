<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\Entity;
use Cake\Validation\Validator;

/**
 * DutyLogs Model
 */
class DutyLogsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('duty_logs');
        $this->displayField('name');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->add('dl_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('dl_year_month', 'create')
            ->notEmpty('dl_year_month');

		$validator
			->add('log_id', 'valid', ['rule' => 'numeric'])
            ->requirePresence('log_id', 'create')
            ->notEmpty('log_id');

		$validator
			->add('end_flag', 'valid', ['rule' => 'numeric'])
            ->requirePresence('end_flag', 'create')
            ->notEmpty('end_flag');

        $validator
            ->add('date', 'valid', ['rule' => 'date'])
            ->requirePresence('date', 'create')
            ->allowEmpty('date');

        $validator
            ->add('change_date', 'valid', ['rule' => 'date'])
            ->requirePresence('change_date', 'create')
            ->notEmpty('change_date');

        $validator
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->requirePresence('before_type', 'create')
            ->allowEmpty('before_type');

        $validator
            ->requirePresence('after_type', 'create')
            ->allowEmpty('after_type');

        $validator
            ->allowEmpty('change_p_id1');

        $validator
            ->allowEmpty('change_name1');

        $validator
            ->allowEmpty('change_before_type1');

        $validator
            ->allowEmpty('change_after_type1');

        $validator
            ->allowEmpty('change_p_id2');

        $validator
            ->allowEmpty('change_name2');

        $validator
            ->allowEmpty('change_before_type2');

        $validator
            ->allowEmpty('change_after_type2');

        return $validator;
    }

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}

	/**
	 * 変更ログ登録
	 *
	 * @param type $year_month
	 * @param type $day
	 * @param type $log_id
	 * @param type $change_p_id
	 * @param type $change_name
	 * @param type $before_type
	 * @param type $after_type
	 * @param type $end_flag
	 * @return boolean
	 */
	public function changeLog($year_month, $day, $log_id, $change_p_id, $change_name, $before_type, $after_type, $end_flag=FALSE)
	{
		$year = (int) substr($year_month, 0, 4);
		$month = (int) substr($year_month, 4, 2);

		if ($day != NULL) {
			if ($day>=21 && $day <= 31) {
				$month -= 1;
				if ($month == 0) {
					$month = 12;
					$year -= 1;
				}
			}
		}

		$entity = $this->newEntity([
			'dl_year_month' => $year_month,
			'log_id' => $log_id,
			'end_flag' => ($end_flag)?1:0,
			'date' => ($day != NULL) ?sprintf("%04d-%02d-%02d", $year, $month, $day) : NULL,
			'change_date' => date("Y-m-d"),
			'p_id' => $change_p_id,
			'name' => $change_name,
			'before_type' => $before_type,
			'after_type' => $after_type
		]);

		if ($this->save($entity) === FALSE) {
			Log::error($entity->errors());
			return FALSE;
		} else {
			if ($end_flag) {
				$this->updateAll(['end_flag' => 1], [
					'log_id' => $log_id,
					'end_flag' => 0
				]);
			}
			return TRUE;
		}
	}

	public function endLog($log_id)
	{
		$this->updateAll(['end_flag' => 1], [
			'log_id' => $log_id,
			'end_flag' => 0
		]);
	}

	public function getDayMap($year_month, $log_id)
	{
		$duty_log_list = $this->find()->where([
			'dl_year_month' => $year_month,
			'log_id' => $log_id,
			'end_flag' => 0
		])->order([
			'id' => 'ASC'
		])->toArray();

		$duty_log_map = [];

		if (count($duty_log_list)>0)
		{
			foreach ($duty_log_list as $d)
			{
				$day = date('j', $d->date->timestamp);

				// 同じ日付のログは最終ログで上書き
				$duty_log_map[$day][$d->p_id] = $d;
			}
		}

		return $duty_log_map;
	}

	public function getValidLogId($year_month)
	{
		$duty_log = $this->find()->where([
			'dl_year_month' => $year_month,
			'end_flag' => 0
		])->first();

		if ($duty_log !== NULL) {
			return $duty_log->log_id;
		} else {
			return 0;
		}
	}
}

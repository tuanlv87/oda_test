<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Datasource\EntityInterface;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;

/**
 * Common Model
 */
class AppTable extends Table
{
	private $order = [];

	public function inListConfig($value, $configname)
	{
		if ($value == '') return TRUE;
		return array_key_exists($value, Configure::read($configname));
	}

	public function getInListMessage($configname)
	{
		$msg = [];
		$arr = Configure::read($configname);
		foreach ($arr as $val => $text) {
			if ($val == $text) {
				$msg[] = $val;
			} else {
				$msg[] = $val . '（'.$text.'）';
			}
		}
		return '「'.implode(', ', $msg).'」';
	}

	public function truncate()
	{
		$this->connection()->query("TRUNCATE ".$this->_table);
	}

	public function setOrder($order)
	{
		$this->order = $order;
	}

	public function beforeFind($event, Query $query)
	{
		$query->order($this->order);
		//array_unshift($query['order'], $this->order);
		$this->order = [];
	}

	/**
	 * CsvComponentから使用
	 * @param array $data
	 * @return array
	 */
	public function csvCheckUniqueData(array &$data)
	{
		return [];
	}

	public function isRules(EntityInterface $entity)
	{
        $mode = $entity->isNew() ? RulesChecker::CREATE : RulesChecker::UPDATE;
        if (! $this->checkRules($entity, $mode, NULL)) {
            return FALSE;
        } else {
			return TRUE;
		}
	}
}
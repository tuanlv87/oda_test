<?php
namespace App\Model\Table;

use App\Model\Entity\DutyWork;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DutyWorks Model
 */
class DutyWorksTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('duty_works');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('dw_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('dw_year_month', 'create')
            ->notEmpty('dw_year_month');
            
        $validator
            ->add('dw_date', 'valid', ['rule' => 'date'])
            ->requirePresence('dw_date', 'create')
            ->notEmpty('dw_date');
            
        $validator
            ->add('task_type', 'valid', ['rule' => 'numeric'])
            ->requirePresence('task_type', 'create')
            ->notEmpty('task_type');
            
        $validator
            ->add('start_date', 'valid', ['rule' => 'date'])
            ->allowEmpty('start_date');
            
        $validator
            ->add('end_date', 'valid', ['rule' => 'date'])
            ->allowEmpty('end_date');
            
        $validator
            ->allowEmpty('duty_type');
            
        $validator
            ->allowEmpty('start_time');
            
        $validator
            ->allowEmpty('end_time');
            
        $validator
            ->add('work_hours', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('work_hours');
            
        $validator
            ->add('night_work_hours', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('night_work_hours');
            
        $validator
            ->add('meal_allowance', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('meal_allowance');

        return $validator;
    }

	public function getDayMap($year_month)
	{
		$duty_work_list = $this->find()->where([
			'dw_year_month' => $year_month
		])->toArray();

		$duty_work_map = [];

		if (count($duty_work_list)>0)
		{
			foreach ($duty_work_list as $d)
			{
				$day = date('j', $d->dw_date->timestamp);
				// 同じ日に同じ勤務種別は無し
				$duty_work_map[$day][$d->duty_type] = $d;
			}
		}

		return $duty_work_map;
	}

	public function getDutyTypeMap($p_id, $year_month, $day)
	{
		$year = (int)substr($year_month, 0, 4);
		$month = (int)substr($year_month, 4, 2);
		if ($day>=21 && $day <= 31) {
			$month -= 1;
			if ($month == 0) {
				$month = 12;
				$year -= 1;
			}
		}

		$duty_work_list = $this->find()->where([
			'dw_date' => sprintf("%04d-%02d-%02d", $year, $month, $day),
			'p_id' => $p_id
		])->toArray();

		$duty_work_map = [];

		if (count($duty_work_list)>0)
		{
			foreach ($duty_work_list as $d)
			{
				// 同じ日に同じ勤務種別は無し
				$duty_work_map[$d->duty_type] = $d;
			}
		}

		return $duty_work_map;
	}

	public function getTotal($date, $task_id)
	{
		$d = $this->find()->select([
			'total' => 'COUNT(*)'
		])->where([
			'dw_date' => $date,
			'task_id' => $task_id
		])->first();

		return $d->total;
	}
}

<?php
namespace App\Model\Table;

use App\Model\Entity\Holiday;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Holidays Model
 */
class HolidaysTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('holidays');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('hdate', 'valid', ['rule' => 'date'])
            ->requirePresence('hdate', 'create')
            ->notEmpty('hdate');
            
        $validator
            ->requirePresence('hname', 'create')
            ->notEmpty('hname');

        return $validator;
    }

	public function getHolidayMap($start_date, $end_date)
	{
		$holiday_list = $this->find()->where([
			'hdate >=' => $start_date,
			'hdate <=' => $end_date
		])
		->toArray();

		$holiday_map = [];

		if (count($holiday_list) > 0) {
			foreach ($holiday_list as $d) {
				$holiday_map[$d->hdate->timestamp] = $d->hname;
			}
		}

		return $holiday_map;
	}
}

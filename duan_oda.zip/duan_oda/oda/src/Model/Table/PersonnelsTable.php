<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\Entity;
use Cake\ORM\RulesChecker;
use Cake\Validation\Validator;

/**
 * Personnels Model
 */
class PersonnelsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('personnels');
        $this->displayField('p_id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
		return $validator
			->notEmpty('status', ITEM_PM001.'を入力してください。')
			->add('status', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_PM001.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_status_types'],
					'message' => ITEM_PM001.'は'.$this->getInListMessage('personnel_status_types').'から指定してください。'
				]
			])
			->notEmpty('p_id', ITEM_PM002.'を入力してください。')
			->notEmpty('name', ITEM_PM003.'を入力してください。')
			->notEmpty('kana', ITEM_PM004.'を入力してください。')
			->requirePresence('gender', TRUE, ITEM_PM005.'を選択してください。')
			->add('gender', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_PM005.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'gender_types_2'],
					'message' => ITEM_PM005.'は'.$this->getInListMessage('gender_types_2').'から指定してください。'
				]
			])
			->notEmpty('birth_date', ITEM_PM006.'を入力してください。')
			->add('birth_date', [
				'date' => [
					'rule' => 'date',
					'message' => ITEM_PM006.'はYYYY/MM/DD形式で入力してください。'
				],
				'compare' => [
					'rule' => function($value, $content) {
						if (empty($value) || empty($content['data']['enter_date'])) return TRUE;
						if (! strtotime($value) || ! strtotime($content['data']['enter_date'])) return TRUE;
						return (strtotime($value) < strtotime($content['data']['enter_date']));
					},
					'message' => ITEM_PM006.'は'.ITEM_PM007.'より過去の日付を入力してください。'
				]
			])
			->notEmpty('enter_date', ITEM_PM007.'を入力してください。')
			->add('enter_date', [
				'date' => [
					'rule' => 'date',
					'message' => ITEM_PM007.'はYYYY/MM/DD形式で入力してください。'
				],
				'compare' => [
					'rule' => function($value, $content) {
						if (empty($value) || empty($content['data']['birth_date'])) return TRUE;
						if (! strtotime($value) || ! strtotime($content['data']['birth_date'])) return TRUE;
						return (strtotime($value) > strtotime($content['data']['birth_date']));
					},
					'message' => ITEM_PM007.'は'.ITEM_PM006.'より未来の日付を入力してください。'
				]
			])
			->allowEmpty('leave_date')
			->add('leave_date', [
				'date' => [
					'rule' => 'date',
					'message' => ITEM_PM008.'はYYYY/MM/DD形式で入力してください。'
				],
				'compare' => [
					'rule' => function($value, $content) {
						if (empty($value) || empty($content['data']['enter_date'])) return TRUE;
						if (! strtotime($value) || ! strtotime($content['data']['enter_date'])) return TRUE;
						return (strtotime($value) >= strtotime($content['data']['enter_date']));
					},
					'message' => ITEM_PM008.'は'.ITEM_PM007.'より未来の日付を入力してください。'
				]
			])
			->requirePresence('employee_type', TRUE, ITEM_PM009.'を選択してください。')
			->add('employee_type', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM009.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'employee_types'],
					'message' => ITEM_PM009.'は'.$this->getInListMessage('employee_types').'から指定してください。'
				]
			])
			->allowEmpty('title_code')
			->add('title_code', [
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'title_codes'],
					'message' => ITEM_PM010.'は'.$this->getInListMessage('title_codes').'から指定してください。'
				]
			])
			->allowEmpty('paid_vacation')
			->add('paid_vacation', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM011.'は数値で入力してください。'
				]
			])
			->allowEmpty('last_paid_vacation')
			->add('last_paid_vacation', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM012.'は数値で入力してください。'
				]
			])
			->notEmpty('team_id', ITEM_PM013.'を選択してください。')
			->add('team_id', [
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'team_ids'],
					'message' => ITEM_PM013.'は'.$this->getInListMessage('team_ids').'から指定してください。'
				]
			])
			->allowEmpty('crew_id')
			->add('crew_id', [
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'crew_ids'],
					'message' => ITEM_PM014.'は'.$this->getInListMessage('crew_ids', 1).'から指定してください。'
				]
			])
			->allowEmpty('personnel_id')
			->add('personnel_id', [
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_ids'],
					'message' => ITEM_PM015.'は'.$this->getInListMessage('personnel_ids', 1).'から指定してください。'
				]
			])
			->allowEmpty('fire_id')
			->add('fire_id', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM016.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_01')
			->add('license_01', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM017.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_01s'],
					'message' => ITEM_PM017.'は'.$this->getInListMessage('personnel_license_01s').'から指定してください。'
				]
			])
			->allowEmpty('license_02')
			->add('license_02', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM018.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_02s'],
					'message' => ITEM_PM018.'は'.$this->getInListMessage('personnel_license_02s').'から指定してください。'
				]
			])
			->allowEmpty('license_03')
			->add('license_03', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM019.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_03s'],
					'message' => ITEM_PM019.'は'.$this->getInListMessage('personnel_license_03s').'から指定してください。'
				]
			])
			->allowEmpty('license_04')
			->add('license_04', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM020.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_04s'],
					'message' => ITEM_PM020.'は'.$this->getInListMessage('personnel_license_04s').'から指定してください。'
				]
			])
			->allowEmpty('license_05')
			->add('license_05', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM021.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_05s'],
					'message' => ITEM_PM021.'は'.$this->getInListMessage('personnel_license_05s').'から指定してください。'
				]
			])
			->allowEmpty('license_06')
			->add('license_06', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM022.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_06s'],
					'message' => ITEM_PM022.'は'.$this->getInListMessage('personnel_license_06s').'から指定してください。'
				]
			])
			->allowEmpty('license_07')
			->add('license_07', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM023.'は数値で入力してください。'
				],
				'inListConfig' => [
					'rule' => [[$this, 'inListConfig'], 'personnel_license_07s'],
					'message' => ITEM_PM023.'は'.$this->getInListMessage('personnel_license_07s').'から指定してください。'
				]
			])
			->allowEmpty('license_08')
			->add('license_08', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM024.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_09')
			->add('license_09', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM025.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_10')
			->add('license_10', [
				'numeric' => [
					'rule' => 'numeric',
					'message' => ITEM_PM026.'は数値で入力してください。'
				]
			])
			->allowEmpty('bus_stop')
			->allowEmpty('mobile_number');
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param RulesChecker $rules The rules object to be modified.
     * @return RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['p_id'], 'この'.ITEM_PM002.'は既に登録されています。'));
		$rules->add($rules->isUnique(['name'], 'この'.ITEM_PM003.'は既に登録されています。'));
        return $rules;
    }

	public function csvCheckUniqueData(array &$data)
	{
		$errors = [];
		if ($data['name'] && $data['p_id'])
		{
			$res = $this->find()->select([
				'count' => 'COUNT(*)'
			])->where([
				'name' => $data['name'],
				'p_id <>' => $data['p_id']
			])->first();
			if ($res->count>0) {
				$errors['name'][0] = 'この'.ITEM_PM003.'は既に登録されています。';
			}
		}
		return $errors;
	}

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}

	public function getPidMap()
	{
		$list = $this->find()->toArray();

		$map = [];
		if (count($list)>0) {
			foreach ($list as $d) {
				if ($d->p_id>0) {
					$map[$d->p_id] = $d;
				}
			}
		}
		return $map;
	}
}

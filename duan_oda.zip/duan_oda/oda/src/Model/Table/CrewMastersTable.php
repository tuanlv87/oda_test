<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\Entity;
use Cake\Validation\Validator;

/**
 * WatchFires Model
 */
class CrewMastersTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('crew_masters');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }




    /**
     * �o�^��ID�A�X�V��ID�̓o�^
     * @param Event $event
     * @param Entity $entity
     */
    public function beforeSave(Event $event, Entity $entity)
    {
        if ($entity->isNew()) {
            $entity->set('created_user',  Configure::read('logged_u_id'));
        }
        $entity->set('modified_user',  Configure::read('logged_u_id'));
    }


}

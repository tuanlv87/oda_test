<?php
namespace App\Model\Table;

use App\Model\Entity\TaskTable;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TaskTables Model
 */
class TaskTablesTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('task_tables');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('status', 'valid', ['rule' => 'numeric'])
            ->requirePresence('status', 'create')
            ->notEmpty('status');
            
        $validator
            ->add('tt_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('tt_year_month', 'create')
            ->notEmpty('tt_year_month');

        $validator
            ->add('tt_date', 'valid', ['rule' => 'date'])
            ->requirePresence('tt_date', 'create')
            ->notEmpty('tt_date');

        $validator
            ->requirePresence('day_name', 'create')
            ->notEmpty('day_name');
            
        $validator
            ->allowEmpty('t_ids');
            
        $validator
            ->allowEmpty('t_ids_end');
            
        $validator
            ->allowEmpty('tm_ids');
            
        $validator
            ->allowEmpty('tm_ids_end');

        return $validator;
    }

	public function getTableMap($year_month)
	{
		$task_table_list = $this->find()->where([
			'tt_year_month' => $year_month
		])->toArray();

		$table_map = [];

		if (count($task_table_list)>0)
		{
			foreach ($task_table_list as $d)
			{
				$table_map[$d->tt_date->timestamp] = $d;
			}
		}

		return $table_map;
	}
}

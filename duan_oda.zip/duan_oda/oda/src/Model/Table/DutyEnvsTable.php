<?php
namespace App\Model\Table;

use App\Model\Entity\DutyEnv;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DutyEnvs Model
 */
class DutyEnvsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('duty_envs');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('de_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('de_year_month', 'create')
            ->notEmpty('de_year_month');

        $validator
			->add('status', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('status');

        $validator
			->add('holiday_flag', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('holiday_flag');

        $validator
			->add('update_flag', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('update_flag');

        $validator
            ->allowEmpty('start_team');

        $validator
			->add('start_fire_day', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('start_fire_day');

        $validator
            ->add('publish_date', 'valid', ['rule' => 'date'])
            ->allowEmpty('publish_date');

        return $validator;
    }
}

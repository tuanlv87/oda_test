<?php
namespace App\Model\Table;

use App\Model\Entity\Env;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Envs Model
 */
class EnvsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('envs');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->requirePresence('env_key', 'create')
            ->notEmpty('env_key');
            
        $validator
            ->allowEmpty('env_value');

        return $validator;
    }

	public function getValue($key)
	{
		$env = $this->find()->where(['env_key'=>$key])->first();
		return ($env===NULL) ? NULL : $env->env_value;
	}

	public function toSave($key, $value)
	{
		$env = $this->find()->where(['env_key'=>$key])->first();
		if ($env === NULL) {
			$env = $this->newEntity([
				'env_key' => $key,
				'env_value' => $value
			]);
		} else {
			$env = $this->patchEntity($env, [
				'env_value' => $value
			]);
		}
		$this->save($env);
		return $env->errors() ? $env->errors() : NULL;
	}
}

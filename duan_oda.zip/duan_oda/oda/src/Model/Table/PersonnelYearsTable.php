<?php
namespace App\Model\Table;

use Cake\Validation\Validator;

/**
 * PersonnelYears Model
 */
class PersonnelYearsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('personnel_years');
        $this->displayField('p_id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('py_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('py_year_month', 'create')
            ->notEmpty('py_year_month');
            
        $validator
            ->add('work_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('work_days', 'create')
            ->notEmpty('work_days');
            
        $validator
            ->add('vacation_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('vacation_days', 'create')
            ->notEmpty('vacation_days');
            
        $validator
            ->add('work_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('work_hours', 'create')
            ->notEmpty('work_hours');
            
        $validator
            ->add('night_work_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('night_work_hours', 'create')
            ->notEmpty('night_work_hours');
            
        $validator
            ->add('extra_work_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('extra_work_hours', 'create')
            ->notEmpty('extra_work_hours');
            
        $validator
            ->add('extra_night_work_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('extra_night_work_hours', 'create')
            ->notEmpty('extra_night_work_hours');
            
        $validator
            ->add('overtime', 'valid', ['rule' => 'numeric'])
            ->requirePresence('overtime', 'create')
            ->notEmpty('overtime');
            
        $validator
            ->add('overtime25', 'valid', ['rule' => 'numeric'])
            ->requirePresence('overtime25', 'create')
            ->notEmpty('overtime25');
            
        $validator
            ->add('overtime35', 'valid', ['rule' => 'numeric'])
            ->requirePresence('overtime35', 'create')
            ->notEmpty('overtime35');
            
        $validator
            ->add('d_duty', 'valid', ['rule' => 'numeric'])
            ->requirePresence('d_duty', 'create')
            ->notEmpty('d_duty');
            
        $validator
            ->add('n_duty', 'valid', ['rule' => 'numeric'])
            ->requirePresence('n_duty', 'create')
            ->notEmpty('n_duty');
            
        $validator
            ->add('dn_duty', 'valid', ['rule' => 'numeric'])
            ->requirePresence('dn_duty', 'create')
            ->notEmpty('dn_duty');
            
        $validator
            ->add('day_duty', 'valid', ['rule' => 'numeric'])
            ->requirePresence('day_duty', 'create')
            ->notEmpty('day_duty');
            
        $validator
            ->add('night_duty', 'valid', ['rule' => 'numeric'])
            ->requirePresence('night_duty', 'create')
            ->notEmpty('night_duty');
            
        $validator
            ->add('fire_plural', 'valid', ['rule' => 'numeric'])
            ->requirePresence('fire_plural', 'create')
            ->notEmpty('fire_plural');
            
        $validator
            ->add('fire_jippo', 'valid', ['rule' => 'numeric'])
            ->requirePresence('fire_jippo', 'create')
            ->notEmpty('fire_jippo');
            
        $validator
            ->add('acting_captain', 'valid', ['rule' => 'numeric'])
            ->requirePresence('acting_captain', 'create')
            ->notEmpty('acting_captain');
            
        $validator
            ->add('meal_allowance', 'valid', ['rule' => 'numeric'])
            ->requirePresence('meal_allowance', 'create')
            ->notEmpty('meal_allowance');
            
        $validator
            ->add('absence_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('absence_days', 'create')
            ->notEmpty('absence_days');
            
        $validator
            ->add('r_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('r_days', 'create')
            ->notEmpty('r_days');
            
        $validator
            ->add('hl_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hl_days', 'create')
            ->notEmpty('hl_days');
            
        $validator
            ->add('hd1_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hd1_days', 'create')
            ->notEmpty('hd1_days');
            
        $validator
            ->add('hd2_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hd2_days', 'create')
            ->notEmpty('hd2_days');
            
        $validator
            ->add('hd3_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hd3_days', 'create')
            ->notEmpty('hd3_days');
            
        $validator
            ->add('hd4_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hd4_days', 'create')
            ->notEmpty('hd4_days');
            
        $validator
            ->add('hd5_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('hd5_days', 'create')
            ->notEmpty('hd5_days');
            
        $validator
            ->add('x_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('x_days', 'create')
            ->notEmpty('x_days');
            
        $validator
            ->add('y_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('y_days', 'create')
            ->notEmpty('y_days');
            
        $validator
            ->add('z_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('z_days', 'create')
            ->notEmpty('z_days');
            
        $validator
            ->add('me1_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('me1_days', 'create')
            ->notEmpty('me1_days');
            
        $validator
            ->add('me2_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('me2_days', 'create')
            ->notEmpty('me2_days');
            
        $validator
            ->add('ne1_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('ne1_hours', 'create')
            ->notEmpty('ne1_hours');

        $validator
            ->add('ne2_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('ne2_hours', 'create')
            ->notEmpty('ne2_hours');

        $validator
            ->add('ne3_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('ne3_hours', 'create')
            ->notEmpty('ne3_hours');

        $validator
            ->add('ne4_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('ne4_hours', 'create')
            ->notEmpty('ne4_hours');

        $validator
            ->add('f_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('f_hours', 'create')
            ->notEmpty('f_hours');

        $validator
            ->add('fe_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('fe_hours', 'create')
            ->notEmpty('fe_hours');

        $validator
            ->add('fd_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('fd_days', 'create')
            ->notEmpty('fd_days');

        $validator
            ->add('oj1_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('oj1_hours', 'create')
            ->notEmpty('oj1_hours');

        $validator
            ->add('oj2_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('oj2_hours', 'create')
            ->notEmpty('oj2_hours');

        $validator
            ->add('oj3_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('oj3_hours', 'create')
            ->notEmpty('oj3_hours');

        $validator
            ->add('sh_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('sh_days', 'create')
            ->notEmpty('sh_days');

        $validator
            ->add('se_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('se_hours', 'create')
            ->notEmpty('se_hours');

        $validator
            ->add('se_night_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('se_night_hours', 'create')
            ->notEmpty('se_night_hours');

        $validator
            ->add('sm_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('sm_hours', 'create')
            ->notEmpty('sm_hours');

        $validator
            ->add('sm_night_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('sm_night_hours', 'create')
            ->notEmpty('sm_night_hours');

        $validator
            ->add('te_days', 'valid', ['rule' => 'numeric'])
            ->requirePresence('te_days', 'create')
            ->notEmpty('te_days');

        $validator
            ->add('mt_hours', 'valid', ['rule' => 'numeric'])
            ->requirePresence('mt_hours', 'create')
            ->notEmpty('mt_hours');

        return $validator;
    }

	public function csvCheckUniqueData(array &$data)
	{
		$errors = [];
//		if ($data['name'] && $data['p_id'])
//		{
//			$res = $this->find()->select([
//				'count' => 'COUNT(*)'
//			])->where([
//				'name' => $data['name'],
//				'p_id <>' => $data['p_id']
//			])->first();
//			if ($res->count>0) {
//				$errors['name'][0] = 'この'.ITEM_PM003.'は既に登録されています。';
//			}
//		}
		return $errors;
	}
}

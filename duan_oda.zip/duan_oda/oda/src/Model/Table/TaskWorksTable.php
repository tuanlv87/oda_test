<?php
namespace App\Model\Table;

use App\Model\Entity\TaskWork;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TaskWorks Model
 */
class TaskWorksTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('task_works');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->add('status', 'valid', ['rule' => 'numeric'])
            ->requirePresence('status', 'create')
            ->notEmpty('status');
            
        $validator
            ->add('tw_year_month', 'valid', ['rule' => 'numeric'])
            ->requirePresence('tw_year_month', 'create')
            ->notEmpty('tw_year_month');
            
        $validator
            ->add('tw_date', 'valid', ['rule' => 'date'])
            ->requirePresence('tw_date', 'create')
            ->notEmpty('tw_date');
            
        $validator
            ->add('tw_type', 'valid', ['rule' => 'numeric'])
            ->requirePresence('tw_type', 'create')
            ->notEmpty('tw_type');
            
        $validator
            ->allowEmpty('duty_type');
            
        $validator
            ->add('personnel', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('personnel');
            
        $validator
            ->add('manager', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('manager');
            
        $validator
            ->add('sub_manager', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('sub_manager');
            
        $validator
            ->add('leader', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('leader');
            
        $validator
            ->add('sub_leader', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('sub_leader');
            
        $validator
            ->add('chief', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('chief');
            
        $validator
            ->add('sub_chief', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('sub_chief');
            
        $validator
            ->add('woman_only', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('woman_only');
            
        $validator
            ->add('woman_possible', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('woman_possible');
            
        $validator
            ->add('license_01', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_01');
            
        $validator
            ->add('license_02', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_02');
            
        $validator
            ->add('license_03', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_03');
            
        $validator
            ->add('license_04', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_04');
            
        $validator
            ->add('license_05', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_05');
            
        $validator
            ->add('license_06', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_06');
            
        $validator
            ->add('license_07', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_07');
            
        $validator
            ->add('license_08', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_08');
            
        $validator
            ->add('license_09', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_09');
            
        $validator
            ->add('license_10', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('license_10');
            
        $validator
            ->allowEmpty('personnel_names');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        return $rules;
    }
}

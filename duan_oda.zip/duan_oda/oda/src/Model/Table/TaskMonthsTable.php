<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\I18n\Time;
use Cake\ORM\Entity;
use Cake\ORM\RulesChecker;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

/**
 * TaskMonths Model
 */
class TaskMonthsTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('task_months');
        $this->displayField('tm_id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
		return $validator
			->notEmpty('tm_year_month', ITEM_TMM_TM_YEAR_MONTH.'を入力してください。')
			->add('tm_year_month',[
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_TM_YEAR_MONTH.'はYYYYMM形式の数値で入力してください。'
				],
				'minLength' => [
					'rule' => ['minLength', 6],
					'message' => ITEM_TMM_TM_YEAR_MONTH.'はYYYYMM形式の6桁で入力してください。'
				],
				'maxLength' => [
					'rule' => ['maxLength', 6],
					'message' => ITEM_TMM_TM_YEAR_MONTH.'はYYYYMM形式の6桁で入力してください。'
				]
			])
			->requirePresence('status', 'create', ITEM_TMM_STATUS.'を入力してください。')
			->notEmpty('status', ITEM_TMM_STATUS.'を入力してください。')
			->add('status',[
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_STATUS.'は数値で入力してください。'
				]
			])
			->notEmpty('tm_id', ITEM_TMM_TM_ID.'を入力してください。')
			->add('tm_id', [
				'maxLength' => [
					'rule' => ['maxLength', 8],
					'message' => ITEM_TMM_TM_ID.'は8文字以下にしてください。'
				]
			])
			->notEmpty('task_name', ITEM_TMM_TASK_NAME.'を入力してください。')
			->allowEmpty('show_name')
			->add('show_name', [
				'maxLength' => [
					'rule' => ['maxLength', 12],
					'message' => ITEM_TMM_SHOW_NAME.'は12文字以下にしてください。'
				]
			])
			->notEmpty('show_mark', ITEM_TMM_SHOW_MARK.'を入力してください。')
			->allowEmpty('frame_color')
			->notEmpty('start_date', ITEM_TMM_START_DATE.'を入力してください。')
			->add('start_date', [
				'valid' => [
					'rule' => 'date',
					'message' => ITEM_TMM_START_DATE.'はYYYY/MM/DD形式で入力してください。'
				],
				'year_month_check' => [
					'rule' => function($value, $content){
						if (strlen($content['data']['tm_year_month'])==6 && $value!='' && strtotime($value)) {
							$year_month = $content['data']['tm_year_month'];
							$year = (int)substr($year_month, 0, 4);
							$month = (int)substr($year_month, 4, 2);
							$start_year = $year;
							$start_month = $month - 1;
							if ($start_month == 0) {
								$start_month = 12;
								$start_year -= 1;
							}
							$st = strtotime(sprintf("%04d-%02d-%02d", $start_year, $start_month, DAT_START_DAY));
							$et = strtotime(sprintf("%04d-%02d-%02d", $year, $month, DAT_END_DAY));
							$ts = strtotime($value);
							if ($ts < $st || $ts > $et) {
								return FALSE;
							}
						}
						return TRUE;
					},
					'message' => ITEM_TMM_START_DATE.'は当該年月の21日以降の日付を入力してください。'
				]
			])
			->allowEmpty('end_date')
			->add('end_date', [
				'valid' => [
					'rule' => 'date',
					'message' => ITEM_TMM_END_DATE.'はYYYY/MM/DD形式で入力してください。'
				],
				'compare' => [
					'rule' => function($value, $content) {
						if (empty($value) || empty($content['data']['start_date'])) return TRUE;
						if (! strtotime($value) || ! strtotime($content['data']['start_date'])) return TRUE;
						return (strtotime($value) >= strtotime($content['data']['start_date']));
					},
					'message' => ITEM_TMM_END_DATE.'は'.ITEM_TMM_START_DATE.'より未来の日付を入力してください。'
				],
				'check' => [
					'rule' => function($value, $content) {
						if ($content['data']['start_date'] == ''
							|| ! strtotime($content['data']['start_date'])
							|| ! strtotime($value))
						{
							return TRUE;
						}
						$sd = new Time($content['data']['start_date']);
						$ed = new Time($value);
						if ($sd->day >= DAT_START_DAY) {
							$sd->modify('+1 month');
							$sd->modify('-1 day');
							if ($ed->timestamp > $sd->timestamp) {
								return FALSE;
							}
						} else {
							if ($sd->month != $ed->month || $ed->day >= DAT_START_DAY) {
								return FALSE;
							}
						}
						return TRUE;
					},
					'message' => ITEM_TMM_END_DATE.'は当該年月の20日までの日付を入力してください。'
				],
//				'year_month_check' => [
//					'rule' => function($value, $content){
//						if (strlen($content['data']['tm_year_month'])==6 && $value!='' && strtotime($value)) {
//							$year_month = $content['data']['tm_year_month'];
//							$year = (int)substr($year_month, 0, 4);
//							$month = (int)substr($year_month, 4, 2);
//							$start_year = $year;
//							$start_month = $month - 1;
//							if ($start_month == 0) {
//								$start_month = 12;
//								$start_year -= 1;
//							}
//							$st = strtotime(sprintf("%04d-%02d-%02d", $start_year, $start_month, DAT_START_DAY));
//							$et = strtotime(sprintf("%04d-%02d-%02d", $year, $month, DAT_END_DAY));
//							$ts = strtotime($value);
//							if ($ts < $st || $ts > $et) {
//								return FALSE;
//							}
//						}
//						return TRUE;
//					},
//					'message' => ITEM_TMM_END_DATE.'が年月の範囲外の日付です。'
//				]
			])
			->notEmpty('duty_type', ITEM_TMM_START_TIME.'と'.ITEM_TMM_END_TIME.'が未入力の場合は'.ITEM_TMM_DUTY_TYPE.'を選択してください。', function($content){
				if (empty($content['data']['duty_type'])
						&& $content['data']['start_time'] == ''
						&& $content['data']['end_time'] == '')
				{
					return TRUE;
				}
				return FALSE;
			})
			->allowEmpty('start_time')
			->add('start_time', [
				'valid' => [
					'rule' => function($value, $content){
						if ($value != '' && !preg_match('/^[0-9]{2}:[0-9]{2}$/', $value)) {
							return FALSE;
						}
						return TRUE;
					},
					'message' => ITEM_TMM_START_TIME.'は時間（HH:MM）形式で入力してください。'
				]
			])
			->allowEmpty('end_time')
			->add('end_time', [
				'valid' => [
					'rule' => function($value, $content){
						if ($value != '' && !preg_match('/^[0-9]{2}:[0-9]{2}$/', $value)) {
							return FALSE;
						}
						return TRUE;
					},
					'message' => ITEM_TMM_END_TIME.'は時間（HH:MM）形式で入力してください。'
				],
				'over' => [
					'rule' => function($value, $content){
						if ($value != '' && $content['data']['start_date'] != '' && $content['data']['end_date'] != '') {
							$hours = explode(':', $value);
							$hours = (int)$hours[0];
							if ($hours > 24 && strtotime($content['data']['start_date']) != strtotime($content['data']['end_date'])) {
								return FALSE;
							}
						}
						return TRUE;
					},
					'message' => ITEM_TMM_END_TIME.'を24時以降にする場合は'.ITEM_TMM_START_DATE.'と'.ITEM_TMM_END_DATE.'を同じ日付にしてください。'
				]
			])
			->allowEmpty('work_hours')
			->add('work_hours', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_WORK_HOURS.'は数値で入力してください。'
				]
			])
			->allowEmpty('night_work_hours')
			->add('night_work_hours', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_NIGHT_WORK_HOURS.'は数値で入力してください。'
				]
			])
			->allowEmpty('meal_allowance')
			->add('meal_allowance', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_MEAL_ALLOWANCE.'は数値で入力してください。'
				]
			])
			->allowEmpty('personnel')
			->add('personnel', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_PERSONNEL.'は数値で入力してください。'
				]
			])
			->allowEmpty('manager')
			->add('manager', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_MANAGER.'は数値で入力してください。'
				]
			])
			->allowEmpty('sub_manager')
			->add('sub_manager', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_SUB_MANAGER.'は数値で入力してください。'
				]
			])
			->allowEmpty('leader')
			->add('leader', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LEADER.'は数値で入力してください。'
				]
			])
			->allowEmpty('sub_leader')
			->add('sub_leader', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_SUB_LEADER.'は数値で入力してください。'
				]
			])
			->allowEmpty('chief')
			->add('chief', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_CHIEF.'は数値で入力してください。'
				]
			])
			->allowEmpty('sub_chief')
			->add('sub_chief', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_SUB_CHIEF.'は数値で入力してください。'
				]
			])
			->allowEmpty('woman_only')
			->add('woman_only', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_WOMAN_ONLY.'は値で入力してください。'
				]
			])
			->allowEmpty('woman_possible')
			->add('woman_possible', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_WOMAN_POSSIBLE.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_01')
			->add('license_01', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_01.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_02')
			->add('license_02', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_02.'は値で入力してください。'
				]
			])
			->allowEmpty('license_03')
			->add('license_03', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_03.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_04')
			->add('license_04', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_04.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_05')
			->add('license_05', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_05.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_06')
			->add('license_06', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_06.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_07')
			->add('license_07', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_07.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_08')
			->add('license_08', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_08.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_09')
			->add('license_09', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_09.'は数値で入力してください。'
				]
			])
			->allowEmpty('license_10')
			->add('license_10', [
				'valid' => [
					'rule' => 'numeric',
					'message' => ITEM_TMM_LICENSE_10.'は数値で入力してください。'
				]
			])
			->allowEmpty('personnel_names')
			->add('personnel_names', [
				'custom' => [
					'rule' => function($value, $content) {
						$names = explode(';', $value);
						$Personnels = TableRegistry::get('Personnels');
						$flag = TRUE;
						$err_names = [];
						foreach ($names as $name) {
							if ($name != '') {
								$item = $Personnels->find()->where([
									'name' => $name
								])->first();
								if ($item === NULL) {
									$err_names[] = $name;
									$flag = FALSE;
								}
							}
						}
						if ($flag === FALSE) {
							return ITEM_TMM_PERSONNEL_NAMES.'に存在しない氏名（'.implode('、', $err_names).'）が入力されています。';
						} else {
							return TRUE;
						}
					},
					'message' => ITEM_TMM_PERSONNEL_NAMES.'に存在しない氏名が入力されています。'
				]
			]);
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param RulesChecker $rules The rules object to be modified.
     * @return RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['tm_id','tm_year_month'], 'このT-IDは既に登録されています。'));
        return $rules;
    }

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}

	public function getTmIdMap($year_month)
	{
		$list = $this->find()->where([
			'tm_year_month' => $year_month
		])->toArray();
		$map = [];
		if (count($list)>0) {
			foreach ($list as $d) {
				$map[$d->tm_id] = $d;
			}
		}
		return $map;
	}

	public function getTaskMonth($tm_id, $year_month)
	{
		return $this->find()->where([
			'tm_year_month' => $year_month,
			'tm_id' => $tm_id
		])->first();
	}
}

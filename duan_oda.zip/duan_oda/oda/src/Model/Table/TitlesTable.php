<?php
namespace App\Model\Table;

use App\Model\Entity\Title;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Titles Model
 */
class TitlesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('titles');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');
            
        $validator
            ->requirePresence('title_code', 'create')
            ->notEmpty('title_code');
            
        $validator
            ->add('title_order', 'valid', ['rule' => 'numeric'])
            ->requirePresence('title_order', 'create')
            ->notEmpty('title_order');
            
        $validator
            ->requirePresence('title_display', 'create')
            ->notEmpty('title_display');
            
        $validator
            ->requirePresence('title_name', 'create')
            ->notEmpty('title_name');

        return $validator;
    }
}

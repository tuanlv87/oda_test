<?php
namespace App\Model\Table;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\Entity;
use Cake\ORM\RulesChecker;
use Cake\Validation\Validator;

/**
 * Tasks Model
 */
class TasksTable extends AppTable
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('tasks');
        $this->displayField('t_id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param Validator $validator Validator instance.
     * @return Validator
     */
    public function validationDefault(Validator $validator)
    {
        return $validator
			->requirePresence('status', 'create', 'ステータスを選択してください。')
			->notEmpty('status', 'ステータスを選択してください。')
			->add('status', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'ステータスは数値で入力してください。'
				]
			])
			->notEmpty('t_id', 'T-IDを入力してください。')
			->add('t_id', [
				'maxLength' => [
					'rule' => ['maxLength', 8],
					'message' => 'T-IDは8文字以内で入力してください。'
				]
			])
			->notEmpty('guard_name', '警備対象を入力してください。')
			->requirePresence('day_type', 'create', '曜日を選択してください。')
			->notEmpty('day_type')
			->requirePresence('night_day', 'create', '昼夜の別を選択してください。')
			->notEmpty('night_day')
			->allowEmpty('personnel')
			->add('personnel', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '人数は数値で入力してください。'
				]
			])
			->allowEmpty('manager')
			->add('manager', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'マネージャーは数値で入力してください。'
				]
			])
			->allowEmpty('sub_manager')
			->add('sub_manager', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'サブ・マネージャーは数値で入力してください。'
				]
			])
			->allowEmpty('leader')
			->add('leader', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'リーダーは数値で入力してください。'
				]
			])
			->allowEmpty('sub_leader')
			->add('sub_leader', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'サブ・リーダーは数値で入力してください。'
				]
			])
			->allowEmpty('chief')
			->add('chief', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'チーフは数値で入力してください。'
				]
			])
			->allowEmpty('sub_chief')
			->add('sub_chief', [
				'valid' => [
					'rule' => 'numeric',
					'message' => 'サブ・チーフは数値で入力してください。'
				]
			])
			->allowEmpty('woman_only')
			->add('woman_only', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '女性のみは数値で入力してください。'
				]
			])
			->allowEmpty('woman_possible')
			->add('woman_possible', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '女性可は数値で入力してください。'
				]
			])
			->allowEmpty('license_01')
			->add('license_01', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格01は数値で入力してください。'
				]
			])
			->allowEmpty('license_02')
			->add('license_02', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格02は数値で入力してください。'
				]
			])
			->allowEmpty('license_03')
			->add('license_03', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格03は数値で入力してください。'
				]
			])
			->allowEmpty('license_04')
			->add('license_04', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格04は数値で入力してください。'
				]
			])
			->allowEmpty('license_05')
			->add('license_05', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格05は数値で入力してください。'
				]
			])
			->allowEmpty('license_06')
			->add('license_06', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格06は数値で入力してください。'
				]
			])
			->allowEmpty('license_07')
			->add('license_07', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格07は数値で入力してください。'
				]
			])
			->allowEmpty('license_08')
			->add('license_08', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格08は数値で入力してください。'
				]
			])
			->allowEmpty('license_09')
			->add('license_09', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格09は数値で入力してください。'
				]
			])
			->allowEmpty('license_10')
			->add('license_10', [
				'valid' => [
					'rule' => 'numeric',
					'message' => '資格10は数値で入力してください。'
				]
			]);
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param RulesChecker $rules The rules object to be modified.
     * @return RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['t_id'], 'このT-IDは既に登録されています。'));
        return $rules;
    }

	/**
	 * 登録者ID、更新者IDの登録
	 * @param Event $event
	 * @param Entity $entity
	 */
	public function beforeSave(Event $event, Entity $entity)
	{
		if ($entity->isNew()) {
			$entity->set('created_user',  Configure::read('logged_u_id'));
		}
		$entity->set('modified_user',  Configure::read('logged_u_id'));
	}

	public function getTidMap()
	{
		$list = $this->find()->toArray();
		$map = [];
		if (count($list)>0) {
			foreach ($list as $d) {
				$map[$d->t_id] = $d;
			}
		}
		return $map;
	}

	public function getTask($t_id)
	{
		return $this->find()->where(['t_id'=>$t_id])->first();
	}
}

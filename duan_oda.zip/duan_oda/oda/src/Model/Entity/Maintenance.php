<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Maintenance Entity.
 */
class Maintenance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'mdate' => true,
        'mname' => true,
		'mtype' => true,
		'myear_month' => true,
    ];
}

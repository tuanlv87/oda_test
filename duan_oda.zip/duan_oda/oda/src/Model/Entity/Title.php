<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Title Entity.
 */
class Title extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'title_code' => true,
        'title_order' => true,
        'title_display' => true,
        'title_name' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PersonnelYear Entity.
 */
class PersonnelYear extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'py_year_month' => true,
        'p_id' => true,
        'work_days' => true,
        'vacation_days' => true,
        'work_hours' => true,
        'night_work_hours' => true,
        'extra_work_hours' => true,
        'extra_night_work_hours' => true,
        'overtime' => true,
        'overtime25' => true,
        'overtime35' => true,
        'd_duty' => true,
        'n_duty' => true,
        'dn_duty' => true,
        'day_duty' => true,
        'night_duty' => true,
        'fire_plural' => true,
        'fire_jippo' => true,
        'acting_captain' => true,
        'meal_allowance' => true,
        'absence_days' => true,
        'r_days' => true,
        'hl_days' => true,
        'hd1_days' => true,
        'hd2_days' => true,
        'hd3_days' => true,
        'hd4_days' => true,
        'hd5_days' => true,
        'x_days' => true,
        'y_days' => true,
        'z_days' => true,
        'me1_days' => true,
        'me2_days' => true,
        'ne1_hours' => true,
        'ne2_hours' => true,
        'ne3_hours' => true,
        'ne4_hours' => true,
        'f_hours' => true,
        'fe_hours' => true,
        'fd_days' => true,
        'oj1_hours' => true,
        'oj2_hours' => true,
        'oj3_hours' => true,
        'sh_days' => true,
        'se_hours' => true,
		'se_night_hours' => true,
        'sm_hours' => true,
		'sm_night_hours' => true,
        'te_days' => true,
        'mt_hours' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Personnel Entity.
 */
class Personnel extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'status' => true,
        'p_id' => true,
        'name' => true,
        'kana' => true,
        'gender' => true,
        'birth_date' => true,
        'enter_date' => true,
        'leave_date' => true,
        'employee_type' => true,
        'title_code' => true,
        'paid_vacation' => true,
        'last_paid_vacation' => true,
        'team_id' => true,
        'crew_id' => true,
        'personnel_id' => true,
        'fire_id' => true,
        'license_01' => true,
        'license_02' => true,
        'license_03' => true,
        'license_04' => true,
        'license_05' => true,
        'license_06' => true,
        'license_07' => true,
        'license_08' => true,
        'license_09' => true,
        'license_10' => true,
        'bus_stop' => true,
        'mobile_number' => true,
		'created_user' => true,
		'modified_user' => true,
    ];
}

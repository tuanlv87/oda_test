<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DutyLogAlert Entity.
 */
class DutyLogAlert extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'dla_year_month' => true,
        'log_id' => true,
        'sort_order' => true,
        'message' => true,
    ];
}

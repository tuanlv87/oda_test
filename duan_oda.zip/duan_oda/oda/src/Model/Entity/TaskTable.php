<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * TaskTable Entity.
 */
class TaskTable extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'status' => true,
        'tt_year_month' => true,
        'tt_date' => true,
        'day_name' => true,
        't_ids' => true,
        't_ids_end' => true,
        'tm_ids' => true,
        'tm_ids_end' => true,
    ];
}

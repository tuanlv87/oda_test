<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * WatchFire Entity.
 */
class Setting extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'title' => true,
		'value' => true,
        'created_user' => true,
        'modified_user' => true,

    ];
}

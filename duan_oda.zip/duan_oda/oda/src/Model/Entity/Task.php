<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Task Entity.
 */
class Task extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'status' => true,
        't_id' => true,
        'guard_name' => true,
        'day_type' => true,
        'night_day' => true,
        'personnel' => true,
        'manager' => true,
        'sub_manager' => true,
        'leader' => true,
        'sub_leader' => true,
        'chief' => true,
        'sub_chief' => true,
        'woman_only' => true,
        'woman_possible' => true,
        'license_01' => true,
        'license_02' => true,
        'license_03' => true,
        'license_04' => true,
        'license_05' => true,
        'license_06' => true,
        'license_07' => true,
        'license_08' => true,
        'license_09' => true,
        'license_10' => true,
		'created_user' => true,
		'modified_user' => true,
    ];
}

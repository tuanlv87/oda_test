<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DutyEnv Entity.
 */
class DutyEnv extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'de_year_month' => true,
		'status' => true,
		'holiday_flag' => true,
		'update_flag' => true,
        'start_team' => true,
		'start_fire_day' => true,
		'publish_date' => true,
    ];
}

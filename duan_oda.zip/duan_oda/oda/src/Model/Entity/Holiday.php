<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Holiday Entity.
 */
class Holiday extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'hdate' => true,
        'hname' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * User Entity.
 */
class User extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'u_id' => true,
        'auth_type' => true,
        'name' => true,
        'rname' => true,
        'password' => true,
        'email' => true,
		'created_user' => true,
		'modified_user' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * WatchFire Entity.
 */
class WatchFire extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'status' => true,
		'wf_year_month' => true,
        'wf_year' => true,
		'wf_month' => true,
		'wf_order' => true,
        'wf_type' => true,
        'd_21' => true,
        'd_22' => true,
        'd_23' => true,
        'd_24' => true,
        'd_25' => true,
        'd_26' => true,
        'd_27' => true,
        'd_28' => true,
        'd_29' => true,
        'd_30' => true,
        'd_31' => true,
        'd_1' => true,
        'd_2' => true,
        'd_3' => true,
        'd_4' => true,
        'd_5' => true,
        'd_6' => true,
        'd_7' => true,
        'd_8' => true,
        'd_9' => true,
        'd_10' => true,
        'd_11' => true,
        'd_12' => true,
        'd_13' => true,
        'd_14' => true,
        'd_15' => true,
        'd_16' => true,
        'd_17' => true,
        'd_18' => true,
        'd_19' => true,
        'd_20' => true,
		'created_user' => true,
		'modified_user' => true,
    ];
}

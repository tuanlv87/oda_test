<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DutyLog Entity.
 */
class DutyLog extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'dl_year_month' => true,
		'log_id' => true,
		'end_flag' => true,
        'date' => true,
        'change_date' => true,
        'p_id' => true,
        'name' => true,
        'before_type' => true,
        'after_type' => true,
        'change_p_id1' => true,
        'change_name1' => true,
        'change_before_type1' => true,
        'change_after_type1' => true,
        'change_p_id2' => true,
        'change_name2' => true,
        'change_before_type2' => true,
        'change_after_type2' => true,
    ];
}

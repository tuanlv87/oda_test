<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DutyWork Entity.
 */
class DutyWork extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'dw_year_month' => true,
        'dw_date' => true,
		'p_id' => true,
        'task_type' => true,
        'task_id' => true,
        'start_date' => true,
        'end_date' => true,
        'duty_type' => true,
        'start_time' => true,
        'end_time' => true,
        'work_hours' => true,
        'night_work_hours' => true,
        'meal_allowance' => true,
    ];
}

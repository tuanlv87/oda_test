<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * WatchFire Entity.
 */
class CrewMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'crew_id' => true,
		'crew_member' => true,
        'created_user' => true,
        'modified_user' => true,
    ];
}

<?php
$config['message_settings'] = [
    "error_messages" => array("E001" => "不正なリクエストです。トップページに戻って作業をやり直してください。",
                              "E002" => "対象のデータがありません。",
                            )
];
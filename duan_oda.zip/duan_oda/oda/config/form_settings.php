<?php
$config['form_settings'] = [
	'user' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label'],
		],
		'u_id' => [
			'text' => 'ID',
			'type' => 'text',
			'required' => TRUE,
			'filter' => 'mb_convert_kana:a',
			'class' => 'w-300'
		],
		'auth_type' => [
			'text' => '権限',
			'type' => 'radios',
			'config' => 'users_auth_types2',
			'selected' => '2'
		],
		'name' => [
			'text' => '氏名',
			'type' => 'text',
			'class' => 'w-300',
			'required' => TRUE,
		],
		'rname' => [
			'text' => 'ローマ字氏名',
			'type' => 'text',
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'password' => [
			'text'=>'パスワード',
			'type'=>'password',
			'class'=>'w-300',
			'rowclass'=>'mb-0',
			'required' => TRUE,
			'filter' => 'mb_convert_kana:a',
		],
		'password_confirm' => [
			'text'=>'パスワード（確認）',
			'type'=>'password',
			'class'=>'w-300',
			'required' => TRUE,
			'filter' => 'mb_convert_kana:a',
		],
		'email' => [
			'text' => 'E-mail',
			'type' => 'text',
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		]
	],
	'personnel' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label']
		],
		'status' => [
			'text' => ITEM_PM001,
			'type' => 'select',
			'config' => 'personnel_status_types',
			'blank' => TRUE,
			'required' => TRUE,
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'p_id' => [
			'text' => ITEM_PM002,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'name' => [
			'text' => ITEM_PM003,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
			'filter' => 'removeSpace',
		],
		'kana' => [
			'text' => ITEM_PM004,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
		],
		'gender' => [
			'text' => ITEM_PM005,
			'type' => 'radios',
			'config' => 'gender_types_2',
			'selected' => '',
			'required' => TRUE,
			'filter' => 'mb_convert_kana:a',
		],
		'birth_date' => ['text' => ITEM_PM006, 'type' => 'date', 'required' => TRUE],
		'enter_date' => ['text' => ITEM_PM007, 'type' => 'date', 'required' => TRUE],
		'leave_date' => ['text' => ITEM_PM008, 'type' => 'date'],
		'employee_type' => ['text' => ITEM_PM009, 'type' => 'radios', 'config' => 'employee_types', 'selected' => '', 'required' => TRUE],
		'title_code' => [
			'text' => ITEM_PM010,
			'type' => 'select',
			'config' => 'title_codes',
			'blank' => TRUE,
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'paid_vacation' => ['text' => ITEM_PM011, 'type' => 'text', 'class' => 'w-80'],
		'last_paid_vacation' => ['text' => ITEM_PM012, 'type' => 'text', 'class' => 'w-80'],
		'team_id' => ['text' => ITEM_PM013, 'type' => 'select', 'config' => 'team_ids', 'blank' => TRUE, 'filter' => 'mb_convert_kana:a', 'required' => TRUE, 'class' => 'w-300'],
		'crew_id' => ['text' => ITEM_PM014, 'type' => 'select', 'config' => 'crew_ids', 'blank' => TRUE, 'class' => 'w-300'],
		'personnel_id' => ['text' => ITEM_PM015, 'type' => 'select', 'config' => 'personnel_ids', 'blank' => TRUE, 'class' => 'w-300'],
		'fire_id' => ['text' => ITEM_PM016, 'type' => 'text', 'class' => 'w-80'],
		'license_01' => ['text' => ITEM_PM017, 'type' => 'select', 'config' => 'personnel_license_01s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_02' => ['text' => ITEM_PM018, 'type' => 'select', 'config' => 'personnel_license_02s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_03' => ['text' => ITEM_PM019, 'type' => 'select', 'config' => 'personnel_license_03s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_04' => ['text' => ITEM_PM020, 'type' => 'select', 'config' => 'personnel_license_04s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_05' => ['text' => ITEM_PM021, 'type' => 'select', 'config' => 'personnel_license_05s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_06' => ['text' => ITEM_PM022, 'type' => 'select', 'config' => 'personnel_license_06s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_07' => ['text' => ITEM_PM023, 'type' => 'select', 'config' => 'personnel_license_07s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_08' => ['text' => ITEM_PM024, 'type' => 'select', 'config' => 'personnel_license_08s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_09' => ['text' => ITEM_PM025, 'type' => 'select', 'config' => 'personnel_license_09s', 'blank' => TRUE, 'class' => 'w-300'],
		'license_10' => ['text' => ITEM_PM026, 'type' => 'select', 'config' => 'personnel_license_10s', 'blank' => TRUE, 'class' => 'w-300'],
		'bus_stop' => ['text' => ITEM_PM027, 'type' => 'text', 'class' => 'w-300'],
		'mobile_number' => ['text' => ITEM_PM028, 'type' => 'text', 'class' => 'w-300']
	],
	'personnel_year' => [
		'py_year_month' => [
			'text' => ITEM_PMY_PY_YEAR_MONTH,
			'type' => 'text',
		],
		'p_id' => [
			'text' => ITEM_PMY_P_ID,
			'type' => 'text',
		],
		'work_days' => [
			'text' => ITEM_PMY_WORK_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'vacation_days' => [
			'text' => ITEM_PMY_VACATION_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'work_hours' => [
			'text' => ITEM_PMY_WORK_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'night_work_hours' => [
			'text' => ITEM_PMY_NIGHT_WORK_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'extra_work_hours' => [
			'text' => ITEM_PMY_EXTRA_WORK_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'extra_night_work_hours' => [
			'text' => ITEM_PMY_EXTRA_NIGHT_WORK_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'overtime' => [
			'text' => ITEM_PMY_OVERTIME,
			'type' => 'text',
			'default' => '0',
		],
		'overtime25' => [
			'text' => ITEM_PMY_OVERTIME25,
			'type' => 'text',
			'default' => '0',
		],
		'overtime35' => [
			'text' => ITEM_PMY_OVERTIME35,
			'type' => 'text',
			'default' => '0',
		],
		'd_duty' => [
			'text' => ITEM_PMY_D_DUTY,
			'type' => 'text',
			'default' => '0',
		],
		'n_duty' => [
			'text' => ITEM_PMY_N_DUTY,
			'type' => 'text',
			'default' => '0',
		],
		'dn_duty' => [
			'text' => ITEM_PMY_DN_DUTY,
			'type' => 'text',
			'default' => '0',
		],
		'day_duty' => [
			'text' => ITEM_PMY_DAY_DUTY,
			'type' => 'text',
			'default' => '0',
		],
		'night_duty' => [
			'text' => ITEM_PMY_NIGHT_DUTY,
			'type' => 'text',
			'default' => '0',
		],
		'fire_plural' => [
			'text' => ITEM_PMY_FIRE_PLURAL,
			'type' => 'text',
			'default' => '0',
		],
		'fire_jippo' => [
			'text' => ITEM_PMY_FIRE_JIPPO,
			'type' => 'text',
			'default' => '0',
		],
		'acting_captain' => [
			'text' => ITEM_PMY_ACTING_CAPTAIN,
			'type' => 'text',
			'default' => '0',
		],
		'meal_allowance' => [
			'text' => ITEM_PMY_MEAL_ALLOWANCE,
			'type' => 'text',
			'default' => '0',
		],
		'absence_days' => [
			'text' => ITEM_PMY_ABSENCE_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'r_days' => [
			'text' => ITEM_PMY_R_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hl_days' => [
			'text' => ITEM_PMY_HL_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hd1_days' => [
			'text' => ITEM_PMY_HD1_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hd2_days' => [
			'text' => ITEM_PMY_HD2_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hd3_days' => [
			'text' => ITEM_PMY_HD3_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hd4_days' => [
			'text' => ITEM_PMY_HD4_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'hd5_days' => [
			'text' => ITEM_PMY_HD5_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'x_days' => [
			'text' => ITEM_PMY_X_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'y_days' => [
			'text' => ITEM_PMY_Y_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'z_days' => [
			'text' => ITEM_PMY_Z_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'me1_days' => [
			'text' => ITEM_PMY_ME1_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'me2_days' => [
			'text' => ITEM_PMY_ME2_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'ne1_hours' => [
			'text' => ITEM_PMY_NE1_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'ne2_hours' => [
			'text' => ITEM_PMY_NE2_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'ne3_hours' => [
			'text' => ITEM_PMY_NE3_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'ne4_hours' => [
			'text' => ITEM_PMY_NE4_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'f_hours' => [
			'text' => ITEM_PMY_F_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'fe_hours' => [
			'text' => ITEM_PMY_FE_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'fd_days' => [
			'text' => ITEM_PMY_FD_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'oj1_hours' => [
			'text' => ITEM_PMY_OJ1_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'oj2_hours' => [
			'text' => ITEM_PMY_OJ2_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'oj3_hours' => [
			'text' => ITEM_PMY_OJ3_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'sh_days' => [
			'text' => ITEM_PMY_SH_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'se_hours' => [
			'text' => ITEM_PMY_SE_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'se_night_hours' => [
			'text' => ITEM_PMY_SE_NIGHT_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'sm_hours' => [
			'text' => ITEM_PMY_SM_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'sm_night_hours' => [
			'text' => ITEM_PMY_SM_NIGHT_HOURS,
			'type' => 'text',
			'default' => '0',
		],
		'te_days' => [
			'text' => ITEM_PMY_TE_DAYS,
			'type' => 'text',
			'default' => '0',
		],
		'mt_hours' => [
			'text' => ITEM_PMY_MT_HOURS,
			'type' => 'text',
			'default' => '0',
		]
	],
	'task' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label']
		],
		'status' => [
			'text' => 'ステータス',
			'type' => 'radios',
			'config' => 'task_status_types',
			'required' => TRUE,
		],
		't_id' => [
			'text' => 'T-ID',
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
		],
		'guard_name' => [
			'text' => '警備対象',
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
		],
		'day_type' => [
			'text' => '曜日',
			'type' => 'radios',
			'config' => 'task_day_types',
			'required' => TRUE,
		],
		'night_day' => [
			'text' => '昼夜の別',
			'type' => 'radios',
			'config' => 'task_day_nights',
			'required' => TRUE,
		],
		'personnel' => [
			'text' => '人数',
			'type' => 'text',
			'class' => 'w-80',
		],
		'manager' => [
			'text' => 'マネージャー',
			'type' => 'text',
			'class' => 'w-80',
		],
		'sub_manager' => [
			'text' => 'サブ・マネージャー',
			'type' => 'text',
			'class' => 'w-80',
		],
		'leader' => ['text' => 'リーダー', 'type' => 'text', 'class' => 'w-80'],
		'sub_leader' => ['text' => 'サブ・リーダー', 'type' => 'text', 'class' => 'w-80'],
		'chief' => ['text' => 'チーフ', 'type' => 'text', 'class' => 'w-80'],
		'sub_chief' => ['text' => 'サブ・チーフ', 'type' => 'text', 'class' => 'w-80'],
		'woman_only' => ['text' => '女性のみ', 'type' => 'text', 'class' => 'w-80'],
		'woman_possible' => ['text' => '女性可', 'type' => 'text', 'class' => 'w-80'],
		'license_01' => ['text' => 'Q1', 'type' => 'text', 'class' => 'w-80'],
		'license_02' => ['text' => 'Q2', 'type' => 'text', 'class' => 'w-80'],
		'license_03' => ['text' => 'Q3', 'type' => 'text', 'class' => 'w-80'],
		'license_04' => ['text' => 'Q4', 'type' => 'text', 'class' => 'w-80'],
		'license_05' => ['text' => 'Q5', 'type' => 'text', 'class' => 'w-80'],
		'license_06' => ['text' => 'Q6', 'type' => 'text', 'class' => 'w-80'],
		'license_07' => ['text' => 'Q7', 'type' => 'text', 'class' => 'w-80'],
		'license_08' => ['text' => 'Q8', 'type' => 'text', 'class' => 'w-80'],
		'license_09' => ['text' => 'Q9', 'type' => 'text', 'class' => 'w-80'],
		'license_10' => ['text' => 'Q10', 'type' => 'text', 'class' => 'w-80']
	],
	'task_month' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label']
		],
		'status' => [
			'text' => ITEM_TMM_STATUS,
			'type' => 'view',
			'config' => 'task_month_status_types',
			'edit_only' => TRUE,
		],
		'tm_year_month' => [
			'text' => ITEM_TMM_TM_YEAR_MONTH,
			'type' => 'current_year_month',
			'filter' => 'year_month',
		],
		'tm_id' => [
			'text' => ITEM_TMM_TM_ID,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'task_name' => [
			'text' => ITEM_TMM_TASK_NAME,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
		],
		'show_name' => [
			'text' => ITEM_TMM_SHOW_NAME,
			'type' => 'text',
			'class' => 'w-300',
		],
		'show_mark' => [
			'text' => ITEM_TMM_SHOW_MARK,
			'type' => 'text',
			'required' => TRUE,
			'class' => 'w-300',
		],
		'frame_color' => [
			'text' => ITEM_TMM_FRAME_COLOR,
			'type' => 'text',
			'class' => 'w-140',
			'filter' => 'mb_convert_kana:a',
		],
		'start_date' => [
			'text' => ITEM_TMM_START_DATE,
			'type' => 'date',
			'required' => TRUE
		],
		'end_date' => [
			'text' => ITEM_TMM_END_DATE,
			'type' => 'date'
		],
		'duty_type' => [
			'text' => ITEM_TMM_DUTY_TYPE,
			'type' => 'select',
			'options' => ['D'=>'D', 'N'=>'N'],
			'blank' => TRUE,
			'class' => 'w-300',
			'filter' => 'mb_convert_kana:a',
		],
		'start_time' => [
			'text' => ITEM_TMM_START_TIME,
			'type' => 'text',
			'class' => 'w-140',
			'filter' => ['mb_convert_kana:a', 'time'],
		],
		'end_time' => [
			'text' => ITEM_TMM_END_TIME,
			'type' => 'text',
			'class' => 'w-140',
			'filter' => ['mb_convert_kana:a', 'time'],
		],
		'work_hours' => [
			'text' => ITEM_TMM_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'night_work_hours' => [
			'text' => ITEM_TMM_NIGHT_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'meal_allowance' => [
			'text' => ITEM_TMM_MEAL_ALLOWANCE,
			'type' => 'text',
			'class' => 'w-80',
		],
		'personnel' => ['text' => ITEM_TMM_PERSONNEL, 'type' => 'text', 'class' => 'w-80'],
		'manager' => ['text' => ITEM_TMM_MANAGER, 'type' => 'text', 'class' => 'w-80'],
		'sub_manager' => ['text' => ITEM_TMM_SUB_MANAGER, 'type' => 'text', 'class' => 'w-80'],
		'leader' => ['text' => ITEM_TMM_LEADER, 'type' => 'text', 'class' => 'w-80'],
		'sub_leader' => ['text' => ITEM_TMM_SUB_LEADER, 'type' => 'text', 'class' => 'w-80'],
		'chief' => ['text' => ITEM_TMM_CHIEF, 'type' => 'text', 'class' => 'w-80'],
		'sub_chief' => ['text' => ITEM_TMM_SUB_CHIEF, 'type' => 'text', 'class' => 'w-80'],
		'woman_only' => ['text' => ITEM_TMM_WOMAN_ONLY, 'type' => 'text', 'class' => 'w-80'],
		'woman_possible' => ['text' => ITEM_TMM_WOMAN_POSSIBLE, 'type' => 'text', 'class' => 'w-80'],
		'license_01' => ['text' => ITEM_TMM_LICENSE_01, 'type' => 'text', 'class' => 'w-80'],
		'license_02' => ['text' => ITEM_TMM_LICENSE_02, 'type' => 'text', 'class' => 'w-80'],
		'license_03' => ['text' => ITEM_TMM_LICENSE_03, 'type' => 'text', 'class' => 'w-80'],
		'license_04' => ['text' => ITEM_TMM_LICENSE_04, 'type' => 'text', 'class' => 'w-80'],
		'license_05' => ['text' => ITEM_TMM_LICENSE_05, 'type' => 'text', 'class' => 'w-80'],
		'license_06' => ['text' => ITEM_TMM_LICENSE_06, 'type' => 'text', 'class' => 'w-80'],
		'license_07' => ['text' => ITEM_TMM_LICENSE_07, 'type' => 'text', 'class' => 'w-80'],
		'license_08' => ['text' => ITEM_TMM_LICENSE_08, 'type' => 'text', 'class' => 'w-80'],
		'license_09' => ['text' => ITEM_TMM_LICENSE_09, 'type' => 'text', 'class' => 'w-80'],
		'license_10' => ['text' => ITEM_TMM_LICENSE_10, 'type' => 'text', 'class' => 'w-80'],
		'personnel_names' => [
			'text' => ITEM_TMM_PERSONNEL_NAMES,
			'type' => 'text',
			'filter' => ['mb_convert_kana:a', 'removeSpace', 'convertName'],
		]
	],
	'duty_assignment' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label']
		],
//		'status' => [
//			'text' => ITEM_DAT_STATUS,
//			'type' => 'text',
//			'required' => TRUE,
//			'class' => 'w-80',
//		],
		'p_id' => [
			'text' => ITEM_DAT_P_ID,
			'type' => 'text',
			'required' => TRUE,
		],
		'name' => [
			'text' => ITEM_DAT_NAME,
			'type' => 'text',
			'required' => TRUE,
		],
		'kana' => [
			'text' => ITEM_DAT_KANA,
			'type' => 'text',
			'required' => TRUE,
		],
		'gender' => [
			'text' => ITEM_DAT_GENDER,
			'type' => 'radios',
			'config' => 'gender_types_2',
			'selected' => '',
			'required' => TRUE,
		],
		'service_years' => [
			'text' => ITEM_DAT_SERVICE_YEARS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'new_employee' => ['text' => ITEM_DAT_NEW_EMPLOYEE, 'type' => 'text', 'class' => 'w-80'],
		'title_code' => ['text' => ITEM_DAT_TITLE_CODE, 'type' => 'select', 'config' => 'title_codes', 'blank' => TRUE, 'filter' => 'mb_convert_kana:a'],
		'paid_vacation' => ['text' => ITEM_DAT_PAID_VACATION, 'type' => 'text', 'class' => 'w-80'],
		'last_paid_vacation' => ['text' => ITEM_DAT_LAST_PAID_VACATION, 'type' => 'text', 'class' => 'w-80'],
		'team_id' => ['text' => ITEM_DAT_TEAM_ID, 'type' => 'select', 'config' => 'team_ids', 'blank' => TRUE, 'filter' => 'mb_convert_kana:a', 'required' => TRUE],
		'crew_id' => ['text' => ITEM_DAT_CREW_ID, 'type' => 'select', 'config' => 'crew_ids', 'blank' => TRUE],
		'personnel_id' => ['text' => ITEM_DAT_PERSONNEL_ID, 'type' => 'select', 'config' => 'personnel_ids', 'blank' => TRUE],
		'fire_id' => ['text' => ITEM_DAT_FIRE_ID, 'type' => 'text', 'class' => 'w-80'],
		'd_duty' => ['text' => ITEM_DAT_D_DUTY, 'type' => 'text', 'class' => 'w-80'],
		'n_duty' => ['text' => ITEM_DAT_N_DUTY, 'type' => 'text', 'class' => 'w-80'],
		'dn_duty' => ['text' => ITEM_DAT_DN_DUTY, 'type' => 'text', 'class' => 'w-80'],
		'day_duty' => ['text' => ITEM_DAT_DAY_DUTY, 'type' => 'text', 'class' => 'w-80'],
		'night_duty' => ['text' => ITEM_DAT_NIGHT_DUTY, 'type' => 'text', 'class' => 'w-80'],
		'fire_plural' => ['text' => ITEM_DAT_FIRE_PLURAL, 'type' => 'text', 'class' => 'w-80'],
		'fire_jippo' => ['text' => ITEM_DAT_FIRE_JIPPO, 'type' => 'text', 'class' => 'w-80'],
		'acting_captain' => ['text' => ITEM_DAT_ACTING_CAPTAIN, 'type' => 'text', 'class' => 'w-80'],
		'meal_allowance' => ['text' => ITEM_DAT_MEAL_ALLOWANCE, 'type' => 'text', 'class' => 'w-80'],
		'absence_days' => ['text' => ITEM_DAT_ABSENCE_DAYS, 'type' => 'text', 'class' => 'w-80'],
		'work_days' => [
			'text' => ITEM_DAT_WORK_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'vacation_days' => [
			'text' => ITEM_DAT_VACATION_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'work_hours' => [
			'text' => ITEM_DAT_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'night_work_hours' => [
			'text' => ITEM_DAT_NIGHT_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'extra_work_hours' => [
			'text' => ITEM_DAT_EXTRA_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'extra_night_work_hours' => [
			'text' => ITEM_DAT_EXTRA_NIGHT_WORK_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'overtime25' => [
			'text' => ITEM_DAT_OVERTIME25,
			'type' => 'text',
			'class' => 'w-80',
		],
		'overtime35' => [
			'text' => ITEM_DAT_OVERTIME35,
			'type' => 'text',
			'class' => 'w-80',
		],
		'r_days' => [
			'text' => ITEM_DAT_R_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hl_days' => [
			'text' => ITEM_DAT_HL_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hd1_days' => [
			'text' => ITEM_DAT_HD1_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hd2_days' => [
			'text' => ITEM_DAT_HD2_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hd3_days' => [
			'text' => ITEM_DAT_HD3_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hd4_days' => [
			'text' => ITEM_DAT_HD4_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'hd5_days' => [
			'text' => ITEM_DAT_HD5_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'x_days' => [
			'text' => ITEM_DAT_X_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'y_days' => [
			'text' => ITEM_DAT_Y_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'z_days' => [
			'text' => ITEM_DAT_Z_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'me1_days' => [
			'text' => ITEM_DAT_ME1_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'me2_days' => [
			'text' => ITEM_DAT_ME2_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'ne1_hours' => [
			'text' => ITEM_DAT_NE1_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'ne2_hours' => [
			'text' => ITEM_DAT_NE2_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'ne3_hours' => [
			'text' => ITEM_DAT_NE3_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'ne4_hours' => [
			'text' => ITEM_DAT_NE4_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'f_hours' => [
			'text' => ITEM_DAT_F_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'fe_hours' => [
			'text' => ITEM_DAT_FE_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'fd_days' => [
			'text' => ITEM_DAT_FD_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'oj1_hours' => [
			'text' => ITEM_DAT_OJ1_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'oj2_hours' => [
			'text' => ITEM_DAT_OJ2_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'oj3_hours' => [
			'text' => ITEM_DAT_OJ3_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'sh_days' => [
			'text' => ITEM_DAT_SH_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'se_hours' => [
			'text' => ITEM_DAT_SE_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'se_night_hours' => [
			'text' => ITEM_DAT_SE_NIGHT_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'sm_hours' => [
			'text' => ITEM_DAT_SM_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'sm_night_hours' => [
			'text' => ITEM_DAT_SM_NIGHT_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'te_days' => [
			'text' => ITEM_DAT_TE_DAYS,
			'type' => 'text',
			'class' => 'w-80',
		],
		'mt_hours' => [
			'text' => ITEM_DAT_MT_HOURS,
			'type' => 'text',
			'class' => 'w-80',
		],
	],
	'watch_fire' => [
		'status' => ['text' => 'ステータス'],
		'wf_year_month' => ['text' => '年月'],
		'wf_type' => ['text' => '宿日直・消防訓練別'],
		'd_21' => ['text' => '21日'],
		'd_22' => ['text' => '22日'],
		'd_23' => ['text' => '23日'],
		'd_24' => ['text' => '24日'],
		'd_25' => ['text' => '25日'],
		'd_26' => ['text' => '26日'],
		'd_27' => ['text' => '27日'],
		'd_28' => ['text' => '28日'],
		'd_29' => ['text' => '29日'],
		'd_30' => ['text' => '30日'],
		'd_31' => ['text' => '31日'],
		'd_1' => ['text' => '1日'],
		'd_2' => ['text' => '2日'],
		'd_3' => ['text' => '3日'],
		'd_4' => ['text' => '4日'],
		'd_5' => ['text' => '5日'],
		'd_6' => ['text' => '6日'],
		'd_7' => ['text' => '7日'],
		'd_8' => ['text' => '8日'],
		'd_9' => ['text' => '9日'],
		'd_10' => ['text' => '10日'],
		'd_11' => ['text' => '11日'],
		'd_12' => ['text' => '12日'],
		'd_13' => ['text' => '13日'],
		'd_14' => ['text' => '14日'],
		'd_15' => ['text' => '15日'],
		'd_16' => ['text' => '16日'],
		'd_17' => ['text' => '17日'],
		'd_18' => ['text' => '18日'],
		'd_19' => ['text' => '19日'],
		'd_20' => ['text' => '20日']
	],
	'duty_update' => [
		'_init' => [
			'header' => ['class' => 'col-xs-3 control-label']
		],
		'p_id' => [
			'text' => ITEM_DAT_P_ID,
			'type' => 'view',
		],
		'name' => [
			'text' => ITEM_DAT_NAME,
			'type' => 'view',
		],
		'kana' => [
			'text' => ITEM_DAT_KANA,
			'type' => 'view',
		],
		'd_duty' => [
			'text' => ITEM_DAT_D_DUTY,
			'type' => 'view'
		],
		'n_duty' => [
			'text' => ITEM_DAT_N_DUTY,
			'type' => 'view'
		],
		'dn_duty' => [
			'text' => ITEM_DAT_DN_DUTY,
			'type' => 'view'
		],
		'day_duty' => [
			'text' => ITEM_DAT_DAY_DUTY,
			'type' => 'view'
		],
		'night_duty' => [
			'text' => ITEM_DAT_NIGHT_DUTY,
			'type' => 'view'
		],
		'fire_plural' => [
			'text' => ITEM_DAT_FIRE_PLURAL,
			'type' => 'view'
		],
		'fire_jippo' => ['text' => ITEM_DAT_FIRE_JIPPO, 'type' => 'text', 'class' => 'w-80'],
		'acting_captain' => ['text' => ITEM_DAT_ACTING_CAPTAIN, 'type' => 'text', 'class' => 'w-80'],
		'meal_allowance' => ['text' => ITEM_DAT_MEAL_ALLOWANCE, 'type' => 'text', 'class' => 'w-80'],
		'absence_days' => ['text' => ITEM_DAT_ABSENCE_DAYS, 'type' => 'text', 'class' => 'w-80'],
		'work_hours' => [
			'text' => ITEM_DAT_WORK_HOURS,
			'type' => 'view',
		],
		'night_work_hours' => [
			'text' => ITEM_DAT_NIGHT_WORK_HOURS,
			'type' => 'view',
		],
		'overtime25' => [
			'text' => ITEM_DAT_OVERTIME25,
			'type' => 'view',
		],
		'overtime35' => [
			'text' => ITEM_DAT_OVERTIME35,
			'type' => 'view',
		],
	],
];

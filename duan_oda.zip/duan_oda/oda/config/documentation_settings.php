<?php
$config["documentation_settings"] = array(
    // 印刷物一覧
    "documents" => array("A010" => " A010 勤務日程表-1",
                         "A010D"=> " A010 勤務日程表-1(確認用)",
                         "A011" => " A011 勤務日程表-2",
                         "A012" => " A012 勤務日程表-3",
                         "A020" => " A020 勤務日程表-4",
                         "A030" => " A030 勤務日程表-5",
                         "A040" => " A040 勤務時間集計表",
                         "A041" => " A041 勤務要員集計表",
                         "A100" => " A100 補勤者リスト",
                         "B010" => " B010 宿日直日程表",
                         "B020" => " B020 消防兼務・訓練日程表",
                         "B030" => " B030 臨時警備勤務詳細",
                         "B031" => " B031 月次タスク日程表",
                         "C010" => " C010 時間管理簿",
                         "S010" => " S010 勤務表ログリスト"
                        ),
    // コード一覧１
    "codes1" => array("D"     => ["disp" => "D"    , "color" => "",       "before" => 1, "after" => 0, "num" => 1, "mean" => "昼勤"],
                      "N"     => ["disp" => "N"    , "color" => "",       "before" => 1, "after" => 0, "num" => 1, "mean" => "夜勤"],
                      "DN"    => ["disp" => "DN"   , "color" => "",       "before" => 1, "after" => 0, "num" => 1, "mean" => "昼夜勤"],
                      "DW"    => ["disp" => "日"   , "color" => "",       "before" => 1, "after" => 0, "num" => 0, "mean" => "日直"],
                      "NW"    => ["disp" => "宿"   , "color" => "",       "before" => 1, "after" => 0, "num" => 0, "mean" => "宿直"],
                      "Rnn"   => ["disp" => "Rnn"  , "color" => "",       "before" => 1, "after" => 1, "num" => 1, "mean" => "臨時警備"],
                      "HLnn"  => ["disp" => "Hnn"  , "color" => "",       "before" => 1, "after" => 1, "num" => 1, "mean" => "返還高レベル使用済み燃料臨時警備"],
                      "HD1"   => ["disp" => ""     , "color" => "808080", "before" => 1, "after" => 0, "num" => 0, "mean" => "指定休"],
                      "HD2"   => ["disp" => "休"   , "color" => "FFFFB2", "before" => 1, "after" => 1, "num" => 0, "mean" => "休暇"],
                      "HD3"   => ["disp" => "特"   , "color" => "FFFFB2", "before" => 1, "after" => 1, "num" => 0, "mean" => "特別休暇"],
                      "HD4"   => ["disp" => "臨"   , "color" => "FFFFB2", "before" => 1, "after" => 1, "num" => 0, "mean" => "夏期休暇"],
                      "HD5"   => ["disp" => ""     , "color" => "",       "before" => 1, "after" => 0, "num" => 0, "mean" => "公休"],
                      "HD6"   => ["disp" => ""     , "color" => "",       "before" => 1, "after" => 0, "num" => 0, "mean" => "明け"],
                      "X"     => ["disp" => "X"    , "color" => "",       "before" => 1, "after" => 1, "num" => 0, "mean" => "欠勤"],
                      "Ynn"   => ["disp" => "Ynn"  , "color" => "",       "before" => 0, "after" => 1, "num" => 0, "mean" => "早退"],
                      "Znn"   => ["disp" => "Znn"  , "color" => "",       "before" => 0, "after" => 1, "num" => 0, "mean" => "補勤"],
                      "ME1nn" => ["disp" => "健"   , "color" => "",       "before" => 1, "after" => 2, "num" => 0, "mean" => "健康診断"],
                      "ME2nn" => ["disp" => "電"   , "color" => "",       "before" => 0, "after" => 1, "num" => 0, "mean" => "電離診断"],
                      "NE1nn" => ["disp" => "NE1"  , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "新任教育"],
                      "NE2nn" => ["disp" => "NE2"  , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "システム教育"],
                      "NE3nn" => ["disp" => "NE3"  , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "現任教育"],
                      "NE4nn" => ["disp" => "NE4"  , "color" => "",       "before" => 0, "after" => 1, "num" => 0, "mean" => "運転適正診断講習"],
                      "FE00"  => ["disp" => "F"    , "color" => "FFFFCC", "before" => 0, "after" => 0, "num" => 0, "mean" => "定期消防訓練"],
                      "FEnn"  => ["disp" => "FEnn" , "color" => "",       "before" => 0, "after" => 2, "num" => 0, "mean" => "消防・防災訓練"],
                      "FDnn"  => ["disp" => "FD"   , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "消化専門隊隊長代行"],
                      "OJT1nn"=> ["disp" => "d"    , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "On the Job Trainning D 勤務"],
                      "OJT2nn"=> ["disp" => "n"    , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "On the Job Trainning N 勤務"],
                      "OJT3nn"=> ["disp" => "dn"   , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "On the Job Trainning DN 勤務"],
                      "SHnn"  => ["disp" => "SHnn" , "color" => "",       "before" => 0, "after" => 2, "num" => 0, "mean" => "保安教育"],
                      "SEnn"  => ["disp" => "SEnn" , "color" => "",       "before" => 0, "after" => 2, "num" => 0, "mean" => "教育・研修"],
                      "SMnn"  => ["disp" => "SMnn" , "color" => "",       "before" => 0, "after" => 2, "num" => 0, "mean" => "指定業務"],
                      "TEnn"  => ["disp" => "TEnn" , "color" => "",       "before" => 0, "after" => 2, "num" => 0, "mean" => "講習"],
                      "MTnn"  => ["disp" => "MTnn" , "color" => "",       "before" => 0, "after" => 0, "num" => 0, "mean" => "責任者会議"]
                     ),

    // コード一覧2
    "codes2" => array("D"      => ["up" => 1, "down" => 1],
                      "N"      => ["up" => 1, "down" => 1],
                      "DN"     => ["up" => 1, "down" => 0],
                      "DW"     => ["up" => 1, "down" => 0],
                      "NW"     => ["up" => 1, "down" => 0],
                      "Rnn"    => ["up" => 0, "down" => 1],
                      "HD1"    => ["up" => 1, "down" => 0],
                      "HD2"    => ["up" => 1, "down" => 0],
                      "HD3"    => ["up" => 1, "down" => 0],
                      "HD4"    => ["up" => 1, "down" => 0],
                      "ME1nn"  => ["up" => 0, "down" => 1],
                      "ME2nn"  => ["up" => 0, "down" => 1],
                      "NE1nn"  => ["up" => 1, "down" => 1],
                      "NE2nn"  => ["up" => 1, "down" => 1],
                      "NE3nn"  => ["up" => 0, "down" => 1],
                      "NE4nn"  => ["up" => 0, "down" => 1],
                      "FE00"   => ["up" => 0, "down" => 1],
                      "FEnn"   => ["up" => 0, "down" => 1],
                      "FDmm"   => ["up" => 1, "down" => 0],     // mm:00-50
                      "FDnn"   => ["up" => 1, "down" => 1],     // nn:51-99
                      "OJT1nn" => ["up" => 1, "down" => 1],
                      "OJT2nn" => ["up" => 1, "down" => 1],
                      "OJT3nn" => ["up" => 1, "down" => 1],
                      "SHnn"   => ["up" => 0, "down" => 1],
                      "SEnn"   => ["up" => 0, "down" => 1],
                      "SMnn"   => ["up" => 0, "down" => 1],
                      "TEnn"   => ["up" => 0, "down" => 1],
                      "MTnn"   => ["up" => 0, "down" => 1]),

    // 規定時間
    "prescribed_hours" => array("28" => 152.0,
                                "29" => 157.4,
                                "30" => 162.8,
                                "31" => 168.3),
                                
    // 規定時間(A2用）
    "prescribed_a2_hours" => array("28" => 79.9,
                                   "29" => 82.8,
                                   "30" => 85.7,
                                   "31" => 88.5),

    // 勤務時間
    "working_hours" => array("D"  => 9.0,
                             "N"  => 9.0,
                             "DN" => 18.0),

    // 深夜時間
    "night_working_hours" => array("N" => 4.0,
                                   "DN" => 4.0),

    // A020の１件辺りの処理時間の目安
    "a020_create_time" => 0.75,
);

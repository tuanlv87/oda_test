<?php

use Phinx\Migration\AbstractMigration;

class Initial extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     *
     * Uncomment this method if you would like to use it.
     *
    public function change()
    {
    }
    */
    
    /**
     * Migrate Up.
     */
    public function up()
    {
//		$this->table('user_masters')
//			->addColumn('auth_type', 'integer')
//			->addColumn('name', 'string', ['limit'=>128, 'null'=>'1', 'default'=>'NULL'])
//			->addColumn('rname', 'string', ['limit'=>128, 'null'=>'1', 'default'=>'NULL'])
//			->addColumn('password', 'string', ['limit'=>32, 'binary'=>'1', 'null'=>'1', 'default'=>'NULL'])
//			->addColumn('email', 'string', ['limit'=>128, 'null'=>'1', 'default'=>'NULL'])
//			->addColumn('created', 'timestamp', ['null'=>'1', 'default'=>'NULL'])
//			->addColumn('modified', 'timestamp', ['null'=>'1', 'default'=>'NULL'])
//			->create();

		$query = "
			DROP TABLE IF EXISTS users;
			CREATE TABLE IF NOT EXISTS users (
			 id bigint unsigned NOT NULL AUTO_INCREMENT,
			 code varchar(12) NOT NULL UNIQUE,
			 auth_type smallint unsigned NOT NULL,
			 name varchar(128) NULL DEFAULT NULL,
			 rname varchar(128) NULL DEFAULT NULL,
			 password varchar(32) binary NULL DEFAULT NULL,
			 email varchar(128) NULL DEFAULT NULL,
			 reg_date datetime NULL DEFAULT NULL,
			 created datetime NULL DEFAULT NULL,
			 modified datetime NULL DEFAULT NULL,
			 PRIMARY KEY (id)
			) ENGINE=InnoDb DEFAULT CHARSET=utf8;
		";
		$this->execute($query);
    }

    /**
     * Migrate Down.
     */
    public function down()
    {

    }
}
<?php
define('ODA_VERSION', '0.51.161128');

define('POST_INIT_BACKUP', TRUE);
define('PRE_BUILD_BACKUP', TRUE);

// 20MB
define('MAX_UPLOAD_FILESIZE', 20971520);

define('GENDER_TYPE_MAN', 1);
define('GENDER_TYPE_WOMAN', 2);

$config['gender_types'] = array(
	1 => '男',
	2 => '女'
);

$config['gender_types_2'] = array(
	1 => '男性',
	2 => '女性'
);

define('AUTH_TYPE_ADMIN', 1);
define('AUTH_TYPE_MANAGER', 2);
define('AUTH_TYPE_USER', 3);

/**
 * ユーザー権限で閲覧可能なcontrollerとaction
 */
$config['auth_allow_read_user'] = [
	'Users' => ['index', 'table'],
	'Masters' => ['index'],
	'Personnels' => ['index', 'table', 'download'],
	'PersonnelYears' => ['index', 'download'],
	'Tasks' => ['index', 'table', 'download'],
	'WatchFires' => ['index', 'table', 'download'],
	'TaskMonths' => ['top', 'index', 'table', 'table_list', 'table_schedule', 'download'],
	'Duty' => ['index', 'table', 'download'],
];

/**
 * 管理者権限で閲覧可能なUsersのaction
 * Users以外は制限無し
 */
$config['auth_allow_read_manager'] = [
	'Users' => ['index', 'table', 'edit', 'edit_confirm', 'edit_save'],
];

$config['users_auth_types'] = array(
	1 => 'admin',
	2 => '管理者',
	3 => '一般'
);

$config['users_auth_types2'] = array(
	2 => '管理者',
	3 => '一般'
);

$config['common_codes'] = array(
	'T-ID' => 'T-ID'
);

$config['day_names'] = ['日', '月', '火', '水', '木', '金', '土'];

define('SELECT_START_YEAR', 2015);

$config['select_month_list'] = [1=>1, 2=>2, 3=>3, 4=>4, 5=>5, 6=>6, 7=>7, 8=>8, 9=>9, 10=>10, 11=>11, 12=>12];

$config['day_order_array'] = [21,22,23,24,25,26,27,28,29,30,31,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];

$config['show_marks'] = [
	'DW' => '日',
	'NW' => '宿',
	'FE' => '消'
];

define('LOG_ID_FORMAT', '#%07d');

// -------------------------
// バックアップ用
// -------------------------
define('BACKUP_MAX_HISTORY', 20);
define('BACKUP_TYPE_NORMAL', 0);
define('BACKUP_TYPE_POST_INIT', 1);
define('BACKUP_TYPE_PRE_BUILD', 2);
define('BACKUP_TYPE_PUBLISH', 3);

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
	$config['backup_dir_path'] = ROOT.'/backup';
	$config['backup_dump_cmd'] = '"C:/Program Files/MySQL/MySQL Server 5.6/bin/mysqldump" %s --host=%s --user=%s --password=%s > %s';
	$config['backup_debug_dump_cmd'] = '"C:/Program Files/MySQL/MySQL Server 5.6/bin/mysqldump" %s --skip-extended-insert --host=%s --user=%s --password=%s > %s';
	$config['backup_restore_cmd'] = '"C:/Program Files/MySQL/MySQL Server 5.6/bin/mysql" %s --host=%s --user=%s --password=%s < %s';
} else if (PHP_OS == 'Linux') {
	$config['backup_dir_path'] = ROOT.'/backup';
	$config['backup_dump_cmd'] = '"mysqldump" %s --host=%s --user=%s --password=%s > %s';
	$config['backup_debug_dump_cmd'] = '"mysqldump" %s --skip-extended-insert --host=%s --user=%s --password=%s > %s';
	$config['backup_restore_cmd'] = '"mysql" %s --host=%s --user=%s --password=%s < %s';

} else {
	// /Applications/XAMPP/xamppfiles/bin/mysql oda_db --host=127.0.0.1 --user=root --password=root < /Users/hiroyoshi/Dropbox/MSS_ODA/20150902/150902_143829_2.dmp
	$config['backup_dir_path'] = ROOT.'/backup';
	$config['backup_dump_cmd'] = '/Applications/XAMPP/xamppfiles/bin/mysqldump %s --skip-extended-insert --host=%s --user=%s --password=%s > %s';
	$config['backup_restore_cmd'] = '/Applications/XAMPP/xamppfiles/bin/mysql %s --host=%s --user=%s --password=%s < %s';
}

// -------------------------
// 日程表作成
// -------------------------
define('DAT_STATUS_DEFAULT', 0);
define('DAT_OLD_EMPLOYEE', 0);
define('DAT_NEW_EMPLOYEE', 1);

define('DAT_START_DAY', 21);
define('DAT_END_DAY', 20);
define('DAT_FIND_MAX', 100);

define('DAT_WORK_HOURS_D', 9);
define('DAT_WORK_HOURS_N', 9);
define('DAT_FIRE_HOURS', 3);
define('DAT_PAID_VACATION', 9);
define('DAT_NIGHT_HOURS_N', 4);

define('DAT_CODE_D', 'D');
define('DAT_CODE_N', 'N');
define('DAT_CODE_DN', 'DN');
define('DAT_CODE_DW', 'DW');
define('DAT_CODE_NW', 'NW');
define('DAT_CODE_NOT_D', '-D');
define('DAT_CODE_NOT_N', '-N');
define('DAT_CODE_NOT_DN', '-DN');
define('DAT_CODE_PRI_D', '+D');
define('DAT_CODE_PRI_N', '+N');
define('DAT_CODE_PRI_DN', '+DN');
define('DAT_CODE_PRI_KOUKYU', '+HD5');
define('DAT_CODE_PRI_AKE', '+HD6');
define('DAT_CODE_SHITEI', 'HD1');
define('DAT_CODE_NORMAL', 'HD2');
define('DAT_CODE_SPECIAL', 'HD3');
define('DAT_CODE_RINJI', 'HD4');
define('DAT_CODE_KOUKYU', 'HD5');
define('DAT_CODE_AKE', 'HD6');
define('DAT_CODE_KEKKIN', 'X');
define('DAT_CODE_F', 'F');
define('DAT_CODE_FE', 'FE');
define('DAT_CODE_FE00', 'FE00');
define('DAT_CODE_MT', 'MT');
// 消防兼務日
define('DAT_CODE_FKD', 'FKD');
define('DAT_CODE_FKN', 'FKN');
// 消防残務日
define('DAT_CODE_EW', 'EW');

define('DAT_D_START_TIME', '07:30');
define('DAT_D_END_TIME', '17:30');
define('DAT_D_WORK_HOURS', 9);

define('DAT_N_START_TIME', '17:30');
define('DAT_N_END_TIME', '31:30'); // 7:30
define('DAT_N_WORK_HOURS', 9);
define('DAT_N_NIGHT_HOURS', 4);
//Dungnh
define('CREW_NO', 'CREW_NO');
define('FIRE_NO', 'FIRE_NO');
define('TRAINING_START_TIME', 'TRAINING_START_TIME');
define('TRAINING_STOP_TIME', 'TRAINING_STOP_TIME');

define('All_SETTING', 'All_SETTING');
define('PRIVATE_SETTING', 'PRIVATE_SETTING');

//$config['dat_codes'] = [
//	'D' => 'D',
//	'N' => 'N',
//	'DN' => 'DN',
//	'DW' => '日',
//	'NW' => '宿'
//];

$config['duty_base_hours'] = [
	28 => 152.0,
	29 => 157.4,
	30 => 162.8,
	31 => 168.3
];

$config['duty_a2_base_hours'] = [
	28 => 79.9,
	29 => 82.8,
	30 => 85.7,
	31 => 88.5
];

/**
 * 消防兼務開始日
 */
$config['duty_fire_dates'] = [
	21 => '21日',
	22 => '22日'
];

/**
 * チームID
 */
$config['duty_team_ids'] = [
	'A' => 'A',
	'B' => 'B',
	'C' => 'C'
];

$config['duty_team_rote'] = [
	'A' => ['C', 'B'],
	'B' => ['A', 'C'],
	'C' => ['B', 'A'],
];

/**
 * 日程表作成用　一般
 */
$config['duty_title_codes_1'] = ['MGR', 'MGR-S', 'LDR', 'LDR-S', 'CHF', 'CHF-S', 'A1'];

/**
 * 日程表作成用　フェロー
 */
$config['duty_title_codes_2'] = ['A2'];

$config['duty_personnel_checks'] = [
	'manager' => 'MGR',
	'sub_manager' => 'MGR-S',
	'leader' => 'LDR',
	'sub_leader' => 'LDR-S',
	'chief' => 'CHF',
	'sub_chief' => 'CHF-S'
];

$config['duty_personnel_checks_2'] = [
	'MGR' => 'manager',
	'MGR-S' => 'sub_manager',
	'LDR' => 'leader',
	'LDR-S' => 'sub_leader',
	'CHF' => 'chief',
	'CHF-S' => 'sub_chief'
];

/**
 * 土日祝が休みの役職
 */
$config['duty_holiday_titles'] = [
	'MGR',
	'MGR-S'
];

// -------------------------
// 日程表管理
// -------------------------
define('DE_STATUS_INIT', 1);
define('DE_STATUS_BUILD', 2);

// -------------------------
// 警備員マスター
// -------------------------

/**
 * ステータス
 */
define('PM_STATUS_TYPE_VALID', 1);
define('PM_STATUS_TYPE_LONG', -1);
define('PM_STATUS_TYPE_STOP', -2);
define('PM_STATUS_TYPE_RETIRE', -9);

$config['personnel_status_types'] = [
	1 => '有効',
	-1 => '長期出張',
	-2 => '休職',
	-9 => '退職'
];

/**
 * 新卒・中途採用の別
 */
define('PM_EMPLOYEE_TYPE_NEW', 1);
define('PM_EMPLOYEE_TYPE_MID', 2);

$config['employee_types'] = [
	PM_EMPLOYEE_TYPE_NEW => '新卒',
	PM_EMPLOYEE_TYPE_MID => '中途採用'
];

/**
 * 役職コード
 */
$config['title_codes'] = [
	'MGR' => 'MGR',
	'MGR-S' => 'MGR-S',
	'LDR' => 'LDR',
	'LDR-S' => 'LDR-S',
	'CHF' => 'CHF',
	'CHF-S' => 'CHF-S',
	'A1' => 'A1',
	'A2' => 'A2'
];

/**
 * チームID ['値' => '表示値']
 */
$config['team_ids'] = [
	'A' => 'A',
	'B' => 'B',
	'C' => 'C',
	'X' => 'X（本部）',
	'Y' => 'Y（フェロー）'
];

/**
 * チーム内クルーID ['値' => '表示値']
 */
$config['crew_ids'] = [
	'1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6', '7' => '7', '8' => '8'
];

/**
 * クルー内個人ID ['値' => '表示値']
 */
$config['personnel_ids'] = [
	'1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6', '7' => '7', '8' => '8', '9' => '9'
];

$config['fire_ids'] = [
	'1' => '1', '2' => '2', '3' => '3', '4' => '4'
];

$config['personnel_license_01s'] = [
	1 => '有り'
];
$config['personnel_license_02s'] = [
	1 => '有り'
];
$config['personnel_license_03s'] = [
	1 => '有り'
];
$config['personnel_license_04s'] = [
	1 => '有り'
];
$config['personnel_license_05s'] = [
	1 => '有り'
];
$config['personnel_license_06s'] = [
	1 => '隊長',
	2 => '隊長代行'
];
$config['personnel_license_07s'] = [
	1 => '兼務員',
	2 => '機関員'
];
$config['personnel_license_08s'] = [
	1 => '有り'
];
$config['personnel_license_09s'] = [
	1 => '有り'
];
$config['personnel_license_10s'] = [
	1 => '有り'
];
// -------------------------
// タスクマスター
// -------------------------

/**
 * ステータス
 */
define('TM_STATUS_TYPE_VALID', 1);
define('TM_STATUS_TYPE_INVALID', 0);

$config['task_status_types'] = [
	TM_STATUS_TYPE_VALID => '有効',
	TM_STATUS_TYPE_INVALID => '無効'
];

$config['task_day_types'] = [
	'W' => 'W',
	'S' => 'S',
	'H' => 'H'
];

$config['task_day_nights'] = [
	'D' => '昼',
	'N' => '夜'
];

// -------------------------
// 月次タスクマスター
// -------------------------

/**
 * ステータス
 */
define('TMM_STATUS_TYPE_COMP', 1);
define('TMM_STATUS_TYPE_NOTCOMP', 0);
define('TMM_STATUS_TYPE_CANCEL', -9);

$config['task_month_status_types'] = [
	TMM_STATUS_TYPE_COMP => '処理済',
	TMM_STATUS_TYPE_NOTCOMP => '未処理',
	TMM_STATUS_TYPE_CANCEL => '取消'
];

define('TMM_COUNT_TM_ID', '/^(R|HL)[0-9]+/');

// -------------------------
// タスクマスタテーブル
// -------------------------
define('TMT_STATUS_TYPE_COMP', 1);
define('TMT_STATUS_TYPE_NOTCOMP', 0);

// -------------------------
// 一時タスク
// -------------------------
define('TW_STATUS_TYPE_COMP', 1);
define('TW_STATUS_TYPE_NOTCOMP', 0);

define('TW_TYPE_TMM', 1);
define('TW_TYPE_TM', 2);

// -------------------------
// 勤務詳細
// -------------------------
define('DD_TYPE_TMM', 1);
define('DD_TYPE_TM', 2);

// -------------------------
// 宿日直・消防訓練
// -------------------------
define('WFT_STATUS_TYPE_COMP', 1);
define('WFT_STATUS_TYPE_NOTCOMP', 0);

// -------------------------
// 環境設定
// -------------------------
define('ENV_TMM_CURRENT_YEAR_MONTH', 'TMM_CURRENT_YEAR_MONTH');


// -------------------------
// 休暇設定
// -------------------------
/**
 * 			{value:'HD1', name:'HD1（指定休）'},
			{value:'HD2', name:'HD2（休暇）'},
			{value:'HD3', name:'HD3（特別休暇）'},
			{value:'HD4', name:'HD4（夏期休暇）'},
			{value:'HD5', name:'HD5（公休）'},
			{value:'-D', name:'-D（昼勤としない）'},
			{value:'-N', name:'-N（夜勤としない）'},
			{value:'-DN', name:'-DN（昼夜勤としない）'}
 */

 // -------------------------
 // 日程表の編集・更新で設定されるコード一覧
 // （taskテーブル、task_monthsテーブル、休暇HDXXは除く）
 // -------------------------
$config['duty_update_code_list'] = [
	'X'    => "欠勤",
	'DW'   => "日直",
	'NW'   => "宿直",
	'FKD'  => "兼務日(D)",
	'FKN'  => "兼務日(N)",
	'EW'   => "残務日",
	'FE00' => "定期消防訓練"
];

ALTER TABLE `maintenances` ADD `myear_month` INT UNSIGNED NULL DEFAULT NULL AFTER `mtype`;

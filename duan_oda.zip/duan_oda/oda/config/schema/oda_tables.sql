CREATE TABLE IF NOT EXISTS users (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 u_id varchar(12) NOT NULL,
 auth_type smallint NOT NULL,
 name varchar(128) NOT NULL,
 rname varchar(128) NULL DEFAULT NULL,
 password varchar(32) binary NOT NULL,
 email varchar(128) NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS personnels (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 p_year int unsigned NOT NULL,
 p_id varchar(32) NOT NULL,
 name varchar(128) NOT NULL,
 kana varchar(128) NOT NULL,
 gender smallint NOT NULL,
 birth_date date NOT NULL,
 enter_date date NOT NULL,
 leave_date date NULL DEFAULT NULL,
 employee_type smallint NOT NULL,
 title_code varchar(16) NULL DEFAULT NULL,
 paid_vacation int unsigned NULL DEFAULT 0,
 last_paid_vacation int unsigned NULL DEFAULT NULL,
 team_id char(1) NOT NULL,
 crew_id int NULL DEFAULT NULL,
 personnel_id int NULL DEFAULT NULL,
 fire_id int NULL DEFAULT NULL,
 license_01 smallint NULL DEFAULT NULL,
 license_02 smallint NULL DEFAULT NULL,
 license_03 smallint NULL DEFAULT NULL,
 license_04 smallint NULL DEFAULT NULL,
 license_05 smallint NULL DEFAULT NULL,
 license_06 smallint NULL DEFAULT NULL,
 license_07 smallint NULL DEFAULT NULL,
 license_08 smallint NULL DEFAULT NULL,
 license_09 smallint NULL DEFAULT NULL,
 license_10 smallint NULL DEFAULT NULL,
 bus_stop text NULL DEFAULT NULL,
 mobile_number text NULL DEFAULT NULL,
 created_user text NULL DEFAULT NULL,
 modified_user text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS personnel_years (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 py_year_month int unsigned NOT NULL,
 p_id varchar(32) NOT NULL,
 work_days int unsigned NOT NULL DEFAULT 0,
 vacation_days int unsigned NOT NULL DEFAULT 0,
 work_hours int unsigned NOT NULL DEFAULT 0,
 night_work_hours int unsigned NOT NULL DEFAULT 0,
 extra_work_hours int unsigned NOT NULL DEFAULT 0,
 extra_night_work_hours int unsigned NOT NULL DEFAULT 0,
 overtime int unsigned NOT NULL DEFAULT 0,
 overtime25 int unsigned NOT NULL DEFAULT 0,
 overtime35 int unsigned NOT NULL DEFAULT 0,
 d_duty int unsigned NOT NULL DEFAULT 0,
 n_duty int unsigned NOT NULL DEFAULT 0,
 dn_duty int unsigned NOT NULL DEFAULT 0,
 day_duty int unsigned NOT NULL DEFAULT 0,
 night_duty int unsigned NOT NULL DEFAULT 0,
 fire_plural int unsigned NOT NULL DEFAULT 0,
 fire_jippo int unsigned NOT NULL DEFAULT 0,
 acting_captain int unsigned NOT NULL DEFAULT 0,
 meal_allowance int unsigned NOT NULL DEFAULT 0,
 absence_days int unsigned NOT NULL DEFAULT 0,
 r_days int unsigned NOT NULL DEFAULT 0,
 hl_days int unsigned NOT NULL DEFAULT 0,
 hd1_days int unsigned NOT NULL DEFAULT 0,
 hd2_days int unsigned NOT NULL DEFAULT 0,
 hd3_days int unsigned NOT NULL DEFAULT 0,
 hd4_days int unsigned NOT NULL DEFAULT 0,
 hd5_days int unsigned NOT NULL DEFAULT 0,
 x_days int unsigned NOT NULL DEFAULT 0,
 y_days int unsigned NOT NULL DEFAULT 0,
 z_days int unsigned NOT NULL DEFAULT 0,
 me1_days int unsigned NOT NULL DEFAULT 0,
 me2_days int unsigned NOT NULL DEFAULT 0,
 ne1_days int unsigned NOT NULL DEFAULT 0,
 ne2_days int unsigned NOT NULL DEFAULT 0,
 ne3_days int unsigned NOT NULL DEFAULT 0,
 ne4_days int unsigned NOT NULL DEFAULT 0,
 f_days int unsigned NOT NULL DEFAULT 0,
 fe_days int unsigned NOT NULL DEFAULT 0,
 fd_days int unsigned NOT NULL DEFAULT 0,
 oj1_days int unsigned NOT NULL DEFAULT 0,
 oj2_days int unsigned NOT NULL DEFAULT 0,
 oj3_days int unsigned NOT NULL DEFAULT 0,
 sh_days int unsigned NOT NULL DEFAULT 0,
 se_days int unsigned NOT NULL DEFAULT 0,
 sm_days int unsigned NOT NULL DEFAULT 0,
 te_days int unsigned NOT NULL DEFAULT 0,
 mt_days int unsigned NOT NULL DEFAULT 0,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS tasks (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 t_year int unsigned NOT NULL,
 t_id varchar(4) NOT NULL,
 guard_name varchar(128) NOT NULL,
 day_type char(1) NOT NULL,
 night_day char(1) NOT NULL,
 personnel int unsigned NULL DEFAULT 0,
 manager int unsigned NULL DEFAULT 0,
 sub_manager int unsigned NULL DEFAULT 0,
 leader int unsigned NULL DEFAULT 0,
 sub_leader int unsigned NULL DEFAULT 0,
 chief int unsigned NULL DEFAULT 0,
 sub_chief int unsigned NULL DEFAULT 0,
 woman_only int unsigned NULL DEFAULT 0,
 woman_possible int unsigned NULL DEFAULT 0,
 license_01 int unsigned NULL DEFAULT 0,
 license_02 int unsigned NULL DEFAULT 0,
 license_03 int unsigned NULL DEFAULT 0,
 license_04 int unsigned NULL DEFAULT 0,
 license_05 int unsigned NULL DEFAULT 0,
 license_06 int unsigned NULL DEFAULT 0,
 license_07 int unsigned NULL DEFAULT 0,
 license_08 int unsigned NULL DEFAULT 0,
 license_09 int unsigned NULL DEFAULT 0,
 license_10 int unsigned NULL DEFAULT 0,
 created_user text NULL DEFAULT NULL,
 modified_user text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS task_months (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 tm_year_month int unsigned NOT NULL,
 tm_id varchar(4) NOT NULL,
 task_name varchar(128) NOT NULL,
 show_name varchar(128) NULL DEFAULT NULL,
 show_mark varchar(16) NOT NULL,
 frame_color varchar(8) NULL DEFAULT NULL,
 start_date date NOT NULL,
 end_date date NULL DEFAULT NULL,
 duty_type varchar(8) NULL DEFAULT NULL,
 start_time char(5) NULL DEFAULT NULL,
 end_time char(5) NULL DEFAULT NULL,
 work_hours int unsigned NULL DEFAULT 0,
 night_work_hours int unsigned NULL DEFAULT 0,
 meal_allowance smallint unsigned NULL DEFAULT 0,
 personnel int NULL DEFAULT 0,
 manager int unsigned NULL DEFAULT 0,
 sub_manager int unsigned NULL DEFAULT 0,
 leader int unsigned NULL DEFAULT 0,
 sub_leader int unsigned NULL DEFAULT 0,
 chief int unsigned NULL DEFAULT 0,
 sub_chief int unsigned NULL DEFAULT 0,
 woman_only int unsigned NULL DEFAULT 0,
 woman_possible int unsigned NULL DEFAULT 0,
 license_01 int unsigned NULL DEFAULT 0,
 license_02 int unsigned NULL DEFAULT 0,
 license_03 int unsigned NULL DEFAULT 0,
 license_04 int unsigned NULL DEFAULT 0,
 license_05 int unsigned NULL DEFAULT 0,
 license_06 int unsigned NULL DEFAULT 0,
 license_07 int unsigned NULL DEFAULT 0,
 license_08 int unsigned NULL DEFAULT 0,
 license_09 int unsigned NULL DEFAULT 0,
 license_10 int unsigned NULL DEFAULT 0,
 personnel_names text NULL DEFAULT NULL,
 created_user text NULL DEFAULT NULL,
 modified_user text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS task_tables (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 tt_year_month int unsigned NOT NULL,
 tt_date int unsigned NOT NULL,
 day_name char(2) NOT NULL,
 t_ids text NULL,
 t_ids_end text NULL,
 tm_ids text NULL,
 tm_ids_end text NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS watch_fires (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 wf_year_month int unsigned NOT NULL,
 wf_year int unsigned NOT NULL,
 wf_month int unsigned NOT NULL,
 wf_order int unsigned NOT NULL,
 wf_type varchar(4) NOT NULL,
 d_21 int unsigned NULL DEFAULT NULL,
 d_22 int unsigned NULL DEFAULT NULL,
 d_23 int unsigned NULL DEFAULT NULL,
 d_24 int unsigned NULL DEFAULT NULL,
 d_25 int unsigned NULL DEFAULT NULL,
 d_26 int unsigned NULL DEFAULT NULL,
 d_27 int unsigned NULL DEFAULT NULL,
 d_28 int unsigned NULL DEFAULT NULL,
 d_29 int unsigned NULL DEFAULT NULL,
 d_30 int unsigned NULL DEFAULT NULL,
 d_31 int unsigned NULL DEFAULT NULL,
 d_1 int unsigned NULL DEFAULT NULL,
 d_2 int unsigned NULL DEFAULT NULL,
 d_3 int unsigned NULL DEFAULT NULL,
 d_4 int unsigned NULL DEFAULT NULL,
 d_5 int unsigned NULL DEFAULT NULL,
 d_6 int unsigned NULL DEFAULT NULL,
 d_7 int unsigned NULL DEFAULT NULL,
 d_8 int unsigned NULL DEFAULT NULL,
 d_9 int unsigned NULL DEFAULT NULL,
 d_10 int unsigned NULL DEFAULT NULL,
 d_11 int unsigned NULL DEFAULT NULL,
 d_12 int unsigned NULL DEFAULT NULL,
 d_13 int unsigned NULL DEFAULT NULL,
 d_14 int unsigned NULL DEFAULT NULL,
 d_15 int unsigned NULL DEFAULT NULL,
 d_16 int unsigned NULL DEFAULT NULL,
 d_17 int unsigned NULL DEFAULT NULL,
 d_18 int unsigned NULL DEFAULT NULL,
 d_19 int unsigned NULL DEFAULT NULL,
 d_20 int unsigned NULL DEFAULT NULL,
 created_user text NULL DEFAULT NULL,
 modified_user text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS duty_assignments (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 da_year_month int unsigned NOT NULL,
 p_id varchar(32) NOT NULL,
 name varchar(128) NOT NULL,
 kana varchar(128) NOT NULL,
 gender smallint NOT NULL,
 service_years double(4,1) unsigned NOT NULL DEFAULT 0,
 new_employee int unsigned NOT NULL DEFAULT 0,
 title_code varchar(16) NULL DEFAULT NULL,
 paid_vacation int unsigned NULL DEFAULT 0,
 last_paid_vacation int unsigned NULL DEFAULT NULL,
 team_id char(1) NOT NULL,
 crew_id smallint NULL DEFAULT NULL,
 personnel_id smallint NULL DEFAULT NULL,
 fire_id smallint NULL DEFAULT NULL,
 d_duty int unsigned NOT NULL DEFAULT 0,
 n_duty int unsigned NOT NULL DEFAULT 0,
 dn_duty int unsigned NOT NULL DEFAULT 0,
 day_duty int unsigned NOT NULL DEFAULT 0,
 night_duty int unsigned NOT NULL DEFAULT 0,
 fire_plural int unsigned NOT NULL DEFAULT 0,
 fire_jippo int unsigned NOT NULL DEFAULT 0,
 acting_captain int unsigned NOT NULL DEFAULT 0,
 meal_allowance int unsigned NOT NULL DEFAULT 0,
 absence_days int unsigned NOT NULL DEFAULT 0,
 work_days int unsigned NOT NULL DEFAULT 0,
 vacation_days int unsigned NOT NULL DEFAULT 0,
 work_hours int unsigned NOT NULL DEFAULT 0,
 night_work_hours int unsigned NOT NULL DEFAULT 0,
 extra_work_hours int unsigned NOT NULL DEFAULT 0,
 extra_night_work_hours int unsigned NOT NULL DEFAULT 0,
 overtime25 int unsigned NOT NULL DEFAULT 0,
 overtime35 int unsigned NOT NULL DEFAULT 0,
 r_days int unsigned NOT NULL DEFAULT 0,
 hl_days int unsigned NOT NULL DEFAULT 0,
 hd1_days int unsigned NOT NULL DEFAULT 0,
 hd2_days int unsigned NOT NULL DEFAULT 0,
 hd3_days int unsigned NOT NULL DEFAULT 0,
 hd4_days int unsigned NOT NULL DEFAULT 0,
 hd5_days int unsigned NOT NULL DEFAULT 0,
 x_days int unsigned NOT NULL DEFAULT 0,
 y_days int unsigned NOT NULL DEFAULT 0,
 z_days int unsigned NOT NULL DEFAULT 0,
 me1_days int unsigned NOT NULL DEFAULT 0,
 me2_days int unsigned NOT NULL DEFAULT 0,
 ne1_days int unsigned NOT NULL DEFAULT 0,
 ne2_days int unsigned NOT NULL DEFAULT 0,
 ne3_days int unsigned NOT NULL DEFAULT 0,
 ne4_days int unsigned NOT NULL DEFAULT 0,
 f_days int unsigned NOT NULL DEFAULT 0,
 fe_days int unsigned NOT NULL DEFAULT 0,
 fd_days int unsigned NOT NULL DEFAULT 0,
 oj1_days int unsigned NOT NULL DEFAULT 0,
 oj2_days int unsigned NOT NULL DEFAULT 0,
 oj3_days int unsigned NOT NULL DEFAULT 0,
 sh_days int unsigned NOT NULL DEFAULT 0,
 se_days int unsigned NOT NULL DEFAULT 0,
 sm_days int unsigned NOT NULL DEFAULT 0,
 te_days int unsigned NOT NULL DEFAULT 0,
 mt_days int unsigned NOT NULL DEFAULT 0,
 document_order int unsigned NOT NULL DEFAULT 0,
 d_21 text NULL DEFAULT NULL,
 d_22 text NULL DEFAULT NULL,
 d_23 text NULL DEFAULT NULL,
 d_24 text NULL DEFAULT NULL,
 d_25 text NULL DEFAULT NULL,
 d_26 text NULL DEFAULT NULL,
 d_27 text NULL DEFAULT NULL,
 d_28 text NULL DEFAULT NULL,
 d_29 text NULL DEFAULT NULL,
 d_30 text NULL DEFAULT NULL,
 d_31 text NULL DEFAULT NULL,
 d_1 text NULL DEFAULT NULL,
 d_2 text NULL DEFAULT NULL,
 d_3 text NULL DEFAULT NULL,
 d_4 text NULL DEFAULT NULL,
 d_5 text NULL DEFAULT NULL,
 d_6 text NULL DEFAULT NULL,
 d_7 text NULL DEFAULT NULL,
 d_8 text NULL DEFAULT NULL,
 d_9 text NULL DEFAULT NULL,
 d_10 text NULL DEFAULT NULL,
 d_11 text NULL DEFAULT NULL,
 d_12 text NULL DEFAULT NULL,
 d_13 text NULL DEFAULT NULL,
 d_14 text NULL DEFAULT NULL,
 d_15 text NULL DEFAULT NULL,
 d_16 text NULL DEFAULT NULL,
 d_17 text NULL DEFAULT NULL,
 d_18 text NULL DEFAULT NULL,
 d_19 text NULL DEFAULT NULL,
 d_20 text NULL DEFAULT NULL,
 created_user text NULL DEFAULT NULL,
 modified_user text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS envs (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 env_key varchar(64) NOT NULL,
 env_value text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS holidays (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 hdate date NOT NULL,
 hname varchar(32) NOT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS task_works (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 status smallint NOT NULL,
 tw_year_month int unsigned NOT NULL,
 tw_date date NOT NULL,
 tw_type smallint unsigned NOT NULL DEFAULT 0,
 task_id varchar(4) NOT NULL,
 duty_type varchar(8) NULL DEFAULT NULL,
 personnel int unsigned NULL DEFAULT 0,
 manager int unsigned NULL DEFAULT 0,
 sub_manager int unsigned NULL DEFAULT 0,
 leader int unsigned NULL DEFAULT 0,
 sub_leader int unsigned NULL DEFAULT 0,
 chief int unsigned NULL DEFAULT 0,
 sub_chief int unsigned NULL DEFAULT 0,
 woman_only int unsigned NULL DEFAULT 0,
 woman_possible int unsigned NULL DEFAULT 0,
 license_01 int unsigned NULL DEFAULT 0,
 license_02 int unsigned NULL DEFAULT 0,
 license_03 int unsigned NULL DEFAULT 0,
 license_04 int unsigned NULL DEFAULT 0,
 license_05 int unsigned NULL DEFAULT 0,
 license_06 int unsigned NULL DEFAULT 0,
 license_07 int unsigned NULL DEFAULT 0,
 license_08 int unsigned NULL DEFAULT 0,
 license_09 int unsigned NULL DEFAULT 0,
 license_10 int unsigned NULL DEFAULT 0,
 personnel_names text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS duty_works (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 dw_year_month int unsigned NOT NULL,
 dw_date date NOT NULL,
 p_id varchar(32) NOT NULL,
 task_type smallint unsigned NOT NULL DEFAULT 0,
 task_id varchar(4) NOT NULL,
 start_date date NULL DEFAULT NULL,
 end_date date NULL DEFAULT NULL,
 duty_type varchar(8) NULL DEFAULT NULL,
 start_time char(5) NULL DEFAULT NULL,
 end_time char(5) NULL DEFAULT NULL,
 work_hours int unsigned NULL DEFAULT 0,
 night_work_hours int unsigned NULL DEFAULT 0,
 meal_allowance smallint unsigned NULL DEFAULT 0,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS duty_envs (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 de_year_month int unsigned NOT NULL,
 status int unsigned NULL DEFAULT 0,
 holiday_flag smallint unsigned NULL DEFAULT 0,
 start_team text NULL DEFAULT NULL,
 publish_date date NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS duty_logs (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 dl_year_month int unsigned NOT NULL,
 date date NOT NULL,
 change_date date NOT NULL,
 p_id varchar(32) NOT NULL,
 name varchar(128) NOT NULL,
 before_type text NOT NULL,
 after_type text NOT NULL,
 change_p_id1 varchar(32) NULL DEFAULT NULL,
 change_name1 varchar(128) NULL DEFAULT NULL,
 change_before_type1 text NULL DEFAULT NULL,
 change_after_type1 text NULL DEFAULT NULL,
 change_p_id2 varchar(32) NULL DEFAULT NULL,
 change_name2 varchar(128) NULL DEFAULT NULL,
 change_before_type2 text NULL DEFAULT NULL,
 change_after_type2 text NULL DEFAULT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS titles (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 title_code varchar(16) NOT NULL,
 title_order int NOT NULL,
 title_display varchar(32) NOT NULL,
 title_name varchar(32) NOT NULL,
 created datetime NOT NULL,
 modified datetime NOT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('MGR', '1', 'MGR', 'マネージャー', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('MGR-S', '2', 'MGR-S', 'サブ・マネージャー', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('LDR', '3', 'LDR', 'リーダー', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('LDR-S', '4', 'LDR-S', 'サブ・リーダー', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('CHF', '5', 'CHF', 'チーフ', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('CHF-S', '6', 'CHF-S', 'サブ・チーフ', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('A1', '7', 'A1', 'フェローA1', NOW(), NOW());
INSERT INTO titles (title_code, title_order, title_display, title_name, created, modified) VALUES ('A2', '8', 'A2', 'フェローA2', NOW(), NOW());

TRUNCATE holidays;
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/1/1','元日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/1/12','成人の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/2/11','建国記念の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/3/21','春分の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/4/29','昭和の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/5/3','憲法記念日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/5/4','みどりの日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/5/5','こどもの日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/5/6','振替休日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/7/20','海の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/9/21','敬老の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/9/22','国民の休日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/9/23','秋分の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/10/12','体育の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/11/3','文化の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/11/23','勤労感謝の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2015/12/23','天皇誕生日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/1/1','元日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/1/11','成人の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/2/11','建国記念の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/3/20','春分の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/3/21','振替休日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/4/29','昭和の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/5/3','憲法記念日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/5/4','みどりの日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/5/5','こどもの日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/7/18','海の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/8/11','山の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/9/19','敬老の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/9/22','秋分の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/10/10','体育の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/11/3','文化の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/11/23','勤労感謝の日',NOW(),NOW());
INSERT INTO holidays (hdate,hname,created,modified) VALUES ('2016/12/23','天皇誕生日',NOW(),NOW());

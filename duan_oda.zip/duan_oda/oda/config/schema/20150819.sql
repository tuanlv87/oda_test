
ALTER TABLE `task_months` CHANGE `work_hours` `work_hours` DOUBLE(4,1) UNSIGNED NULL DEFAULT '0.0';
ALTER TABLE `task_months` CHANGE `night_work_hours` `night_work_hours` DOUBLE(4,1) UNSIGNED NULL DEFAULT '0.0';

ALTER TABLE `duty_assignments` CHANGE `work_hours` `work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `night_work_hours` `night_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `extra_work_hours` `extra_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `extra_night_work_hours` `extra_night_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `overtime25` `overtime25` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `overtime35` `overtime35` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';

ALTER TABLE `duty_works` CHANGE `work_hours` `work_hours` DOUBLE(4,1) UNSIGNED NULL DEFAULT '0.0';
ALTER TABLE `duty_works` CHANGE `night_work_hours` `night_work_hours` DOUBLE(4,1) UNSIGNED NULL DEFAULT '0.0';

ALTER TABLE `personnel_years` CHANGE `work_hours` `work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `night_work_hours` `night_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `extra_work_hours` `extra_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `extra_night_work_hours` `extra_night_work_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `overtime` `overtime` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `overtime25` `overtime25` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `overtime35` `overtime35` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';

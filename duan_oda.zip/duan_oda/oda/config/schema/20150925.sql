ALTER TABLE `task_months` CHANGE `tm_id` `tm_id` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `tasks` CHANGE `t_id` `t_id` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `duty_works` CHANGE `task_id` `task_id` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `task_works` CHANGE `task_id` `task_id` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `duty_envs` ADD `update_flag` SMALLINT UNSIGNED NOT NULL DEFAULT '0' AFTER `holiday_flag`;
ALTER TABLE `duty_envs` ADD `start_fire_day` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `start_team`;
ALTER TABLE `duty_logs` ADD `created_user` TEXT NULL DEFAULT NULL AFTER `change_after_type2`, ADD `modified_user` TEXT NULL DEFAULT NULL AFTER `created_user`;


ALTER TABLE `maintenances` ADD `mtype` INT NOT NULL DEFAULT '0' AFTER `mname`;

ALTER TABLE `duty_assignments` CHANGE `ne1_days` `ne1_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `ne2_days` `ne2_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `ne3_days` `ne3_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `ne4_days` `ne4_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `f_days` `f_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `fe_days` `fe_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `oj1_days` `oj1_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `oj2_days` `oj2_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `oj3_days` `oj3_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `se_days` `se_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `sm_days` `sm_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `duty_assignments` CHANGE `mt_days` `mt_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';

ALTER TABLE `duty_assignments` ADD `se_night_hours` DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT '0.0' AFTER `se_hours`;
ALTER TABLE `duty_assignments` ADD `sm_night_hours` DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT '0.0' AFTER `sm_hours`;

ALTER TABLE `personnel_years` CHANGE `ne1_days` `ne1_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `ne2_days` `ne2_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `ne3_days` `ne3_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `ne4_days` `ne4_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `f_days` `f_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `fe_days` `fe_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `oj1_days` `oj1_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `oj2_days` `oj2_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `oj3_days` `oj3_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `se_days` `se_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `sm_days` `sm_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';
ALTER TABLE `personnel_years` CHANGE `mt_days` `mt_hours` DOUBLE(4,1) UNSIGNED NOT NULL DEFAULT '0.0';

ALTER TABLE `personnel_years` ADD `se_night_hours` DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT '0.0' AFTER `se_hours`;
ALTER TABLE `personnel_years` ADD `sm_night_hours` DECIMAL(4,1) UNSIGNED NOT NULL DEFAULT '0.0' AFTER `sm_hours`;

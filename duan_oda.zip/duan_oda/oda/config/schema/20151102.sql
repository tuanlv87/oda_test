CREATE TABLE IF NOT EXISTS duty_log_alerts (
    id bigint unsigned NOT NULL AUTO_INCREMENT,
    dla_year_month int unsigned NOT NULL,
    log_id int unsigned NOT NULL,
    sort_order int unsigned NOT NULL,
    message varchar(256) NOT NULL,
    created datetime NOT NULL,
    modified datetime NOT NULL,
    PRIMARY KEY (id),
    UNIQUE(dla_year_month, log_id, sort_order)
) ENGINE=InnoDb DEFAULT CHARSET=utf8;

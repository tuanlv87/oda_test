<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:34:15
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\init_comp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:304065657260d426175-63808823%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f35d1fd05ed2a49e0be7ec36826e8fa43f0e4605' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\init_comp.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '304065657260d426175-63808823',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657260d4a0291_70100733',
  'variables' => 
  array (
    'errors' => 0,
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657260d4a0291_70100733')) {function content_5657260d4a0291_70100733($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
<form class="form-horizontal" method="POST">
	<div class="notice-message">
		<p class="bg-danger text-danger">エラーが発生しました。初期化できません。<br><br>
			<?php echo htmlspecialchars(var_dump($_smarty_tpl->tpl_vars['errors']->value), ENT_QUOTES, 'UTF-8');?>

		</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/duty_build/init",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>

<?php } else { ?>
<form class="form-horizontal" method="POST">
	<div class="notice-message">
		<p class="bg-success text-success">正常に初期化されました。<br>
			日程表作成のために「<a href="/task_months/">月次タスクマスター</a>」「<a href="/holiday/form">休暇設定</a>」をおこなってください。
		</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-5">
			<a href="init" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
</form>
<?php }?>
<?php }} ?>

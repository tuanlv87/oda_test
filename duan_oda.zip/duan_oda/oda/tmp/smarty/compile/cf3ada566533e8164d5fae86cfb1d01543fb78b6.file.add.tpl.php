<?php /* Smarty version Smarty-3.1.21, created on 2016-03-07 10:36:25
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1708056dcdb1931a119-74049892%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cf3ada566533e8164d5fae86cfb1d01543fb78b6' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\add.tpl',
      1 => 1456791162,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1708056dcdb1931a119-74049892',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ret' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56dcdb19394236_91551272',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56dcdb19394236_91551272')) {function content_56dcdb19394236_91551272($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/tasks/add_confirm">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>
<?php }} ?>

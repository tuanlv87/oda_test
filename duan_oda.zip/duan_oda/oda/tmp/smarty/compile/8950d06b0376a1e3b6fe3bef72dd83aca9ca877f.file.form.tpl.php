<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:42:16
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyUpdate\form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1194456614a64563ac2-72352113%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8950d06b0376a1e3b6fe3bef72dd83aca9ca877f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyUpdate\\form.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1194456614a64563ac2-72352113',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56614a64657d08_02902253',
  'variables' => 
  array (
    'errors' => 0,
    'year_options' => 0,
    'year_selected' => 0,
    'month_options' => 0,
    'month_selected' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56614a64657d08_02902253')) {function content_56614a64657d08_02902253($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php';
?><form class="form-horizontal" method="get" action="/duty_update/form_pid">
	<p>年月を選択してください。</p>
	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['year']||$_smarty_tpl->tpl_vars['errors']->value['month']) {?> has-error<?php }?>">
		<label for="inputEmail3" class="col-xs-2 w-120 control-label">年月</label>
		<div class="col-xs-10 w-200">
			<select name="year">
				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['year_options']->value,'selected'=>$_smarty_tpl->tpl_vars['year_selected']->value),$_smarty_tpl);?>

			</select>
			年
			<select name="month">
				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['month_options']->value,'selected'=>$_smarty_tpl->tpl_vars['month_selected']->value),$_smarty_tpl);?>

			</select>
			月
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-10">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
</form>
<?php }} ?>

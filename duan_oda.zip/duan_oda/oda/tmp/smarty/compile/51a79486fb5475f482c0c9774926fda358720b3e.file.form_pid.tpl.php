<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:42:02
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyUpdate\form_pid.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24892565fd06d96d930-25980243%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '51a79486fb5475f482c0c9774926fda358720b3e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyUpdate\\form_pid.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24892565fd06d96d930-25980243',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565fd06dadbc93_17867671',
  'variables' => 
  array (
    'log_id' => 0,
    'new_flag' => 0,
    'duty_log_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565fd06dadbc93_17867671')) {function content_565fd06dadbc93_17867671($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_log_id')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.log_id.php';
if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
?><form id="form" class="form-horizontal" method="GET" action="/duty_update/edit">
	<?php if ($_REQUEST['log_id']>0) {?>
        <?php $_smarty_tpl->tpl_vars["log_id"] = new Smarty_variable($_REQUEST['log_id'], null, 0);?>
        <?php $_smarty_tpl->tpl_vars["new_flag"] = new Smarty_variable($_REQUEST['new_flag'], null, 0);?>
	<?php }?>
	<input name="year" value="<?php echo htmlspecialchars($_REQUEST['year'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="month" value="<?php echo htmlspecialchars($_REQUEST['month'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="log_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['log_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="new_flag" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['new_flag']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_year" value="<?php echo htmlspecialchars($_REQUEST['year'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_month" value="<?php echo htmlspecialchars($_REQUEST['month'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_log_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['log_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<p>社員番号を入力してください。</p>
	<div class="form-group">
		<label class="col-xs-2 w-120 control-label">年月</label>
		<div class="col-xs-10 w-200">
			<div class="form-value">
				<?php echo htmlspecialchars($_REQUEST['year'], ENT_QUOTES, 'UTF-8');?>
年<?php echo htmlspecialchars($_REQUEST['month'], ENT_QUOTES, 'UTF-8');?>
月
			</div>
		</div>
	</div>
	<div class="form-group">
		<label class="col-xs-2 w-120 control-label">ログNO</label>
		<div class="col-xs-10 w-200">
			<div class="form-value">
				<?php echo htmlspecialchars(smarty_modifier_log_id($_smarty_tpl->tpl_vars['log_id']->value), ENT_QUOTES, 'UTF-8');?>

				<?php if ($_smarty_tpl->tpl_vars['new_flag']->value==1) {?>
					（新規ログNO）
				<?php } else { ?>
					（継続ログNO）
				<?php }?>
			</div>
		</div>
	</div>
<?php if ($_smarty_tpl->tpl_vars['duty_log_list']->value) {?>
	<div class="form-group">
		<div style="padding:0 15px;width:500px;">
		<table class="table">
			<thead>
				<tr>
					<th>社員ID</th>
					<th>日付</th>
					<th>変更前のコード</th>
					<th>→</th>
					<th>変更後のコード</th>
				</tr>
			</thead>
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_log_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<tbody>
				<tr>
					<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['p_id'], ENT_QUOTES, 'UTF-8');?>
</td>
					<td><?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['d']->value['date']), ENT_QUOTES, 'UTF-8');?>
</td>
					<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['before_type'], ENT_QUOTES, 'UTF-8');?>
</td>
					<td></td>
					<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['after_type'], ENT_QUOTES, 'UTF-8');?>
</td>
				</tr>
			</tbody>
	<?php } ?>
		</table>
		</div>
	</div>
<?php }?>
	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['p_id']) {?> has-error<?php }?>">
		<label for="inputEmail3" class="col-xs-2 w-120 control-label">社員番号</label>
		<div class="col-xs-10 w-300">
			<input class="form-control w-80" id="input-p_id" name="p_id" value="<?php echo htmlspecialchars($_REQUEST['p_id'], ENT_QUOTES, 'UTF-8');?>
" placeholder="" type="text">
			<?php if ($_smarty_tpl->tpl_vars['errors']->value['p_id']) {?>
				<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['p_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
					<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
				<?php } ?>
			<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-10">
			<button type="submit" class="btn btn-primary">次へ</button>
			<?php if ($_smarty_tpl->tpl_vars['new_flag']->value!=1) {?>
			<button type="button" class="btn btn-default end-btn">ログを終了する</button>
			<?php echo '<script'; ?>
>
				$('.end-btn').click(function() {
					$('#form').attr("action", "/DutyUpdate/end");
					$('#form').attr("method", "POST");
				    $('#form').submit();
				});
			<?php echo '</script'; ?>
>
			<?php }?>
		</div>
	</div>
</form>
<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/DutyUpdate/end",'form_id'=>"endForm"), 0);?>

<?php }} ?>

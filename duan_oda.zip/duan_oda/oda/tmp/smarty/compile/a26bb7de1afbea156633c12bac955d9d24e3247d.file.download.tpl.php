<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 19:04:03
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13673574427138fd452-36882750%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a26bb7de1afbea156633c12bac955d9d24e3247d' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\download.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13673574427138fd452-36882750',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'current_year_month' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5744271393a4e3_56776436',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5744271393a4e3_56776436')) {function content_5744271393a4e3_56776436($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><?php if ($_smarty_tpl->tpl_vars['current_year_month']->value!='') {?>
<form class="form-horizontal" method="POST" action="download">
	<p><?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['current_year_month']->value), ENT_QUOTES, 'UTF-8');?>
の月次タスクマスターをダウンロードします。</p>
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
</form>
<?php } else { ?>
	<p class="text-danger">年月指定を実行してください。</p>
<?php }?>
<?php }} ?>

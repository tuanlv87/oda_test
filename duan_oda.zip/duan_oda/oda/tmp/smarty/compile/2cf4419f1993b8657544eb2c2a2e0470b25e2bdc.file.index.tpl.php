<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 18:30:00
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Home\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9122565725dc64b684-63158814%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2cf4419f1993b8657544eb2c2a2e0470b25e2bdc' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Home\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9122565725dc64b684-63158814',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725dc6c57a1_18261489',
  'variables' => 
  array (
    'userInfo' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725dc6c57a1_18261489')) {function content_565725dc6c57a1_18261489($_smarty_tpl) {?><div class="home-menu">
	<ul>
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li><a href="/users/">利用者管理</a></li>
		<li><a href="/masters/">マスターファイル管理</a></li>
		<li><a href="/task_months/">月次ファイル管理</a></li>
		<li>&nbsp;</li>
		<li><a href="/duty/">日程表管理</a></li>
		<li>&nbsp;</li>
		<li><a href="/documentation">資料作成</a></li>
		<li>&nbsp;</li>
		<li><a href="/maintenances/">システム保守</a></li>
		<li>&nbsp;</li>
		<li><a href="/logout">終　了</a></li>
<?php } else { ?>
		<li><a href="/users/">利用者管理</a></li>
		<li><a href="/masters/">マスターファイル管理</a></li>
		<li><a href="/task_months/">月次ファイル管理</a></li>
		<li>&nbsp;</li>
		<li><a href="/duty/">日程表管理</a></li>
		<li>&nbsp;</li>
		<li><a href="/documentation">資料作成</a></li>
		<li>&nbsp;</li>
		<li><a href="/logout">終　了</a></li>
<?php }?>
	</ul>
</div>
<div class="version-text">
	Ver. <?php echo htmlspecialchars(@constant('ODA_VERSION'), ENT_QUOTES, 'UTF-8');?>

</div>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-07-19 17:08:54
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Documentation\c010.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16595565b9af0e56b02-92039894%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff16e5fb3c55450afd7ce69c5ab8919fa094c73f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Documentation\\c010.tpl',
      1 => 1468915168,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16595565b9af0e56b02-92039894',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565b9af1082a64_28193866',
  'variables' => 
  array (
    'document' => 0,
    'documents' => 0,
    'Target_Date_Year' => 0,
    'Target_Date_Month' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565b9af1082a64_28193866')) {function content_565b9af1082a64_28193866($_smarty_tpl) {?><link rel="stylesheet" type="text/css" href="/css/documentation/common.css" media="all">
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/common.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/c010.js"><?php echo '</script'; ?>
>
<div class="main-content">
    <div class="center" style="width:300px;">
        <form>
            <h4>●<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['documents']->value[$_smarty_tpl->tpl_vars['document']->value], ENT_QUOTES, 'UTF-8');?>
</h4>
            <input type="hidden" name="Target_Date_Year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['Target_Date_Year']->value, ENT_QUOTES, 'UTF-8');?>
" />
            <input type="hidden" name="Target_Date_Month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['Target_Date_Month']->value, ENT_QUOTES, 'UTF-8');?>
" />

            <input type="hidden" name="document" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['document']->value, ENT_QUOTES, 'UTF-8');?>
" />
            <table>

            </table>
            <button id="print_btn" type="submit" class="btn btn-primary">作成</button>
        </form>
        <?php echo $_smarty_tpl->getSubTemplate ("Element/documentation_link.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("Element/documentation_mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:45:19
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Documentation\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31784565728286e3fc7-21127718%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c99ac52eaf6dd2fb539ae2d34352a9c8956a48bd' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Documentation\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31784565728286e3fc7-21127718',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56572828815297_85460725',
  'variables' => 
  array (
    'defautDate' => 0,
    'defautYear' => 0,
    'documents' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56572828815297_85460725')) {function content_56572828815297_85460725($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_select_date')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_select_date.php';
if (!is_callable('smarty_function_html_radios')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_radios.php';
?><link rel="stylesheet" type="text/css" href="/css/documentation/common.css" media="all">
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/common.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/index.js"><?php echo '</script'; ?>
>
<div class="main-content">
    <div class="center" style="width:250px">
        <form method="post" action="/documentation/setting">
            <p>印刷する資料を選んでください。</p>
            <table>
                <tr>
                    <td>
                        <label>
                        <?php echo smarty_function_html_select_date(array('time'=>$_smarty_tpl->tpl_vars['defautDate']->value,'start_year'=>$_smarty_tpl->tpl_vars['defautYear']->value-1,'end_year'=>$_smarty_tpl->tpl_vars['defautYear']->value+1,'display_days'=>false,'display_months'=>false),$_smarty_tpl);?>

                        年</label>
                    </td>
                    <td>
                        <label><?php echo smarty_function_html_select_date(array('time'=>$_smarty_tpl->tpl_vars['defautDate']->value,'display_days'=>false,'display_months'=>true,'display_years'=>false,'month_format'=>"%m"),$_smarty_tpl);?>
月</label>
                    </td>
                </tr>
            </table>
            <div class="menu">
            <?php echo smarty_function_html_radios(array('name'=>"document",'options'=>$_smarty_tpl->tpl_vars['documents']->value,'separator'=>'<br />'),$_smarty_tpl);?>

            </div>
            <button id="next_btn" type="submit" class="btn btn-primary">次へ</button>
        </form>
        <div sytle="height:30px;">&nbsp;</div>
        <div>
            <ul>
                <li><a href="/">トップメニューに戻る</a></li>
            </ul>
        </div>
    </div>
</div>
<?php }} ?>

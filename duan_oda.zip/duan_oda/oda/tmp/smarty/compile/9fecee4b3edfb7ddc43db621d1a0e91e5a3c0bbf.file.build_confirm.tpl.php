<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:38:42
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1631156572735815294-64151010%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9fecee4b3edfb7ddc43db621d1a0e91e5a3c0bbf' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1631156572735815294-64151010',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565727358cc441_55645884',
  'variables' => 
  array (
    'duty_env_status' => 0,
    'task_month_total' => 0,
    'holiday_flag' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565727358cc441_55645884')) {function content_565727358cc441_55645884($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST">
<?php if ($_smarty_tpl->tpl_vars['duty_env_status']->value==0) {?>
	<div class="notice-message">
		<p class="bg-danger"><?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の日程表は初期化されていません。「<a href="/duty_build/init">初期化</a>」を実行してください。</p>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php } elseif ($_smarty_tpl->tpl_vars['duty_env_status']->value==1) {?>
	<div class="notice-message">
		<p class="bg-warning"><?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の日程表を作成します。よろしければ「作成」ボタンを押してください。</p>
	</div>
	<?php if ($_smarty_tpl->tpl_vars['task_month_total']->value==0) {?>
	<div class="notice-message">
		<p class="bg-danger"><?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の月次タスクマスターが作成されていません。</p>
	</div>
	<?php }?>
	<?php if ($_smarty_tpl->tpl_vars['holiday_flag']->value==0) {?>
	<div class="notice-message">
		<p class="bg-danger"><?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の休暇設定がされていません。</p>
	</div>
	<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary send-btn">作成</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php } elseif ($_smarty_tpl->tpl_vars['duty_env_status']->value==2) {?>
	<div class="notice-message">
		<p class="bg-warning">作成済の<?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の日程表を更新します。よろしければ「更新」ボタンを押してください。</p>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary send-btn">更新</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php }?>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"/duty_build/build_comp",'form_id'=>"sendForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"/duty_build/build",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.send-btn').click(function(){
	showMask();
	$('#sendForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"現在、日程表を作成しています。"), 0);?>
<?php }} ?>

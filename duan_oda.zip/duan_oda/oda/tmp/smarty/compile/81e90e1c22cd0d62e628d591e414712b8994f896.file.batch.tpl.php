<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 15:41:46
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\batch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:26299568ca9223c5d26-12303260%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '81e90e1c22cd0d62e628d591e414712b8994f896' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\batch.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '26299568ca9223c5d26-12303260',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_568ca922402db4_64278485',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_568ca922402db4_64278485')) {function content_568ca922402db4_64278485($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_batch.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

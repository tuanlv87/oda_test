<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 17:26:10
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\delete.tpl" */ ?>
<?php /*%%SmartyHeaderCode:809656d4c3adc939a7-09211675%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1bb594ccd427f745c861f3a9bf6596b63e8ff6d8' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\delete.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '809656d4c3adc939a7-09211675',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d4c3adcd0a34_54779530',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d4c3adcd0a34_54779530')) {function content_56d4c3adcd0a34_54779530($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('key'=>"t_id",'text_id'=>"タスクID"), 0);?>

<?php }} ?>

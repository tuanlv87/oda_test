<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:28:58
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\side_navi.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10224565725e151a3b5-62702740%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83b8e615a444ea293f39cfcb4e2411b2b7a2ff3f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\side_navi.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10224565725e151a3b5-62702740',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e16c57a5_27027528',
  'variables' => 
  array (
    'sideNavi' => 0,
    'userInfo' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e16c57a5_27027528')) {function content_565725e16c57a5_27027528($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_active')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.active.php';
?><div class="side_navi">
<?php if ($_smarty_tpl->tpl_vars['sideNavi']->value['user']) {?>
	<h2 class="side-title">利用者管理</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/users/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['user'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1) {?>
		<li class="list-group-item"><a href="/users/batch" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['user'],"batch"), ENT_QUOTES, 'UTF-8');?>
">一括登録</a></li>
		<li class="list-group-item"><a href="/users/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['user'],"form"), ENT_QUOTES, 'UTF-8');?>
">登録・更新</a></li>
		<li class="list-group-item"><a href="/users/delete" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['user'],"delete"), ENT_QUOTES, 'UTF-8');?>
">削除</a></li>
		<li class="list-group-item"><a href="/users/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['user'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
<?php }?>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['master']) {?>
	<h5 class="side-title2">マスターファイルを選んでください</h5>
	<ul class="list-group">
		<li class="list-group-item"><a href="/personnels/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['master'],''), ENT_QUOTES, 'UTF-8');?>
">警備員マスター</a></li>
		<li class="list-group-item"><a href="/personnel_years/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['master'],''), ENT_QUOTES, 'UTF-8');?>
">年次警備員マスター</a></li>
		<li class="list-group-item"><a href="/tasks/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['master'],''), ENT_QUOTES, 'UTF-8');?>
">タスクマスター</a></li>
		<li class="list-group-item"><a href="/watch_fires/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['master'],''), ENT_QUOTES, 'UTF-8');?>
">宿日直・消防訓練マスター</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['personnel']) {?>
	<h2 class="side-title">警備員マスター</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/personnels/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
		<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/personnels/batch" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel'],"batch"), ENT_QUOTES, 'UTF-8');?>
">一括登録</a></li>
		<li class="list-group-item"><a href="/personnels/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel'],"form"), ENT_QUOTES, 'UTF-8');?>
">登録・更新</a></li>
		<li class="list-group-item"><a href="/personnels/delete" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel'],"delete"), ENT_QUOTES, 'UTF-8');?>
">削除</a></li>
		<?php }?>
		<li class="list-group-item"><a href="/personnels/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/masters/">マスターファイル選択に戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['personnel_year']) {?>
	<h2 class="side-title">年次警備員マスター</h2>
	<ul class="list-group">
		<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/personnel_years/batch" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel_year'],"batch"), ENT_QUOTES, 'UTF-8');?>
">一括登録</a></li>
		<?php }?>
		<li class="list-group-item"><a href="/personnel_years/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['personnel_year'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/masters/">マスターファイル選択に戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['task']) {?>
	<h2 class="side-title">タスクマスター</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/tasks/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
		<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/tasks/batch" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task'],"batch"), ENT_QUOTES, 'UTF-8');?>
">一括登録</a></li>
		<li class="list-group-item"><a href="/tasks/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task'],"form"), ENT_QUOTES, 'UTF-8');?>
">登録・更新</a></li>
		<li class="list-group-item"><a href="/tasks/delete" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task'],"delete"), ENT_QUOTES, 'UTF-8');?>
">削除</a></li>
		<?php }?>
		<li class="list-group-item"><a href="/tasks/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/masters/">マスターファイル選択に戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['watch_fire']) {?>
	<h2 class="side-title">宿日直・消防訓練マスター</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/watch_fires/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['watch_fire'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
		<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/watch_fires/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['watch_fire'],"form"), ENT_QUOTES, 'UTF-8');?>
">登録・更新</a></li>
		<?php }?>
		<li class="list-group-item"><a href="/watch_fires/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['watch_fire'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/masters/">マスターファイル選択に戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['task_month']) {?>
	<h2 class="side-title">月次タスクマスター</h2>
	<ul class="list-group">
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/task_months/year_month" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"year_month"), ENT_QUOTES, 'UTF-8');?>
">年月指定</a></li>
<?php }?>
		<li class="list-group-item"><a href="/task_months/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/task_months/batch" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"batch"), ENT_QUOTES, 'UTF-8');?>
">一括登録</a></li>
		<li class="list-group-item"><a href="/task_months/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"form"), ENT_QUOTES, 'UTF-8');?>
">登録・更新</a></li>
		<li class="list-group-item"><a href="/task_months/delete" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"delete"), ENT_QUOTES, 'UTF-8');?>
">削除</a></li>
<?php }?>
		<li class="list-group-item"><a href="/task_months/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['task_month'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['duty']||$_smarty_tpl->tpl_vars['sideNavi']->value['holiday']||$_smarty_tpl->tpl_vars['sideNavi']->value['duty_update']||$_smarty_tpl->tpl_vars['sideNavi']->value['duty_log_list']||$_smarty_tpl->tpl_vars['sideNavi']->value['duty_publish']) {?>
	<h2 class="side-title">日程表管理</h2>
	<ul class="list-group">
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/duty_build/">作成</a></li>
		<li class="list-group-item"><a href="/holiday/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['holiday'],"form"), ENT_QUOTES, 'UTF-8');?>
">休暇設定</a></li>
<?php }?>
		<li class="list-group-item"><a href="/duty/table" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty'],"table"), ENT_QUOTES, 'UTF-8');?>
">一覧表示</a></li>
<?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2) {?>
		<li class="list-group-item"><a href="/duty_update/form" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_update'],"form"), ENT_QUOTES, 'UTF-8');?>
">編集更新</a></li>
		<li class="list-group-item"><a href="/duty_log_list/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_log_list'],"index"), ENT_QUOTES, 'UTF-8');?>
">ログ・リスト表示</a></li>
		<li class="list-group-item"><a href="/duty_publish/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_publish'],"index"), ENT_QUOTES, 'UTF-8');?>
">日程表発簡</a></li>
		<li class="list-group-item"><a href="/close_month/">月末処理</a></li>
<?php }?>
		<li class="list-group-item"><a href="/duty/download" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty'],"download"), ENT_QUOTES, 'UTF-8');?>
">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build']) {?>
	<h2 class="side-title">日程表管理</h2>
	<ul class="list-group">
		<li class="list-group-item">
			<a href="/duty_build/" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build'],"index"), ENT_QUOTES, 'UTF-8');?>
">作成</a>
			<ul>
				<li><a href="/duty_build/init" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build'],"init"), ENT_QUOTES, 'UTF-8');?>
">初期化</a></li>
				<li><a href="/duty_build/build" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build'],"build"), ENT_QUOTES, 'UTF-8');?>
">作成</a></li>
				<li><a href="/duty_build/build_add" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build'],"build_add"), ENT_QUOTES, 'UTF-8');?>
">作成（月次タスク追加）</a></li>
				<li><a href="/duty_build/check" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['duty_build'],"check"), ENT_QUOTES, 'UTF-8');?>
">整合性チェック</a></li>
			</ul>
		</li>
		<li class="list-group-item"><a href="/holiday/form">休暇設定</a></li>
		<li class="list-group-item"><a href="/duty/table">一覧表示</a></li>
		<li class="list-group-item"><a href="/duty_update/form">編集更新</a></li>
		<li class="list-group-item"><a href="/duty_log_list/">ログ・リスト表示</a></li>
		<li class="list-group-item"><a href="/duty_publish/">日程表発簡</a></li>
		<li class="list-group-item"><a href="/close_month/">月末処理</a></li>
		<li class="list-group-item"><a href="/duty/download">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/duty/">日程表管理トップメニューに戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['close_month']) {?>
	<h2 class="side-title">日程表管理</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/duty_build/">作成</a></li>
		<li class="list-group-item"><a href="/holiday/form">休暇設定</a></li>
		<li class="list-group-item"><a href="/duty/table">一覧表示</a></li>
		<li class="list-group-item"><a href="/duty_update/form">編集更新</a></li>
		<li class="list-group-item">
			<a href="/close_month/">月末処理</a>
			<ul>
				<li><a href="/close_month/update" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['close_month'],"update"), ENT_QUOTES, 'UTF-8');?>
">更新</a></li>
			</ul>
		</li>
		<li class="list-group-item"><a href="/duty/download">ダウンロード</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/duty/">日程表管理トップメニューに戻る</a></li>
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php } elseif ($_smarty_tpl->tpl_vars['sideNavi']->value['maintenance']) {?>
	<h2 class="side-title">システム保守</h2>
	<ul class="list-group">
		<li class="list-group-item"><a href="/maintenances/backup" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['maintenance'],"backup"), ENT_QUOTES, 'UTF-8');?>
">バックアップ</a></li>
		<li class="list-group-item"><a href="/maintenances/restore" class="<?php echo htmlspecialchars(smarty_modifier_active($_smarty_tpl->tpl_vars['sideNavi']->value['maintenance'],"restore"), ENT_QUOTES, 'UTF-8');?>
">リストア</a></li>
	</ul>
	<ul class="side_navi_bottom">
		<li><a href="/">トップメニューに戻る</a></li>
	</ul>
<?php }?>
</div>
<?php }} ?>

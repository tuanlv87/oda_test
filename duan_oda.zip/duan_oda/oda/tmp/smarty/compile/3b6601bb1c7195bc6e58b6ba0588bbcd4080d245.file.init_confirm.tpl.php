<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:33:57
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\init_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31403565726082f4ea3-80976176%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b6601bb1c7195bc6e58b6ba0588bbcd4080d245' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\init_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31403565726082f4ea3-80976176',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657260836efc6_65882750',
  'variables' => 
  array (
    'init_status' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657260836efc6_65882750')) {function content_5657260836efc6_65882750($_smarty_tpl) {?><form class="form-horizontal" method="POST">
<?php if ($_smarty_tpl->tpl_vars['init_status']->value==1) {?>
	<div class="notice-message">
		<p class="bg-danger"><?php echo htmlspecialchars($_POST['duty_year'], ENT_QUOTES, 'UTF-8');?>
年<?php echo htmlspecialchars($_POST['duty_month'], ENT_QUOTES, 'UTF-8');?>
月の日程表は初期化済です。続行すると日程表を消去して初期化直後の状態になります。
			<br>よろしければ「実行」ボタンを押してください。</p>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary send-btn">実行</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-warning"><?php echo htmlspecialchars($_POST['duty_year'], ENT_QUOTES, 'UTF-8');?>
年<?php echo htmlspecialchars($_POST['duty_month'], ENT_QUOTES, 'UTF-8');?>
月の日程表を初期化します。よろしければ「実行」ボタンを押してください。</p>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary send-btn">実行</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php }?>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"init_comp",'form_id'=>"sendForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"init",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.send-btn').click(function(){
	showMask();
	$('#sendForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"日程表を初期化しています。"), 0);?>

<?php }} ?>

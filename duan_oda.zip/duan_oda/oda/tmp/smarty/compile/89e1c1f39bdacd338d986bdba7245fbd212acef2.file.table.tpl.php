<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 15:26:29
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\WatchFires\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3788565b9763139c12-88737988%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89e1c1f39bdacd338d986bdba7245fbd212acef2' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\WatchFires\\table.tpl',
      1 => 1478075604,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3788565b9763139c12-88737988',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565b97631b3d34_56401551',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565b97631b3d34_56401551')) {function content_565b97631b3d34_56401551($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"wf_year_month",'pagination'=>true,'striped_row'=>3,'edit_url'=>"/watch_fires/edit?ret=/watch_fires/table.page:".((string)$_GET['page'])."&year_month=%s"), 0);?>

<?php }} ?>

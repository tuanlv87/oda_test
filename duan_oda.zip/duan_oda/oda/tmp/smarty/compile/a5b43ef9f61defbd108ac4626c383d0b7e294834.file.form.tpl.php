<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 17:24:42
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2485956dcdb142dd085-74671701%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5b43ef9f61defbd108ac4626c383d0b7e294834' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\form.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2485956dcdb142dd085-74671701',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56dcdb1431a114_38394064',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56dcdb1431a114_38394064')) {function content_56dcdb1431a114_38394064($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('key'=>"t_id",'text_id'=>"タスクID"), 0);?>

<?php }} ?>

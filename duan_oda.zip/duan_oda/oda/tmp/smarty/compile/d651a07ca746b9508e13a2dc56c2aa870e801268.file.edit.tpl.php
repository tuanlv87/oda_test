<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:31:47
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:270965743f89ce3c0b1-27079353%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd651a07ca746b9508e13a2dc56c2aa870e801268' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\edit.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '270965743f89ce3c0b1-27079353',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5743f89ceb61d5_13693436',
  'variables' => 
  array (
    '_p_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5743f89ceb61d5_13693436')) {function content_5743f89ceb61d5_13693436($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/personnels/edit_confirm">
	<input name="_p_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_p_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>
<?php }} ?>

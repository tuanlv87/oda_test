<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 19:03:11
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\delete_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7152574426df11f1c7-22781913%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'be6e44d5f9fd4dddaf58415521c52d52d9cf01a3' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\delete_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7152574426df11f1c7-22781913',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_tm_id' => 0,
    'ret' => 0,
    'publish_after_flag' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_574426df1992e0_70591752',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574426df1992e0_70591752')) {function content_574426df1992e0_70591752($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="delete_save">
	<input name="_tm_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_tm_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php if ($_smarty_tpl->tpl_vars['publish_after_flag']->value>0) {?>
	<div class="notice-message">
		<p class="bg-danger text-danger">（発刊後）この月次タスクマスターを取消処理しますか？</p>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger text-danger">（発刊前）この月次タスクマスターを削除しますか？</p>
	</div>
<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</form><?php }} ?>

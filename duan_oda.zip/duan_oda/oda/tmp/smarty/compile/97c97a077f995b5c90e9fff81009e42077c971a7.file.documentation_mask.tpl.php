<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:45:30
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Element\documentation_mask.tpl" */ ?>
<?php /*%%SmartyHeaderCode:95685657282d79b179-73326370%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97c97a077f995b5c90e9fff81009e42077c971a7' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Element\\documentation_mask.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '95685657282d79b179-73326370',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657282d79b170_12494809',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657282d79b170_12494809')) {function content_5657282d79b170_12494809($_smarty_tpl) {?><div id="mask">
    <div id="message">
        現在、ファイルを作成しています。<br/>
        しばらくお待ちください。処理時間:<span id="time">0</span>秒
    </div>
    <div class="progress" style="width:80%;margin: 0 auto;">
      <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
      </div>
    </div>
</div>
<?php }} ?>

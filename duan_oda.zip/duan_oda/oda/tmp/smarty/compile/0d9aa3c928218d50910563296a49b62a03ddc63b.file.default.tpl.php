<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 18:29:53
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Layout\default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27501565725d4cbb5b5-52287133%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0d9aa3c928218d50910563296a49b62a03ddc63b' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Layout\\default.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27501565725d4cbb5b5-52287133',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725d4cf8644_46327981',
  'variables' => 
  array (
    'this' => 0,
    'title_for_layout' => 0,
    'sideNavi' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725d4cf8644_46327981')) {function content_565725d4cf8644_46327981($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<?php echo $_smarty_tpl->tpl_vars['this']->value->Html->charset();?>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['title_for_layout']->value, ENT_QUOTES, 'UTF-8');?>
</title>
	<link rel="stylesheet" href="/bootstrap-3.3.4/css/bootstrap.min.css">
	<link rel="stylesheet" href="/css/app.css" media="all">
	<link rel="stylesheet" href="/css/print.css" media="print">
    <?php echo $_smarty_tpl->tpl_vars['this']->value->fetch('meta');?>

    <?php echo $_smarty_tpl->tpl_vars['this']->value->fetch('css');?>

	<?php echo '<script'; ?>
 src="/js/jquery-2.1.4.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/js/app.js"><?php echo '</script'; ?>
>
	<?php echo $_smarty_tpl->tpl_vars['this']->value->fetch('script');?>

</head>
<body>
	<header>
		<div class="header-title">
			<h1>ODA-R</h1>
		</div>
	</header>
	<div class="container-fluid">
		<div class="row">
<?php if ($_smarty_tpl->tpl_vars['sideNavi']->value) {?>
			<div class="col-xs-4 col-side">
<?php echo $_smarty_tpl->getSubTemplate ("side_navi.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

			</div>
			<div class="col-xs-8 col-main">
				<div class="main_content">
<?php echo $_smarty_tpl->tpl_vars['this']->value->fetch('content');?>

				</div>
			</div>
<?php } else { ?>
<?php echo $_smarty_tpl->tpl_vars['this']->value->fetch('content');?>

<?php }?>
		</div>
	</div>
</body>
</html>
<?php }} ?>

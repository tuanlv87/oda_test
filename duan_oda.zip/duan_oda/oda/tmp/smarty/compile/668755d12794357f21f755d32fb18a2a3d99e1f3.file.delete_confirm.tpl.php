<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 17:29:21
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\delete_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7575574410e1ae58d7-39986621%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '668755d12794357f21f755d32fb18a2a3d99e1f3' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\delete_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7575574410e1ae58d7-39986621',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_t_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_574410e1b5f9f1_16241553',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574410e1b5f9f1_16241553')) {function content_574410e1b5f9f1_16241553($_smarty_tpl) {?><form class="form-horizontal" method="post" action="/tasks/delete_save">
	<input name="_t_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_t_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	
	<div class="notice-message">
		<p class="bg-danger text-danger">このタスクマスターを削除しますか？</p>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 17:28:25
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20519565fa36255ffa1-71353472%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '917b4a6d75a3dae04b18dba121ff58f9bd044fca' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\edit.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20519565fa36255ffa1-71353472',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565fa3626541e6_05912849',
  'variables' => 
  array (
    '_t_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565fa3626541e6_05912849')) {function content_565fa3626541e6_05912849($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/tasks/edit_confirm">
	<input name="_t_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_t_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>
<?php }} ?>

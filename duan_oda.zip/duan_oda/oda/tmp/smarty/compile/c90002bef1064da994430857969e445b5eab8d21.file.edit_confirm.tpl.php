<?php /* Smarty version Smarty-3.1.21, created on 2016-05-25 08:08:15
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyUpdate\edit_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:119156614af94ac882-79036456%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c90002bef1064da994430857969e445b5eab8d21' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyUpdate\\edit_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '119156614af94ac882-79036456',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56614af95a0ac8_97400843',
  'variables' => 
  array (
    'warnings' => 0,
    'message' => 0,
    'task_errors' => 0,
    'duty_assignment' => 0,
    'values' => 0,
    'originals' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56614af95a0ac8_97400843')) {function content_56614af95a0ac8_97400843($_smarty_tpl) {?><?php if (!is_callable('smarty_function_duty_assignment_days')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.duty_assignment_days.php';
?><form class="form-horizontal" method="POST">
<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['warnings']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
	<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
(アラート)</p>
<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['task_errors']->value) {?>
	<div class="notice-message">
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['task_errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
		<p class="bg-danger text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
	</div>
	<div class="notice-message">
		<p class="bg-warning">そのままログを終了して登録する場合は「登録」ボタンを押してください。</p>
	</div>
<?php } elseif ($_REQUEST['end_log']>0) {?>
	<div class="notice-message">
		<p class="bg-warning">この内容でログを終了して登録する場合は「登録」ボタンを押してください。</p>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-warning">この内容で登録する場合は「登録」ボタンを押してください。</p>
	</div>
<?php }?>
	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>

	<div class="form-calendar">
	<?php echo smarty_function_duty_assignment_days(array('duty_assignment'=>$_smarty_tpl->tpl_vars['duty_assignment']->value,'values'=>$_smarty_tpl->tpl_vars['values']->value,'originals'=>$_smarty_tpl->tpl_vars['originals']->value,'mode'=>"view"),$_smarty_tpl);?>

	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("view_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['duty_assignment']->value), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/duty_update/edit_save",'form_id'=>"saveForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/duty_update/edit",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.save-btn').click(function(){
	$('#saveForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>
<?php }} ?>

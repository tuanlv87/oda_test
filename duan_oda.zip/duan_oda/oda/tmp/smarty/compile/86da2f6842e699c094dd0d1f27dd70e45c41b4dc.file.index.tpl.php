<?php /* Smarty version Smarty-3.1.21, created on 2016-04-04 16:04:37
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyPublish\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1312556d3a0ce3d0900-20263045%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '86da2f6842e699c094dd0d1f27dd70e45c41b4dc' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyPublish\\index.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1312556d3a0ce3d0900-20263045',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d3a0ce487ab4_22748284',
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d3a0ce487ab4_22748284')) {function content_56d3a0ce487ab4_22748284($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
?><form class="form-horizontal" method="GET" action="form">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>発簡日を設定する日程表の年月を選択してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">年月</label>
		<div class="col-xs-9 w-400">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<?php if ($_smarty_tpl->tpl_vars['d']->value['publish_date']) {?>
				<label style="color:#aaa;">
					<input name="year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio" disabled="disabled"> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>
（発簡済み：<?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['d']->value['publish_date']), ENT_QUOTES, 'UTF-8');?>
）
				</label>
				<?php } else { ?>
				<label>
					<input name="year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_REQUEST['year_month']==$_smarty_tpl->tpl_vars['d']->value->de_year_month) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
				<?php }?>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-9">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">作成された日程表がありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

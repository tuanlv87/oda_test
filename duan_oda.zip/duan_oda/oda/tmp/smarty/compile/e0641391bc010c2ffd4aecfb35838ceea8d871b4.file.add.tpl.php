<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:28
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:640457060d1ebf6807-51299753%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e0641391bc010c2ffd4aecfb35838ceea8d871b4' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\add.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '640457060d1ebf6807-51299753',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_57060d1ec33894_03028328',
  'variables' => 
  array (
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57060d1ec33894_03028328')) {function content_57060d1ec33894_03028328($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="add_confirm">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form><?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:37:37
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7436565a73ff76cab2-54462180%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc0f0cfdea28fb675960b258902b922d2ad14133' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\table.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7436565a73ff76cab2-54462180',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a73ff860cf3_26303946',
  'variables' => 
  array (
    'current_year_month' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a73ff860cf3_26303946')) {function content_565a73ff860cf3_26303946($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="post" action="">
<?php if ($_smarty_tpl->tpl_vars['current_year_month']->value!='') {?>
	<div class="form-group">
		<p><?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['current_year_month']->value), ENT_QUOTES, 'UTF-8');?>
の月次タスクマスターを一覧表示します。</p>
		<div class="radio">
			<label>
				<input class="select-file" name="filename" value="table_list" type="radio" checked>
				 一覧
			</label>
			<label>
				<input class="select-file" name="filename" value="table_schedule" type="radio">
				日程表
			</label>
		</div>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary">次へ</button>
	</div>
<?php } else { ?>
	<p class="text-danger">年月指定を実行してください。</p>
<?php }?>
</form>


<?php echo '<script'; ?>
>
$(function(){
	$('form').submit(function(){
		var selectFile = $('.select-file:checked').val();
		window.location.href = selectFile;
		return false;
	});
});
<?php echo '</script'; ?>
>

<?php }} ?>

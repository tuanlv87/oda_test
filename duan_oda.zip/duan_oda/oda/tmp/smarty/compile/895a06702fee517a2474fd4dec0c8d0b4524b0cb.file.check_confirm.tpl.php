<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:44:47
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\check_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:62105657522f9094d6-33558326%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '895a06702fee517a2474fd4dec0c8d0b4524b0cb' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\check_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '62105657522f9094d6-33558326',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657522f9c0680_10505052',
  'variables' => 
  array (
    'check_errors' => 0,
    'ts' => 0,
    'arr' => 0,
    'err' => 0,
    'error' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657522f9c0680_10505052')) {function content_5657522f9c0680_10505052($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\modifier.date_format.php';
?><form class="form-horizontal" method="POST">
<?php if ($_smarty_tpl->tpl_vars['check_errors']->value) {?>
	<div class="notice-message">
		<p class="bg-danger text-success">日程表に以下の問題が見つかりました。</p>
	</div>
	<table class="table">
	<?php  $_smarty_tpl->tpl_vars['arr'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['arr']->_loop = false;
 $_smarty_tpl->tpl_vars['ts'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['check_errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['arr']->key => $_smarty_tpl->tpl_vars['arr']->value) {
$_smarty_tpl->tpl_vars['arr']->_loop = true;
 $_smarty_tpl->tpl_vars['ts']->value = $_smarty_tpl->tpl_vars['arr']->key;
?>
		<thead>
			<tr>
				<th class="text-left" colspan="2"><?php if ($_smarty_tpl->tpl_vars['ts']->value>0) {
echo htmlspecialchars(smarty_modifier_date_format($_smarty_tpl->tpl_vars['ts']->value,"%Y/%m/%d"), ENT_QUOTES, 'UTF-8');
} else { ?>（全体）<?php }?></th>
			</tr>
		</thead>
		<tbody>
		<?php  $_smarty_tpl->tpl_vars['err'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['err']->_loop = false;
 $_smarty_tpl->tpl_vars['p_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['err']->key => $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->_loop = true;
 $_smarty_tpl->tpl_vars['p_id']->value = $_smarty_tpl->tpl_vars['err']->key;
?>
			<tr>
				<td class="text-warning"><?php if ($_smarty_tpl->tpl_vars['err']->value[0]['name']) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['err']->value[0]['name'], ENT_QUOTES, 'UTF-8');
} else { ?>（全体）<?php }?></td>
				<td>
			<?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['err']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
					<p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['error']->value['message'], ENT_QUOTES, 'UTF-8');?>
</p>
			<?php } ?>
				</td>
			</tr>
		<?php } ?>
		</tbody>
	<?php } ?>
	</table>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-success text-success">日程表に問題は見つかりませんでした。</p>
	</div>
<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<a href="check" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
</form>
<?php }} ?>

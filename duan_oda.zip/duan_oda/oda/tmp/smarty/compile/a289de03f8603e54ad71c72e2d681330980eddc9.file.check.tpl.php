<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:44:20
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\check.tpl" */ ?>
<?php /*%%SmartyHeaderCode:201095657522075e0e7-80254793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a289de03f8603e54ad71c72e2d681330980eddc9' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\check.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '201095657522075e0e7-80254793',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56575220815298_09313569',
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56575220815298_09313569')) {function content_56575220815298_09313569($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="check">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>整合性チェックをする年月を選択してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-2 w-100 control-label">年月</label>
		<div class="col-xs-10 w-300">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['duty_year_month']==$_smarty_tpl->tpl_vars['d']->value->de_year_month) {?> selected<?php }?>> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">作成された日程表がありません。</p>
	</div>
<?php }?>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"日程表の整合性チェックをしています。"), 0);?>


<?php echo '<script'; ?>
>
$(function(){
	$('form').submit(function(){
		showMask();
	});
});
<?php echo '</script'; ?>
>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 18:47:45
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\table_schedule.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11255569f08066d38f0-83113434%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'acfa33e4b830633c56210d052b40d9a4c3f76def' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\table_schedule.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11255569f08066d38f0-83113434',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_569f08068bbd74_85725333',
  'variables' => 
  array (
    'month_title' => 0,
    'date_title' => 0,
    'cals' => 0,
    'c' => 0,
    'primary_list' => 0,
    'd' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_569f08068bbd74_85725333')) {function content_569f08068bbd74_85725333($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_term_date')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.term_date.php';
if (!is_callable('smarty_modifier_term_time')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.term_time.php';
if (!is_callable('smarty_modifier_task_month_personnel')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.task_month_personnel.php';
if (!is_callable('smarty_function_task_month_schedule')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.task_month_schedule.php';
?><h4><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['month_title']->value, ENT_QUOTES, 'UTF-8');?>
月度（<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['date_title']->value, ENT_QUOTES, 'UTF-8');?>
） <a class="btn btn-primary" onclick="window.print();">印刷</a></h4>

<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th rowspan="2">ID</th>
			<th rowspan="2">表示</th>
			<th rowspan="2" class="w-200">タスク名称</th>
			<th rowspan="2">期間</th>
			<th rowspan="2">時間</th>
			<th rowspan="2">人数</th>
<?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['cals']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
			<th style="border-bottom-width:1px;"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['c']->value['day'], ENT_QUOTES, 'UTF-8');?>
</th>
<?php } ?>
		</tr>
		<tr>
<?php  $_smarty_tpl->tpl_vars['c'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['c']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['cals']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['c']->key => $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->_loop = true;
?>
			<th style="background-color:<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['c']->value['color'], ENT_QUOTES, 'UTF-8');?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['c']->value['day_name'], ENT_QUOTES, 'UTF-8');?>
</th>
<?php } ?>
		</tr>
	</thead>
	<tbody>
<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['primary_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
		<tr>
			<td class="centered-text nowrap"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['tm_id'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td class="centered-text nowrap"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['show_mark'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td class="w-200 nowrap"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['task_name'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td class="centered-text nowrap"><?php echo htmlspecialchars(smarty_modifier_term_date($_smarty_tpl->tpl_vars['d']->value), ENT_QUOTES, 'UTF-8');?>
</td>
			<td class="centered-text nowrap"><?php echo htmlspecialchars(smarty_modifier_term_time($_smarty_tpl->tpl_vars['d']->value), ENT_QUOTES, 'UTF-8');?>
</td>
			<td class="centered-text w-20 nowrap"><?php echo htmlspecialchars(smarty_modifier_task_month_personnel($_smarty_tpl->tpl_vars['d']->value['personnel']), ENT_QUOTES, 'UTF-8');?>
</td>
	<?php echo smarty_function_task_month_schedule(array('cals'=>$_smarty_tpl->tpl_vars['cals']->value,'task_month'=>$_smarty_tpl->tpl_vars['d']->value),$_smarty_tpl);?>

		</tr>
<?php } ?>
	</tbody>
</table>
<?php }} ?>

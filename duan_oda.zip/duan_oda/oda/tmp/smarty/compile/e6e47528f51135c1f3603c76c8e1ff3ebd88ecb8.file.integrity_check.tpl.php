<?php /* Smarty version Smarty-3.1.21, created on 2016-02-29 10:03:05
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyUpdate\integrity_check.tpl" */ ?>
<?php /*%%SmartyHeaderCode:989456c56a3cc6f352-77806627%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e6e47528f51135c1f3603c76c8e1ff3ebd88ecb8' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyUpdate\\integrity_check.tpl',
      1 => 1456302352,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '989456c56a3cc6f352-77806627',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56c56a3cd26507_14196569',
  'variables' => 
  array (
    'duty_log_list' => 0,
    'd' => 0,
    'task_errors' => 0,
    'message' => 0,
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c56a3cd26507_14196569')) {function content_56c56a3cd26507_14196569($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
?><div class="form-group">
	<div style="padding:0 15px;width:500px;">
	<table class="table">
		<thead>
			<tr>
				<th>社員ID</th>
				<th>日付</th>
				<th>変更前のコード</th>
				<th>→</th>
				<th>変更後のコード</th>
			</tr>
		</thead>
<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_log_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
		<tbody>
			<tr>
				<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['p_id'], ENT_QUOTES, 'UTF-8');?>
</td>
				<td><?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['d']->value['date']), ENT_QUOTES, 'UTF-8');?>
</td>
				<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['before_type'], ENT_QUOTES, 'UTF-8');?>
</td>
				<td></td>
				<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['after_type'], ENT_QUOTES, 'UTF-8');?>
</td>
			</tr>
		</tbody>
<?php } ?>
	</table>
	</div>
</div>
<?php if ($_smarty_tpl->tpl_vars['task_errors']->value) {?>
<div class="notice-message">
<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['task_errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
	<p class="bg-danger text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
<?php } ?>
</div>
<?php } else { ?>
	<p class="bg-success text-success">更新処理は適切に終了しています</p>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['task_errors']->value) {?>
<div class="form-group form-action">
	<div class="col-xs-offset-2">
		<a href="/DutyUpdate/form_pid?year=<?php echo htmlspecialchars($_REQUEST['_year'], ENT_QUOTES, 'UTF-8');?>
&month=<?php echo htmlspecialchars($_REQUEST['_month'], ENT_QUOTES, 'UTF-8');?>
&log_id=<?php echo htmlspecialchars($_REQUEST['_log_id'], ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default back-btn">ログを続ける</a>
		<button type="button" class="btn btn-default end-new-btn">次のログを始める</button>
		<button type="button" class="btn btn-default end-btn">更新処理を終了する</button>
	</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/DutyUpdate/end_new",'form_id'=>"endNewForm"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/DutyUpdate/end",'form_id'=>"endForm"), 0);?>


<?php echo '<script'; ?>
>
$('.end-new-btn').click(function() {
    $('#endNewForm').submit();
});

$('.end-btn').click(function() {
    $('#endForm').submit();
});
<?php echo '</script'; ?>
>
<?php } else { ?>
<div class="form-group form-action">
	<div class="col-xs-offset-2">
		<button type="button" class="btn btn-default end-new-btn">次のログを始める</button>
		<a href="/Duty/index" class="btn btn-default end-btn">更新処理を終了する</a>
	</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/DutyUpdate/end_new",'form_id'=>"endNewForm"), 0);?>

<?php echo '<script'; ?>
>
$('.end-new-btn').click(function() {
    $('#endNewForm').submit();
});
<?php echo '</script'; ?>
>
<?php }?>
<?php }} ?>

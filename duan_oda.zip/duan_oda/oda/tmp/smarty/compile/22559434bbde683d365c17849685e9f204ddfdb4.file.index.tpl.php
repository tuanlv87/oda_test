<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:42:30
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyLogList\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2907656caa62329dec8-42629322%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22559434bbde683d365c17849685e9f204ddfdb4' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyLogList\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2907656caa62329dec8-42629322',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56caa623a02033_84829874',
  'variables' => 
  array (
    'year_options' => 0,
    'year_selected' => 0,
    'month_options' => 0,
    'month_selected' => 0,
    'this' => 0,
    'list_settings' => 0,
    'h' => 0,
    'edit_url' => 0,
    'userInfo' => 0,
    'delete_url' => 0,
    'primary_list' => 0,
    'before_row' => 0,
    'd' => 0,
    'duty_log_alerts_map' => 0,
    'message' => 0,
    'striped_row' => 0,
    'even_by' => 0,
    'col' => 0,
    'idx' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56caa623a02033_84829874')) {function content_56caa623a02033_84829874($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php';
if (!is_callable('smarty_modifier_config')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.config.php';
if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
if (!is_callable('smarty_modifier_zero_to_space')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.zero_to_space.php';
if (!is_callable('smarty_modifier_table_log_id')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.table_log_id.php';
if (!is_callable('smarty_modifier_table_log_date')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.table_log_date.php';
?><ul class="pagination">
    <li class="select-year-month">
        <select name="year">
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['year_options']->value,'selected'=>$_smarty_tpl->tpl_vars['year_selected']->value),$_smarty_tpl);?>

        </select>
        年
        <select name="month">
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['month_options']->value,'selected'=>$_smarty_tpl->tpl_vars['month_selected']->value),$_smarty_tpl);?>

        </select>
        月
        <input type="button" value="切替" class="btn btn-primary send-btn">
    </li>
    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->prev('« 前へ');?>

    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->numbers();?>

    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->next('次へ »');?>

</ul>

<table class="table table-bordered">
    <thead>
        <tr>
            <?php  $_smarty_tpl->tpl_vars['h'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['h']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['list_settings']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['h']->key => $_smarty_tpl->tpl_vars['h']->value) {
$_smarty_tpl->tpl_vars['h']->_loop = true;
?>
            <th><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['h']->value['text'], ENT_QUOTES, 'UTF-8');?>
</th>
            <?php } ?>
            <?php if ($_smarty_tpl->tpl_vars['edit_url']->value&&($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2)) {?>
            <th>編集</th>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['delete_url']->value&&($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1||$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==2)) {?>
            <th>削除</th>
            <?php }?>
        </tr>
    </thead>
    <tbody>
<?php $_smarty_tpl->tpl_vars["before_row"] = new Smarty_variable(null, null, 0);?>
<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['primary_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['d']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['d']->key;
 $_smarty_tpl->tpl_vars['d']->index++;
?>
    <?php if ($_smarty_tpl->tpl_vars['before_row']->value!=null&&$_smarty_tpl->tpl_vars['before_row']->value->log_id!=$_smarty_tpl->tpl_vars['d']->value->log_id&&isset($_smarty_tpl->tpl_vars['duty_log_alerts_map']->value[$_smarty_tpl->tpl_vars['before_row']->value->log_id])) {?>
        <?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_smarty_tpl->tpl_vars['idx2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['duty_log_alerts_map']->value[$_smarty_tpl->tpl_vars['before_row']->value->log_id]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
 $_smarty_tpl->tpl_vars['idx2']->value = $_smarty_tpl->tpl_vars['message']->key;
?>
        <tr class="bg-danger text-danger"><td colspan="7"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</td></tr>
        <?php } ?>
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['striped_row']->value) {?>
        <?php $_smarty_tpl->tpl_vars["even_by"] = new Smarty_variable($_smarty_tpl->tpl_vars['striped_row']->value, null, 0);?>
    <?php } else { ?>
        <?php $_smarty_tpl->tpl_vars["even_by"] = new Smarty_variable(1, null, 0);?>
    <?php }?>

    <?php if (!(1 & $_smarty_tpl->tpl_vars['d']->index / $_smarty_tpl->tpl_vars['even_by']->value)) {?>
        <tr class="odd-row">
    <?php } else { ?>
        <tr class="even-row">
    <?php }?>
    <?php  $_smarty_tpl->tpl_vars['h'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['h']->_loop = false;
 $_smarty_tpl->tpl_vars['col'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['list_settings']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['h']->key => $_smarty_tpl->tpl_vars['h']->value) {
$_smarty_tpl->tpl_vars['h']->_loop = true;
 $_smarty_tpl->tpl_vars['col']->value = $_smarty_tpl->tpl_vars['h']->key;
?>
        <?php if ($_smarty_tpl->tpl_vars['col']->value=="frame_color") {?>
            <td class="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['h']->value['class'], ENT_QUOTES, 'UTF-8');?>
" style="background-color:#<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}, ENT_QUOTES, 'UTF-8');?>
;"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}, ENT_QUOTES, 'UTF-8');?>
</td>
        <?php } else { ?>
            <td class="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['h']->value['class'], ENT_QUOTES, 'UTF-8');?>
">
            <?php if ($_smarty_tpl->tpl_vars['h']->value['config']!='') {?>
                <?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value},$_smarty_tpl->tpl_vars['h']->value['config']), ENT_QUOTES, 'UTF-8');?>

            <?php } elseif ($_smarty_tpl->tpl_vars['h']->value['filter']=="date") {?>
                <?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}), ENT_QUOTES, 'UTF-8');?>

            <?php } elseif ($_smarty_tpl->tpl_vars['h']->value['filter']=="year_month") {?>
                <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}), ENT_QUOTES, 'UTF-8');?>

            <?php } elseif ($_smarty_tpl->tpl_vars['h']->value['filter']=="zero_to_space") {?>
                <?php echo htmlspecialchars(smarty_modifier_zero_to_space($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}), ENT_QUOTES, 'UTF-8');?>

            <?php } elseif ($_smarty_tpl->tpl_vars['h']->value['filter']=="log_id") {?>
                <?php if ($_smarty_tpl->tpl_vars['idx']->value>0) {?>
                    <?php echo htmlspecialchars(smarty_modifier_table_log_id($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value},$_smarty_tpl->tpl_vars['before_row']->value->{$_smarty_tpl->tpl_vars['col']->value}), ENT_QUOTES, 'UTF-8');?>

                <?php } else { ?>
                    <?php echo htmlspecialchars(smarty_modifier_table_log_id($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}), ENT_QUOTES, 'UTF-8');?>

                <?php }?>
            <?php } elseif ($_smarty_tpl->tpl_vars['h']->value['filter']=="log_date") {?>
                <?php if ($_smarty_tpl->tpl_vars['idx']->value>0) {?>
                    <?php echo htmlspecialchars(smarty_modifier_table_log_date($_smarty_tpl->tpl_vars['d']->value,$_smarty_tpl->tpl_vars['before_row']->value), ENT_QUOTES, 'UTF-8');?>

                <?php } else { ?>
                    <?php echo htmlspecialchars(smarty_modifier_table_log_date($_smarty_tpl->tpl_vars['d']->value), ENT_QUOTES, 'UTF-8');?>

                <?php }?>
            <?php } else { ?>
                <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->{$_smarty_tpl->tpl_vars['col']->value}, ENT_QUOTES, 'UTF-8');?>

            <?php }?>
            </td>
        <?php }?>
    <?php } ?>

    <?php $_smarty_tpl->tpl_vars["before_row"] = new Smarty_variable($_smarty_tpl->tpl_vars['d']->value, null, 0);?>
        </tr>
<?php }
if (!$_smarty_tpl->tpl_vars['d']->_loop) {
?>
        <tr>
            <td colspan="<?php echo htmlspecialchars(count($_smarty_tpl->tpl_vars['list_settings']->value), ENT_QUOTES, 'UTF-8');?>
" class="text-muted">データがありません。</td>
        </tr>
<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['before_row']->value!=null&&isset($_smarty_tpl->tpl_vars['duty_log_alerts_map']->value[$_smarty_tpl->tpl_vars['before_row']->value->log_id])) {?>
    <?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_smarty_tpl->tpl_vars['idx2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['duty_log_alerts_map']->value[$_smarty_tpl->tpl_vars['before_row']->value->log_id]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
 $_smarty_tpl->tpl_vars['idx2']->value = $_smarty_tpl->tpl_vars['message']->key;
?>
    <tr class="bg-danger text-danger"><td colspan="7"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</td></tr>
    <?php } ?>
<?php }?>
    </tbody>
</table>

<ul class="pagination">
    <li class="select-year-month">
        <select name="year">
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['year_options']->value,'selected'=>$_smarty_tpl->tpl_vars['year_selected']->value),$_smarty_tpl);?>

        </select>
        年
        <select name="month">
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['month_options']->value,'selected'=>$_smarty_tpl->tpl_vars['month_selected']->value),$_smarty_tpl);?>

        </select>
        月
        <input type="button" value="切替" class="btn btn-primary send-btn">
    </li>
    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->prev('« 前へ');?>

    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->numbers();?>

    <?php echo $_smarty_tpl->tpl_vars['this']->value->Paginator->next('次へ »');?>

</ul>
<?php echo '<script'; ?>
>
$('.send-btn').click(function(){
    var year = $(this).prev().prev().find(":selected").val();
    var month = $(this).prev().find(":selected").val();
    window.location.href = "?year="+year+"&month="+month;
});
<?php echo '</script'; ?>
>

<?php }} ?>

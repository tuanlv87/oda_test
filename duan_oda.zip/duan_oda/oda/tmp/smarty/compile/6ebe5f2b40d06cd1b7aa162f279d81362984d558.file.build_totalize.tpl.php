<?php /* Smarty version Smarty-3.1.21, created on 2016-01-29 09:37:24
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_totalize.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1231656aab4447270e9-22199014%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ebe5f2b40d06cd1b7aa162f279d81362984d558' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_totalize.tpl',
      1 => 1454026992,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1231656aab4447270e9-22199014',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56aab4447a1206_64194147',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aab4447a1206_64194147')) {function content_56aab4447a1206_64194147($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="build_totalize_confirm">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>作成（再集計）する以下の項目を入力してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">年月</label>
		<div class="col-xs-9 w-300">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['duty_year_month']==$_smarty_tpl->tpl_vars['d']->value->de_year_month) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-9">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">作成された日程表がありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-03-17 10:26:49
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_edit_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:725156ea07d9ed4419-88157160%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dca4a8527ccdadad9603689adb2395cf2e69245a' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_edit_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '725156ea07d9ed4419-88157160',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'values' => 0,
    'originals' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56ea07d9f114a8_25827597',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ea07d9f114a8_25827597')) {function content_56ea07d9f114a8_25827597($_smarty_tpl) {?>	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">更新</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("view_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'originals'=>$_smarty_tpl->tpl_vars['originals']->value), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">更新</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-13 09:53:28
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Maintenances\backup_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29235568e3f79cdeca9-20902030%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '46c97590f11c9d221c2a1e438dbe39084612cbde' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Maintenances\\backup_save.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29235568e3f79cdeca9-20902030',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_568e3f79d58dc3_93090985',
  'variables' => 
  array (
    'errors' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_568e3f79d58dc3_93090985')) {function content_568e3f79d58dc3_93090985($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-danger text-danger">エラーが発生しました。バックアップできません。<br><br>
			<?php echo htmlspecialchars(var_dump($_smarty_tpl->tpl_vars['errors']->value), ENT_QUOTES, 'UTF-8');?>

		</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-0 col-xs-5">
			<a href="backup" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>
<?php } else { ?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-success text-success">正常にバックアップされました。</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-0 col-xs-5">
			<a href="backup" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>
<?php }?>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:35:30
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Holiday\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23489567b784be25189-69319443%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '51e236820ab22e62e6354e03986b33110fb162d0' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Holiday\\edit.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23489567b784be25189-69319443',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_567b784c239567_82208842',
  'variables' => 
  array (
    '_year' => 0,
    '_month' => 0,
    '_p_id' => 0,
    'ret' => 0,
    'errors' => 0,
    'message' => 0,
    'duty_assignment' => 0,
    'values' => 0,
    'env_status' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_567b784c239567_82208842')) {function content_567b784c239567_82208842($_smarty_tpl) {?><?php if (!is_callable('smarty_function_duty_assignment_days')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.duty_assignment_days.php';
?><form class="form-horizontal" method="POST" action="/holiday/edit_confirm">
	<input name="_year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_year']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_month']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_p_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_p_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>

	<div class="form-group">
		<label class="form-label col-xs-2 control-label">休暇設定</label>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_days']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_days']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
	<div class="form-calendar">
	<?php echo smarty_function_duty_assignment_days(array('duty_assignment'=>$_smarty_tpl->tpl_vars['duty_assignment']->value,'values'=>$_smarty_tpl->tpl_vars['values']->value,'mode'=>"edit"),$_smarty_tpl);?>

	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("form_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'editMode'=>true), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>

<?php echo '<script'; ?>
>
var duty_code_input = <?php if ($_smarty_tpl->tpl_vars['env_status']->value==2) {?>false<?php } else { ?>true<?php }?>;

$(function(){
if (duty_code_input) {
	var dutyCodeInput = $('.duty-code-input');
	dutyCodeInput.typeahead({
		source:[
			{value:'HD1', name:'HD1（指定休）'},
			{value:'HD2', name:'HD2（休暇）'},
			{value:'HD3', name:'HD3（特別休暇）'},
			{value:'HD4', name:'HD4（夏期休暇）'},
			{value:'-D', name:'-D（昼勤としない）'},
			{value:'-N', name:'-N（夜勤としない）'},
			{value:'-DN', name:'-DN（昼夜勤としない）'},
			{value:'+D', name:'+D（昼勤とする）'},
			{value:'+N', name:'+N（夜勤とする）'},
			{value:'+DN', name:'+DN（昼夜勤とする）'},
			{value:'+HD5', name:'+HD5（公休とする）'},
			{value:'+HD6', name:'+HD6（明けとする）'}
		],
		autoSelect: true,
		minLength: 0,
		items: 13,
		showHintOnFocus: true,
		updater: function(item){
			var setval = item.value;
//			var val = this.$element.val();
//			if (val && ! val.match(/^HD[0-9]+/) && ! val.match(/^\-(D|N|DN)/)) {
//				alert('ここでは休暇設定に関わる変更以外はできません。');
//				return val;
//			}
//			if (val != '') {
//				setval = val + ',' + setval;
//			}
			return setval;
		}
	});
}
	// 変更禁止
//	dutyCodeInput.keydown(function(e){
//		if (e.keyCode != 8) {
//			alert('手動で勤務コードを変更することはできません。');
//			return false;
//		}
//	});
});

<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/bootstrap3-typeahead.min.js"><?php echo '</script'; ?>
><?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-06-09 15:58:21
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Maintenances\backup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24984568cb60e402db4-96089808%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1afb073e992db12a50ec9e42cd87789c9b3ee92f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Maintenances\\backup.tpl',
      1 => 1465284828,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24984568cb60e402db4-96089808',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_568cb60e43fe45_55154053',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_568cb60e43fe45_55154053')) {function content_568cb60e43fe45_55154053($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="backup">
	<p>バックアップは最大<?php echo htmlspecialchars(@constant('BACKUP_MAX_HISTORY'), ENT_QUOTES, 'UTF-8');?>
個まで保存されます。超えたものは古いバックアップから削除されます。</p>
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
</form>

<?php echo '<script'; ?>
>
$('form').submit(function(){
	showMask();
});
<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"現在、バックアップしています。"), 0);?>

<?php }} ?>

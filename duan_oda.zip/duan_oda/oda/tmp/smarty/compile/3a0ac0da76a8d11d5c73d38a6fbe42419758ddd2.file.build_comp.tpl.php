<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:39:39
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_comp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4900565727e3a77837-55055074%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a0ac0da76a8d11d5c73d38a6fbe42419758ddd2' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_comp.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4900565727e3a77837-55055074',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565727e3af1952_77632281',
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565727e3af1952_77632281')) {function content_565727e3af1952_77632281($_smarty_tpl) {?><form class="form-horizontal" method="POST">
<?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
	<div class="notice-message">
		<div class="bg-danger text-success">日程表を更新できません。
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
		<div class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</div>
	<?php } ?>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-success text-success">日程表が作成されました。</p>
	</div>
<?php }?>

	<div class="form-group form-action">
		<div class="col-xs-5">
			<a href="build" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
</form>
<?php }} ?>

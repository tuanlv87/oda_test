<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:37:46
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\color_picker.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1274565725e5daf7f8-24592900%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '41ffc99df6d5b6b3b5b1dd25a21adc4f043c5c3e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\color_picker.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1274565725e5daf7f8-24592900',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e5daf7f0_80737322',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e5daf7f0_80737322')) {function content_565725e5daf7f0_80737322($_smarty_tpl) {?><?php echo '<script'; ?>
>
$(function(){
	$('#input-frame_color').simpleColorPicker({
		colorsPerLine: 16,
		onChangeColor: function(color) {
			$('#input-frame_color').val(color.replace('#', ''));
//			$('#input-frame_color').css('background-color', color);
		}
	});
//	var color = $('#input-frame_color').val();
//	if (color !== '') {
//		$('#input-frame_color').css('background-color', '#'+color);
//	}
});
<?php echo '</script'; ?>
>
<link rel="stylesheet" href="/css/jquery.simple-color-picker.css">
<?php echo '<script'; ?>
 src="/js/jquery.simple-color-picker.js"><?php echo '</script'; ?>
>
<?php }} ?>

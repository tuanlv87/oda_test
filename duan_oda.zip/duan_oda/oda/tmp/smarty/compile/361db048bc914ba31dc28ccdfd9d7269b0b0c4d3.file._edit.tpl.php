<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:08
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13012565fa362691270-07081001%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '361db048bc914ba31dc28ccdfd9d7269b0b0c4d3' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_edit.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13012565fa362691270-07081001',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565fa362691278_37851417',
  'variables' => 
  array (
    'ret' => 0,
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565fa362691278_37851417')) {function content_565fa362691278_37851417($_smarty_tpl) {?>	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("form_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'editMode'=>true), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>
<?php }} ?>

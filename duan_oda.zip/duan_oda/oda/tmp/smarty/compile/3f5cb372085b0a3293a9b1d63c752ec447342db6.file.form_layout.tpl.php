<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:08
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\form_layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6949565725e5b4d254-89377477%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f5cb372085b0a3293a9b1d63c752ec447342db6' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\form_layout.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6949565725e5b4d254-89377477',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e5daf7f6_14447820',
  'variables' => 
  array (
    'form_settings' => 0,
    'f' => 0,
    'editMode' => 0,
    'col' => 0,
    'show_display' => 0,
    'errors' => 0,
    'header_class' => 0,
    'values' => 0,
    'selected' => 0,
    'userInfo' => 0,
    'select_options' => 0,
    'current_year_month' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e5daf7f6_14447820')) {function content_565725e5daf7f6_14447820($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_config')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.config.php';
if (!is_callable('smarty_function_assign_config')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.assign_config.php';
if (!is_callable('smarty_function_html_radios')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_radios.php';
if (!is_callable('smarty_function_html_options')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php';
if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?>	<div class="form-group">
		<span class="required">*</span> は必須項目
	</div>
<?php  $_smarty_tpl->tpl_vars['f'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['f']->_loop = false;
 $_smarty_tpl->tpl_vars['col'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['form_settings']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['f']->key => $_smarty_tpl->tpl_vars['f']->value) {
$_smarty_tpl->tpl_vars['f']->_loop = true;
 $_smarty_tpl->tpl_vars['col']->value = $_smarty_tpl->tpl_vars['f']->key;
?>
	<?php $_smarty_tpl->tpl_vars["show_display"] = new Smarty_variable(true, null, 0);?>
	<?php if ($_smarty_tpl->tpl_vars['f']->value['edit_only']&&!$_smarty_tpl->tpl_vars['editMode']->value) {?>
		<?php $_smarty_tpl->tpl_vars["show_display"] = new Smarty_variable(false, null, 0);?>
	<?php }?>
	<?php if ($_smarty_tpl->tpl_vars['col']->value=="_init") {?>
		<?php $_smarty_tpl->tpl_vars["header_class"] = new Smarty_variable($_smarty_tpl->tpl_vars['f']->value['header']['class'], null, 0);?>
	<?php } elseif ($_smarty_tpl->tpl_vars['show_display']->value) {?>
	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]) {?> has-error<?php }?> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');?>
">
		<label for="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['text'], ENT_QUOTES, 'UTF-8');?>

			<?php if ($_smarty_tpl->tpl_vars['f']->value['required']) {?><span class="required">*</span><?php }?>
		</label>
		<div class="col-xs-5 form-value">
<?php if ($_SERVER['REQUEST_METHOD']=="POST"||$_smarty_tpl->tpl_vars['editMode']->value) {?>
	<?php $_smarty_tpl->tpl_vars["selected"] = new Smarty_variable($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], null, 0);?>
<?php } else { ?>
	<?php $_smarty_tpl->tpl_vars["selected"] = new Smarty_variable($_smarty_tpl->tpl_vars['f']->value['selected'], null, 0);?>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['f']->value['type']=="radios") {?>
	<?php if ($_smarty_tpl->tpl_vars['col']->value=="auth_type"&&$_smarty_tpl->tpl_vars['selected']->value=="1") {?>
				<div class="view-value">
					admin <input name=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
 value="1" type="hidden">
				</div>
	<?php } elseif ($_smarty_tpl->tpl_vars['col']->value=="auth_type"&&$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']!=@constant('AUTH_TYPE_ADMIN')&&$_smarty_tpl->tpl_vars['editMode']->value) {?>
				<div class="view-value">
					<?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],$_smarty_tpl->tpl_vars['f']->value['config']), ENT_QUOTES, 'UTF-8');?>
 <input name=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
 value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
				</div>
	<?php } else { ?>
				<div class="radio">
		<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
					<?php echo smarty_function_assign_config(array('var'=>"select_options",'config'=>$_smarty_tpl->tpl_vars['f']->value['config']),$_smarty_tpl);?>

					<?php echo smarty_function_html_radios(array('name'=>$_smarty_tpl->tpl_vars['col']->value,'options'=>$_smarty_tpl->tpl_vars['select_options']->value,'selected'=>$_smarty_tpl->tpl_vars['selected']->value,'separator'=>''),$_smarty_tpl);?>

		<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['options']) {?>
					<?php echo smarty_function_html_radios(array('options'=>$_smarty_tpl->tpl_vars['f']->value['options'],'selected'=>$_smarty_tpl->tpl_vars['selected']->value),$_smarty_tpl);?>

		<?php } else { ?>
					<?php echo smarty_function_html_radios(array('name'=>$_smarty_tpl->tpl_vars['col']->value,'values'=>$_smarty_tpl->tpl_vars['f']->value['values'],'output'=>$_smarty_tpl->tpl_vars['f']->value['output'],'selected'=>$_smarty_tpl->tpl_vars['selected']->value,'separator'=>''),$_smarty_tpl);?>

		<?php }?>
				</div>
	<?php }?>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="select") {?>
			<select class="form-control <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['class'], ENT_QUOTES, 'UTF-8');?>
" id="select-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
">
	<?php if ($_smarty_tpl->tpl_vars['f']->value['blank']) {?><option value="">選択してください</option><?php }?>
	<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
				<?php echo smarty_function_assign_config(array('var'=>"select_options",'config'=>$_smarty_tpl->tpl_vars['f']->value['config']),$_smarty_tpl);?>

				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['select_options']->value,'selected'=>$_smarty_tpl->tpl_vars['selected']->value),$_smarty_tpl);?>

	<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['options']) {?>
				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['f']->value['options'],'selected'=>$_smarty_tpl->tpl_vars['selected']->value),$_smarty_tpl);?>

	<?php } else { ?>
				<?php echo smarty_function_html_options(array('values'=>$_smarty_tpl->tpl_vars['f']->value['values'],'output'=>$_smarty_tpl->tpl_vars['f']->value['output'],'selected'=>$_smarty_tpl->tpl_vars['selected']->value),$_smarty_tpl);?>

	<?php }?>
			</select>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="password") {?>
			<input class="form-control mb-5 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['class'], ENT_QUOTES, 'UTF-8');?>
" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" placeholder="" type="password">
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="date") {?>
			<input class="form-control w-140 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['class'], ENT_QUOTES, 'UTF-8');?>
" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" value="<?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]), ENT_QUOTES, 'UTF-8');?>
" placeholder="" maxlength="10" type="text">
			<span class="text-muted">YYYY/MM/DD形式</span>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="year_month") {?>
			<div class="col-xs-3" style="width:150px;margin-left:-15px;">
				<div class="input-group">
					<input class="form-control" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
_year" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
_year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" maxlength="4" type="text">
					<div class="input-group-addon">年</div>
				</div>
			</div>
			<div class="col-xs-2" style="width:120px;">
				<div class="input-group">
					<input class="form-control" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
_month" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
					<div class="input-group-addon">月</div>
				</div>
			</div>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="current_year_month") {?>
			<div class="view-value">
				<?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['current_year_month']->value), ENT_QUOTES, 'UTF-8');?>

			</div>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="view") {?>
			<div class="view-value">
	<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
				<?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],$_smarty_tpl->tpl_vars['f']->value['config']), ENT_QUOTES, 'UTF-8');?>

	<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['filter']=="year_month") {?>
				<?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]), ENT_QUOTES, 'UTF-8');?>

	<?php } else { ?>
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

	<?php }?>
			</div>
<?php } else { ?>
	<?php if ($_smarty_tpl->tpl_vars['col']->value=="u_id"&&$_smarty_tpl->tpl_vars['userInfo']->value['auth_type']!=@constant('AUTH_TYPE_ADMIN')&&$_smarty_tpl->tpl_vars['editMode']->value) {?>
			<div class="view-value">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

			</div>
			<input class="form-control <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['class'], ENT_QUOTES, 'UTF-8');?>
" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<?php } else { ?>
			<input class="form-control <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['class'], ENT_QUOTES, 'UTF-8');?>
" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>
" placeholder="" type="text">
	<?php }?>
	<?php if ($_smarty_tpl->tpl_vars['f']->value['text_muted']) {?>
			<span class="text-muted"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['text_muted'], ENT_QUOTES, 'UTF-8');?>
</span>
	<?php }?>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['f']->value['help']) {?>
			<p class="help-block"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['help'], ENT_QUOTES, 'UTF-8');?>
</p>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<?php }?>
<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['editMode']->value) {?>
	<div class="form-group <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');?>
">
		<label class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
">登録年月日</label>
		<div class="col-xs-9 form-value">
			<div class="view-value">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['created'], ENT_QUOTES, 'UTF-8');
if ($_smarty_tpl->tpl_vars['values']->value['created_user']) {?>　<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['created_user'], ENT_QUOTES, 'UTF-8');
}?>
			</div>
		</div>
	</div>
	<div class="form-group <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');?>
">
		<label class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
">最終更新年月日</label>
		<div class="col-xs-9 form-value">
			<div class="view-value">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['modified'], ENT_QUOTES, 'UTF-8');
if ($_smarty_tpl->tpl_vars['values']->value['modified_user']) {?>　<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['modified_user'], ENT_QUOTES, 'UTF-8');
}?>
			</div>
		</div>
	</div>
<?php }?><?php }} ?>

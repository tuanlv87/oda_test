<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:36:42
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10974565a69ee453363-54925201%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9e4bf108fd6e294807e9bbab5c5c7b97ae05c5d1' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10974565a69ee453363-54925201',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a69ee453369_46212055',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a69ee453369_46212055')) {function content_565a69ee453369_46212055($_smarty_tpl) {?><?php }} ?>

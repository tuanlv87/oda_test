<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:36:26
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_edit_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1808256ea080c7ad330-59454466%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd78efdc50edde9aa91504cfc379687f4cc24969' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_edit_save.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1808256ea080c7ad330-59454466',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56ea080c7ea3c7_32557682',
  'variables' => 
  array (
    'errors' => 0,
    'offset_num' => 0,
    'values' => 0,
    'back_to_action' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ea080c7ea3c7_32557682')) {function content_56ea080c7ea3c7_32557682($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-danger text-danger">エラーが発生しました。更新できません。<br><br>
			<?php echo htmlspecialchars(var_dump($_smarty_tpl->tpl_vars['errors']->value), ENT_QUOTES, 'UTF-8');?>

		</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['offset_num']->value, ENT_QUOTES, 'UTF-8');?>
 col-xs-5">
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
</form>

<?php ob_start();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['back_to_action']->value, ENT_QUOTES, 'UTF-8');?>
<?php $_tmp1=ob_get_clean();?><?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>$_tmp1,'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>

<?php } else { ?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-success text-success">正常に更新されました。</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['offset_num']->value, ENT_QUOTES, 'UTF-8');?>
 col-xs-5">
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
</form>
<?php }?>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:48
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\delete_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:84895743dcc28462a5-72092113%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '23289dd24ee554a4f2554ba6119ea8712effa27f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\delete_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '84895743dcc28462a5-72092113',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5743dcc2883339_05630802',
  'variables' => 
  array (
    '_u_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5743dcc2883339_05630802')) {function content_5743dcc2883339_05630802($_smarty_tpl) {?><form class="form-horizontal" method="post" action="/users/delete_save">
	<input name="_u_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_u_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

	<div class="notice-message">
		<p class="bg-danger text-danger">この利用者マスターを削除しますか？</p>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</form><?php }} ?>

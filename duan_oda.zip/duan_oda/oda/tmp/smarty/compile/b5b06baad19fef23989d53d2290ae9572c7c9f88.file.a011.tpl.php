<?php /* Smarty version Smarty-3.1.21, created on 2016-04-05 09:31:35
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Documentation\a011.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5866565b97dbe56b08-46859691%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b5b06baad19fef23989d53d2290ae9572c7c9f88' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Documentation\\a011.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5866565b97dbe56b08-46859691',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565b97dbf0dcb1_60200754',
  'variables' => 
  array (
    'document' => 0,
    'documents' => 0,
    'Target_Date_Year' => 0,
    'Target_Date_Month' => 0,
    'teamList' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565b97dbf0dcb1_60200754')) {function content_565b97dbf0dcb1_60200754($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_options.php';
?><link rel="stylesheet" type="text/css" href="/css/documentation/common.css" media="all">
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/common.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="/js/documentation/a011.js"><?php echo '</script'; ?>
>
<div class="main-content">
    <div class="center" style="width:300px;">
        <form>
            <h4>●<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['documents']->value[$_smarty_tpl->tpl_vars['document']->value], ENT_QUOTES, 'UTF-8');?>
</h4>
            <input type="hidden" name="Target_Date_Year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['Target_Date_Year']->value, ENT_QUOTES, 'UTF-8');?>
" />
            <input type="hidden" name="Target_Date_Month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['Target_Date_Month']->value, ENT_QUOTES, 'UTF-8');?>
" />
            <label><input type="checkbox" name="is_header" value="1" checked="checked" />&nbsp;ヘッダーを出力する</label><br/>
            <input type="hidden" name="document" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['document']->value, ENT_QUOTES, 'UTF-8');?>
" />
            <table>
                <tr>
                    <td width="100px;">
                        <label>チームID</label>
                    </td>
                    <td>
                        <?php echo smarty_function_html_options(array('name'=>'team_id','options'=>$_smarty_tpl->tpl_vars['teamList']->value),$_smarty_tpl);?>

                    </td>
                </tr>
            </table>
            <button id="print_btn" type="submit" class="btn btn-primary">作成</button>
        </form>
        <?php echo $_smarty_tpl->getSubTemplate ("Element/documentation_link.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("Element/documentation_mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:33:57
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\mask.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17569565726083ac050-47883137%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a5b7f6be4ea5cf22573d4b44ff8c55302ab99a3' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\mask.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17569565726083ac050-47883137',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565726083ac052_10322694',
  'variables' => 
  array (
    'mask_message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565726083ac052_10322694')) {function content_565726083ac052_10322694($_smarty_tpl) {?><div id="mask">
    <div id="message">
        <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['mask_message']->value, ENT_QUOTES, 'UTF-8');?>
<br/>
        しばらくお待ちください。処理時間: <span id="time">0</span>秒
    </div>
    <div class="progress" style="width:80%;margin: 10px auto;">
      <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
      </div>
    </div>
</div>
<?php }} ?>

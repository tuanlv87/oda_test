<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 17:23:32
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\batch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:440157440f84dc1f95-62399116%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '998d737ad5366505ce6982a0128653387640d38e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\batch.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '440157440f84dc1f95-62399116',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_57440f84dff029_72041047',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57440f84dff029_72041047')) {function content_57440f84dff029_72041047($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_batch.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

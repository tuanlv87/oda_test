<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:31:08
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Masters\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23065565a69ec678870-31025779%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18387cf1d685162760101922b4ad7be57f73e637' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Masters\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23065565a69ec678870-31025779',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a69ec678878_71764586',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a69ec678878_71764586')) {function content_565a69ec678878_71764586($_smarty_tpl) {?><?php }} ?>

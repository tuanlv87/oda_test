<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:08
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9353566e507d918206-59412395%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d2f83c7534c0caa30ae744835b0bab44ae92404' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\edit.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9353566e507d918206-59412395',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_566e507d955290_94869887',
  'variables' => 
  array (
    '_u_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_566e507d955290_94869887')) {function content_566e507d955290_94869887($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/users/edit_confirm">
	<input name="_u_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_u_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>
<?php }} ?>

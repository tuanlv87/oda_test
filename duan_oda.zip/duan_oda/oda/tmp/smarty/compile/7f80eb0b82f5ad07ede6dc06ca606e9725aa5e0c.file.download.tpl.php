<?php /* Smarty version Smarty-3.1.21, created on 2016-04-06 18:02:29
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\PersonnelYears\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:43495704d0a5ceaa48-08696727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7f80eb0b82f5ad07ede6dc06ca606e9725aa5e0c' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\PersonnelYears\\download.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '43495704d0a5ceaa48-08696727',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5704d0a5d27ad8_75853048',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5704d0a5d27ad8_75853048')) {function content_5704d0a5d27ad8_75853048($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="download">
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
</form><?php }} ?>

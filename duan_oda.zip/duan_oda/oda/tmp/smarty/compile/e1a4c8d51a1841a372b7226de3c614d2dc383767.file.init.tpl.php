<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:33:29
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\init.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13406565725fc2b7e13-28904322%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e1a4c8d51a1841a372b7226de3c614d2dc383767' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\init.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13406565725fc2b7e13-28904322',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725fc331f30_26807811',
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725fc331f30_26807811')) {function content_565725fc331f30_26807811($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="init_confirm">
	<p>初期化する年月を入力してください。</p>
	<div class="form-group">
		<div class="col-xs-3" style="width:150px;">
			<div class="input-group">
				<input class="form-control" id="input-duty_year" name="duty_year" value="<?php echo htmlspecialchars($_POST['duty_year'], ENT_QUOTES, 'UTF-8');?>
" maxlength="4" type="text">
				<div class="input-group-addon">年</div>
			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_year']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_year']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
		<div class="col-xs-2" style="width:120px;">
			<div class="input-group">
				<input class="form-control" id="input-duty_month" name="duty_month" value="<?php echo htmlspecialchars($_POST['duty_month'], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
				<div class="input-group-addon">月</div>
			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
</form><?php }} ?>

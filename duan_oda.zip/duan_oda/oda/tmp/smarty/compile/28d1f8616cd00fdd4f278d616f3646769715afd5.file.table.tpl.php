<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:36:45
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Tasks\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5311565a69f0082a65-96303321%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '28d1f8616cd00fdd4f278d616f3646769715afd5' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Tasks\\table.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5311565a69f0082a65-96303321',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a69f00fcb85_70055911',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a69f00fcb85_70055911')) {function content_565a69f00fcb85_70055911($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"t_id",'pagination'=>true,'edit_url'=>"/tasks/edit?ret=/tasks/table.page:".((string)$_GET['page'])."&t_id=%s",'delete_url'=>"/tasks/delete_confirm?ret=/tasks/table.page:".((string)$_GET['page'])."&t_id=%s"), 0);?>

<?php }} ?>

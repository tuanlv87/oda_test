<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 15:46:43
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\delete.tpl" */ ?>
<?php /*%%SmartyHeaderCode:60556d4c3615e69e3-93556385%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '96dafaeca75b16c0cf498c53f760ef5e987655e1' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\delete.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '60556d4c3615e69e3-93556385',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d4c361660b06_69260284',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d4c361660b06_69260284')) {function content_56d4c361660b06_69260284($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('key'=>"p_id",'text_id'=>"社員番号"), 0);?>

<?php }} ?>

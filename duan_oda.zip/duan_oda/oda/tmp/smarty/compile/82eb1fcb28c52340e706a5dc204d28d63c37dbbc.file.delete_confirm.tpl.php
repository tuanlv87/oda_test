<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 15:46:52
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\delete_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:39855743f8dc28d520-58330985%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '82eb1fcb28c52340e706a5dc204d28d63c37dbbc' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\delete_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '39855743f8dc28d520-58330985',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_p_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5743f8dc307646_00525890',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5743f8dc307646_00525890')) {function content_5743f8dc307646_00525890($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="delete_save">
	<input name="_p_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_p_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

	<div class="notice-message">
		<p class="bg-danger text-danger">この警備員マスターを削除しますか？</p>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</form>
<?php }} ?>

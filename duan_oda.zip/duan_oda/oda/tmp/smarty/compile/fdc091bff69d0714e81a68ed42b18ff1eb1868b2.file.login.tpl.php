<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 18:29:53
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Home\login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6020565725d4c41493-41101502%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdc091bff69d0714e81a68ed42b18ff1eb1868b2' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Home\\login.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6020565725d4c41493-41101502',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725d4cbb5b3_83469143',
  'variables' => 
  array (
    'errors' => 0,
    'this' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725d4cbb5b3_83469143')) {function content_565725d4cbb5b3_83469143($_smarty_tpl) {?><div class="login-area">
	<form class="form-horizontal" method="post">
		<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['u_id']) {?> has-error<?php }?>">
			<label for="input-u_id" class="col-xs-3 control-label">ID</label>
			<div class="col-xs-9">
				<input class="form-control" id="input-u_id" name="u_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['this']->value->request->data['u_id'], ENT_QUOTES, 'UTF-8');?>
" placeholder="" type="text">
	<?php if ($_smarty_tpl->tpl_vars['errors']->value['u_id']) {?>
		<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['u_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
				<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
		<?php } ?>
	<?php }?>
			</div>
		</div>
		<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['password']) {?> has-error<?php }?>">
			<label for="input-password" class="col-xs-3 control-label">PW</label>
			<div class="col-xs-9">
				<input class="form-control" id="input-password" name="password" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['this']->value->request->data['password'], ENT_QUOTES, 'UTF-8');?>
" placeholder="" type="password">
	<?php if ($_smarty_tpl->tpl_vars['errors']->value['password']) {?>
		<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['password']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
				<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
		<?php } ?>
	<?php }?>
			</div>
		</div>
		<div class="form-action">
			<div class="col-xs-offset-3">
				<button type="submit" class="btn btn-primary">ログイン</button>
			</div>
		</div>
	</form>
</div>
<?php }} ?>

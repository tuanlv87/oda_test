<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:42:05
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyUpdate\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24261565fd0707c2542-55200200%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '87f005bfcdc53b1f15a293f8c9cde8b0619991cf' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyUpdate\\edit.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24261565fd0707c2542-55200200',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565fd0709308a4_25818622',
  'variables' => 
  array (
    '_year' => 0,
    '_month' => 0,
    '_p_id' => 0,
    '_log_id' => 0,
    '_new_flag' => 0,
    'ret' => 0,
    'values' => 0,
    'errors' => 0,
    'message' => 0,
    'duty_assignment' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565fd0709308a4_25818622')) {function content_565fd0709308a4_25818622($_smarty_tpl) {?><?php if (!is_callable('smarty_function_duty_assignment_days')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.duty_assignment_days.php';
?><form id="edit-form" class="form-horizontal" method="POST" action="/duty_update/edit_confirm">
	<input name="_year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_year']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_month']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_p_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_p_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_log_id" id="_log_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_log_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="_new_flag" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_new_flag']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="end_log" value="0" id="end-log" type="hidden">
	<input name="p_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['p_id'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="name" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['name'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="kana" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['kana'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="work_hours" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['work_hours'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="night_work_hours" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['night_work_hours'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="overtime25" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['overtime25'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="overtime35" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['overtime35'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">

	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="/duty_update/form_pid?year=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_year']->value, ENT_QUOTES, 'UTF-8');?>
&month=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_month']->value, ENT_QUOTES, 'UTF-8');?>
&log_id=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_log_id']->value, ENT_QUOTES, 'UTF-8');?>
&new_flag=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_new_flag']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>
	<div class="form-group">
		<label class="form-label col-xs-2 control-label">編集更新</label>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_days']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_days']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
	<div class="form-calendar">
	<?php echo smarty_function_duty_assignment_days(array('duty_assignment'=>$_smarty_tpl->tpl_vars['duty_assignment']->value,'values'=>$_smarty_tpl->tpl_vars['values']->value,'mode'=>"edit"),$_smarty_tpl);?>

	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("form_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">更新</button>
			<a href="/duty_update/form_pid?year=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_year']->value, ENT_QUOTES, 'UTF-8');?>
&month=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_month']->value, ENT_QUOTES, 'UTF-8');?>
&log_id=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_log_id']->value, ENT_QUOTES, 'UTF-8');?>
&new_flag=<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_new_flag']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>

<?php echo '<script'; ?>
>
$(function(){
	var dutyCodeInput = $('.duty-code-input');
	$('#edit-form').submit(function(){
		var em = false;
		dutyCodeInput.each(function(){
			if ($(this).val() == '') {
				em = true;
			}
		});
		if (em == true) {
			alert('日程表を埋めてください。');
			return false;

		}
	});
	$('.end-btn').click(function(){
		$('#end-log').val(1);
		$('#edit-form').submit();

	});
	dutyCodeInput.typeahead({
		source: function(query, process) {
			var self = this;
			var items;

			$.ajax({
				async: false,
				timeout: 10000,
				type: 'POST',
				url: '/duty_update/task_id_list',
				data: {
					'date': self.$element.attr('data-duty-date'),
					'log_no' : $("#_log_id").val()
				}
			}).done(function(data){
				if (data) {
					items = JSON.parse(data);
				}
			});

			this.items = items.length;

			//$.ajaxSetup({
			//	'async': false
			//});
			//$.getJSON('/duty_update/task_id_list', {
			//	'date': self.$element.attr('data-duty-date')
			//}, function(json){
			//	items = json;
			//});
			return this.render(items).show();
		},
		autoSelect: true,
		minLength: 0,
		items: 12,
		showHintOnFocus: true,
		updater: function(item){
			var setval = item.value;
			var val = this.$element.val();
			if (val != '') {
				setval = val + ',' + setval;
			}
			return setval;
		}
	});
});
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="/js/bootstrap3-typeahead.min.js"><?php echo '</script'; ?>
>
<?php }} ?>

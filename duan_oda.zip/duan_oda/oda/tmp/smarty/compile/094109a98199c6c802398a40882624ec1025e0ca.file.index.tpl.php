<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 15:26:26
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\WatchFires\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16639565b9760b3d3b2-67300912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '094109a98199c6c802398a40882624ec1025e0ca' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\WatchFires\\index.tpl',
      1 => 1478075604,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16639565b9760b3d3b2-67300912',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565b9760b3d3b5_09342683',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565b9760b3d3b5_09342683')) {function content_565b9760b3d3b5_09342683($_smarty_tpl) {?><?php }} ?>

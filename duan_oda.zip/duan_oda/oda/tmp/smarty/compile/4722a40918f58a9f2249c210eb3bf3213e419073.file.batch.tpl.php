<?php /* Smarty version Smarty-3.1.21, created on 2016-04-06 18:02:10
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\PersonnelYears\batch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:165515704d092e95e30-49928378%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4722a40918f58a9f2249c210eb3bf3213e419073' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\PersonnelYears\\batch.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '165515704d092e95e30-49928378',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5704d092f0ff58_63882537',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5704d092f0ff58_63882537')) {function content_5704d092f0ff58_63882537($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_batch.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

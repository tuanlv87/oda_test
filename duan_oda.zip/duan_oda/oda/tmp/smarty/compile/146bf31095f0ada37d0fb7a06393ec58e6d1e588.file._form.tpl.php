<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:40
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:22510565725e40187e6-55380270%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '146bf31095f0ada37d0fb7a06393ec58e6d1e588' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_form.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22510565725e40187e6-55380270',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e40187e4_53982916',
  'variables' => 
  array (
    'text_id' => 0,
    'key' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e40187e4_53982916')) {function content_565725e40187e4_53982916($_smarty_tpl) {?><form class="form-horizontal" method="GET" action="edit">
	<div class="form-group mb-40">
		<div class="col-xs-12">
			<a href="add" class="btn btn-primary">新規登録</a>
		</div>
	</div>
	<p>更新の場合は<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['text_id']->value, ENT_QUOTES, 'UTF-8');?>
を入力して「更新」をクリックしてください。</p>
	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['key']->value]) {?> has-error<?php }?>">
		<label class="col-xs-1 control-label w-120"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['text_id']->value, ENT_QUOTES, 'UTF-8');?>
</label>
		<div class="col-xs-3 w-200">
			<input class="form-control" id="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['key']->value, ENT_QUOTES, 'UTF-8');?>
" name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['key']->value, ENT_QUOTES, 'UTF-8');?>
" value="<?php echo htmlspecialchars($_REQUEST[$_smarty_tpl->tpl_vars['key']->value], ENT_QUOTES, 'UTF-8');?>
" type="text">
		</div>
		<div class="col-xs-2">
			<button type="submit" class="btn btn-primary">更新</button>
		</div>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['key']->value]) {?>
	<div class="form-group">
		<div class="col-xs-12 mtm-10">
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['key']->value]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
		</div>
	</div>
<?php }?>
</form>
<?php }} ?>

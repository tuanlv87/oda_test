<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:26
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\batch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:25973566f936ed62455-21516746%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0cac72f364e78cb34687485b91d685c89eb4d76b' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\batch.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25973566f936ed62455-21516746',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_566f936eddc577_36123135',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_566f936eddc577_36123135')) {function content_566f936eddc577_36123135($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_batch.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

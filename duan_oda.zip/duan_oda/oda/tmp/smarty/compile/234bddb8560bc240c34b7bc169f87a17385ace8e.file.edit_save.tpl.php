<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:36:26
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Holiday\edit_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1062658a27b3a338184-60625665%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '234bddb8560bc240c34b7bc169f87a17385ace8e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Holiday\\edit_save.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1062658a27b3a338184-60625665',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_58a27b3a375217_72388099',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a27b3a375217_72388099')) {function content_58a27b3a375217_72388099($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit_save.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('back_to_action'=>"/holiday/form",'offset_num'=>2), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 18:36:20
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\WatchFires\form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203856d8b0b6280de9-92506067%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8697c8df9216328cfa866e1448e6f8d8649cb7a0' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\WatchFires\\form.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203856d8b0b6280de9-92506067',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d8b0b6375020_86434569',
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d8b0b6375020_86434569')) {function content_56d8b0b6375020_86434569($_smarty_tpl) {?><form class="form-horizontal" method="GET" action="/watch_fires/edit">
	<p>登録・更新する年月を入力して「次へ」をクリックしてください。</p>
	<div class="form-group">
		<div class="col-xs-3" style="width:150px;">
			<div class="input-group">
				<input class="form-control" id="input-year" name="year" value="<?php echo htmlspecialchars($_POST['year'], ENT_QUOTES, 'UTF-8');?>
" maxlength="4" type="text">
				<div class="input-group-addon">年</div>
			</div>
		</div>
		<div class="col-xs-2" style="width:120px;">
			<div class="input-group">
				<input class="form-control" id="input-month" name="month" value="<?php echo htmlspecialchars($_POST['month'], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
				<div class="input-group-addon">月</div>
			</div>
		</div>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year']||$_smarty_tpl->tpl_vars['errors']->value['month']) {?>
	<div class="form-group">
		<div class="col-xs-10">
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
		</div>
	</div>
<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-25 08:14:06
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Duty\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1490056d3a3fd0b71b2-95074152%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '282063d15e6fe86055251f9acc051750d5aaf837' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Duty\\download.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1490056d3a3fd0b71b2-95074152',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d3a3fd16e367_19150130',
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d3a3fd16e367_19150130')) {function content_56d3a3fd16e367_19150130($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="download">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>ダウンロードする年月を選択してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-2 w-100 control-label">年月</label>
		<div class="col-xs-10 w-300">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['year_month']==$_smarty_tpl->tpl_vars['d']->value->year_month) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-10">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">作成された日程表がありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

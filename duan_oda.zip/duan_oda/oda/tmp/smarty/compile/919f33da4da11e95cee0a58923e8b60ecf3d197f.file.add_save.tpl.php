<?php /* Smarty version Smarty-3.1.21, created on 2016-04-08 11:07:28
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\add_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16752570712602e5b34-00761984%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '919f33da4da11e95cee0a58923e8b60ecf3d197f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\add_save.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16752570712602e5b34-00761984',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_57071260322bc6_52349060',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57071260322bc6_52349060')) {function content_57071260322bc6_52349060($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_add_save.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('back_to_action'=>"add",'offset_num'=>3), 0);?>

<?php }} ?>

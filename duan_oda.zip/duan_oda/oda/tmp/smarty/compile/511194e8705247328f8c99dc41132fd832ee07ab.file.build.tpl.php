<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:38:28
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8255565725fd9a1e64-92792377%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '511194e8705247328f8c99dc41132fd832ee07ab' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8255565725fd9a1e64-92792377',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725fda960a2_06708300',
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
    'duty_fire_options' => 0,
    'team_id_options' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725fda960a2_06708300')) {function content_565725fda960a2_06708300($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
if (!is_callable('smarty_function_assign_config')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.assign_config.php';
if (!is_callable('smarty_function_html_radios')) include 'C:\\oda\\Apache24\\htdocs\\oda\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_radios.php';
?><form class="form-horizontal" method="POST" action="build_confirm">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>作成（更新）する以下の項目を入力してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">年月</label>
		<div class="col-xs-9 w-300">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<?php if ($_smarty_tpl->tpl_vars['d']->value['publish_date']!='') {?>
				<label style="color:#aaa;">
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio" disabled="disabled"> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>
（発簡済み）
				</label>
				<?php } elseif ($_smarty_tpl->tpl_vars['d']->value['update_flag']==1) {?>
				<label style="color:#aaa;">
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio" disabled="disabled"> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>
（手動編集更新済み）
				</label>
				<?php } else { ?>
				<label>
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['duty_year_month']==$_smarty_tpl->tpl_vars['d']->value->de_year_month) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
				<?php }?>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">消防兼務開始日</label>
		<div class="col-xs-9 w-300">
			<div class="radio">
			<?php echo smarty_function_assign_config(array('var'=>"duty_fire_options",'config'=>"duty_fire_dates"),$_smarty_tpl);?>

			<?php echo smarty_function_html_radios(array('name'=>"duty_fire_date",'options'=>$_smarty_tpl->tpl_vars['duty_fire_options']->value,'selected'=>$_POST['duty_fire_date']),$_smarty_tpl);?>

			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_fire_date']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_fire_date']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group">
		<label class="col-xs-3 w-140 control-label">チーム</label>
		<div class="col-xs-9 w-300">
			<div class="radio">
			<?php echo smarty_function_assign_config(array('var'=>"team_id_options",'config'=>"duty_team_ids"),$_smarty_tpl);?>

			<?php echo smarty_function_html_radios(array('name'=>"duty_team_id",'options'=>$_smarty_tpl->tpl_vars['team_id_options']->value,'selected'=>$_POST['duty_team_id']),$_smarty_tpl);?>

			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_team_id']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_team_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-9">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">初期化された日程表がありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

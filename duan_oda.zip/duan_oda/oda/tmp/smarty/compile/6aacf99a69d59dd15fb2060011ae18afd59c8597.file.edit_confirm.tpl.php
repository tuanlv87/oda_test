<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:36:22
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Holiday\edit_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2375758a27b36a221d3-66814153%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6aacf99a69d59dd15fb2060011ae18afd59c8597' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Holiday\\edit_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2375758a27b36a221d3-66814153',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'duty_assignment' => 0,
    'values' => 0,
    'originals' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_58a27b36ad9382_95917917',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a27b36ad9382_95917917')) {function content_58a27b36ad9382_95917917($_smarty_tpl) {?><?php if (!is_callable('smarty_function_duty_assignment_days')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.duty_assignment_days.php';
?><form class="form-horizontal" method="POST">
	<div class="notice-message">
		<p class="bg-warning">この内容で登録する場合は「登録」ボタンを押してください。</p>
	</div>

	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>

	<div class="form-calendar">
	<?php echo smarty_function_duty_assignment_days(array('duty_assignment'=>$_smarty_tpl->tpl_vars['duty_assignment']->value,'values'=>$_smarty_tpl->tpl_vars['values']->value,'originals'=>$_smarty_tpl->tpl_vars['originals']->value,'mode'=>"view"),$_smarty_tpl);?>

	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("view_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'originals'=>$_smarty_tpl->tpl_vars['originals']->value), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/holiday/edit_save",'form_id'=>"saveForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/holiday/edit",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.save-btn').click(function(){
	$('#saveForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>
<?php }} ?>

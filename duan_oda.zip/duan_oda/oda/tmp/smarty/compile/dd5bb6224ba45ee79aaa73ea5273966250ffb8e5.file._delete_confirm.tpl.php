<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:48
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_delete_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:196305743dcc293a4e4-21647890%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd5bb6224ba45ee79aaa73ea5273966250ffb8e5' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_delete_confirm.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '196305743dcc293a4e4-21647890',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5743dcc2977570_34290661',
  'variables' => 
  array (
    'ret' => 0,
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5743dcc2977570_34290661')) {function content_5743dcc2977570_34290661($_smarty_tpl) {?>	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-danger save-btn">削除</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("view_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'deleteMode'=>true), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-danger save-btn">削除</button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-03-17 10:27:40
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\edit_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1495756ea080c6f6180-61468025%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9c034f248748a7ab27586befe6a6c36587afa01a' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\edit_save.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1495756ea080c6f6180-61468025',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56ea080c7702a8_32842355',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ea080c7702a8_32842355')) {function content_56ea080c7702a8_32842355($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit_save.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('back_to_action'=>"/users/edit",'offset_num'=>3), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:28
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21276565725e5ad3132-58793793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1b3e3b4dc7dbb5d580c8bf0c9a3baa3573bdce8e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_add.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21276565725e5ad3132-58793793',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e5ad3132_99177108',
  'variables' => 
  array (
    'values' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e5ad3132_99177108')) {function content_565725e5ad3132_99177108($_smarty_tpl) {?>	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">登録</button>
			<a href="form" class="btn btn-default">戻る</a>
		</div>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("form_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'editMode'=>false), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="submit" class="btn btn-primary">登録</button>
			<a href="form" class="btn btn-default">戻る</a>
		</div>
	</div>
<?php }} ?>

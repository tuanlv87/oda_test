<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 19:02:17
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\delete.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13264574426a9b5f9f1-43426779%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6efb419dbf670f133578164a939d00ee0e15f3d4' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\delete.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13264574426a9b5f9f1-43426779',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'current_year_month' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_574426a9b9ca80_55861300',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574426a9b9ca80_55861300')) {function content_574426a9b9ca80_55861300($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><?php if ($_smarty_tpl->tpl_vars['current_year_month']->value!='') {?>
<p><?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['current_year_month']->value), ENT_QUOTES, 'UTF-8');?>
の月次タスクマスターを削除します。</p>
<?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('key'=>"tm_id",'text_id'=>"月次タスクID"), 0);?>

<?php } else { ?>
	<p class="text-danger">年月指定を実行してください。</p>
<?php }?>
<?php }} ?>

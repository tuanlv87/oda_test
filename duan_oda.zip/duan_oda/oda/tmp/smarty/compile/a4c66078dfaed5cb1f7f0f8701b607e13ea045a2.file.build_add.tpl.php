<?php /* Smarty version Smarty-3.1.21, created on 2016-05-25 07:57:39
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1668456a9bf3ad59f86-86689417%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a4c66078dfaed5cb1f7f0f8701b607e13ea045a2' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_add.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1668456a9bf3ad59f86-86689417',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56a9bf3ae11130_28530385',
  'variables' => 
  array (
    'duty_env_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56a9bf3ae11130_28530385')) {function content_56a9bf3ae11130_28530385($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="build_add_confirm">
<?php if ($_smarty_tpl->tpl_vars['duty_env_list']->value) {?>
	<p>作成（月次タスク追加）する以下の項目を入力してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">年月</label>
		<div class="col-xs-9 w-300">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['duty_env_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="duty_year_month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value->de_year_month, ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['duty_year_month']==$_smarty_tpl->tpl_vars['d']->value->de_year_month) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value->de_year_month), ENT_QUOTES, 'UTF-8');?>

				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['duty_year_month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['duty_year_month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-9">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">作成された日程表がありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

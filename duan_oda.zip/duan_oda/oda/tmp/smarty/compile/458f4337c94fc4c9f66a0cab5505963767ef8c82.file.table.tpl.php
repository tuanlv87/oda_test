<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:31:21
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2805856614962b96964-21774016%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '458f4337c94fc4c9f66a0cab5505963767ef8c82' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\table.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2805856614962b96964-21774016',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56614962c8aba0_97561363',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56614962c8aba0_97561363')) {function content_56614962c8aba0_97561363($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"p_id",'pagination'=>true,'edit_url'=>"/personnels/edit/?ret=/personnels/table.page:".((string)$_GET['page'])."&p_id=%s",'delete_url'=>"/personnels/delete_confirm?ret=/personnels/table.page:".((string)$_GET['page'])."&p_id=%s"), 0);?>

<?php }} ?>

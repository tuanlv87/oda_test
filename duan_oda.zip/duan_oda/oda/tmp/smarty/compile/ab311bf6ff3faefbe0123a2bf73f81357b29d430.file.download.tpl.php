<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 18:38:53
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\WatchFires\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:39495744212d438915-15860001%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ab311bf6ff3faefbe0123a2bf73f81357b29d430' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\WatchFires\\download.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '39495744212d438915-15860001',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5744212d4759a8_78595371',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5744212d4759a8_78595371')) {function content_5744212d4759a8_78595371($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="download">
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-04-04 16:05:00
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyPublish\form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:88465702121c5868d5-56185705%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'db7862e00593d76e685f08b5dd5bb451d67bf13c' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyPublish\\form.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '88465702121c5868d5-56185705',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5702121c63da88_58435580',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5702121c63da88_58435580')) {function content_5702121c63da88_58435580($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="form_save">
	<input name="year_month" value="<?php echo htmlspecialchars($_REQUEST['year_month'], ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<p>発簡日を入力してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-3 w-140 control-label">年月</label>
		<div class="col-xs-9 w-300">
			<?php echo htmlspecialchars(smarty_modifier_year_month($_REQUEST['year_month']), ENT_QUOTES, 'UTF-8');?>

		</div>
	</div>
	<div class="form-group">
		<label class="col-xs-3 w-140 control-label">発簡日</label>
		<div class="col-xs-9 w-140">
			<div class="input-group">
				<input class="form-control" name="year" value="<?php echo htmlspecialchars($_REQUEST['year'], ENT_QUOTES, 'UTF-8');?>
" maxlength="4" type="text">
				<div class="input-group-addon">年</div>
			</div>
		</div>
		<div class="col-xs-9 w-100" style="padding-left:0;">
			<div class="input-group">
				<input class="form-control" name="month" value="<?php echo htmlspecialchars($_REQUEST['month'], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
				<div class="input-group-addon">月</div>
			</div>
		</div>
		<div class="col-xs-9 w-100" style="padding-left:0;">
			<div class="input-group">
				<input class="form-control" name="day" value="<?php echo htmlspecialchars($_REQUEST['day'], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
				<div class="input-group-addon">日</div>
			</div>
		</div>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year']||$_smarty_tpl->tpl_vars['errors']->value['month']||$_smarty_tpl->tpl_vars['errors']->value['day']) {?>
	<div class="form-group">
		<label class="col-xs-3 w-140 control-label"></label>
		<div class="col-xs-9">
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['day']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
		</div>
	</div>
<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-9">
			<button type="submit" class="btn btn-primary">登録</button>
		</div>
	</div>
</form>
<?php }} ?>

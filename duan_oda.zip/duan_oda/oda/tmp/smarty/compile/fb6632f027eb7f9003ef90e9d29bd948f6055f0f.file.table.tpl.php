<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:01
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:153985666961c786450-76871099%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb6632f027eb7f9003ef90e9d29bd948f6055f0f' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\table.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '153985666961c786450-76871099',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5666961c800578_57383038',
  'variables' => 
  array (
    'userInfo' => 0,
    'delete_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5666961c800578_57383038')) {function content_5666961c800578_57383038($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['userInfo']->value['auth_type']==1) {?>
	<?php $_smarty_tpl->tpl_vars["delete_url"] = new Smarty_variable("/users/delete_confirm?ret=/users/table.page:".((string)$_GET['page'])."&u_id=%s", null, 0);?>
<?php } else { ?>
	<?php $_smarty_tpl->tpl_vars["delete_url"] = new Smarty_variable('', null, 0);?>
<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"u_id",'pagination'=>true,'edit_url'=>"/users/edit/?ret=/users/table.page:".((string)$_GET['page'])."&u_id=%s",'delete_url'=>$_smarty_tpl->tpl_vars['delete_url']->value), 0);?>

<?php }} ?>

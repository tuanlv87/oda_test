<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:54
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:147145743e92e620d94-05947965%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e4b15d6b35fad87e473bdec1cea146a4fa0adcf3' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\download.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '147145743e92e620d94-05947965',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5743e92e65de24_96875417',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5743e92e65de24_96875417')) {function content_5743e92e65de24_96875417($_smarty_tpl) {?><form method="POST" action="/users/download">
	<div class="form-group">
		<button type="submit" class="btn btn-primary">開始</button>
	</div>
</form>
<?php }} ?>

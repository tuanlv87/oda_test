<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 15:47:43
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4838565f8f4f4e6e28-26623699%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c9c2958dd84941dcf323f6015c40534884bfbe17' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\download.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4838565f8f4f4e6e28-26623699',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565f8f4f523eb5_13348101',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565f8f4f523eb5_13348101')) {function content_565f8f4f523eb5_13348101($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="download">
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
</form><?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-11-28 15:26:37
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\WatchFires\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203956d8b0e95d75c4-44051469%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cb046f569b7d8ad74f00fc748b61d7a0ee79a19e' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\WatchFires\\edit.tpl',
      1 => 1478075604,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203956d8b0e95d75c4-44051469',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d8b0e97bfa41_05745570',
  'variables' => 
  array (
    'ret' => 0,
    'year' => 0,
    'month' => 0,
    'dw_odata' => 0,
    'nw_odata' => 0,
    'fire' => 0,
    'fe_data' => 0,
    'errors' => 0,
    'dw_data' => 0,
    'message' => 0,
    'nw_data' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d8b0e97bfa41_05745570')) {function content_56d8b0e97bfa41_05745570($_smarty_tpl) {?><?php if (!is_callable('smarty_function_watch_fire_days')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.watch_fire_days.php';
if (!is_callable('smarty_function_watch_fire_checkbox')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.watch_fire_checkbox.php';
?><form class="form-horizontal" method="POST" action="/watch_fires/edit_confirm">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="year" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['year']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="month" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['month']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="dw_odata" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['dw_odata']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="nw_odata" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['nw_odata']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	
	<div class="form-group form-action">
		<label class="col-xs-2 form-label2"></label>
		<div class="col-xs-5 form-value2">
			<button type="submit" class="btn btn-primary"><?php if ($_smarty_tpl->tpl_vars['fire']->value) {?>更新<?php } else { ?>登録<?php }?></button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>

	<div class="form-group">
		<label class="col-xs-2 form-label2">年月</label>
		<div class="col-xs-8 form-value2">
			<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['year']->value, ENT_QUOTES, 'UTF-8');?>
年<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['month']->value, ENT_QUOTES, 'UTF-8');?>
月
		</div>
	</div>

	<div class="form-group">
		<label class="col-xs-2 form-label2">消防訓練</label>
	</div>
	<div class="form-calendar watch-fire-calendar">
	<?php echo smarty_function_watch_fire_days(array('year'=>$_smarty_tpl->tpl_vars['year']->value,'month'=>$_smarty_tpl->tpl_vars['month']->value,'fire'=>$_smarty_tpl->tpl_vars['fire']->value,'values'=>$_smarty_tpl->tpl_vars['fe_data']->value,'errors'=>$_smarty_tpl->tpl_vars['errors']->value,'mode'=>"edit"),$_smarty_tpl);?>

	</div>
	
	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['dw_data']) {?> has-error<?php }?>">
		<label class="col-xs-2 form-label2">日直</label>
		<div class="col-xs-8 form-value3">
			<div class="checkbox">
			<?php echo smarty_function_watch_fire_checkbox(array('year'=>$_smarty_tpl->tpl_vars['year']->value,'month'=>$_smarty_tpl->tpl_vars['month']->value,'name'=>"dw_data",'values'=>$_smarty_tpl->tpl_vars['dw_data']->value,'mode'=>"edit"),$_smarty_tpl);?>

			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['dw_data']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['dw_data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>

	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value['nw_data']) {?> has-error<?php }?>">
		<label class="col-xs-2 form-label2">宿直</label>
		<div class="col-xs-8 form-value3">
			<div class="checkbox">
			<?php echo smarty_function_watch_fire_checkbox(array('year'=>$_smarty_tpl->tpl_vars['year']->value,'month'=>$_smarty_tpl->tpl_vars['month']->value,'name'=>"nw_data",'values'=>$_smarty_tpl->tpl_vars['nw_data']->value,'mode'=>"edit"),$_smarty_tpl);?>

			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['nw_data']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['nw_data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>

<?php if ($_smarty_tpl->tpl_vars['fire']->value) {?>
	<div class="form-group" style="margin-top:30px;">
		<label class="col-xs-2 form-label2">登録年月日</label>
		<div class="col-xs-9 form-value2">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['fire']->value['created'], ENT_QUOTES, 'UTF-8');
if ($_smarty_tpl->tpl_vars['fire']->value['created_user']) {?>　<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['fire']->value['created_user'], ENT_QUOTES, 'UTF-8');
}?>
		</div>
	</div>
	<div class="form-group">
		<label class="col-xs-2 form-label2">最終更新年月日</label>
		<div class="col-xs-9 form-value2">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['fire']->value['modified'], ENT_QUOTES, 'UTF-8');
if ($_smarty_tpl->tpl_vars['fire']->value['modified_user']) {?>　<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['fire']->value['modified_user'], ENT_QUOTES, 'UTF-8');
}?>
		</div>
	</div>
<?php }?>

	<div class="form-group form-action">
		<label class="col-xs-2 form-label2"></label>
		<div class="col-xs-5 form-value2">
			<button type="submit" class="btn btn-primary"><?php if ($_smarty_tpl->tpl_vars['fire']->value) {?>更新<?php } else { ?>登録<?php }?></button>
			<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>
<?php }} ?>

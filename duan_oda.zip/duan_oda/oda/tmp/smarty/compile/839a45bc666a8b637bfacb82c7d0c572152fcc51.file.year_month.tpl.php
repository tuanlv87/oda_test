<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:32:42
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\year_month.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32469565a74535475a6-78004805%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '839a45bc666a8b637bfacb82c7d0c572152fcc51' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\year_month.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32469565a74535475a6-78004805',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a745372fa28_76575151',
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a745372fa28_76575151')) {function content_565a745372fa28_76575151($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="year_month_confirm">
	<p>年月を指定してください。</p>
	<div class="form-group">
		<div class="col-xs-3" style="width:150px;">
			<div class="input-group">
				<input class="form-control" id="input-year" name="year" value="<?php echo htmlspecialchars($_REQUEST['year'], ENT_QUOTES, 'UTF-8');?>
" maxlength="4" type="text">
				<div class="input-group-addon">年</div>
			</div>
		</div>
		<div class="col-xs-2" style="width:120px;">
			<div class="input-group">
				<input class="form-control" id="input-month" name="month" value="<?php echo htmlspecialchars($_REQUEST['month'], ENT_QUOTES, 'UTF-8');?>
" maxlength="2" type="text">
				<div class="input-group-addon">月</div>
			</div>
		</div>
	</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
	<div class="form-group">
		<div class="col-xs-12">
<?php if ($_smarty_tpl->tpl_vars['errors']->value['year']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['year']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['month']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['month']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">次へ</button>
		</div>
	</div>
</form>
<?php }} ?>

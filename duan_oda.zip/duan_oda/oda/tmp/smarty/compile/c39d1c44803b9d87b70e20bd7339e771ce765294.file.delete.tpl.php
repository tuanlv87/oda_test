<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:15
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\delete.tpl" */ ?>
<?php /*%%SmartyHeaderCode:102356d8b055745921-04072917%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c39d1c44803b9d87b70e20bd7339e771ce765294' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\delete.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '102356d8b055745921-04072917',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d8b0557829b5_53178556',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d8b0557829b5_53178556')) {function content_56d8b0557829b5_53178556($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Parts/_delete.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('key'=>"u_id",'text_id'=>"利用者ID"), 0);?>

<?php }} ?>

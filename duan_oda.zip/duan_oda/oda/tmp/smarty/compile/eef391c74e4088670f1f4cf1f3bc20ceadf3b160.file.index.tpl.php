<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:28:58
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:172815666961aa9fba5-81092712%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eef391c74e4088670f1f4cf1f3bc20ceadf3b160' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\index.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '172815666961aa9fba5-81092712',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5666961aa9fba9_32997394',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5666961aa9fba9_32997394')) {function content_5666961aa9fba9_32997394($_smarty_tpl) {?><?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-05-13 09:50:10
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Maintenances\restore.tpl" */ ?>
<?php /*%%SmartyHeaderCode:143225657262823dcf4-61691196%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '107e8fa14976606923c0fa9beb9c1c83bd507c3b' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Maintenances\\restore.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '143225657262823dcf4-61691196',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565726282f4ea5_65755159',
  'variables' => 
  array (
    'maintenance_list' => 0,
    'd' => 0,
    'isDisabled' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565726282f4ea5_65755159')) {function content_565726282f4ea5_65755159($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="restore">
<?php if ($_smarty_tpl->tpl_vars['maintenance_list']->value) {?>
	<p>リストアするデータの日付を選択してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-2 w-100 control-label">日付</label>
		<div class="col-xs-10 w-400">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['maintenance_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="mdate" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['id'], ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['mdate']==$_smarty_tpl->tpl_vars['d']->value['id']) {?> checked="checked" <?php }?> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['isDisabled']->value, ENT_QUOTES, 'UTF-8');?>
 /> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['mdate'], ENT_QUOTES, 'UTF-8');?>

					<?php if ($_smarty_tpl->tpl_vars['d']->value['mtype']==@constant('BACKUP_TYPE_POST_INIT')) {?>
						（<?php if ($_smarty_tpl->tpl_vars['d']->value['myear_month']) {
echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value['myear_month']), ENT_QUOTES, 'UTF-8');
}?>日程表初期化後）
					<?php } elseif ($_smarty_tpl->tpl_vars['d']->value['mtype']==@constant('BACKUP_TYPE_PRE_BUILD')) {?>
						（<?php if ($_smarty_tpl->tpl_vars['d']->value['myear_month']) {
echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value['myear_month']), ENT_QUOTES, 'UTF-8');
}?>日程表作成前）
					<?php } elseif ($_smarty_tpl->tpl_vars['d']->value['mtype']==@constant('BACKUP_TYPE_PUBLISH')) {?>
						（<?php if ($_smarty_tpl->tpl_vars['d']->value['myear_month']) {
echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value['myear_month']), ENT_QUOTES, 'UTF-8');
}?>日程表発簡）
						<?php $_smarty_tpl->tpl_vars["isDisabled"] = new Smarty_variable("disabled", null, 0);?>
					<?php }?>
				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['mdate']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['mdate']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">バックアップがありません。</p>
	</div>
<?php }?>
</form>

<?php echo '<script'; ?>
>
$('form').submit(function(){
	showMask();
});
<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"現在、リストアしています。"), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:40:14
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Duty\table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:79625657261cc04404-70933331%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a67b4be5025261bde120721a01114384982b831' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Duty\\table.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '79625657261cc04404-70933331',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657261ccbb5b9_55373214',
  'variables' => 
  array (
    'all_work_hours_avg' => 0,
    'all_work_hours_max' => 0,
    'all_work_hours_min' => 0,
    'all_work_hours_stddev' => 0,
    'debug_list' => 0,
    'team_id' => 0,
    'd' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657261ccbb5b9_55373214')) {function content_5657261ccbb5b9_55373214($_smarty_tpl) {?><div style="margin-bottom:20px;">
（デバッグ）
<table class="table table-bordered" style="width:auto;">
	<thead>
		<tr>
			<th>チーム</th>
			<th>合計勤務時間</th>
			<th>平均勤務時間</th>
			<th>最大勤務時間</th>
			<th>最小勤務時間</th>
			<th>標準偏差</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>全体</td>
			<td></td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['all_work_hours_avg']->value, ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['all_work_hours_max']->value, ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['all_work_hours_min']->value, ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['all_work_hours_stddev']->value, ENT_QUOTES, 'UTF-8');?>
</td>
		</tr>
<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_smarty_tpl->tpl_vars['team_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['debug_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
 $_smarty_tpl->tpl_vars['team_id']->value = $_smarty_tpl->tpl_vars['d']->key;
?>
	<?php if ($_smarty_tpl->tpl_vars['team_id']->value!='X') {?>
		<tr>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['team_id']->value, ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['work_hours_sum'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['work_hours_avg'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['work_hours_max'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['work_hours_min'], ENT_QUOTES, 'UTF-8');?>
</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['work_hours_stddev'], ENT_QUOTES, 'UTF-8');?>
</td>
		</tr>
	<?php }?>
<?php } ?>
	</tbody>
</table>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"p_id",'pagination'=>true,'select_year_month'=>true,'edit_url'=>"/duty_update/edit/?ret=/duty/table.page:".((string)$_GET['page']).";year:".((string)$_GET['year']).";month:".((string)$_GET['month'])."&year=".((string)$_GET['year'])."&month=".((string)$_GET['month'])."&p_id=%s"), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-01-28 16:19:16
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_add_comp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1040256a9c0f41ab3f7-94816124%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2d592c72da6716cf0f09c89c9110a7ed2c658702' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_add_comp.tpl',
      1 => 1453955858,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1040256a9c0f41ab3f7-94816124',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56a9c0f4225511_37410921',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56a9c0f4225511_37410921')) {function content_56a9c0f4225511_37410921($_smarty_tpl) {?><form class="form-horizontal" method="POST">
<?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
	<div class="notice-message">
		<div class="bg-danger text-success">日程表を更新できません。
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
		<div class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</div>
	<?php } ?>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-success text-success">日程表が更新されました。</p>
	</div>
<?php }?>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<a href="build_add" class="btn btn-default back-btn">戻る</a>
		</div>
	</div>
</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:29:26
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_batch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2314566f936eddc576-09432225%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a8a77deb23967397fa99ef8d2c3d86a5c568ad91' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_batch.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2314566f936eddc576-09432225',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_566f936ee19607_82686274',
  'variables' => 
  array (
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_566f936ee19607_82686274')) {function content_566f936ee19607_82686274($_smarty_tpl) {?><form method="POST" action="batch_confirm" enctype="multipart/form-data">
	<input name="MAX_FILE_SIZE" value="<?php echo htmlspecialchars(@constant('MAX_UPLOAD_FILESIZE'), ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<div class="form-group">
		<label class="control-label">登録ファイル</label>
		<div>
			<input name="file" placeholder="" type="file" style="margin-top:7px;">
		</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['file']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['file']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
		<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary">チェック</button>
	</div>
</form>
<?php }} ?>

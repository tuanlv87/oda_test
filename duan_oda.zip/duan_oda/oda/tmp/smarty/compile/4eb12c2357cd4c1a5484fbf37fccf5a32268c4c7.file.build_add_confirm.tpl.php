<?php /* Smarty version Smarty-3.1.21, created on 2016-05-25 07:58:23
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\DutyBuild\build_add_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2163656a9c0e644aa22-63131987%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4eb12c2357cd4c1a5484fbf37fccf5a32268c4c7' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\DutyBuild\\build_add_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2163656a9c0e644aa22-63131987',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56a9c0e64c4b47_49439179',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56a9c0e64c4b47_49439179')) {function content_56a9c0e64c4b47_49439179($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST">
	<div class="notice-message">
		<p class="bg-warning">作成済の<?php echo htmlspecialchars(smarty_modifier_year_month($_POST['duty_year_month']), ENT_QUOTES, 'UTF-8');?>
の日程表に月次タスクの名前指定を追加します。よろしければ「更新」ボタンを押してください。</p>
	</div>
	<div class="form-group form-action">
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary send-btn">更新</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"/duty_build/build_add_comp",'form_id'=>"sendForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_POST,'action'=>"/duty_build/build_add",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.send-btn').click(function(){
	showMask();
	$('#sendForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/mask.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('mask_message'=>"現在、日程表を作成（月次タスク追加）しています。"), 0);?>
<?php }} ?>

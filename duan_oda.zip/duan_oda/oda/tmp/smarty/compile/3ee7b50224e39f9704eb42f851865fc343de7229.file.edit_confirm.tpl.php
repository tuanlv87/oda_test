<?php /* Smarty version Smarty-3.1.21, created on 2016-03-17 10:26:49
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\edit_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:109056ea07d9de01d4-14057785%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ee7b50224e39f9704eb42f851865fc343de7229' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\edit_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '109056ea07d9de01d4-14057785',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'values' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56ea07d9e5a2f0_01586775',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56ea07d9e5a2f0_01586775')) {function content_56ea07d9e5a2f0_01586775($_smarty_tpl) {?><form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-warning">この内容で更新する場合は「更新」ボタンを押してください。</p>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/users/edit_save",'form_id'=>"saveForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"/users/edit",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.save-btn').click(function(){
	$('#saveForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>
<?php }} ?>

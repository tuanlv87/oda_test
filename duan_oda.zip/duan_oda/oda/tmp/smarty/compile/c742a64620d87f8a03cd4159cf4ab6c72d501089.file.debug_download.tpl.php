<?php /* Smarty version Smarty-3.1.21, created on 2016-06-09 15:58:59
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Maintenances\debug_download.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1820575913b3a83684-95396690%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c742a64620d87f8a03cd4159cf4ab6c72d501089' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Maintenances\\debug_download.tpl',
      1 => 1465284828,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1820575913b3a83684-95396690',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'maintenance_list' => 0,
    'd' => 0,
    'errors' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_575913b3b778c7_10387321',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575913b3b778c7_10387321')) {function content_575913b3b778c7_10387321($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><form class="form-horizontal" method="POST" action="debug_download">
<p style="color:#f00;">ここではバックアップデータから警備員名をチームID＋10000-社員番号、利用者氏名を利用者IDに置き換えたデータをダウンロードします。</p>
<?php if ($_smarty_tpl->tpl_vars['maintenance_list']->value) {?>
	<p>ダウンロードするデータの日付を選択してください。</p>
	<div class="form-group">
		<label for="" class="col-xs-2 w-100 control-label">日付</label>
		<div class="col-xs-10 w-400">
	<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['maintenance_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
?>
			<div class="radio">
				<label>
					<input name="mdate" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['id'], ENT_QUOTES, 'UTF-8');?>
" type="radio"<?php if ($_POST['mdate']==$_smarty_tpl->tpl_vars['d']->value['id']) {?> checked="checked"<?php }?> /> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['d']->value['mdate'], ENT_QUOTES, 'UTF-8');?>

					<?php if ($_smarty_tpl->tpl_vars['d']->value['mtype']==@constant('BACKUP_TYPE_POST_INIT')) {?>
						（<?php if ($_smarty_tpl->tpl_vars['d']->value['myear_month']) {
echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value['myear_month']), ENT_QUOTES, 'UTF-8');
}?>日程表初期化後）
					<?php } elseif ($_smarty_tpl->tpl_vars['d']->value['mtype']==@constant('BACKUP_TYPE_PRE_BUILD')) {?>
						（<?php if ($_smarty_tpl->tpl_vars['d']->value['myear_month']) {
echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['d']->value['myear_month']), ENT_QUOTES, 'UTF-8');
}?>日程表作成前）
					<?php }?>
				</label>
			</div>
	<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['mdate']) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value['mdate']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<div class="form-group">
		<div class="col-xs-3">
			<button type="submit" class="btn btn-primary">開始</button>
		</div>
	</div>
<?php } else { ?>
	<div class="notice-message">
		<p class="bg-danger">バックアップがありません。</p>
	</div>
<?php }?>
</form>
<?php }} ?>

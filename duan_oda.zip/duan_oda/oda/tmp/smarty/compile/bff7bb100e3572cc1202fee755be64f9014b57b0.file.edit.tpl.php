<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 18:46:56
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15938566e4bdf39c517-68178525%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bff7bb100e3572cc1202fee755be64f9014b57b0' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\edit.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15938566e4bdf39c517-68178525',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_566e4bdf416636_94017738',
  'variables' => 
  array (
    '_tm_id' => 0,
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_566e4bdf416636_94017738')) {function content_566e4bdf416636_94017738($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="edit_confirm">
	<input name="_tm_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['_tm_id']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>

<?php echo $_smarty_tpl->getSubTemplate ("color_picker.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:37:46
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9359565725e5a59012-81267640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c61c0e7b3aa7e27032ba345a8d8c4931917cfb65' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\add.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9359565725e5a59012-81267640',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565725e5ad3132_75204958',
  'variables' => 
  array (
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565725e5ad3132_75204958')) {function content_565725e5ad3132_75204958($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/task_months/add_confirm">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>

<?php echo $_smarty_tpl->getSubTemplate ("color_picker.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>

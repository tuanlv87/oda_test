<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:37:38
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\TaskMonths\table_list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13909565a7401bb74d4-30956832%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '77e3aa4a7ec9ea564a7a6962111c5b7ef777a351' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\TaskMonths\\table_list.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13909565a7401bb74d4-30956832',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565a7401c315f7_18300611',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565a7401c315f7_18300611')) {function content_565a7401c315f7_18300611($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("list_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('idname'=>"tm_id",'pagination'=>true,'edit_url'=>"/task_months/edit?ret=/task_months/table_list.page:".((string)$_GET['page'])."&tm_id=%s",'delete_url'=>"/task_months/delete_confirm?ret=/task_months/table_list.page:".((string)$_GET['page'])."&tm_id=%s"), 0);?>

<?php }} ?>

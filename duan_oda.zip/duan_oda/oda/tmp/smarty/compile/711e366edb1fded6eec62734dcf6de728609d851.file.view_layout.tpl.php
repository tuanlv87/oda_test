<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:30:48
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\view_layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:341256614af95a0ac3-49204878%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '711e366edb1fded6eec62734dcf6de728609d851' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\view_layout.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '341256614af95a0ac3-49204878',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56614af974beb9_94708634',
  'variables' => 
  array (
    'form_settings' => 0,
    'col' => 0,
    'f' => 0,
    'originals' => 0,
    'values' => 0,
    'deleteMode' => 0,
    'errors' => 0,
    'modify_class' => 0,
    'display_none' => 0,
    'header_class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56614af974beb9_94708634')) {function content_56614af974beb9_94708634($_smarty_tpl) {?><?php if (!is_callable('smarty_function_assign_compare_date')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\function.assign_compare_date.php';
if (!is_callable('smarty_modifier_config')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.config.php';
if (!is_callable('smarty_modifier_date_f')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.date_f.php';
if (!is_callable('smarty_modifier_year_month')) include 'C:\\oda\\Apache24\\htdocs\\oda\\plugins\\smarty\\modifier.year_month.php';
?><?php  $_smarty_tpl->tpl_vars['f'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['f']->_loop = false;
 $_smarty_tpl->tpl_vars['col'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['form_settings']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['f']->key => $_smarty_tpl->tpl_vars['f']->value) {
$_smarty_tpl->tpl_vars['f']->_loop = true;
 $_smarty_tpl->tpl_vars['col']->value = $_smarty_tpl->tpl_vars['f']->key;
?>
	<?php if ($_smarty_tpl->tpl_vars['col']->value=="_init") {?>
		<?php $_smarty_tpl->tpl_vars["header_class"] = new Smarty_variable($_smarty_tpl->tpl_vars['f']->value['header']['class'], null, 0);?>
	<?php } else { ?>

		<?php $_smarty_tpl->tpl_vars["modify_class"] = new Smarty_variable('', null, 0);?>
		<?php if ($_smarty_tpl->tpl_vars['originals']->value&&$_smarty_tpl->tpl_vars['col']->value!="password_confirm") {?>
			<?php if ($_smarty_tpl->tpl_vars['f']->value['type']=="date") {?>
				<?php echo smarty_function_assign_compare_date(array('date1'=>$_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],'date2'=>$_smarty_tpl->tpl_vars['originals']->value[$_smarty_tpl->tpl_vars['col']->value],'var'=>"modify_class",'class_name'=>"view-modify"),$_smarty_tpl);?>

			<?php } elseif ($_smarty_tpl->tpl_vars['originals']->value[$_smarty_tpl->tpl_vars['col']->value]!=$_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]) {?>
				<?php $_smarty_tpl->tpl_vars["modify_class"] = new Smarty_variable(" view-modify", null, 0);?>
			<?php }?>
		<?php }?>

		<?php $_smarty_tpl->tpl_vars["display_none"] = new Smarty_variable('', null, 0);?>
		<?php if ($_smarty_tpl->tpl_vars['deleteMode']->value&&$_smarty_tpl->tpl_vars['col']->value=="password_confirm") {?>
			<?php $_smarty_tpl->tpl_vars["display_none"] = new Smarty_variable(" display-none", null, 0);?>
		<?php }?>

	<div class="form-group<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]) {?> has-error<?php }?> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');
echo htmlspecialchars($_smarty_tpl->tpl_vars['modify_class']->value, ENT_QUOTES, 'UTF-8');
echo htmlspecialchars($_smarty_tpl->tpl_vars['display_none']->value, ENT_QUOTES, 'UTF-8');?>
 view-row">
		<label for="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['text'], ENT_QUOTES, 'UTF-8');?>
</label>
		<div class="col-xs-9 form-value">
			<div class="view-value">
<?php if ($_smarty_tpl->tpl_vars['f']->value['type']=="radios") {?>
	<?php if ($_smarty_tpl->tpl_vars['col']->value=="auth_type"&&$_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]=="1") {?>
				admin
	<?php } else { ?>
		<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
				<?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],$_smarty_tpl->tpl_vars['f']->value['config']), ENT_QUOTES, 'UTF-8');?>

		<?php } else { ?>
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

		<?php }?>
	<?php }?>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="select") {?>
	<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
			<?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],$_smarty_tpl->tpl_vars['f']->value['config']), ENT_QUOTES, 'UTF-8');?>

	<?php } else { ?>
			<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

	<?php }?>
<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="password") {?>
			<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['type']=="date") {?>
			<?php echo htmlspecialchars(smarty_modifier_date_f($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]), ENT_QUOTES, 'UTF-8');?>

<?php } else { ?>
	<?php if ($_smarty_tpl->tpl_vars['f']->value['config']) {?>
			<?php echo htmlspecialchars(smarty_modifier_config($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value],$_smarty_tpl->tpl_vars['f']->value['config']), ENT_QUOTES, 'UTF-8');?>

	<?php } elseif ($_smarty_tpl->tpl_vars['f']->value['filter']=="year_month") {?>
			<?php echo htmlspecialchars(smarty_modifier_year_month($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value]), ENT_QUOTES, 'UTF-8');?>

	<?php } else { ?>
			<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value[$_smarty_tpl->tpl_vars['col']->value], ENT_QUOTES, 'UTF-8');?>

	<?php }?>
<?php }?>
			</div>
<?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]) {?>
	<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['col']->value]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
			<p class="text-danger"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8');?>
</p>
	<?php } ?>
<?php }?>
		</div>
	</div>
	<?php }?>
<?php } ?>
<?php if ($_smarty_tpl->tpl_vars['deleteMode']->value) {?>
	<div class="form-group <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');?>
">
		<label for="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
">登録年月日</label>
		<div class="col-xs-9 form-value">
			<div class="view-value">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['created'], ENT_QUOTES, 'UTF-8');?>

			</div>
		</div>
	</div>
	<div class="form-group <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['rowclass'], ENT_QUOTES, 'UTF-8');?>
">
		<label for="input-<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['col']->value, ENT_QUOTES, 'UTF-8');?>
" class="form-label <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['header_class']->value, ENT_QUOTES, 'UTF-8');?>
">最終更新年月日</label>
		<div class="col-xs-9 form-value">
			<div class="view-value">
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['values']->value['modified'], ENT_QUOTES, 'UTF-8');?>

			</div>
		</div>
	</div>
<?php }?>
<?php }} ?>

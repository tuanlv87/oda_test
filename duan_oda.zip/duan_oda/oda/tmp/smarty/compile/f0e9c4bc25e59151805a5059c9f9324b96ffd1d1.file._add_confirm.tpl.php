<?php /* Smarty version Smarty-3.1.21, created on 2016-04-08 11:07:20
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Parts\_add_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1835557071258a86d30-74623862%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0e9c4bc25e59151805a5059c9f9324b96ffd1d1' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Parts\\_add_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1835557071258a86d30-74623862',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'values' => 0,
    'originals' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_57071258ac3dc7_39020923',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57071258ac3dc7_39020923')) {function content_57071258ac3dc7_39020923($_smarty_tpl) {?>	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>

	<?php echo $_smarty_tpl->getSubTemplate ("view_layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('values'=>$_smarty_tpl->tpl_vars['values']->value,'originals'=>$_smarty_tpl->tpl_vars['originals']->value), 0);?>


	<div class="form-group form-action">
		<label class="form-label"></label>
		<div class="col-xs-5">
			<button type="button" class="btn btn-primary save-btn">登録</button>
			<button type="button" class="btn btn-default back-btn">戻る</button>
		</div>
	</div>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2016-04-08 11:07:20
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Users\add_confirm.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1667457071258a49ca5-56030527%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a53e2c05268c8dc3b88896455318d1026d40441' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Users\\add_confirm.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1667457071258a49ca5-56030527',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'values' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_57071258a86d32_19192278',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57071258a86d32_19192278')) {function content_57071258a86d32_19192278($_smarty_tpl) {?><form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-warning">この内容で登録する場合は「登録」ボタンを押してください。</p>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_add_confirm.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>

<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"add_save",'form_id'=>"saveForm"), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("hidden_form.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('datas'=>$_smarty_tpl->tpl_vars['values']->value,'action'=>"add",'form_id'=>"backForm"), 0);?>


<?php echo '<script'; ?>
>
$('.save-btn').click(function(){
	$('#saveForm').submit();
});
$('.back-btn').click(function(){
	$('#backForm').submit();
});
<?php echo '</script'; ?>
>
<?php }} ?>

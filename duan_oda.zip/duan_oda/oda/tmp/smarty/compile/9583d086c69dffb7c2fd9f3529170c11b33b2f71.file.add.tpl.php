<?php /* Smarty version Smarty-3.1.21, created on 2016-05-24 15:44:38
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Personnels\add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1308656d4c3574f27a6-44319961%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9583d086c69dffb7c2fd9f3529170c11b33b2f71' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Personnels\\add.tpl',
      1 => 1457693950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1308656d4c3574f27a6-44319961',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_56d4c35752f831_24263701',
  'variables' => 
  array (
    'ret' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56d4c35752f831_24263701')) {function content_56d4c35752f831_24263701($_smarty_tpl) {?><form class="form-horizontal" method="POST" action="/personnels/add_confirm">
	<input name="ret" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ret']->value, ENT_QUOTES, 'UTF-8');?>
" type="hidden">

<?php echo $_smarty_tpl->getSubTemplate ("Parts/_add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

</form>
<?php }} ?>

<?php /* Smarty version Smarty-3.1.21, created on 2017-02-14 12:45:30
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Element\documentation_link.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13795657282d75e0e9-25691715%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b106e71fc1c5d6613751028d6611088bc36c925' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Element\\documentation_link.tpl',
      1 => 1480324338,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13795657282d75e0e9-25691715',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5657282d75e0e0_18190426',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5657282d75e0e0_18190426')) {function content_5657282d75e0e0_18190426($_smarty_tpl) {?><div sytle="height:30px;">&nbsp;</div>
<div>
    <ul>
        <li><a href="/documentation">資料作成トップメニューに戻る</a></li>
        <li><a href="/">トップメニューに戻る</a></li>
    </ul>
</div>
<?php }} ?>

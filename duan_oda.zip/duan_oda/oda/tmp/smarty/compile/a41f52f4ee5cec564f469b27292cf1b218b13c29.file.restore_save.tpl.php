<?php /* Smarty version Smarty-3.1.21, created on 2016-01-08 14:03:22
         compiled from "C:\oda\Apache24\htdocs\oda\src\Template\Maintenances\restore_save.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18717565727c7481a25-99680126%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a41f52f4ee5cec564f469b27292cf1b218b13c29' => 
    array (
      0 => 'C:\\oda\\Apache24\\htdocs\\oda\\src\\Template\\Maintenances\\restore_save.tpl',
      1 => 1452229036,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18717565727c7481a25-99680126',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_565727c74fbb44_39176544',
  'variables' => 
  array (
    'errors' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_565727c74fbb44_39176544')) {function content_565727c74fbb44_39176544($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-danger text-danger">エラーが発生しました。リストアできません。<br><br>
			<?php echo htmlspecialchars(var_dump($_smarty_tpl->tpl_vars['errors']->value), ENT_QUOTES, 'UTF-8');?>

		</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-0 col-xs-5">
			<a href="restore" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>
<?php } else { ?>
<form class="form-horizontal">
	<div class="notice-message">
		<p class="bg-success text-success">正常にリストアされました。</p>
	</div>

	<div class="form-group form-action">
		<div class="col-xs-offset-0 col-xs-5">
			<a href="restore" class="btn btn-default">戻る</a>
		</div>
	</div>
</form>
<?php }?>
<?php }} ?>
